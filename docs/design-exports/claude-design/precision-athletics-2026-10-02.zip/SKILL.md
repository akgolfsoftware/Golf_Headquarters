---
name: ak-golf-design
description: Use this skill to generate well-branded interfaces and assets for AK Golf (Precision Athletics — PlayerHQ and AgencyOS), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the readme.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Quick rules: IBM Plex Sans for words, IBM Plex Mono (tabular-nums) for every number. Graphite #141413 primary buttons, rust #9B2415 only for important action signals. 8px radius on cards/buttons/inputs, 12px on modals, 999px on badges/status. Five training axes (FYS green · TEK ochre · SLAG blue · SPILL plum · TURN red) as 12% tinted badges. Light theme by default; `data-theme="night"` for Live-økt and slagregistrering. Norwegian UI copy, no emoji. Vocabulary, statuses, AK-formelen and the forbidden-word list live in guidelines/treningsplanlegging-master.md (the only authority; guidelines/ordmaster.md and assets/ak-vocabulary.js are derived) — follow it literally: øvelse not drill, registrere not logge, brutto score always, coach not trener, Caddie is the AI assistant.

## Runde 37 — hvor ting ligger
Aktivt: PlayerHQ og AgencyOS-skjermer i ui_kits/*/screens, plan-komponenter i components/plan (ikke ds-plan.jsx), teknisk plan i ui_kits/_shared/tp-*.jsx, Workbench i WB3*.jsx. Historikk: arkiv/2026-09-30/. Kildemateriale fra Training Motor: _kilde/. Skjermpakke og reiser: overlevering/skjermpakke-anders-2026-09-30.md. Skill mellom simulert prototype, kildelest kode og ekte appkontroll; ingenting er godkjent av Anders uten hans vurdering.
