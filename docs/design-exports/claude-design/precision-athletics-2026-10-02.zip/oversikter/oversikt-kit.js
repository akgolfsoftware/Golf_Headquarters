/* Oversikter · små adaptere til designsystemets komponenter. Leser navnerommet ved rendring, så lasterekkefølgen spiller ingen rolle. */
(() => {
  const ns = () => window.AKGolfPrecisionAthletics_7d7c29 || {};
  const h = (...a) => window.React.createElement(...a);
  const BtnPrimary = (p) => h(ns().Button, { variant: "primary", fullWidth: p.fullWidth, size: p.size === "sm" ? "sm" : "md", onClick: p.onClick, disabled: p.disabled, icon: p.icon }, p.children);
  const BtnGhost = (p) => h(ns().Button, { variant: "secondary", size: p.size === "sm" ? "sm" : "md", onClick: p.onClick, disabled: p.disabled, icon: p.icon }, p.children);
  const ValgPiller = ({ label, valg = [], verdi, onChange, mono }) => h("div", { role: "group", "aria-label": label, style: { display: "flex", flexDirection: "column", gap: 6, minWidth: 0 } },
    label && h("span", { className: "kicker" }, label),
    h("div", { style: { display: "flex", flexWrap: "wrap", gap: 6 } }, valg.map((o) => { const id = o.id ?? o, on = id === verdi, off = o.av || o.disabled;
      return h(ns().ChoicePill, { key: id, selected: on, "aria-pressed": on, mono, disabled: off, onClick: () => !off && onChange && onChange(id) }, o.label ?? o); })));
  window.AKOversikt = { BtnPrimary, BtnGhost, ValgPiller };
})();
