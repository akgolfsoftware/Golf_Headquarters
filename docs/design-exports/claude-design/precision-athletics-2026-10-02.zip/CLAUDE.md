# Prosjektregler (AK Golf Precision Athletics)

## Språk — master
- `guidelines/treningsplanlegging-master.md` (kopi av repoets `docs/treningsplanlegging.md`) er fasit for alt synlig språk: ordvalg, staving, menynavn, statuser, meldinger, tall/enheter og treningsbegreper.
- Gjelder alle eksisterende og nye skjermer, tilstander, komponenteksempler og overleveringer, også pågående IUP, Workbench, DataGolf og testbatteri.
- `guidelines/ordmaster.md`, `assets/ak-vocabulary.js`, eldre designfiler og eksempler er avledet. Ved avvik vinner treningsplanlegging-master.md.
- Les relevant kapittel før tekst skrives eller rettes. Uavklart begrep: registrer spørsmålet i `status.md` under «Språkspørsmål», ikke finn på ny fasit.
- Språkregelen endrer ikke produkt- eller testfasit eller visuell retning.

## Øvrig
- Codex (ikke Grok) koder appen. Bare PH-01 er visuelt godkjent. Workbench-kombinasjonen A–D er valgt retning; visuell appgodkjenning gjenstår.
- Kun syntetiske data. Primærhandling grafitt #141413, rust #9B2415 bare som signal.
- 8-ball: nedre intervallgrenser (0≤rest<0,1 m → 4; <1 → 3; <2 → 2; <3 → 1; ≥3 → 0). 24 × 1 m = 48 av 96. Hele poeng.
