# Delkvittering · lagring, publisering og egen versjon (syntetisk prototype, ingen app/DB)

Status: pågående jobb. Dette er ikke visuell godkjenning og ikke ferdig leveranse.

## Faktiske kontroller (avgrensede UI-reiser, egne namespace per kjøring)
| Fil | Kontroller | Feil |
|---|---|---|
| ui_kits/wb-lagring-repro.html | 79 | 0 |
| ui_kits/wb-pub-live-repro.html | 14 | 0 |
| ui_kits/wb-pub-repro.html | 17 | 0 |
| ui_kits/wb-tpn-repro.html | 70 | 0 |
| ui_kits/wb-funn-repro.html | 24 | 0 |
| ui_kits/wb-tek-repro.html | 48 | 0 |

Siste kjøring av pub/tpn/funn/tek er før de siste modellendringene (egen versjon, recovery); bare `wb-lagring-repro` og `wb-pub-repro` er kjørt etter dem. Lang `wb1-reise` er ikke kjørt etter disse endringene.

## Dekket
- Delt TaskEditor (TPN + AG-TP-01): miljø uten mål=null, mål 0=0, fokus null (ikke «—»), avbryt under lagring kansellerer, vakt (Bli/Forkast/Lagre og fortsett) også ved nivå/eier/plan og global app-nav (AG).
- Transaksjonell lokal lagring (`?lagre=1`): feil før/etter første lagring rulles tilbake, retry gir én endring; «Nullstill valgt plan» rører bare valgt plan, WB_SEL bevares ved feil.
- Delt TP-/antallpublisering (`WB.techPlans/techPlan` rolleavgrenset, `WB.tekKilder` for spiller): korrupt/ikke-skrivbart lager avvises uten overskriving; recovery etter feilet rollback → reload → «IKKE DELT» → retry reparerer uten ny revisjon → PH leser.
- Øktpublisering (`WB.publishSessions(planId, sids, reqId, expect)`, `publishedForPlayer`, `publishedSession`): immutable snapshot, frosset utvalg, requestId-kontrakt, tilbaketrekking uten stille eldre-rev-fallback, «Publiser rev N på nytt» som egen handling.
- Egen versjon (gruppe): «Lag egen versjon» med valgt målplan, full kopi (nye sessionId/drill-id, samme kilde-rev), åpne/retur, ny gruppepub utelater bare denne økta.

## Ugjort / delvis
- Plan/I dag→PH03→Live→PH07 fra publisert økt (påbegynt i neste jobb).
- TEK-konflikt («Behold mitt» → ny import), måneds-/periode-Hent i to-verts reise.
- reisetest-tp er ikke modernisert og er fortsatt rød i sin gamle form.
- Lag egen versjon har ingen redigering av gruppeøkt-innhold utover åpning i vanlig økteditor.

## Publisert økt → PH (ny, wb-pub-live-repro: 14/0)
- AG publiserer golf + FYS (ekte UI) → separat PH-vert: kort i faktisk PH-10 (Plan) og PH-01 (I dag) via `WB3_PUB.Kort` (rendrer ingenting uten publiserte økter, så PH-01-originalen er uendret), PH-03 via `WB3_PUB.Ark` (bare når PHQ_SEL.pub+view03; ellers vanlig demo-PH-03), PH-04/05/07 (golf) og PH-06 (FYS) via adapter til LIVE_DATA under nøkkel pub:<publicationId>:<sessionId>.
- PHQ_SEL.pub / PHQ_SESSION.pub / PHQ_SAVED.pub bærer publicationId, publishedRev, sourceOwner, planId, sessionId, drillInstanceIds. Lagring uten vurdering: null skårer; savefail/retry gir én lagring. Tilbaketrukket: ærlig tilstand i panel, PH-10-kort og PH-03.
- Retur: Live «Lukk» går til PHQ_SEL.returnTo (PH-10/PH-01/Workbench), ellers PH-01.

## Fortsatt ugjort
- Kvalitet/RPE/Fokus-vurdering er kjørt bare som «lagre uten vurdering»; vurdert lagring er ikke testet på publisert økt.
- Golf-Live har ikke manuell øvelses-tid/min fra kilden (min=0 når usatt), og FYS bruker ikke fysisk programsnapshot (kun øvelsesinstanser).
- reisetest-tp, TEK-konflikt, måneds-/periode-Hent i to-verts reise.
- Lang wb1-reise er ikke kjørt etter de siste endringene.

## Status etter siste runde (publisert økt → Live, ufullstendig)
Prøve: ui_kits/wb-pub-live2-repro.html (native AG-knapper: bank, FYS-program, publiser; PH reload; I dag-dato-valg; PH-03; Live). Siste kjøring: 12 kontroller, 11 OK, avbrutt av 1 feil.

Gjort og prøvd (OK i siste kjøring): golføkt fra ØVELSESBANK-knapper; FYS-økt fra fysisk programknapp + bankøvelser; publisering i én publisering; PH-01 viser ikke ubemerket alle økter (dato-valg); PH-03 fra I dag; PH-06 FYS starter uten forhåndsutførte sett/kg og med 0 sek; kvittering bevarer faktiske serier (reps/kg=null/done, drillId, kilde-rev); FYS lagre uten vurdering med savefail/retry (én lagring, null skårer, resultat-ID).

Rettet i kode (ikke alle dekket av grønn prøve): usatt golf-tid vises «—»; tom publisert økt: Start sperret i PH-03/PH-04, PH-05/PH-06 tom-guard; sessionId på toppnivå = faktisk økt-ID, cacheKey separat, executionId; LS/LFY gir ærlig tom ved publisert kontekst uten cache (ingen demo-fallback); PH-07 uten kvittering viser ærlig tom; Start revaliderer publikasjonen; video uten kilde gir «Ingen video i kilden».

Åpen feil: golf PH-07 etter «Avslutt og gå til oppsummering» i publisert økt gjør at PH-appen ikke lenger har <main> (sannsynlig render-krasj) → vurdert lagring (Kvalitet/RPE/Fokus) er IKKE bevist. Må diagnostiseres først.

Ikke gjort: tom TURN/SPILL-økt og åpne runde (roundRef/entryRef) mot rundeskjerm; PH-10 beholder demoplan under publiserte kort; tilbaketrekking i annet vindu uten remount er bare kodet (Start revaliderer), ikke kjørt i prøven; teknisk bilde/video fra snapshot bare delvis; hele TEK-konflikt/overstyring-jobben (Behold mitt, atomisk save/reset, vakt i Ovr, grunnlagsvelger ved uke over flere måneder, SessForm-vakt) og avgrenset årsredigering er ikke påbegynt.

## Oppdatering: publisert økt → Live (wb-pub-live2-repro: 16 kontroller, 0 feil)
Årsak til tidligere PH-07-krasj: feilreferanse F(x.min || 0) i FS-useMemo etter global erstatning; rettet til (Fx.min || 0). Parserkontroll (Babel) av PH-live, PH-03, PH-01, PH-10, WB3-pub og WB3-tpn: ok. PH-host bootstrap verifisert før prøven; dobbel videobranch i PH-live fjernet.

Nå bevist med native knapper: golf med vurdering (Kvalitet 3/RPE 8/Fokus 7) med savefail→retry; FYS uten vurdering med savefail→retry; to økter har separate resultater med egne resultat-ID/executionId; sessionId på toppnivå = faktisk økt-ID, cacheKey separat; PHQ_RESULTS lagrer full gjennomføring (execution med serier/drillId/kilde-rev); pin av rev 1 mens rev 2 finnes; tilbaketrekking mellom PH-03 og Start avvises; retur til Plan.
Kodet men ikke egen prøve: video åpnes bare når spillbar URL finnes (ellers deaktivert i publisert kontekst); før/etter-bilde fra snapshot; TURN/SPILL «Åpne runde» (PHQ_RUND → PH-RD-01, RD-skjermene leser ikke konteksten ennå); Start fra åpent WB-publiseringspanel revaliderer.
Ugjort: PH-10 demoplan under publiserte kort; TEK-konflikt/overstyring-vakt, grunnlagsvelger, SessForm-vakt og avgrenset årsredigering (ikke påbegynt).

## Oppdatering 2: publisert økt → Live/resultat/runde
| Fil | Kontroller | Feil |
|---|---|---|
| ui_kits/wb-pub-live2-repro.html | 18 | 0 |
| ui_kits/wb-pub-live3-repro.html | 5 | 0 |

live2 (native AG-bank/FYS-program/publiser → PH): + «Lagrede resultater» i PH-10/PH-01 med eget resultat-ID/executionId; åpne lagret golf-resultat viser lagret variant (Kvalitet 3/RPE 8/Fokus 7) uten ny lagring, også etter tilbaketrekking. Tidsprøve for FYS-start er robust (00:00–00:03). Renderfeil ved åpnet lagret resultat (objekt som React-barn) rettet: PH-07 bruker nå SV (lagret kopi) for saved/RPE/Kvalitet/Fokus.
live3: SPILL-økt = planlagt runde (PH-03 «Åpne runde», ingen Start) → PH-RD-01-banner med publicationId/rev/sessionId/plan/eier, bane/hull usatt, brutto → retur til Plan; SLAG-økt med entryRef forblir treningsøkt (Start); Live bevarer før OG etter-medie (type, dato, filstatus) og video-URL.

Fortsatt ugjort: åpne lagret FYS-resultat er ikke native-prøvd; RD02/RD03 bruker fortsatt RD_DATA-demo for bane/hull (bare banner kobler valgt publisert runde); tilbaketrekking i åpent WB-publiseringspanel før FYS-start er kodet (revalidering) men ikke kjørt; PHQ_RESULTS ligger bare i PH-sidens minne; PH-10 demoplan under publiserte kort; hele TEK-konflikt/overstyring/SessForm-vakt/grunnlagsvelger/årsredigering-jobben er ikke påbegynt.

## Oppdatering 3
wb-pub-live3-repro: 7 kontroller, 0 feil. Nytt: PH-05 viser FØR og ETTER som egne knapper (type, dato, kilde-rev); Før uten URL er deaktivert («ingen fil»), Etter åpner nøyaktig kildens URL ved klikk (window.open stubbet og kontrollert). Banneret i PH-RD-01 påstår ikke lenger «ingen demo»: det sier at RD02/RD-Live fortsatt bruker eksempelbaner.

Fortsatt ugjort (ikke påbegynt i denne runden): faktisk datakobling RD01→RD02→RD-Live til valgt publisert runde (bane/hull/slag usatt → manuelt oppsett uten demohull), WB-panelets start går fortsatt fys/golf; åpne lagret FYS-resultat (native); tilbaketrekking i åpent WB-publiseringspanel før FYS-start (kjørt prøve); to avlesninger av FYS-tid; hele TEK-konflikt/overstyring/SessForm-vakt/grunnlagsvelger/årsredigering.

## Oppdatering 4: TEK-overstyring/konflikt (kun delvis)
Prøver: ui_kits/wb-konflikt-repro.html 10 kontroller / 0 feil (native klikk: manuell 2→8 uten ny import = ingen konflikt; ny import 3 → konflikt; Behold mitt skjuler kun denne importen; import 4 → NY konflikt; Lagre avvist med «Uløst konflikt»; Bruk hentet → importert TEK 4 med ref bevart; nivåbytte med ulagret overstyring går gjennom vakten Bli her / Lagre og fortsett). ui_kits/wb-tek-repro.html: 48/0 (gamle prøver 11/12 består med ny import-bundet konflikt).
Rettet i WB3-lokal Ovr: konflikt bundet til konkret import (WB.impCount økes per Hent), Behold mitt per import, uløst konflikt sperrer Lagre, Tilbakestill tømmer felt først etter at onReset ikke avviser, Ovr registrerer __wbSaveHandler og nav.setDirty.
Ugjort: parent-save/reset (saveDiff/resetOverride) returnerer fortsatt ikke feil til Ovr og er ikke atomisk (blankTEK/SKEY-feil, delvis akse/minutt-skriving); uke/måned-navigasjon (nav-knappene) bypasser fortsatt G; SessForm-vakt; månedsgrunnlagsvelger (openWeekFor auto-velger fortsatt); AG→PH antall-import til periode/måned med reload; gruppe-/to-plan-kilde; årsredigering; RD-dataleser-reise.

## Oppdatering 5: atomisk Lagre/Tilbakestill (Ovr) og import-bundet konflikt
Prøver: wb-atomisk-repro 11/0, wb-konflikt-repro 10/0, wb-tek-repro 48/0 (lagre=1, nytt testområde per kjøring).
API (wb-model.js): WB.saveOverrides(planId, niv, key, { budsjett:{akse: tall|null|undefined}, minutter:{...} }) → {ok:true}|{ok:false,error} (alle skrivinger eller ingen; null = fjern, blank TEK fjerner også kilde-ref; undefined = urørt); WB.clearOverrides(planId, niv, key) → atomisk reset av budsjett+minutter. Begge går gjennom transaksjonen (lokal lagring må lykkes, ellers rulles S/valg tilbake). Parent (WB3-lokal saveDiff/onReset, uke og måned) returnerer {ok,error} til Ovr; Ovr rydder felt/dirty/kf bare etter ok.
Importmarkør: box.tekImportSeq (per eier/plan/scope/key, i S, rulles tilbake sammen med feilet Hent); global WB.impCount er fjernet. Behold mitt/baseline bindes til markøren.
Prøvd native: blankTEK + lagringsfeil; to akser + minutter + simulert feil i senere write (ingenting delvis); reset + lagringsfeil; retry (én endring); reload (samme plan-ID, TEK 4 med samme ref, SLAG likt, ingen økter); konflikt import2→3→4 + uløst Lagre avvist; feilet Hent → markør/TEK/ref uendret, ingen ny konflikt, retry én import.
Ugjort: periodeoverstyring (PerForm) er ikke atomisk-prøvd; måned bruker samme API men har ingen egen prøve; import i annen eier/plan/scope er løst strukturelt (markør per box) men ikke prøvd; uke-/månedsnav/SessForm/grunnlagsvakt og grunnlagsvelger; AG→PH antall-import til periode/måned med reload; gruppe-/to-plan-kilde; årsredigering; RD-dataleser-reise.

## Oppdatering 6 (vakt, grunnlag, API-grenser) – ufullstendig
Prøver (lagre=1, nytt testområde): wb-atomisk-repro 12/0 (inkl. «samlet commit = én skriving» og TEK-ref sammenlignet mot lagret før-ref + disk); wb-grenser-repro 8/0 (AG+PH: WB.editPeriod(planId, periodId, patch) i samlet transaksjon: gyldig edit = én skriving, feil = minne+disk uendret, retry = én commit; WB.saveOverrides/clearOverrides avviser fremmed eier før mutasjon/persist – modell-API-prøve, ikke UI); wb-vakt-repro 24 kontroller / 2 FEIL.
Kode: vakt rundt uke/måned forrige/neste, sidebar-faner og Side-knapper, SessForm (Avbryt/dirty-handler); transaksjonsfilter inkluderer edit*; persist dedupliseres (ingen ekstra skriving etter commit); saveOverrides/clearOverrides begrenset til valgt eier (WB3_CTX) og for spiller egen eier (TP2.scope); månedsliste-reset bruker clearOverrides; openWeekFor skriver ikke lenger månedsgrunnlag automatisk.
FEIL i wb-vakt-repro (AG og PH): «Lagre og fortsett» etter lagringsfeil → retry lagrer SLAG 6 (minne+disk=6, én gang) men navigerer ikke til U51 (uka forblir U50). Forkast, Bli her, lagringsfeil-blir-i-editor og SessForm-grenene (Bli/Forkast/feil/retry uten dobbelt økt) passerer. Årsak ikke funnet.
Ugjort: ekte valg av månedsgrunnlag (UI) for uke over månedsskifte (bare «ingen stille skriving» er kontrollert); native periode-UI (PerForm) bruker ikke prøvd; månedsliste-Tilbakestill uten egen prøve; import i annen eier/plan prøvd bare strukturelt; AG→PH antall-import; årsredigering; RD-dataleser-reise.

## Oppdatering 7: vakt-årsak, editPeriod null, listereset
- wb-vakt-repro: 24 kontroller / 0 feil (AG+PH). Årsak til U50→U51-feilen: transaksjonens rollback (restore) erstattet window.WB_SEL-eierobjektene med kopier; den ventende navigasjonen og nav/goWeek lukket over det frakoblede st-objektet og muterte det. Rettet ved at rollback gjenoppretter WB_SEL på plass (samme objektidentitet).
- wb-grenser-repro: 12 / 0 (nytt: editPeriod {budsjett:null, minutter:null} + lagringsfeil → alt uendret inkl. tekKilde; retry → budsjett, minutter, tekKilde og manuell-flagg ryddet atomisk i én skriving; andre perioder urørt). model: tekManuell settes bare når TEK får tallverdi; null/undefined skilles fra 0.
- Månedslistens «Tilbakestill til arvet» (tilbakestill-uke-<uke>) bruker nå clearOverrides med feilvarsel (toast, ingenting endret). IKKE prøvd native (ingen egen prøve ennå); wb-atomisk-repro (12) / wb-konflikt-repro (10) / wb-tek-repro (48) er ikke kjørt etter denne runden.
Ugjort: native prøve av listereset (kvotefeil/retry/reload), månedsgrunnlagsvelger, AG→PH antall-import, årsredigering, RD-dataleser-reise. Vakt/månedsgrunnlag/Workbench er ikke ferdig.

## Oppdatering 8: vakt på siste utganger + månedslistens Tilbakestill (wb-vakt2-repro: 22 kontroller / 0 feil, AG+PH, lagre=1)
Vakt (WB_GUARD) lagt på: mnd-velger, rediger-uke-*, uke-velger, Opprett årsplan, grunn-*/grunn-eget og maaned-*/maaned-eget, innsetting-plan/uke/okt + ytre innsetting-avbryt, turn-okt-*/turn-apne-*.
Native prøvd (AG og PH): uke-velger med dirty Ovr → vakt (uke uendret), Bli her (felt beholdt), grunnlagsbytte grunn-eget med dirty → vakt, Forkast (ulagret borte, ingen hengende vakt), Opprett årsplan med dirty → vakt, Lagre og fortsett med kvotefeil (blir i uka, utkast 6/40 beholdt, ingenting skrevet), retry (lagret + navigert til U51), månedsliste tilbakestill-uke-2026-U50 med kvotefeil (uendret minne+disk), retry (én skriving, nullstilt, U51 urørt), reload (samme plan, nullstilt, ingen økter). Fixture (merket): to perioder så grunnlagsvalg finnes.
Ikke prøvd native: mnd-velger, rediger-uke-*, maaned-*-bytte, turn-okt/turn-apne (måned→turnering), innsetting-velgere/ytre avbryt med nested SessForm (kode lagt, ingen test); Forkast/Bli for SessForm-grener er dekket i wb-vakt-repro (24/0).
Ugjort: velger for månedsgrunnlag (egen jobb), AG→PH antall-import, årsredigering, RD-dataleser-reise. Ikke hele Workbench ferdig.

## Oppdatering 9: eksplisitt månedsgrunnlag (wb-grunnlag-repro: 22 kontroller / 0 feil, AG+PH, lagre=1)
Bygget (WB3-lokal): uke over månedsskifte uten valgt grunnlag viser «Velg måned eller Eget» med begge måneder (navn, datoer, budsjett per akse med — = ukjent og 0 = kjent 0, minutter), Ovr-editoren er skjult til valg er gjort; openWeekFor overstyrer ikke lenger et eksisterende valg med fra-måned-klikk (skriver bare når ingenting er valgt); maaned-*/maaned-eget gir feilvarsel ved lagringsfeil (rulles tilbake) og går gjennom vakten.
Native prøvd (uke 2026-U53, 28.12–03.01): valgvisning uten skriving; desember/januar/Eget registrerer nøyaktig valget (uker[U53].maaned) med riktig kilde (SLAG 7 fra januar, SLAG 4/SPILL kjent 0 fra desember, Eget → null); kvotefeil ved valg rulles tilbake (disk uendret), retry lagrer; dirty + månedsvalg → vakt (valget står); måned→uke fra DESEMBER overstyrer ikke eksisterende januar-valg; U53→U52→U53 bevarer valg; reload gjenoppretter valg, SLAG 7 og desember-/januar-budsjett. Desember/januar-budsjett satt via merket fixture (setOverride).
Skrive-trace: wb-vakt2-repro/wb-grunnlag-repro asserter IKKE «én fysisk skriving» for save+navigasjon; bare månedsliste-reset og editorens samlede commit er målt (wr-delta=1). Nav-valg av uke persisteres separat via bump.
Ugjort: ref-null/feilbevar for importert TEK i månedslisten (kommende antall-reise), gruppe→egenversjon→andre årsplan→tilbake med valgt grunnlag, planbytte-bevaring av grunnlag, nested innsetting/turnering, AG→PH antall, årsredigering, RD.

## Oppdatering 10: AG→PH antall til MÅNED (wb-antall-repro: siste kjøring 13 kontroller, 2 feil)
Gjort: delt lager registrerer nå teknisk plan (publisert metadata) når antall publiseres, slik at PH kan velge coachens plan som kilde uten publiserte oppgaver; tekSel/taskSel (kildevalg) ligger i S og persisteres/rulles tilbake sammen med planen (reload mister ikke valgt kilde).
Prøvd native (AG+PH-verter, nytt testområde, lagre=1): AG opprett teknisk plan → antall 2 for 2026-12-01–2027-01-31 som utkast → PH reload ser ingen coachutkast → AG «Publiser antall» (rev 1, delt) → PH opprett plan, måned 2026-12, kildevelger uten forvalg → Hent → Bekreft: måned TEK=2 med kilderef (planningCountId, rev 1, eier, technicalPlanId), andre akser urørt, ingen økter → AG rev 2 (antall 3) publisert → PH reload: importsnapshot står (TEK 2, rev 1), «Nyere antall · sammenlign» → Sammenlign → Behold uendret → Oppdater med kvotefeil (uendret) → retry (TEK 3, ref rev 2).
Åpne avvik i siste kjøring: (1) prøvens kandidattekst-regex for «MAANED 2026-12» var feil (innholdet i panelet er riktig: antall 2, gyldighet, revisjon 1, publisert) – ikke rekjørt; (2) PERIODE: periodevisningen har INGEN «Hent planlagt antall» i Workbench (TEK-panel finnes bare på uke og måned) – periodeimport er ikke støttet i brukerflaten ennå.
Ugjort (nye + gamle): periodeimport i UI; førstegangs fra-måned → uke uten r.ok/varsel/retry (openWeekFor kaller setManedGrunnlag uten å sjekke resultat); månedskandidatene viser bare månedens egne overstyringer (ikke arvet periodekjede/kilde); TEK-panel/Hent kan skrive ukebudsjett før månedsvalg er gjort; gruppe-TP-kilde og to årsplaner samme spiller; planA→planB→planA og gruppe→egenversjon-grunnlag; månedslistens tilbakestill-uke med importert TEK-ref; årsredigering; RD-dataleser-reise. Workbench er ikke ferdig.

## Oppdatering 11: antall til PERIODE (wb-antall-repro: 15 kontroller / 0 feil; rå historikk: forrige kjøring 13/2)
Korrigering: periodevisningen HAR TEK-panelet (scope=periode, key=periode-ID) når en periode er valgt; forrige prøve valgte aldri perioden (ingen per-<id>-klikk). Prøven klikker nå per-<periodeId> og bruker panelets Velg kilde / Hent / kandidat / Bekreft. Regex for MAANED rettet.
Prøvd native: PH valgt PERIODE (Grunnperiode 2026-12-01–31): tek-rad data-scope=periode med periodId i returnContext; Hent → kandidat (samme planningCountId) → Bekreft: periode TEK=3 (publisert rev 2) med kilderef (planningCountId, rev 2, eier, technicalPlanId), SLAG uendret, ingen økter/oppgaver; delt lager har bare plan-metadata (tom oppgaveliste) for counts-only plan. Måneds-flyten (rev 1 → rev 2 snapshot/Sammenlign/Behold/Oppdater med kvotefeil/retry) står som i forrige oppdatering.
Ikke prøvd for PERIODE: Sammenlign/Oppdater/Behold/feil/retry (panelet er felles, men ingen egen prøve); periodeskjema-redigering av annen akse mot TEK-ref; PH-gammelt snapshot for periode etter rev 3. Perioden ble opprettet via merket fixture (addPeriod). Ugjort fra delta35: førstegangs fra-måned→uke uten r.ok-sjekk; arvet budsjettkjede i månedskandidater; TEK-panel kan skrive ukebudsjett før månedsvalg; gruppe-TP-kilde/to årsplaner; planA→B→A-grunnlag; tilbakestill-uke med ref; årsredigering; RD.

## Oppdatering 12: periodedelen (wb-antall-repro: 22 kontroller / 0 feil)
Nytt native (PH-vert, per-<periodeId> faktisk valgt): AG rev 3 (antall 4) publisert → PH reload: periodens importsnapshot står (TEK 3, ref rev 2), «Nyere antall · sammenlign» (antall 4, revisjon 3 mot TEK 3) → Behold: uendret → Oppdater med kvotefeil: uendret → retry: TEK 4, ref rev 3 (bare TEK endret, SLAG usatt, ingen økter). Periodeskjema (knapp «Rediger periode»): SLAG 5 og 40 min med lagringsfeil → avvist, periode uendret (TEK 4, ref rev 3), felt beholdt → retry: SLAG 5, 40 min lagret, TEK 4 med samme kilderef (planningCountId, rev 3) og tekManuell=false bevart i minne og på disk. Ingen kodefeil avdekket i denne grenen.
Ikke prøvd: gjenåpning/reload etter periodeskjema-lagring (disk er kontrollert, ikke ny host); andre perioder urørt er ikke eksplisitt assertet; perioden ble opprettet via merket fixture.
Ugjort (egne jobber): fra-måned→uke uten r.ok, arvet budsjettkjede i månedskandidater, TEK-panel før månedsvalg, gruppe-TP/to årsplaner, planA→B→A-grunnlag, tilbakestill-uke med ref, årsredigering, RD.

## Oppdatering 13: kildevalg per plan (kun kodeendring, ingen native prøve ennå)
Årsak: radioene i kildevelgerne (TEK i WB3-tek, oppgavekilde i WB3-okt TpPick) skrev S.tekSel/S.taskSel direkte uten persist/feilhåndtering. Nå: WB.selectTekSrc(planId, key) og WB.selectTaskSrc(planId, key) (transaksjon: lagring må lykkes, ellers rulles valget tilbake; feil vises i kildevelgeren / TpPick), og radioene kaller dem + store.bump. Parser og AG-oppstart ok. Ikke kjørt: reload-prøve av valg per plan, to planer A→B→A med import, tilbakestill-uke etter TEK-import med kvotefeil/retry. Gruppe og årsredigering er egne jobber.
