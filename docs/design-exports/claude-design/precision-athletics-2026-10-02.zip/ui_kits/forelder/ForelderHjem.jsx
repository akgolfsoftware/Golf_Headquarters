(() => {
const { Button, Icon, StatusPill, Avatar, AxisBadge, ChoicePill, Segmented, InlineAlert, Input } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, Grid, Mono, useW } = window.KIT;
const WEEK = [
  { d: "Man", dt: "21.09", items: [{ t: "16:30–18:00", n: "Teknisk · Innspill P3", ax: "tek" }] },
  { d: "Tir", dt: "22.09", items: [{ t: "07:15–08:15", n: "Styrke · Morgentrening", ax: "fys" }] },
  { d: "Ons", dt: "23.09", rest: true },
  { d: "Tor", dt: "24.09", items: [{ t: "16:30–18:30", n: "Fellestrening · Nærspill", ax: "slag" }] },
  { d: "Fre", dt: "25.09", today: true, items: [{ t: "16:30–17:30", n: "Teknisk · Bredde i P3", ax: "tek" }] },
  { d: "Lør", dt: "26.09", tour: "Klubbmesterskap GFGK", items: [{ t: "08:40", n: "Start hull 1 · 18 hull", ax: "turn" }] },
  { d: "Søn", dt: "27.09", rest: true },
];
const ACWR = [["35", 1.58], ["36", 0.94], ["37", 1.05], ["38", 1.21], ["39", 1.12]];

function Day({ day, row }) {
  return (
    <div style={{ background: day.rest ? "var(--surface-sunken)" : "var(--surface-card)", border: "1px solid " + (day.today ? "var(--border-ink)" : "var(--border-hairline)"), borderRadius: 8, padding: 12, display: "flex", flexDirection: row ? "row" : "column", gap: row ? 16 : 12, minWidth: 0 }}>
      <div style={{ display: "flex", flexDirection: row ? "column" : "row", alignItems: row ? "flex-start" : "baseline", gap: row ? 4 : 8, width: row ? 56 : "auto", flexShrink: 0 }}>
        <span style={{ font: "600 14px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{day.d}</span>
        <Mono s={{ color: "var(--text-muted)", fontSize: 11 }}>{day.dt}</Mono>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0, flex: 1 }}>
        {day.today && <div><StatusPill tone="solid">I dag</StatusPill></div>}
        {day.rest && <span style={{ font: "var(--type-body-s)", color: "var(--text-muted)" }}>Hviledag</span>}
        {day.tour && <div style={{ display: "flex", flexDirection: "column", gap: 4 }}><span className="kicker">Turnering</span><span style={{ font: "600 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{day.tour}</span></div>}
        {(day.items || []).map((it, i) => (
          <div key={i} style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}>
            <Mono s={{ color: "var(--text-primary)" }}>{it.t}</Mono>
            <span style={{ font: "400 13px/1.35 var(--font-sans)", color: "var(--text-body)", overflowWrap: "anywhere" }}>{it.n}</span>
            <div><AxisBadge axis={it.ax} dot /></div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AcwrScale({ v }) {
  const lo = 0.5, hi = 2.0, p = (x) => ((Math.min(hi, Math.max(lo, x)) - lo) / (hi - lo)) * 100;
  const seg = [[lo, 0.8, "var(--sand-400)"], [0.8, 1.3, "var(--ok)"], [1.3, 1.5, "var(--warn)"], [1.5, hi, "var(--signal)"]];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, paddingTop: 20 }}>
      <div style={{ position: "relative", height: 10 }}>
        {seg.map(([a, b, c]) => <div key={a} style={{ position: "absolute", top: 0, bottom: 0, left: p(a) + "%", width: p(b) - p(a) + "%", background: c, opacity: c === "var(--sand-400)" ? 1 : 0.85 }}></div>)}
        <div style={{ position: "absolute", top: -8, bottom: -8, left: `calc(${p(v)}% - 1px)`, width: 3, background: "var(--text-primary)", transition: "left 400ms cubic-bezier(.2,.8,.2,1)" }}></div>
        <Mono s={{ position: "absolute", top: -26, left: `clamp(0px, calc(${p(v)}% - 18px), calc(100% - 36px))`, color: "var(--text-primary)", fontWeight: 600, transition: "left 400ms cubic-bezier(.2,.8,.2,1)" }}>{v.toFixed(2).replace(".", ",")}</Mono>
      </div>
      <div style={{ position: "relative", height: 14 }}>
        {[0.8, 1.3, 1.5].map((x) => <Mono key={x} s={{ position: "absolute", left: `calc(${p(x)}% - 12px)`, fontSize: 11, color: "var(--text-muted)" }}>{x.toFixed(1).replace(".", ",")}</Mono>)}
      </div>
    </div>
  );
}

function ForelderHjem({ go }) {
  const w = useW();
  const [wk, setWk] = React.useState("39");
  const [mode, setMode] = React.useState(null);
  const [sess, setSess] = React.useState("fre");
  const [why, setWhy] = React.useState("Sykdom");
  const [sent, setSent] = React.useState(false);
  const v = ACWR.find((a) => a[0] === wk)[1];
  const cols = w > 1100 ? 7 : w >= 600 ? 2 : 1;
  const zone = v > 1.5 ? ["signal", "Over sikker sone"] : v > 1.3 ? ["warn", "Øvre grense"] : v >= 0.8 ? ["ok", "Innenfor sikker sone"] : ["info", "Lav belastning"];
  return (
    <div style={pageWrap}>
      <PageHead kicker="Foreldreportal · Emma Solberg · Uke 39" title="Emmas uke" sub="Planlagte økter, hviledager og turneringer. Endringer fra coach vises her samme dag."
        actions={<><Button variant="secondary" icon="message-square" onClick={() => go("dialog")}>Send melding</Button><Button icon="calendar-x" onClick={() => { setMode(mode === "fravar" ? null : "fravar"); setSent(false); }}>Meld fravær</Button></>} />
      {mode === "fravar" && (
        <Panel kicker="Fravær" title="Meld fravær for Emma" action={<Button variant="ghost" size="sm" icon="x" onClick={() => setMode(null)}>Lukk</Button>}>
          {sent ? <InlineAlert tone="ok" title="Fravær registrert">{(sess === "fre" ? "Fredag 25.09 · 16:30" : "Lørdag 26.09 · Klubbmesterskap") + ". Coach Anders er varslet."}</InlineAlert> : <>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><span style={{ font: "var(--type-label)", color: "var(--text-secondary)" }}>Hvilken økt</span>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <ChoicePill selected={sess === "fre"} onClick={() => setSess("fre")}>Fre 25.09 · 16:30 Teknisk</ChoicePill>
                <ChoicePill selected={sess === "lor"} onClick={() => setSess("lor")}>Lør 26.09 · Klubbmesterskap</ChoicePill>
              </div></div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><span style={{ font: "var(--type-label)", color: "var(--text-secondary)" }}>Årsak</span>
              <Segmented options={["Sykdom", "Skade", "Skole", "Annet"]} value={why} onChange={setWhy} size="lg" fullWidth={w < 600} /></div>
            <Input label="Kommentar til coach (valgfritt)" placeholder="For eksempel: feber siden i går" />
            <div><Button icon="send" onClick={() => setSent(true)}>Send fraværsmelding</Button></div>
          </>}
        </Panel>
      )}
      <Panel kicker="Ukeoversikt" title="21.09–27.09" action={<div style={{ display: "flex", gap: 16, flexWrap: "wrap", font: "var(--type-meta)", color: "var(--text-muted)" }}><span>4 ØKTER</span><span>2 HVILEDAGER</span><span>1 TURNERING</span></div>}>
        <div style={{ display: "grid", gridTemplateColumns: `repeat(${cols},minmax(0,1fr))`, gap: 8 }}>{WEEK.map((d) => <Day key={d.d} day={d} row={cols < 7} />)}</div>
      </Panel>
      <Grid min={340}>
        <Panel kicker="Belastning · ACWR" title="Forhold mellom akutt og kronisk belastning" action={<StatusPill tone={zone[0]} dot>{zone[1]}</StatusPill>}>
          <AcwrScale v={v} />
          <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Sikker sone er 0,8–1,3. Over 1,5 øker skaderisikoen, og coach justerer planen.</p>
          {v > 1.5 && <InlineAlert tone="signal" title={"Uke " + wk + ": belastningen steg raskt"}>Coach Anders reduserte volumet uken etter. Følg med på søvn og ømhet i skuldre og rygg.</InlineAlert>}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(5,minmax(0,1fr))", gap: 8 }}>
            {ACWR.map(([n, x]) => { const on = n === wk; return (
              <button key={n} type="button" aria-pressed={on} onClick={() => setWk(n)} style={{ minHeight: 52, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--surface-sunken)" : "var(--surface-card)", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, padding: 4 }}>
                <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>UKE {n}</span>
                <Mono s={{ color: x > 1.5 ? "var(--signal-ink)" : "var(--text-primary)", fontWeight: 600 }}>{x.toFixed(2).replace(".", ",")}</Mono>
              </button>); })}
          </div>
        </Panel>
        <Panel kicker="Siste fra coach Anders" title="Fellestrening torsdag 24.09">
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}><Avatar name="Anders Kristiansen" size={40} /><div style={{ display: "flex", flexDirection: "column", gap: 4 }}><span style={{ font: "500 14px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>Anders Kristiansen</span><Mono s={{ fontSize: 11, color: "var(--text-muted)" }}>TOR 24.09 · 18:52</Mono></div></div>
          <p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-body)", textWrap: "pretty" }}>Emma jobbet godt med avstandskontroll fra 30–50 m. 7 av 10 innenfor 3 meter på slutten, mot 4 av 10 forrige uke. Før klubbmesterskapet vil jeg at hun holder fast på én pre-shot-rutine. Hun trenger ikke trene mer før lørdag.</p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><AxisBadge axis="slag" /><AxisBadge axis="spill" /></div>
          <div><Button variant="ghost" iconRight="arrow-right" onClick={() => go("dialog")}>Åpne dialogen</Button></div>
        </Panel>
      </Grid>
    </div>
  );
}
window.ForelderHjem = ForelderHjem;
})();
