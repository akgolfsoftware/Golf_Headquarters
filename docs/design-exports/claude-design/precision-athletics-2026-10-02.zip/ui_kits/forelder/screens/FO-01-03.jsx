(() => {
const kidSel = (kids, id, set) => { const { Segmented } = window.AGQ.ns(); return <div style={{ maxWidth: 420 }}><Segmented options={kids.map((k) => k.name.split(" ")[0])} value={kids.find((k) => k.id === id).name.split(" ")[0]} onChange={(v) => set(kids.find((k) => k.name.startsWith(v)).id)} /></div>; };
const pct = (a) => Math.round(a.done / a.plan * 100);
const h = (v) => v.toFixed(1).replace(".", ",");
function FO01({ state, go }) {
  const { PageHeader, Button, StatusPill, EmptyState, InlineAlert, KeyValue, AxisBadge } = window.AGQ.ns();
  const A = window.AGQ, D = window.FO_DATA, { mob, desk } = A.useW(), empty = state === "tom";
  const [kid, setKid] = React.useState("k1"), k = D.kids.find((x) => x.id === kid);
  const today = <A.Card gap={10}><A.Head k={"I dag · " + k.name.split(" ")[0]} aside="LØRDAG 26.09" />{empty || !k.today ? <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen økt i dag.</p> : <A.EvCard axes={k.today.axis}><span style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span style={{ font: "600 15px/1.3 var(--font-sans)", flex: "1 1 160px" }}>{k.today.title}</span><StatusPill tone="ok">{k.today.st}</StatusPill></span><A.Meta>{k.today.t} · {k.today.where.toUpperCase()}</A.Meta></A.EvCard>}</A.Card>;
  const next = <A.Card gap={10}><A.Head k="Neste booking" />{empty || !k.next ? <><p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen booking.</p><div><Button variant="secondary" icon="calendar-plus" onClick={() => go("FO-03")}>Book time</Button></div></> : <><KeyValue items={[["Hva", k.next.title, { mono: false }], ["Når", k.next.when], ["Hvor", k.next.where, { mono: false }]]} /><div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}><StatusPill tone="info">{k.next.st}</StatusPill><span style={{ flex: 1 }}></span><Button size="sm" variant="ghost" onClick={() => go("FO-03")}>Ny booking</Button></div></>}</A.Card>;
  const week = <A.Card gap={8}><A.Head k="Uka · uke 40" aside={empty ? "—" : k.week.length + " ØKTER"} />{empty ? <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen plan publisert for uke 40.</p> : k.week.map(([d, t, m, ax]) => <div key={d} style={{ display: "grid", gridTemplateColumns: "72px minmax(0,1fr)", gap: 10 }}><span style={{ font: "500 12px/1 var(--font-mono)", color: "var(--text-secondary)", paddingTop: 10 }}>{d.toUpperCase()}</span><A.EvCard axes={ax} dashed={!ax.length}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: ax.length ? "var(--text-primary)" : "var(--text-muted)" }}>{t}</span><A.Meta>{m}</A.Meta></A.EvCard></div>)}</A.Card>;
  const rep = <A.Card gap={10}><A.Head k="Ukerapport · etterlevelse" aside={empty ? "—" : "UKE " + k.adh.weeks + " · " + k.adh.src} />
    <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-metric-l)" }}>{empty ? "—" : pct(k.adh) + " %"}</span><A.Meta>{empty ? "—" : "GJENNOMFØRT " + h(k.adh.done) + " AV " + h(k.adh.plan) + " T PLANLAGT"}</A.Meta></div>
    {!empty && k.adh.byWeek.map(([w, d, p]) => <div key={w} style={{ display: "grid", gridTemplateColumns: "56px minmax(0,1fr) 88px", gap: 10, alignItems: "center", minHeight: 26 }}><span style={{ font: "var(--type-num-s)" }}>{w}</span><span style={{ height: 8, background: "var(--surface-sunken)", position: "relative" }}><span style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: Math.min(100, d / p * 100) + "%", background: "var(--text-primary)" }}></span></span><span style={{ font: "var(--type-num-s)", textAlign: "right" }}>{h(d)} / {h(p)} t</span></div>)}
    <A.Meta>SAMME TALL SOM COACHEN SER · GJENNOMFØRT TID MOT PLANLAGT TID, SISTE FIRE UKER</A.Meta></A.Card>;
  return <A.Page max={1200}>
    <PageHeader kicker="Forelder · Lørdag 26.09" title="I dag" sub="Hei Hanne. Her er dagen og uka for barna dine." />
    <A.Gate state={state} loading="Henter dagen …" error={{ title: "Dagen kunne ikke lastes", text: "Bookinger og planer er lagret. Prøv igjen.", code: "FEIL 503 · FORELDER" }}>
      {kidSel(D.kids, kid, setKid)}
      {!empty && k.acwr > 1.5 && <InlineAlert tone="warn" title="Høy belastning denne uka">{k.name.split(" ")[0]} har trent mer enn planlagt de siste sju dagene (ACWR {String(k.acwr).replace(".", ",")} · BELASTNING · 26.09.2026). Anders har lagt inn hviledag torsdag.</InlineAlert>}
      {empty && <EmptyState icon="calendar-days" title="Ingenting planlagt ennå" text="Når coachen publiserer uka, ser du den her. Du kan booke en time nå." action="Book time" actionIcon="calendar-plus" onAction={() => go("FO-03")} />}
      {desk ? <A.Cols tpl="minmax(0,1fr) minmax(0,1fr)"><A.Stack>{today}{next}{rep}</A.Stack>{week}</A.Cols> : <A.Stack>{today}{next}{week}{rep}</A.Stack>}
    </A.Gate>
  </A.Page>;
}
function FO02({ state, go }) {
  const { PageHeader, Button, EmptyState, KeyValue, Sparkline, Avatar, InlineAlert } = window.AGQ.ns();
  const A = window.AGQ, D = window.FO_DATA, { desk } = A.useW(), empty = state === "tom";
  return <A.Page max={1200}>
    <PageHeader kicker="Forelder · Barn" title="Barn" sub="Barn som er koblet til kontoen din og utviklingsprofilen deres." actions={<Button variant="secondary" icon="user-plus" onClick={() => A.toast("Koble barn", "BARNET ELLER COACHEN SENDER DEG EN KODE")}>Koble barn</Button>} />
    <A.Gate state={state} loading="Henter barna …" error={{ title: "Barna kunne ikke hentes", text: "Ingen koblinger er endret. Prøv igjen.", code: "FEIL 502 · BARN" }}>
      {empty ? <EmptyState icon="users" title="Ingen barn koblet" text="Be coachen eller barnet sende deg en koblingskode." action="Skriv inn kode" actionIcon="key-round" onAction={() => A.toast("Skriv inn kode", "6 TEGN")} /> : <>
        <InlineAlert tone="neutral">Helseopplysninger vises bare for spilleren selv, ikke for forelder.</InlineAlert>
        <div style={{ display: "grid", gridTemplateColumns: desk ? "repeat(2,minmax(0,1fr))" : "minmax(0,1fr)", gap: 16 }}>{D.kids.map((k) => <A.Card key={k.id} gap={12}>
          <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}><Avatar name={k.name} size={48} /><div style={{ flex: "1 1 160px" }}><div style={{ font: "var(--type-title-s)" }}>{k.name}</div><A.Meta>{k.grp.toUpperCase()} · {k.age} ÅR · APP-NIVÅ {k.tier}</A.Meta></div></div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,140px),1fr))", gap: 8 }}>{k.profile.map(([n, v, s]) => <div key={n} style={{ padding: 10, borderRadius: 6, background: "var(--surface-flat)", border: "1px solid var(--border-hairline)", display: "flex", flexDirection: "column", gap: 3 }}><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{n}</span><span style={{ font: "600 18px/1.1 var(--font-mono)" }}>{v}</span><A.Meta s={{ fontSize: 10 }}>{s}</A.Meta></div>)}</div>
          <div><A.Meta>SNITT BRUTTO PER MÅNED · MAR–SEP · LAVERE ER BEDRE</A.Meta><div style={{ marginTop: 6 }}><Sparkline values={k.progress} height={48} label={"Snitt brutto " + k.name} /></div></div>
          <KeyValue items={[["Coaching-pakke", k.pkg, { mono: false, hint: k.pkg ? k.clips.left + " AV " + k.clips.total + " KLIPP IGJEN I SEPTEMBER" : "INGEN PAKKE" }], ["Helse", "Bare synlig for " + k.name.split(" ")[0], { mono: false }]]} />
        </A.Card>)}</div>
      </>}
    </A.Gate>
  </A.Page>;
}
function FO03({ state, go }) {
  const { PageHeader, Button, EmptyState, KeyValue, Segmented, ChoicePill, StatusPill, FormField } = window.AGQ.ns();
  const A = window.AGQ, D = window.FO_DATA, { desk } = A.useW(), empty = state === "tom";
  const [kid, setKid] = React.useState("k1"), [svc, setSvc] = React.useState("pt60"), [day, setDay] = React.useState(1), [slot, setSlot] = React.useState(null), [done, setDone] = React.useState(null), [pay, setPay] = React.useState("Klipp");
  const k = D.kids.find((x) => x.id === kid), s = D.services.find((x) => x.id === svc), price = A.price(s, D.rate);
  const canClip = s.clip && k.pkg && k.clips.left > 0, method = canClip ? pay : "Kort";
  const confirm = () => setDone({ kid: k.name, svc: s.name + " " + s.min + " min", when: D.days[day].join(" ") + " · " + slot, method, price });
  if (done) return <A.Page max={720}><A.Card gap={14}><StatusPill tone="ok">Bekreftet</StatusPill><div style={{ font: "var(--type-title-m)" }}>{done.svc} · {done.kid}</div><KeyValue items={[["Når", done.when], ["Betaling", done.method === "Klipp" ? "1 klipp · " + k.pkg : "Kort · " + A.kr(done.price), { mono: false }], ["Coach", "Anders Kristiansen", { mono: false }]]} /><A.Meta>BEKREFTELSE SENDT PÅ E-POST · GRATIS AVBESTILLING TIL 24 TIMER FØR</A.Meta><div><Button variant="secondary" onClick={() => { setDone(null); setSlot(null); }}>Book en til</Button></div></A.Card></A.Page>;
  return <A.Page max={1100}>
    <PageHeader kicker="Forelder · Booking" title="Book time" sub="Du booker på vegne av barnet. Timen bekreftes med en gang når tiden er ledig og betalt." />
    <A.Gate state={state} loading="Henter ledige tider …" error={{ title: "Ledige tider kunne ikke hentes", text: "Ingen timer er booket. Prøv igjen.", code: "FEIL 502 · KALENDER" }}>
      <A.Cols tpl={desk ? "minmax(0,1.3fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
        <A.Stack>
          <A.Card gap={10}><A.Head k="1 · Barn" /><div style={{ maxWidth: 420 }}><Segmented options={D.kids.map((x) => x.name.split(" ")[0])} value={k.name.split(" ")[0]} onChange={(v) => setKid(D.kids.find((x) => x.name.startsWith(v)).id)} /></div><A.Meta>{k.pkg ? k.pkg.toUpperCase() + " · " + k.clips.left + " AV " + k.clips.total + " KLIPP IGJEN · NYE " + k.clips.resets : "INGEN COACHING-PAKKE · BETALES MED KORT"}</A.Meta></A.Card>
          <A.Card gap={10}><A.Head k="2 · Tjeneste" /><div role="radiogroup" aria-label="Tjeneste" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,200px),1fr))", gap: 8 }}>{D.services.map((x) => { const on = x.id === svc; return <button key={x.id} type="button" role="radio" aria-checked={on} onClick={() => setSvc(x.id)} style={{ textAlign: "left", minHeight: 72, padding: 12, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), boxShadow: on ? "inset 0 0 0 1px var(--border-ink)" : "none", background: "var(--surface-card)", color: "var(--text-primary)", cursor: "pointer", display: "flex", flexDirection: "column", gap: 4 }}><span style={{ font: "600 14px/1.3 var(--font-sans)" }}>{x.name} {x.min} min</span><span style={{ font: "var(--type-num-s)" }}>{A.kr(A.price(x, D.rate))}</span><A.Meta>{x.clip ? "1 KLIPP MED PAKKE" : "IKKE KLIPP"}</A.Meta></button>; })}</div><A.Meta>PRISER FRA TJENESTELISTEN · DEMODATA</A.Meta></A.Card>
          <A.Card gap={10}><A.Head k="3 · Tid" /><div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{D.days.map(([d, dt], i) => <ChoicePill key={i} selected={i === day} onClick={() => { setDay(i); setSlot(null); }}>{d} {dt}</ChoicePill>)}</div>
            {empty || !D.slots[day].length ? <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen ledige tider denne dagen.</p> : <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{D.slots[day].map((t) => <ChoicePill key={t} mono selected={slot === t} onClick={() => setSlot(t)}>{t}</ChoicePill>)}</div>}</A.Card>
        </A.Stack>
        <A.Card gap={12}><A.Head k="4 · Bekreft" /><KeyValue items={[["Barn", k.name, { mono: false }], ["Tjeneste", s.name + " " + s.min + " min", { mono: false }], ["Tid", slot ? D.days[day].join(" ") + " · " + slot : null], ["Pris", A.kr(price), { hint: s.price != null ? "FAST PRIS" : "TIMEPRIS × VARIGHET · DEMODATA" }]]} />
          {canClip && <FormField label="Betaling"><Segmented options={["Klipp", "Kort"]} value={pay} onChange={setPay} /></FormField>}
          <A.Meta>{method === "Klipp" ? "TREKKER 1 KLIPP FRA " + k.pkg.toUpperCase() : "BETALES MED KORT · " + D.sub.card.toUpperCase()}</A.Meta>
          <Button fullWidth icon="check" disabled={!slot} onClick={confirm}>Send booking</Button></A.Card>
      </A.Cols>
    </A.Gate>
  </A.Page>;
}
window.FO_SCREENS = window.FO_SCREENS || {};
window.FO_SCREENS["FO-01"] = { id: "FO-01", name: "Forelder i dag", route: "/forelder", Component: FO01 };
window.FO_SCREENS["FO-02"] = { id: "FO-02", name: "Barn", route: "/forelder/barn", Component: FO02 };
window.FO_SCREENS["FO-03"] = { id: "FO-03", name: "Booking for barn", route: "/forelder/booking", Component: FO03 };
})();
