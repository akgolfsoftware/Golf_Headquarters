(() => {
function FO04({ state, go }) {
  const { PageHeader, Button, EmptyState, KeyValue, DataTable, Dialog, StatusPill, InlineAlert, Segmented, FormField } = window.AGQ.ns();
  const A = window.AGQ, D = window.FO_DATA, S = D.sub, { desk } = A.useW(), empty = state === "tom";
  const [cx, setCx] = React.useState(false), [step, setStep] = React.useState(null), [ended, setEnded] = React.useState(false), [per, setPer] = React.useState("Månedlig");
  const endDate = "31.10.2026";
  const sub = <A.Card gap={12}><A.Head k="Abonnement" aside="STRIPE · 26.09.2026" />
    <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span style={{ font: "var(--type-title-s)", flex: "1 1 auto" }}>{S.kid} · {S.plan}</span><StatusPill tone={ended ? "neutral" : "ok"}>{ended ? "Avsluttes " + endDate : "Aktivt"}</StatusPill></div>
    <KeyValue items={[["Pris", S.plan === "FULL" ? (per === "Månedlig" ? A.kr(S.price) + " / mnd" : A.kr(S.year) + " / år") : "0 kr"], ["Neste trekk", ended ? null : S.next, { hint: ended ? "INGEN FLERE TREKK" : A.kr(per === "Månedlig" ? S.price : S.year) }], ["Betalingskort", S.card]]} />
    {!ended && <FormField label="Betalingsperiode"><Segmented options={["Månedlig", "Årlig"]} value={per} onChange={(v) => { setPer(v); A.toast("Endring sendes til Stripe", v === "Årlig" ? "2 690 KR PER ÅR FRA " + S.next : "299 KR PER MÅNED"); }} /></FormField>}
    <KeyValue items={[["Ada Lindvik", "Gratis · 0 kr", { mono: false }]]} />
    {ended ? <InlineAlert tone="neutral" title="Abonnementet er avsluttet i Stripe">Full gjelder til {endDate}. Deretter går Tobias over til Gratis.</InlineAlert> : <div><Button variant="ghost" onClick={() => setCx(true)}>Avslutt abonnement</Button></div>}
  </A.Card>;
  const inv = <DataTable caption="Fakturaer" rowKey="0" columns={[{ key: "0", label: "Nr.", mono: true }, { key: "1", label: "Dato", mono: true }, { key: "2", label: "Gjelder" }, { key: "3", label: "Beløp", mono: true, align: "right", render: (r) => A.kr(r[3]) }, { key: "4", label: "Status", render: (r) => <StatusPill tone={r[4] === "Betalt" ? "ok" : "info"}>{r[4]}</StatusPill> }]} rows={D.invoices.map((r) => ({ ...r }))} />;
  return <A.Page max={1200}>
    <PageHeader kicker="Forelder · Økonomi" title="Økonomi" sub="Abonnement, neste trekk og fakturaer. Betaling håndteres av Stripe." />
    <A.Gate state={state} loading="Henter abonnement og fakturaer …" error={{ title: "Økonomi kunne ikke hentes", text: "Stripe svarer ikke. Ingen trekk er gjort.", code: "STRIPE · 503" }}>
      {empty ? <EmptyState icon="credit-card" title="Ingen abonnement" text="Barna er på Gratis. Full koster 299 kr per måned eller 2 690 kr per år." action="Se Full" actionIcon="arrow-right" onAction={() => A.toast("Full", "299 KR / MND · 2 690 KR / ÅR")} /> : desk ? <A.Cols tpl="minmax(0,1fr) minmax(0,1.3fr)">{sub}{inv}</A.Cols> : <A.Stack>{sub}{inv}</A.Stack>}
    </A.Gate>
    <Dialog open={cx} onClose={() => { setCx(false); setStep(null); }} title="Avslutte Full for Tobias?" footer={step === "stripe" ? <Button variant="ghost" disabled>Venter på Stripe …</Button> : <><Button variant="secondary" onClick={() => setCx(false)}>Behold Full</Button><Button variant="signal" onClick={() => { setStep("stripe"); setTimeout(() => { setStep(null); setCx(false); setEnded(true); A.toast("Avsluttet i Stripe", "FULL GJELDER TIL " + endDate); }, 900); }}>Avslutt abonnement</Button></>}>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}><p style={{ margin: 0, font: "var(--type-body)" }}>Full gjelder ut perioden, til {endDate}. Deretter går Tobias over til Gratis. Du får ikke flere trekk.</p><A.Meta>{step === "stripe" ? "SENDER TIL STRIPE · INGENTING ER ENDRET HOS OSS ENNÅ" : "AVSLUTNINGEN SENDES TIL STRIPE FØRST"}</A.Meta></div>
    </Dialog>
  </A.Page>;
}
function FO05({ state, go }) {
  const { PageHeader, Button, EmptyState, Switch, Timeline, Dialog, InlineAlert, Segmented } = window.AGQ.ns();
  const A = window.AGQ, D = window.FO_DATA, { desk } = A.useW(), empty = state === "tom";
  const [list, setList] = React.useState(D.consent), [log, setLog] = React.useState(D.consentLog), [off, setOff] = React.useState(null), [kid, setKid] = React.useState("k2");
  const k = D.kids.find((x) => x.id === kid), under16 = k.age < 16;
  const stamp = () => new Date().toTimeString().slice(0, 5);
  const setOn = (c, on) => { setList((l) => l.map((x) => x.id === c.id ? { ...x, on } : x)); setLog((l) => [{ day: "LØR 26.09", time: stamp(), title: (on ? "Ga samtykke · " : "Trakk samtykke · ") + c.what.toLowerCase() + " · " + k.name.split(" ")[0], meta: "HANNE LINDVIK · INNLOGGET" }, ...l.map((x, i) => i === 0 && x.day === "LØR 26.09" ? { ...x, day: undefined } : x)]); A.toast(on ? "Samtykke gitt" : "Samtykke trukket", c.what.toUpperCase()); };
  const items = empty ? [] : list.filter((c) => c.kid === kid);
  const [sreq, setSreq] = React.useState(empty ? [] : [{ id: "sr1", kid: "Ada Lindvik", org: "WANG", who: "Marte Vik", email: "marte.vik@wang.no", at: "25.09.2026 · 20:41" }]);
  const decide = (r, ok) => { setSreq((l) => l.filter((x) => x.id !== r.id)); setLog((l) => [{ day: "LØR 26.09", time: stamp(), title: (ok ? "Godkjente deling · " : "Avslo deling · ") + r.org + " · " + r.who + " · Ada", meta: "HANNE LINDVIK · INNLOGGET" }, ...l]); A.toast(ok ? "Delingen er godkjent" : "Delingen er avslått", (r.org + " · " + r.who).toUpperCase() + (ok ? " SER ALT OM ADA" : " FÅR IKKE TILGANG")); };
  const shareCard = <A.Card gap={10}><A.Head k="Deling venter på deg" aside={sreq.length ? sreq.length + " VENTER · UNDER 16" : "INGEN"} />{!sreq.length ? <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen delinger venter.</p> : sreq.map((r) => <div key={r.id} style={{ display: "flex", flexDirection: "column", gap: 8 }}><span style={{ font: "600 14px/1.35 var(--font-sans)" }}>{r.kid.split(" ")[0]} vil dele med {r.org} · {r.who}</span><A.Meta>{r.email.toUpperCase()} · {r.at}</A.Meta><p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Godkjenner du, ser {r.who.split(" ")[0]} alt i PlayerHQ: økter, runder, tester, helse og meldinger. Du eller {r.kid.split(" ")[0]} kan trekke tilgangen når som helst.</p><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button icon="check" onClick={() => decide(r, true)}>Godkjenn</Button><Button variant="ghost" onClick={() => decide(r, false)}>Avslå</Button></div></div>)}</A.Card>;
  const main = <A.Card gap={4}><A.Head k={"Deling · " + k.name} aside={under16 ? "UNDER 16 · FORELDER SAMTYKKER" : "16+ · SPILLEREN SAMTYKKER SELV"} />
    {!under16 ? <p style={{ margin: "8px 0", font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{k.name.split(" ")[0]} er {k.age} år og gir samtykke selv i PlayerHQ. Du ser ikke valgene hans.</p>
      : items.length ? items.map((c, i) => <div key={c.id} style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap", minHeight: 60, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ flex: "1 1 200px", minWidth: 0, display: "flex", flexDirection: "column", gap: 2 }}><span style={{ font: "500 14px/1.3 var(--font-sans)" }}>{c.what}</span><A.Meta>DELES MED {c.scope.toUpperCase()}</A.Meta></span><Switch checked={c.on} onChange={(e) => e.target.checked ? setOn(c, true) : setOff(c)} label={c.on ? "Gitt" : "Ikke gitt"} /></div>)
      : <p style={{ margin: 0 }}>—</p>}
  </A.Card>;
  const hist = <A.Card gap={10}><A.Head k="Revisjonshistorikk" aside={log.length + " ENDRINGER"} /><Timeline items={empty ? [] : log} dense />{empty && <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen endringer.</p>}</A.Card>;
  return <A.Page max={1200}>
    <PageHeader kicker="Forelder · Samtykke" title="Samtykke" sub="Du gir samtykke for barn under 16 år. Alle endringer registreres med hvem og når." />
    <A.Gate state={state} loading="Henter samtykker …" error={{ title: "Samtykkene kunne ikke hentes", text: "Ingen samtykker er endret.", code: "FEIL 502 · SAMTYKKE" }}>
      <div style={{ maxWidth: 420 }}><Segmented options={D.kids.map((x) => x.name.split(" ")[0])} value={k.name.split(" ")[0]} onChange={(v) => setKid(D.kids.find((x) => x.name.startsWith(v)).id)} /></div>
      {!empty && shareCard}
      {empty ? <EmptyState icon="shield-check" title="Ingen samtykker å ta stilling til" text="Coachen sender forespørsel når noe skal deles. Du får e-post med lenke." /> : desk ? <A.Cols tpl="minmax(0,1.2fr) minmax(0,1fr)">{main}{hist}</A.Cols> : <A.Stack>{main}{hist}</A.Stack>}
    </A.Gate>
    <Dialog open={!!off} onClose={() => setOff(null)} title="Trekke samtykket?" footer={<><Button variant="secondary" onClick={() => setOff(null)}>Behold</Button><Button onClick={() => { setOn(off, false); setOff(null); }}>Trekk samtykke</Button></>}>{off && <p style={{ margin: 0, font: "var(--type-body)" }}>{off.what} deles ikke lenger med {off.scope}. Det som allerede er delt, slettes innen 30 dager.</p>}</Dialog>
  </A.Page>;
}
function FO06({ state, go }) {
  const { PageHeader, Button, EmptyState, KeyValue, Avatar, FormField, TextInput, Switch } = window.AGQ.ns();
  const A = window.AGQ, D = window.FO_DATA, { desk } = A.useW(), empty = state === "tom";
  const [msg, setMsg] = React.useState(""), [th, setTh] = React.useState(D.thread), [me, setMe] = React.useState({ ...D.parent });
  const send = () => { if (!msg.trim()) return; setTh((l) => [...l, ["Hanne Lindvik", "26.09 " + new Date().toTimeString().slice(0, 5), msg]]); setMsg(""); A.toast("Meldingen er sendt", "TIL ANDERS KRISTIANSEN"); };
  const coach = <A.Card gap={12}><div style={{ display: "flex", gap: 12, alignItems: "center" }}><Avatar name={D.coach.name} size={48} /><div><div style={{ font: "var(--type-title-s)" }}>{D.coach.name}</div><A.Meta>{D.coach.role.toUpperCase()} · {D.coach.reply.toUpperCase()}</A.Meta></div></div><KeyValue items={[["E-post", D.coach.email, { mono: false }], ["Telefon", D.coach.phone]]} /></A.Card>;
  const thread = <A.Card gap={12}><A.Head k="Siste melding" aside={empty ? "—" : th[th.length - 1][1]} />
    {empty ? <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen meldinger ennå.</p> : <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>{th.map(([w, t, x], i) => { const mine = w === "Hanne Lindvik"; return <div key={i} style={{ alignSelf: mine ? "flex-end" : "flex-start", maxWidth: "min(90%, 520px)", padding: "10px 12px", borderRadius: 8, background: mine ? "var(--surface-sunken)" : "var(--surface-card)", border: "1px solid var(--border-hairline)" }}><A.Meta>{w.toUpperCase()} · {t}</A.Meta><div style={{ font: "var(--type-body)", marginTop: 4 }}>{x}</div></div>; })}</div>}
    <textarea aria-label="Melding til Anders" value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Skriv til Anders" style={{ width: "100%", boxSizing: "border-box", minHeight: 88, padding: 12, borderRadius: 8, border: "1px solid var(--border-control)", background: "var(--surface-card)", color: "var(--text-primary)", font: "var(--type-body)", resize: "vertical" }} />
    <div><Button icon="send" disabled={!msg.trim()} onClick={send}>Send</Button></div></A.Card>;
  const mine = <A.Card gap={12}><A.Head k="Min kontakt" /><FormField label="Navn"><TextInput value={me.name} onChange={(e) => setMe({ ...me, name: e.target.value })} /></FormField><FormField label="E-post"><TextInput type="email" value={me.email} onChange={(e) => setMe({ ...me, email: e.target.value })} /></FormField><FormField label="Telefon"><TextInput mono value={me.phone} onChange={(e) => setMe({ ...me, phone: e.target.value })} /></FormField><Switch defaultChecked label="E-post når en booking er bekreftet" /><Switch defaultChecked label="Ukerapport lørdag" /><div><Button variant="secondary" icon="check" onClick={() => A.toast("Kontaktinfo lagret", "—")}>Lagre</Button></div></A.Card>;
  return <A.Page max={1200}>
    <PageHeader kicker="Forelder · Coach og innstillinger" title="Coach og innstillinger" />
    <A.Gate state={state} loading="Henter coach og meldinger …" error={{ title: "Meldingene kunne ikke hentes", text: "Ingen meldinger er sendt.", code: "FEIL 502 · MELDINGER" }}>
      {desk ? <A.Cols tpl="minmax(0,1fr) minmax(0,1.3fr)"><A.Stack>{coach}{mine}</A.Stack>{thread}</A.Cols> : <A.Stack>{coach}{thread}{mine}</A.Stack>}
    </A.Gate>
  </A.Page>;
}
window.FO_SCREENS = window.FO_SCREENS || {};
window.FO_SCREENS["FO-04"] = { id: "FO-04", name: "Økonomi", route: "/forelder/okonomi", Component: FO04 };
window.FO_SCREENS["FO-05"] = { id: "FO-05", name: "Samtykke", route: "/forelder/samtykke", Component: FO05 };
window.FO_SCREENS["FO-06"] = { id: "FO-06", name: "Coach og innstillinger", route: "/forelder/coach", Component: FO06 };
})();
