(() => {
const { Button, IconButton, StatusPill, Icon } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, Grid, Mono, Kv, kr, useW } = window.KIT;
const INV = [
  { nr: "AKG-2026-1003", dt: "01.10.2026", txt: "Treningskontingent FULL · oktober", sum: 2890, st: "due" },
  { nr: "AKG-2026-0912", dt: "01.09.2026", txt: "Treningskontingent FULL · september", sum: 2890, st: "paid" },
  { nr: "AKG-2026-0887", dt: "18.08.2026", txt: "Simulator-klippekort · Vinterbås 2 · 10 t", sum: 3500, st: "paid" },
  { nr: "AKG-2026-0801", dt: "01.08.2026", txt: "Treningskontingent FULL · august", sum: 2890, st: "paid" },
  { nr: "AKG-2026-0648", dt: "24.06.2026", txt: "Sommerleir · Gamle Fredrikstad · 3 dager", sum: 2400, st: "paid" },
  { nr: "AKG-2026-0601", dt: "01.06.2026", txt: "Treningskontingent TALENT · juni", sum: 1490, st: "paid" },
];
const USED = [["12.09", "Bay 2", 60], ["05.09", "Bay 2", 60], ["29.08", "Bay 1", 60], ["22.08", "Bay 3", 60]];
const Pill = ({ st }) => st === "paid" ? <StatusPill tone="ok" dot>Betalt</StatusPill> : <StatusPill tone="warn" dot>Forfaller</StatusPill>;

function ForelderOkonomi() {
  const w = useW();
  const table = w >= 900;
  const used = USED.length, total = 10;
  return (
    <div style={pageWrap}>
      <PageHead kicker="Økonomi · Emma Solberg" title="Kontingent, klippekort og fakturaer" sub="Betaling skjer via Stripe. Kvitteringer og fakturaer ligger her i 5 år." />
      <Grid min={340}>
        <Panel kicker="Treningskontingent" title="Medlemskap FULL" action={<StatusPill tone="solid">Aktivt</StatusPill>}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-metric)", color: "var(--text-primary)" }}>2 890</span><Mono s={{ color: "var(--text-muted)" }}>KR / MND</Mono></div>
          <div>
            <Kv k="Neste trekk" v="01.10.2026" />
            <Kv k="Betalingskort" v="Visa •••• 4412" />
            <Kv k="Bindingstid" v="Ingen · 1 mnd oppsigelse" mono={false} last />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 8 }}>
            {[["TALENT", 1490, "2 økter i uken, fellestrening"], ["FULL", 2890, "4 økter i uken, TrackMan, testbatteri"]].map(([n, p, d]) => (
              <div key={n} style={{ border: "1px solid " + (n === "FULL" ? "var(--border-ink)" : "var(--border-hairline)"), borderRadius: 8, padding: 12, display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}>
                <span className="kicker">{n}</span><Mono s={{ color: "var(--text-primary)", fontSize: 15 }}>{kr(p)}</Mono><span style={{ font: "400 13px/1.35 var(--font-sans)", color: "var(--text-secondary)" }}>{d}</span>
              </div>))}
          </div>
          <div><Button variant="secondary">Endre medlemskap</Button></div>
        </Panel>
        <Panel kicker="Simulator-klippekort" title="Vinterbås 2 · 10 timer">
          <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-metric)", color: "var(--text-primary)" }}>{used}</span><Mono s={{ color: "var(--text-muted)" }}>AV {total} TIMER BRUKT</Mono></div>
          <div style={{ display: "grid", gridTemplateColumns: `repeat(${total},minmax(0,1fr))`, gap: 4 }} aria-label={`${used} av ${total} timer brukt`}>
            {Array.from({ length: total }, (_, i) => <div key={i} style={{ height: 28, background: i < used ? "var(--primary)" : "var(--surface-sunken)", border: i < used ? "none" : "1px solid var(--border-hairline)" }}></div>)}
          </div>
          <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>6 timer igjen. Gyldig til 30.04.2027.</span>
          <div>
            {USED.map(([d, b, m], i) => <Kv key={d} k={<><Mono s={{ color: "var(--text-primary)" }}>{d}</Mono> · {b}</>} v={m + " min"} last={i === USED.length - 1} />)}
          </div>
        </Panel>
      </Grid>
      <Panel kicker="Fakturahistorikk" title="Fakturaer og kvitteringer" pad={table ? 0 : "var(--card-pad)"} style={table ? { gap: 0 } : null}>
        {table ? (
          <div role="table" style={{ display: "flex", flexDirection: "column" }}>
            <div role="row" style={{ display: "grid", gridTemplateColumns: "150px 110px minmax(0,1fr) 110px 120px 180px", gap: 16, padding: "12px 24px", borderTop: "1px solid var(--border-hairline)", borderBottom: "1px solid var(--border-hairline)", font: "var(--type-kicker)", letterSpacing: "var(--tracking-kicker)", textTransform: "uppercase", color: "var(--text-muted)" }}>
              <span>Faktura</span><span>Dato</span><span>Beskrivelse</span><span style={{ textAlign: "right" }}>Beløp</span><span>Status</span><span></span>
            </div>
            {INV.map((r) => (
              <div role="row" key={r.nr} style={{ display: "grid", gridTemplateColumns: "150px 110px minmax(0,1fr) 110px 120px 180px", gap: 16, padding: "8px 24px", alignItems: "center", minHeight: 48, borderBottom: "1px solid var(--border-hairline)" }}>
                <Mono s={{ color: "var(--text-primary)" }}>{r.nr}</Mono><Mono s={{ color: "var(--text-secondary)" }}>{r.dt}</Mono>
                <span style={{ font: "var(--type-body-s)", color: "var(--text-body)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{r.txt}</span>
                <Mono s={{ color: "var(--text-primary)", textAlign: "right" }}>{kr(r.sum)}</Mono>
                <div><Pill st={r.st} /></div>
                <div style={{ display: "flex", gap: 4, justifyContent: "flex-end" }}>
                  {r.st === "paid" ? <Button variant="ghost" size="sm" iconRight="external-link">Kvittering</Button> : <Button variant="secondary" size="sm">Betal nå</Button>}
                  <IconButton icon="download" label={"Last ned " + r.nr + " som PDF"} size="sm" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {INV.map((r) => (
              <div key={r.nr} style={{ border: "1px solid var(--border-hairline)", borderRadius: 8, padding: 12, display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center" }}><Mono s={{ color: "var(--text-primary)" }}>{r.nr}</Mono><Pill st={r.st} /></div>
                <span style={{ font: "var(--type-body-s)", color: "var(--text-body)" }}>{r.txt}</span>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                  <Mono s={{ color: "var(--text-secondary)" }}>{r.dt} · <span style={{ color: "var(--text-primary)" }}>{kr(r.sum)}</span></Mono>
                  <div style={{ display: "flex", gap: 4 }}>{r.st === "paid" ? <Button variant="ghost" size="sm" iconRight="external-link">Kvittering</Button> : <Button variant="secondary" size="sm">Betal nå</Button>}<IconButton icon="download" label={"Last ned " + r.nr + " som PDF"} /></div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Panel>
    </div>
  );
}
window.ForelderOkonomi = ForelderOkonomi;
})();
