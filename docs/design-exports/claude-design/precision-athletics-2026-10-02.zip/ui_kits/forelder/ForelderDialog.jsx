(() => {
const { Button, Avatar, InlineAlert, StatusPill, Icon } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, Mono, useW } = window.KIT;
const PEOPLE = { anders: ["Anders Kristiansen", "COACH"], emma: ["Emma Solberg", "SPILLER · 14 ÅR"], kari: ["Kari Solberg", "FORELDER"] };
const INIT = [
  { by: "anders", dt: "TOR 24.09 · 18:52", t: "Bra økt i dag, Emma. Avstandskontrollen fra 30–50 m er tydelig bedre. Før lørdag: én pre-shot-rutine, samme hver gang. Ingen ekstra trening fredag etter økten." },
  { by: "emma", dt: "TOR 24.09 · 20:10", t: "Takk! Skal jeg bruke 54-graderen eller 58 på de korte innspillene på hull 7?" },
  { by: "anders", dt: "TOR 24.09 · 20:31", t: "54 med halv sving. Du treffer den mer stabilt, og greenen er hard nå. Registrer gjerne slagene i appen etter runden." },
  { by: "kari", dt: "FRE 25.09 · 07:45", t: "Hei Anders. Emma har litt vondt i venstre håndledd etter styrken tirsdag. Skal vi være forsiktige i dag?" },
  { by: "anders", dt: "FRE 25.09 · 08:12", t: "Takk for beskjed. Vi dropper fullsving i dag og kjører bare putting og korte slag. Si fra om det ikke går bedre til lørdag." },
];

function Msg({ m, mine }) {
  const [n, r] = PEOPLE[m.by];
  return (
    <div style={{ display: "flex", gap: 12, flexDirection: mine ? "row-reverse" : "row", alignItems: "flex-start", maxWidth: "100%" }}>
      <Avatar name={n} size={32} />
      <div style={{ display: "flex", flexDirection: "column", gap: 4, alignItems: mine ? "flex-end" : "flex-start", minWidth: 0, maxWidth: "min(560px, calc(100% - 44px))" }}>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "baseline", justifyContent: mine ? "flex-end" : "flex-start" }}><span style={{ font: "500 13px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{n}</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{r}</span></div>
        <div style={{ background: mine ? "var(--primary)" : "var(--surface-card)", color: mine ? "var(--text-on-primary)" : "var(--text-body)", border: mine ? "none" : "1px solid var(--border-hairline)", borderRadius: 8, padding: "12px 16px", font: "var(--type-body)", textWrap: "pretty", overflowWrap: "anywhere" }}>{m.t}</div>
        <Mono s={{ fontSize: 11, color: "var(--text-muted)" }}>{m.dt}</Mono>
      </div>
    </div>
  );
}

function ForelderDialog() {
  const w = useW();
  const side = w > 1100;
  const [msgs, setMsgs] = React.useState(INIT);
  const [text, setText] = React.useState("");
  const endRef = React.useRef(null);
  React.useEffect(() => { const m = document.querySelector("main"); if (m && msgs.length > INIT.length) m.scrollTo({ top: m.scrollHeight, behavior: "smooth" }); }, [msgs.length]);
  const send = () => { if (!text.trim()) return; setMsgs([...msgs, { by: "kari", dt: "FRE 25.09 · 14:32", t: text.trim() }]); setText(""); };
  return (
    <div style={pageWrap}>
      <PageHead kicker="Dialog · Emma Solberg" title="Coach, spiller og forelder" sub="Én felles tråd. Alle tre ser alle meldinger." />
      <div style={{ display: "grid", gridTemplateColumns: side ? "minmax(0,1fr) 300px" : "minmax(0,1fr)", gap: 24, alignItems: "start" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 16, minWidth: 0 }}>
          <InlineAlert tone="info" title="Beskyttet kommunikasjon">Som foresatt har du automatisk innsyn i all veiledning til spillere under 18 år. Private meldinger mellom coach og spiller er ikke mulig.</InlineAlert>
          <div style={{ display: "flex", flexDirection: "column", gap: 24, padding: "8px 0" }}>{msgs.map((m, i) => <Msg key={i} m={m} mine={m.by === "kari"} />)}<div ref={endRef}></div></div>
          <div style={{ position: "sticky", bottom: 0, background: "var(--surface-page)", paddingBottom: 8 }}>
            <div style={{ background: "var(--surface-card)", border: "1px solid var(--border-control)", borderRadius: 8, padding: 8, display: "flex", gap: 8, alignItems: "flex-end" }}>
              <textarea value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) send(); }} rows={2} placeholder="Skriv til Anders og Emma" aria-label="Melding" style={{ flex: 1, minWidth: 0, resize: "none", border: "none", outline: "none", background: "transparent", font: "var(--type-body)", color: "var(--text-primary)", padding: 8 }}></textarea>
              <Button icon="send" disabled={!text.trim()} onClick={send}>Send</Button>
            </div>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 16, minWidth: 0, order: side ? 0 : -1 }}>
          <Panel kicker="Deltakere" pad={16} style={{ gap: 12 }}>
            <div style={{ display: "flex", flexDirection: side ? "column" : "row", gap: 12, flexWrap: "wrap" }}>
              {Object.entries(PEOPLE).map(([k, [n, r]]) => <div key={k} style={{ display: "flex", gap: 8, alignItems: "center", minWidth: 0 }}><Avatar name={n} size={28} /><div style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "500 13px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{n}</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{r}</span></div></div>)}
            </div>
          </Panel>
          {side && <Panel kicker="Innsynsregel" pad={16} style={{ gap: 8 }}>
            <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Innsynet gjelder til Emma fyller 18 år (<span style={{ font: "var(--type-num-s)" }}>14.03.2030</span>). Caddie-svar til Emma vises også i tråden.</p>
            <div><StatusPill tone="ok" dot>Innsyn aktivt</StatusPill></div>
          </Panel>}
        </div>
      </div>
    </div>
  );
}
window.ForelderDialog = ForelderDialog;
})();
