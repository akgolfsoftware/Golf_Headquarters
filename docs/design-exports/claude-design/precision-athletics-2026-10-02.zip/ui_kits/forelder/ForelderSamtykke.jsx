(() => {
const { Button, Switch, Checkbox, StatusPill, InlineAlert, Icon } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, Grid, Mono } = window.KIT;
const ITEMS = [
  { id: "tm", t: "Datainnsamling i TrackMan", d: "Ballbane, køllehastighet og treffpunkt lagres på Emmas profil. Brukes kun i treningen og vises bare for Emma, deg og coachteamet." },
  { id: "video", t: "Opptak av svingvideo", d: "Coach kan filme svingen under økter for analyse. Videoene deles aldri utenfor akademiet og slettes etter 24 måneder." },
  { id: "pub", t: "Publisering av resultater i akademiet", d: "Navn og brutto score fra turneringer kan vises på resultatlister og i akademiets egne kanaler. Bilder krever eget samtykke." },
];
const NAME = { tm: "TrackMan-data", video: "Svingvideo", pub: "Publisering av resultater" };
const INIT = [
  { dt: "14.08.2026", tid: "19:04", who: "Kari Solberg", what: "Samtykke gitt: TrackMan-data, Svingvideo" },
  { dt: "02.06.2026", tid: "08:31", who: "Kari Solberg", what: "Trukket tilbake: Publisering av resultater" },
  { dt: "11.01.2026", tid: "21:17", who: "Kari Solberg", what: "Samtykke gitt: TrackMan-data, Svingvideo, Publisering av resultater" },
];

function ForelderSamtykke() {
  const [saved, setSaved] = React.useState({ tm: true, video: true, pub: false });
  const [draft, setDraft] = React.useState(saved);
  const [confirm, setConfirm] = React.useState(false);
  const [hist, setHist] = React.useState(INIT);
  const dirty = ITEMS.some((i) => draft[i.id] !== saved[i.id]);
  const anyOn = ITEMS.some((i) => saved[i.id]);
  const lastGiven = hist.find((h) => h.what.startsWith("Samtykke gitt"));
  const commit = (next, what) => { setSaved(next); setDraft(next); setConfirm(false); setHist([{ dt: "25.09.2026", tid: "14:32", who: "Kari Solberg", what }, ...hist]); };
  const save = () => {
    const on = ITEMS.filter((i) => draft[i.id] && !saved[i.id]).map((i) => NAME[i.id]), off = ITEMS.filter((i) => !draft[i.id] && saved[i.id]).map((i) => NAME[i.id]);
    commit(draft, [on.length && "Samtykke gitt: " + on.join(", "), off.length && "Trukket tilbake: " + off.join(", ")].filter(Boolean).join(" · "));
  };
  return (
    <div style={pageWrap}>
      <PageHead kicker="Samtykke · Emma Solberg · 14 år" title="Samtykke for spiller under 16 år" sub="Akademiet trenger samtykke fra foresatte før vi samler inn eller deler data om spillere under 16 år. Du kan endre eller trekke tilbake samtykket når som helst." />
      <Panel pad={20}>
        <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
          <StatusPill tone={anyOn ? "ok" : "neutral"} dot>{anyOn ? "Aktivt samtykke" : "Ingen aktive samtykker"}</StatusPill>
          <span style={{ font: "var(--type-body)", color: "var(--text-body)", minWidth: 0 }}>{anyOn && lastGiven ? <>Aktivt samtykke gitt <Mono s={{ fontSize: 14, color: "var(--text-primary)" }}>{lastGiven.dt}</Mono> av {lastGiven.who}</> : "Akademiet registrerer ingen data om Emma utover oppmøte."}</span>
        </div>
      </Panel>
      <Grid min={420} gap={24} style={{ alignItems: "start" }}>
        <Panel kicker="Valg" title="Hva du samtykker til">
          <div style={{ display: "flex", flexDirection: "column" }}>
            {ITEMS.map((it, i) => (
              <div key={it.id} style={{ display: "flex", gap: 16, alignItems: "flex-start", padding: "16px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}>
                <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 4 }}>
                  <span style={{ font: "600 15px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{it.t}</span>
                  <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{it.d}</span>
                  {draft[it.id] !== saved[it.id] && <span style={{ font: "var(--type-meta)", color: "var(--warn)" }}>IKKE LAGRET</span>}
                </div>
                <Switch aria-label={it.t} checked={!!draft[it.id]} onChange={(e) => setDraft({ ...draft, [it.id]: e.target.checked })} />
              </div>
            ))}
          </div>
          {dirty && <div style={{ display: "flex", flexDirection: "column", gap: 12, paddingTop: 16, borderTop: "1px solid var(--border-hairline)" }}>
            <Checkbox checked={confirm} onChange={(e) => setConfirm(e.target.checked)} label="Jeg er foresatt med foreldreansvar for Emma Solberg" />
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button disabled={!confirm} onClick={save}>Lagre samtykke</Button><Button variant="ghost" onClick={() => { setDraft(saved); setConfirm(false); }}>Avbryt</Button></div>
          </div>}
        </Panel>
        <div style={{ display: "flex", flexDirection: "column", gap: 24, minWidth: 0 }}>
          <Panel kicker="Revisjonshistorikk" title="Alle endringer">
            <div style={{ display: "flex", flexDirection: "column" }}>
              {hist.map((h, i) => (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "minmax(0,96px) minmax(0,1fr)", gap: 12, padding: "12px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}>
                  <div style={{ display: "flex", flexDirection: "column", gap: 2 }}><Mono s={{ color: "var(--text-primary)" }}>{h.dt}</Mono><Mono s={{ fontSize: 11, color: "var(--text-muted)" }}>{h.tid}</Mono></div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "var(--type-body-s)", color: "var(--text-body)", overflowWrap: "anywhere" }}>{h.what}</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{h.who.toUpperCase()} · BANKID</span></div>
                </div>
              ))}
            </div>
          </Panel>
          <Panel kicker="Trekk tilbake" title="Stopp all datainnsamling">
            <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Alle samtykker trekkes tilbake med en gang. Eksisterende video og TrackMan-data slettes innen 30 dager. Emma kan fortsatt trene som før.</p>
            <div><Button variant="signal" disabled={!anyOn} onClick={() => commit({ tm: false, video: false, pub: false }, "Alt samtykke trukket tilbake")}>Trekk tilbake alt samtykke</Button></div>
          </Panel>
        </div>
      </Grid>
      <InlineAlert tone="info" title="Når Emma fyller 16">Hun blir bedt om å gi samtykke selv. Du får beskjed, og innsynet ditt fortsetter til hun er 18.</InlineAlert>
    </div>
  );
}
window.ForelderSamtykke = ForelderSamtykke;
})();
