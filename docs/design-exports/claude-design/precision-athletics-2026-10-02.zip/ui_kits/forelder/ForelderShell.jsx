(() => {
const { KitShell, G } = window.KIT;
const NAV = [
  G("hjem", "I dag", "sun", [["hjem", "Emmas uke", "sun"]]),
  G("samtykke", "Samtykke", "shield-check", [["samtykke", "Samtykke", "shield-check"]]),
  G("okonomi", "Økonomi", "wallet", [["okonomi", "Kontingent og fakturaer", "wallet"]]),
  G("dialog", "Dialog", "messages-square", [["dialog", "Dialog med coach", "messages-square"]]),
];
function ForelderShell() {
  return <KitShell nav={NAV} store="for-page" fallback="hjem" who={{ name: "Kari Solberg", role: "FORELDER · EMMA SOLBERG" }}
    screens={{ hjem: ForelderHjem, samtykke: ForelderSamtykke, okonomi: ForelderOkonomi, dialog: ForelderDialog }} />;
}
window.ForelderShell = ForelderShell;
})();
