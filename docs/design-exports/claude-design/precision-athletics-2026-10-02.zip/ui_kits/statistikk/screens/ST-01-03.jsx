(() => {
const vis = (born, consent) => born != null && (born < 2008 || consent);
const d1 = (v) => v == null ? "—" : v.toFixed(1).replace(".", ",");
const sgc = (v) => v == null ? "—" : (v > 0.04 ? "+" : v < -0.04 ? "−" : "±") + Math.abs(v).toFixed(2).replace(".", ",");
const DG = () => <span style={{ display: "inline-flex", alignItems: "center", font: "500 11px/1 var(--font-sans)", color: "var(--text-secondary)", padding: "5px 8px", borderRadius: 4, border: "1px solid var(--border-hairline)", background: "var(--surface-flat)", whiteSpace: "nowrap" }}>Powered by Data Golf</span>;
function Site({ children, go, cur, state, loading, error }) {
  const { mob } = window.AGQ.useW(), { LoadingState, ErrorState } = window.AGQ.ns();
  const NAV = [["ST-01", "Oversikt"], ["ST-02", "Lister"], ["ST-04", "Turnering"], ["ST-05", "PGA"], ["ST-06", "Verktøy"]];
  return <div style={{ minHeight: "100%", display: "flex", flexDirection: "column" }}>
    <header style={{ borderBottom: "1px solid var(--border-hairline)", background: "var(--surface-flat)" }}><div style={{ maxWidth: 1200, margin: "0 auto", padding: mob ? "10px 16px" : "12px 24px", display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap", boxSizing: "border-box" }}><span style={{ font: "600 16px/1 var(--font-sans)", flex: "1 1 auto" }}>AK Golf Statistikk</span><nav style={{ display: "flex", gap: 2, flexWrap: "wrap" }}>{NAV.map(([id, l]) => <button key={id} type="button" aria-current={cur === id ? "page" : undefined} onClick={() => go(id)} style={{ all: "unset", cursor: "pointer", minHeight: 44, padding: "0 10px", display: "flex", alignItems: "center", font: "500 14px/1 var(--font-sans)", boxShadow: cur === id ? "inset 0 -2px 0 var(--border-ink)" : "none" }}>{l}</button>)}</nav></div></header>
    <div style={{ width: "100%", maxWidth: 1200, margin: "0 auto", padding: mob ? "20px 16px 40px" : "28px 24px 56px", boxSizing: "border-box", display: "flex", flexDirection: "column", gap: 20 }}>
      {state === "laster" ? <LoadingState text={loading} /> : state === "feil" ? <ErrorState {...error} onRetry={() => window.AGQ.toast("Prøver igjen", "—")} /> : children}
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center", borderTop: "1px solid var(--border-hairline)", paddingTop: 16 }}><DG /><window.AGQ.Meta>KUN BRUTTO SCORE · SPILLERE FØDT 2008 ELLER SENERE VISES BARE MED SAMTYKKE</window.AGQ.Meta></div>
    </div></div>;
}
const H1 = ({ k, t, s }) => <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>{k && <span className="kicker">{k}</span>}<h1 style={{ margin: 0, font: "600 clamp(24px, 1.6vw + 16px, 32px)/1.2 var(--font-sans)", textWrap: "balance" }}>{t}</h1>{s && <p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-secondary)", maxWidth: 720, textWrap: "pretty" }}>{s}</p>}</div>;
function ST01({ state, go }) {
  const { SearchField, StatusPill, EmptyState, Icon } = window.AGQ.ns(), A = window.AGQ, D = window.ST_DATA, { mob } = A.useW(), empty = state === "tom";
  const [q, setQ] = React.useState("");
  const hits = q.length > 1 ? D.players.filter((p) => vis(p.born, p.consent) && p.name.toLowerCase().includes(q.toLowerCase())) : [];
  return <Site go={go} cur="ST-01" state={state} loading="Henter statistikk …" error={{ title: "Statistikken kunne ikke hentes", text: "GolfBox svarer ikke. Prøv igjen om litt.", code: "GOLFBOX · 504" }}>
    <H1 k="Statistikk" t="Norsk golf i tall" s="Brutto score fra turneringer og tellende runder. Oppdateres hver natt." />
    <SearchField value={q} onChange={setQ} label="Søk etter spiller, klubb eller bane" placeholder="Søk etter spiller, klubb eller bane" count={q.length > 1 ? hits.length : undefined} />
    {q.length > 1 && <div className="pa-card" style={{ padding: 0, overflow: "hidden" }}>{hits.length ? hits.map((p, i) => <button key={p.id} type="button" onClick={() => go("ST-03")} style={{ all: "unset", boxSizing: "border-box", width: "100%", cursor: "pointer", display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap", padding: "12px 16px", minHeight: 56, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ flex: "1 1 160px", font: "500 14px/1.3 var(--font-sans)" }}>{p.name}</span><A.Meta>{p.club.toUpperCase()} · SNITT {d1(p.avg)}</A.Meta></button>) : <p style={{ margin: 0, padding: 16, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen treff. Spillere født 2008 eller senere vises bare med samtykke.</p>}</div>}
    {empty ? <EmptyState icon="bar-chart-3" title="Ingen resultater ennå" text="Sesongen har ikke startet. Resultater hentes fra GolfBox når første turnering er spilt." /> : <>
      <div className="pa-card" style={{ padding: 16, gap: 10, borderColor: "var(--border-ink)" }}><div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><StatusPill tone="live">Live</StatusPill><span style={{ font: "600 15px/1.3 var(--font-sans)", flex: "1 1 200px" }}>{D.live.t}</span><A.Meta>OPPDATERT {D.live.upd}</A.Meta></div><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{D.live.st} · {D.live.players} spillere · leder {D.live.leader[0]} {D.live.leader[1]}</span><div><button type="button" onClick={() => go("ST-04")} style={{ all: "unset", cursor: "pointer", font: "500 14px/1 var(--font-sans)", color: "var(--link)", minHeight: 44, display: "inline-flex", alignItems: "center", gap: 6 }}>Se leaderboard<Icon name="arrow-right" size={14} /></button></div></div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,170px),1fr))", gap: 8 }}>{D.counts.map(([id, l, n]) => <button key={id} type="button" onClick={() => go("ST-02", id)} className="pa-card pa-card--interactive" style={{ padding: 14, gap: 6, textAlign: "left", font: "inherit", cursor: "pointer", minHeight: 84 }}><span style={{ font: "600 22px/1 var(--font-mono)" }}>{String(n).replace(/\B(?=(\d{3})+(?!\d))/g, " ")}</span><span style={{ font: "500 14px/1.2 var(--font-sans)", color: "var(--text-secondary)" }}>{l}</span></button>)}</div>
      <A.Meta>{D.src}</A.Meta>
    </>}
  </Site>;
}
const LISTS = [["spillere", "Spillere"], ["klubber", "Klubber"], ["baner", "Baner"], ["turneringer", "Turneringer"], ["argang", "Årgang"], ["regioner", "Regioner"], ["pga", "PGA-spillere"], ["blogg", "Blogg"]];
function ST02({ state, go, arg }) {
  const { DataTable, Tabs, SegmentedFilter, EmptyState, Select } = window.AGQ.ns(), A = window.AGQ, D = window.ST_DATA, empty = state === "tom";
  const [tab, setTab] = React.useState(LISTS.some((l) => l[0] === arg) ? arg : "spillere"), [reg, setReg] = React.useState("Alle"), [yr, setYr] = React.useState("2008");
  const P = D.players.filter((p) => vis(p.born, p.consent) && (reg === "Alle" || p.region === reg));
  const cfg = {
    spillere: [[{ key: "place", label: "Plass", mono: true, align: "right", sortable: true, sortValue: (r) => r.place ?? 999, render: (r) => r.place == null ? null : <span style={{ display: "inline-flex", flexDirection: "column", alignItems: "flex-end", gap: 2 }}><span>{r.place}</span><span style={{ font: "var(--type-meta)", fontSize: 10, color: "var(--text-muted)", whiteSpace: "nowrap" }}>RANGERT ETTER SNITT BRUTTO</span></span> }, { key: "name", label: "Spiller", sortable: true }, { key: "club", label: "Klubb" }, { key: "avg", label: "Snitt brutto", mono: true, align: "right", sortable: true, render: (r) => d1(r.avg) }, { key: "rounds", label: "Runder", mono: true, align: "right" }, { key: "best", label: "Beste", mono: true, align: "right" }], P.sort((a, b) => a.place - b.place)],
    klubber: [[{ key: "0", label: "Klubb" }, { key: "1", label: "Region" }, { key: "2", label: "Aktive spillere", mono: true, align: "right" }, { key: "3", label: "Snitt brutto", mono: true, align: "right", render: (r) => d1(r[3]) }], D.clubs.map((r) => ({ ...r }))],
    baner: [[{ key: "0", label: "Bane" }, { key: "1", label: "Tee" }, { key: "2", label: "Par", mono: true, align: "right" }, { key: "3", label: "Lengde", mono: true, align: "right", render: (r) => String(r[3]).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " m" }, { key: "4", label: "Snitt brutto", mono: true, align: "right", render: (r) => d1(r[4]) }], D.courses.map((r) => ({ ...r }))],
    turneringer: [[{ key: "0", label: "Turnering" }, { key: "1", label: "Dato", mono: true }, { key: "2", label: "Bane" }, { key: "3", label: "Status" }], D.tournaments.map((r) => ({ ...r }))],
    argang: [[{ key: "place", label: "Plass", mono: true, align: "right", render: (r) => r.place == null ? null : <span style={{ display: "inline-flex", flexDirection: "column", alignItems: "flex-end", gap: 2 }}><span>{r.place}</span><span style={{ font: "var(--type-meta)", fontSize: 10, color: "var(--text-muted)", whiteSpace: "nowrap" }}>RANGERT ETTER SNITT BRUTTO</span></span> }, { key: "name", label: "Spiller" }, { key: "born", label: "Født", mono: true }, { key: "avg", label: "Snitt brutto", mono: true, align: "right", render: (r) => d1(r.avg) }], D.players.filter((p) => vis(p.born, p.consent) && String(p.born) === yr).map((p, i) => ({ ...p, place: i + 1 }))],
    regioner: [[{ key: "0", label: "Region" }, { key: "1", label: "Aktive spillere", mono: true, align: "right" }, { key: "2", label: "Snitt brutto", mono: true, align: "right", render: (r) => d1(r[2]) }], D.regions.map((r) => ({ ...r }))],
    pga: [[{ key: "1", label: "Rangering", mono: true, align: "right" }, { key: "0", label: "Spiller" }, { key: "2", label: "SG total per runde", mono: true, align: "right", render: (r) => sgc(r[2]) }], D.pga.map((r) => ({ ...r }))],
    blogg: [[{ key: "0", label: "Artikkel" }, { key: "1", label: "Publisert", mono: true }], D.blog.map((r) => ({ ...r }))],
  }[tab];
  return <Site go={go} cur="ST-02" state={state} loading="Henter listen …" error={{ title: "Listen kunne ikke hentes", text: "Prøv igjen om litt.", code: "FEIL 502 · STATS" }}>
    <H1 k="Lister" t={LISTS.find((l) => l[0] === tab)[1]} s={tab === "argang" ? "Aldersstige vises bare fra 16 år. Plass er rangering etter snitt brutto, aldri persentil." : "Plass er rangering etter snitt brutto, aldri persentil."} />
    <Tabs tabs={LISTS.map(([v, l]) => ({ value: v, label: l }))} value={tab} onChange={setTab} />
    {tab === "spillere" && <SegmentedFilter label="Region" value={reg} onChange={setReg} options={["Alle", "Øst", "Oslo", "Sør", "Vest"]} />}
    {tab === "argang" && <div style={{ maxWidth: 240 }}><Select label="Årgang · 16 år og eldre" value={yr} onChange={(e) => setYr(e.target.value)} options={["2010", "2009", "2008", "2007", "2006"].filter((y) => 2026 - +y >= 16)} /></div>}
    {empty ? <EmptyState icon="list" title="Ingen rader" text="Listen fylles når resultater er hentet fra GolfBox." /> : cfg[1].length ? <DataTable rowKey={tab === "spillere" || tab === "argang" ? "id" : "0"} onSelect={() => (tab === "spillere" || tab === "argang") && go("ST-03")} columns={cfg[0]} rows={cfg[1]} /> : <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen spillere å vise for dette utvalget.</p>}
    <A.Meta>{tab === "pga" ? D.dg : D.src}</A.Meta>
  </Site>;
}
function ST03({ state, go }) {
  const { DataTable, Sparkline, Tabs, EmptyState } = window.AGQ.ns(), A = window.AGQ, D = window.ST_DATA, P = D.profile, { desk } = A.useW(), empty = state === "tom";
  const [kind, setKind] = React.useState("spiller");
  const other = { klubb: ["Borregaard GK", [["Aktive spillere", "42"], ["Snitt brutto", "76,8 slag"], ["Runder 2026", "611"]]], bane: ["Borregaard GK · gul tee", [["Par", "71"], ["Lengde", "5 980 m"], ["Snitt brutto", "76,4 slag"]]], region: ["Region Øst", [["Aktive spillere", "412"], ["Snitt brutto", "77,4 slag"], ["Klubber", "18"]]], tour: ["Srixon Tour 2026", [["Runder spilt", "5 av 7"], ["Spillere", "84"], ["Laveste runde", "65 slag (−7)"]]] }[kind];
  return <Site go={go} cur="ST-02" state={state} loading="Henter profil …" error={{ title: "Profilen kunne ikke hentes", text: "Prøv igjen om litt.", code: "FEIL 404 · PROFIL" }}>
    <Tabs tabs={[["spiller", "Spiller"], ["klubb", "Klubb"], ["bane", "Bane"], ["region", "Region"], ["tour", "Tour"]].map(([v, l]) => ({ value: v, label: l }))} value={kind} onChange={setKind} />
    {empty ? <EmptyState icon="user-round" title="Ingen resultater registrert" text="Profilen vises når første tellende runde er hentet." /> : kind === "spiller" ? <>
      <H1 k={P.club + " · Region " + P.region} t={P.name} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,200px),1fr))", gap: 8 }}>{P.keys.map(([k, v, s]) => <div key={k} className="pa-card" style={{ padding: 14, gap: 4 }}><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{k}</span><span style={{ font: "600 22px/1.1 var(--font-mono)" }}>{v}</span><A.Meta s={{ fontSize: 10 }}>{s}</A.Meta></div>)}</div>
      <A.Cols tpl={desk ? "minmax(0,1fr) minmax(0,1.3fr)" : "minmax(0,1fr)"}><div className="pa-card" style={{ padding: 16, gap: 8 }}><A.Head k="Trend · snitt brutto" aside="SISTE 6 MÅNEDER" /><Sparkline values={P.trend} height={72} label="Snitt brutto" /><A.Meta>LAVERE ER BEDRE · {D.src}</A.Meta></div>
        <DataTable caption="Resultater · brutto" rowKey="0" columns={[{ key: "0", label: "Dato", mono: true }, { key: "1", label: "Turnering" }, { key: "2", label: "Brutto", mono: true, align: "right" }, { key: "3", label: "Plass", mono: true, align: "right" }]} rows={P.results.map((r) => ({ ...r }))} /></A.Cols>
    </> : <><H1 k={kind[0].toUpperCase() + kind.slice(1)} t={other[0]} /><div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,200px),1fr))", gap: 8 }}>{other[1].map(([k, v]) => <div key={k} className="pa-card" style={{ padding: 14, gap: 4 }}><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{k}</span><span style={{ font: "600 22px/1.1 var(--font-mono)" }}>{v}</span><A.Meta s={{ fontSize: 10 }}>{D.src}</A.Meta></div>)}</div></>}
  </Site>;
}
window.FO_SCREENS = window.FO_SCREENS || {};
window.FO_SCREENS["ST-01"] = { id: "ST-01", name: "Stats-hub og søk", route: "/statistikk", bare: true, Component: ST01 };
window.FO_SCREENS["ST-02"] = { id: "ST-02", name: "Liste med filter", route: "/statistikk/[liste]", bare: true, Component: ST02 };
window.FO_SCREENS["ST-03"] = { id: "ST-03", name: "Profil/detalj", route: "/statistikk/[type]/[id]", bare: true, Component: ST03 };
window.STP = { Site, H1, DG, vis, d1, sgc };
})();
