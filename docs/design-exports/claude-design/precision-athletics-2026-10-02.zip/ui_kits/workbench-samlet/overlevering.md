# Workbench · samlet trenerverktøy — overlevering (prototype, 02.10.2026)

Hovedlenke: `ui_kits/workbench-samlet/index.html` · tilstander: `tilstander.html` · funksjonsoversikt: knappen «Funksjoner» i appen.
Dette er en klikkbar designprototype med syntetiske data i minnet. Ingen backend, lagring, tilgangsstyring, lenker eller invitasjoner er implementert. Codex eier appkoden.
A–D-referansene i `ui_kits/workbench-retninger/` er urørt. Anders har valgt kombinasjonen av A–D som retning (02.10.2026). Visuell godkjenning av appen gjenstår; bare PH-01 er visuelt godkjent.

Rammer: `desktop.html` (ekte 1440 × 900-iframe) og `mobil.html` (ekte 390 × 844-iframe) med hele appen og Spiller360 i samme ramme.

## Felles kontekst (skall)
- Én navigasjon: Sesongkart · Ukeverksted · Trenerbord · Analyse. Mobil: bunnlinje (Sesong, Uke, Bord, Analyse, Mer).
- Kontekst på tvers: spiller, valgt dato (uke/periode utledes), organisasjonsfilter, sesong. URL-hash `#visning/dato/spiller`.
- Overlegg: Spiller360 · IUP, Gjennomføring (live), Funksjoner. Esc lukker; fokus settes i dialog og tilbake etter lukking.
- Lagringsstatus i toppen («Lagret hh:mm» / «Ikke lagret – prøv igjen»). Alle endringer logges i Historikk.

## Datamodell (syntetisk, felles lager)
- `Season { navn, fra, til }` — eksplisitte datoer (31.08.2026–29.08.2027). Ingen universell uke 43-start. Sesongevaluering som hendelse uka før uke 43 (12.–13.10.2026).
- `Period { id, type ∈ grunn|spesial|turnering|evaluering|ferie|restitusjon, tittel, fra, til, fokus, mal, prio{5 akser}, bud{5 akser: min/uke | null} }` — overlapp avvises.
- `Event { kind ∈ test|samling|evaluering }`, `Tour { fra, til, ut, hjem, hull, land, brutto[], power, powerAar, kilde }` — reise ≠ konkurransedag, Power ≠ ranking.
- `Session { id, pid, dato, fra, til, ax, navn, st ∈ utkast|pub|egen, type ∈ spiller|trener|gruppe, reg: min|null, skip, serie, unntak, grpOf, res, ov[{ n, fokus, reps|min }], meta{ formal, sted, utstyr, metode, press, mal }, inns }` — `reg = null` = ikke registrert (—), `0` = kjent null, fremtid = «kommer». Planlagt fylles aldri inn som registrert. Trenerutkast teller ikke i plan eller sum.
- `Group { id, dato, fra, til, ax, navn, del[pid], adj{ pid: tilpasning } }` + én Session per deltaker (`grpOf`) — ingen dobbelttelling.
- `Busy { type ∈ skole|booking, res }` — skole/reise er rådgivende; booking med samme ressurs er hard kollisjon og holdes tilbake ved publisering.
- `Consent { player × org: aktiv|begrenset|ingen|trukket, omfang }`. Uten deling: ingen data og ingen bidrag til gruppetall.
- `Follow { kind ∈ forslag|registrering|evaluering|test, pid, txt, st }`, `Log { at, who, what, pid }`.
- IUP X11: eksakt tekst fra `kildemateriale/iup-2027-kilde-2026-10-01.json`. 2025-svar beholdes med skala 1–5 og 2025-spørsmålssettet (34/41/41/38), atskilt fra 2027 (34/43/47/38). Sesongevaluering 1–4 i begge.

## Komponenter som bør bli felles
Kontekstlinje, Tidslinje (måned/uke/periodebånd/hendelser/turnering+reise/mengde med timeskala), Månedskalender, Ukekalender (hel = publisert, omriss = spillerens, stiplet = trenerutkast), Øktpanel (flytt/tid/serieomfang/øvelser/detaljer/publiser), Publiseringsdialog (hvem/hva/holdes tilbake), Matrise (spillere × dager, samtykkestyrt), Bulkdialog (gjelder/gjelder ikke + tilpasning), Live-gjennomføring, Spiller360-panel, Analyse/tiltak med A/B og før/etter.

## Foreslått byggerekkefølge
1. Datakontrakt og regler for null/ukjent/kommer/trenerutkast, med tester for summer uten dobbelttelling.
2. Kontekstskall og nivåsti med bevart dato/spiller.
3. Ukeverksted (kalender, øktpanel, publisering, serier, kollisjon).
4. Gjennomføring live → registrert tid → dagbok.
5. Trenerbord (matrise, samtykke, bulk, oppfølging, historikk).
6. Sesongkart (tidslinje, måned, periodeeditor).
7. Analyse til tiltak (A/B, utkast i serie, angre).
8. Spiller360 · IUP X01–X18 mot eksisterende spillereid IUP og samtykkeomfang.

## Uavklart
- Redigerbart i prototypen: X04, X05, X06, X07, X08 (turnering: opprett/rediger, runder × 9/18 hull, reise separat, prioritet, Power/kildeår, forhåndsvisning av uke-/periodepåvirkning, angre), X09, X10 (alle felt per øvelse, oppvarming, varianter, rekkefølge), X11, X12 (katalog → protokoll → råforsøk → resultat → historikk), X14, X15, X16.
- Bevisste lesevisninger: X02/X03 (spilleren eier profil og støtteapparat i PlayerHQ › Meg; trener endrer ikke personopplysninger) og X17/X18 (referansedata forvaltes sentralt og versjoneres; trener velger metode/versjon og sammenligner). Referansene er syntetiske og ikke godkjente normer.
- Turneringstid beregnes fra runder × (18 hull = 4 t 30 min, 9 hull = 2 t 15 min) fordelt på konkurransedager; reisedager gir ikke treningstid. Ingen påmelding eller innsending.
- Dagbok: planlagt = alle publiserte og spillerens egne økter i hele valgt spenn (samme som kalenderen) + turneringsrunder. Registreringsgrad teller bare økter som skulle vært ferdige per nå (prototypens «nå» = fre 2. okt. 2026 kl. 14:20).
- Fullføringsgrad (registrert ÷ planlagt minutter for én økt, f.eks. 45 av 60 = 75 %) og registreringsgrad (antall økter med registrert tid, aggregert) er to ulike tall og vises hver for seg.
- Sesonggrenser per spiller/organisasjon, og plassering av sesongevaluering mot eksplisitt sesong.
- Kilde for ressursbooking og hvem som kan overstyre hard kollisjon.
- Varsling ved publisering/tilbaketrekking.
- WANG/TN: overlevering bare via eksisterende WANG Golf UI prototype og Team Norway App delivery.
