/* Syntetiske data for Workbench-forslag D1. Én spiller, én plan, fast dato. Ingen kobling til appens database. null = ukjent (vises —), 0 = kjent null. */
(() => {
const D = 864e5, P = (s) => { const [y, m, d] = s.split("-").map(Number); return Date.UTC(y, m - 1, d) }, F = (ms) => new Date(ms).toISOString().slice(0, 10), add = (s, n) => F(P(s) + n * D), dow = (s) => (new Date(P(s)).getUTCDay() + 6) % 7, mon = (s) => add(s, -dow(s));
const wkKey = (s) => { const th = P(mon(s)) + 3 * D, y = new Date(th).getUTCFullYear(), w = Math.floor((th - Date.UTC(y, 0, 1)) / D / 7) + 1; return y + "-U" + String(w).padStart(2, "0") };
const MND = ["jan.", "feb.", "mars", "apr.", "mai", "juni", "juli", "aug.", "sep.", "okt.", "nov.", "des."], DAG = ["man", "tir", "ons", "tor", "fre", "lør", "søn"];
const dm = (s) => { const d = new Date(P(s)); return d.getUTCDate() + ". " + MND[d.getUTCMonth()] }, dd = (s) => DAG[dow(s)] + " " + dm(s), yr = (s) => s.slice(0, 4);
const AX = ["fys", "tek", "slag", "spill", "turn"], AXN = { fys: "Fysisk", tek: "Teknisk", slag: "Golfslag", spill: "Spill", turn: "Turnering" }, DUR = { fys: 60, tek: 60, slag: 90, spill: 150, turn: 360 };
const today = "2026-10-01", plan = { id: "plan-26-27", navn: "Sesong 2026/27", fra: "2026-08-31", til: "2027-03-28" }, player = { id: "p1", navn: "Tobias Lindvik" };
const periods = [
 { id: "p1", navn: "Grunnperiode", fra: "2026-08-31", til: "2026-11-22", fokus: "Fysisk base og stabil baksving", mal: "Styrke bein og kjerne 2×/uke; P3–P4 uten kompensasjon", bud: [2, 2, 2, null, null] },
 { id: "p2", navn: "Teknisk periode", fra: "2026-11-23", til: "2027-01-10", fokus: "Overgang P5–P7 og treffpunkt", mal: "Treffpunkt innenfor ±2 cm på 7-jern", bud: [2, 3, 2, 1, null] },
 { id: "p3", navn: "Spesifikk periode", fra: "2027-01-11", til: "2027-02-28", fokus: "Innspill 100–200 m under press", mal: "70 % innenfor målsone på 30 slag", bud: [2, 2, 3, 2, null] },
 { id: "p4", navn: "Konkurranseperiode", fra: "2027-03-01", til: "2027-03-28", fokus: "Spillplan og turnering", mal: "Gjennomføre to turneringsrunder etter spillplan", bud: [1, 1, 3, 3, 0] }];
const events = [
 { id: "e1", navn: "Testuke", fra: "2026-11-09", til: "2026-11-13", type: "Test" },
 { id: "e2", navn: "Heldagssamling", fra: "2026-12-12", til: "2026-12-12", type: "Samling" },
 { id: "e3", navn: "Treningssamling", fra: "2027-01-04", til: "2027-01-08", type: "Samling" },
 { id: "e4", navn: "Turnering", fra: "2027-03-19", til: "2027-03-21", type: "Turnering" }];
const perOf = (s) => periods.find((p) => p.fra <= s && s <= p.til) || null;
const REGF = [1, .83, 1, .67, 1, .92, .75, 1, .83, 1];
const weeks = []; { let i = 0; for (let m = mon(plan.fra); m <= plan.til; m = add(m, 7), i++) {
 const per = perOf(m), key = wkKey(m), til = add(m, 6), past = til < today, cur = m <= today && today <= til, bud = {}, min = {}, reg = {};
 AX.forEach((a, k) => { let b = per.bud[k]; if (a === "tek" && key === "2026-U37") b = null; if (key === "2026-U36") b = null; if (a === "fys" && events[0].fra <= m && m <= events[0].til) b = 0; if (a === "turn" && per.id === "p4") b = (m <= events[3].til && add(m, 6) >= events[3].fra) ? 1 : 0; bud[a] = b; min[a] = b == null ? null : b * DUR[a]; reg[a] = (past && min[a] != null) ? Math.round(min[a] * REGF[i % REGF.length] / 5) * 5 : null });
 if (key === "2026-U37") reg.fys = 0;
 if (cur) { reg.fys = 60; reg.tek = 55; reg.slag = 90; reg.spill = null; reg.turn = null }
 weeks.push({ key, fra: m, til, per: per.id, bud, min, reg, past, cur, future: m > today }) } }
const sessions = [
 { id: "s1", dato: "2026-09-28", ax: "fys", fra: "07:00", til: "08:00", navn: "Styrke bein og kjerne", st: "Publisert", reg: 60, ov: ["Knebøy 4×6", "Markløft 3×5", "Planke 3×45 s"] },
 { id: "s2", dato: "2026-09-29", ax: "tek", fra: "15:30", til: "16:30", navn: "Baksving P3–P4", st: "Publisert", reg: 55, ov: ["Speilovelse 10 min", "Halvsving 20 slag"], pos: "P3.0–P4.0" },
 { id: "s3", dato: "2026-09-30", ax: "slag", fra: "16:00", til: "17:30", navn: "Innspill 100–150 m", st: "Publisert", reg: 90, ov: ["Pyramide 100–150 m", "Målsone 20 slag"] },
 { id: "s4", dato: "2026-10-02", ax: "tek", fra: "09:00", til: "10:00", navn: "Overgang P5–P6", st: "Utkast", reg: null, ov: ["Pause i toppen 15 slag", "Treffpunkt 20 slag"], pos: "P5.0–P6.0" },
 { id: "s5", dato: "2026-10-02", ax: "slag", fra: "15:00", til: "16:30", navn: "Putting 3–10 fot", st: "Utkast", reg: null, ov: ["Ballstart 3 fot", "Lengdekontroll 10 fot"] },
 { id: "s6", dato: "2026-10-03", ax: "spill", fra: "10:00", til: "12:30", navn: "9 hull med mål", st: "Utkast", reg: null, ov: ["9 hull etter spillplan"] }];
const busy = [{ dato: "2026-10-02", fra: "12:00", til: "13:00", navn: "Opptatt · skole" }];
const entries = [
 ["Kildebank", "AG-11-OKT", "Øvelsesbank og kilder"], ["Teknisk plan", "AG-10", "P1.0–P10.0"], ["Fysisk program", "AG-11-FYS", "Sidefelt"], ["Turneringer", "AG-WB-TURN", "Hendelser og runder"],
 ["Målsetninger", "AG-11-MAL", "Resultat- og prosessmål"], ["Volum", "AG-11-VOL", "Kjent delsum og mangler"], ["Stall", "AG-07", "Spillere"], ["Live", "AG-13", "Coachingøkt"]];
window.WBD = { D, P, F, add, dow, mon, wkKey, dm, dd, yr, MND, DAG, AX, AXN, DUR, today, plan, player, periods, events, perOf, weeks, sessions, busy, entries, fri: "2026-10-02" };
})();
