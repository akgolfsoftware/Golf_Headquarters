/* Kandidat 2 · Planbord: perioder som sammenlignbare kolonner; uker som kolonner med fem akser; kalender som egen visning; Flytt eller dra. */
(() => {
const W = window.WBD, K = { id: "planbord", navn: "Planbord" };
K.render = (S, C) => {
 const lv = [["ar", "År", ""], ["periode", "Periode", C.curPer().navn], ["uke", "Uke", "U" + S.wk.slice(-2)], ["okt", "Økt", ""]];
 const rail = `<aside class="rail" aria-label="Innganger">${W.entries.map(([n, id]) => `<button class="ei" data-a="inng" data-v="${id}"><b>${n}</b><small>${id}</small></button>`).join("")}</aside>`;
 const g = C.gate(); let main;
 if (g) main = g; else if (S.level === "ar") main = ar(S, C); else if (S.level === "periode") main = per(S, C); else if (S.level === "uke") main = uke(S, C); else main = `<div class="card">${C.okt()}</div>`;
 const top = `<header class="row" style="justify-content:space-between;align-items:flex-start">${C.who()}${S.mob ? `<button class="btn" data-a="sheet" data-v="inng">Innganger</button>` : ""}</header>${C.crumb(lv)}${C.dirtyBar()}`;
 const sh = S.sheet ? C.sheetBody() : "";
 return top + (S.mob ? `${sh}${main}` : `<div class="shell">${rail}<div style="min-width:0;display:flex;flex-direction:column;gap:12px">${sh}${main}</div></div>`);
};
const card = (p, S, C) => `<article class="pcard${p.id === S.per ? " on" : ""}"><div><h3>${p.navn}</h3><small>${C.range(p.fra, p.til)} · ${W.weeks.filter((w) => w.per === p.id).length} uker</small></div><p style="font-size:13px">${p.fokus}</p>${C.perSumHtml(p.id)}<button class="btn pri" data-a="per" data-v="${p.id}">Åpne periode</button></article>`;
function ar(S, C) {
 const picker = S.mob ? `<div class="strip" style="grid-template-columns:repeat(4,1fr)" role="group" aria-label="Velg periode">${W.periods.map((p, i) => `<button class="${p.id === S.per ? "on" : ""}" data-a="sel" data-v="${p.id}" aria-pressed="${p.id === S.per}">P${i + 1}</button>`).join("")}</div>` : "";
 return `<section><div class="wh" style="margin-bottom:8px"><h2>Perioder side om side</h2><span class="note">${W.events.map((e) => e.navn + " " + W.dm(e.fra)).join(" · ")}</span></div>${picker}<div class="pb-cols" style="${S.mob ? "grid-template-columns:1fr" : ""}">${(S.mob ? [C.curPer()] : W.periods).map((p) => card(p, S, C)).join("")}</div>${C.legend()}</section>`;
}
function per(S, C) {
 const p = C.curPer(), ws = W.weeks.filter((w) => w.per === p.id);
 const head = `<div class="wh"><div><span class="kick">${C.range(p.fra, p.til)}</span><h2>${p.navn}</h2><p class="note">${p.fokus}</p></div><button class="btn" data-a="sheet" data-v="ny-per">Rediger</button></div>`;
 if (S.mob) { const w = C.curWeek().per === p.id ? C.curWeek() : ws[0]; return `${head}<div class="strip" style="grid-template-columns:repeat(${Math.min(ws.length, 7)},1fr)" role="group" aria-label="Velg uke">${ws.slice(0, 7).map((x) => `<button class="${x.key === w.key ? "on" : ""}" data-a="sel" data-v="${x.key}">U${x.key.slice(-2)}</button>`).join("")}</div><div class="card"><h3>Uke ${w.key.slice(-2)} · ${C.range(w.fra, w.til)}</h3>${C.weekCells(w, null)}<button class="btn pri" style="margin-top:8px" data-a="wk" data-v="${w.key}">Åpne uke</button></div>${C.perSumHtml(p.id)}${C.legend()}`; }
 const row = (lab, f) => `<tr><th scope="row" style="text-align:left;font:400 11px var(--font-mono);color:var(--text-secondary)">${lab}</th>${ws.map((w) => `<td>${f(w)}</td>`).join("")}</tr>`;
 return `<section class="card" style="display:flex;flex-direction:column;gap:12px">${head}<table style="width:100%;border-collapse:collapse;table-layout:fixed;font:500 12px var(--font-mono);font-variant-numeric:tabular-nums"><colgroup><col style="width:92px">${ws.map(() => "<col>").join("")}</colgroup><thead><tr><th></th>${ws.map((w) => `<th style="padding:2px"><button class="btn" style="width:100%;padding:0;font-size:12px;min-height:44px" data-a="wk" data-v="${w.key}">U${w.key.slice(-2)}<br><small>${W.dm(w.fra)}</small></button></th>`).join("")}</tr></thead><tbody>${W.AX.map((a) => `<tr><th colspan="${ws.length + 1}" class="a-${a}" style="text-align:left;font:600 12px var(--font-sans);padding-top:8px">${W.AXN[a]}</th></tr>${row("Antall", (w) => C.fmtN(w.bud[a]))}${row("Plan", (w) => C.fmtMin(w.min[a]))}${row("Reg.", (w) => C.regTxt(w, a))}`).join("")}</tbody></table>${C.perSumHtml(p.id)}${C.legend()}</section>`;
}
function uke(S, C) {
 const top = `${C.weekHead()}${C.pubBar()}<div class="seg" role="group" aria-label="Visning"><button class="${S.view !== "kal" ? "on" : ""}" data-a="view" data-v="agenda" aria-pressed="${S.view !== "kal"}">Bord</button><button class="${S.view === "kal" ? "on" : ""}" data-a="view" data-v="kal" aria-pressed="${S.view === "kal"}">Kalender</button></div>`;
 const w = C.curWeek(), days = S.mob ? [S.date] : C.weekDays(), ss = (d) => S.sessions.filter((s) => s.dato === d).sort((a, b) => a.fra.localeCompare(b.fra));
 const board = `${S.mob ? C.dayStrip() : ""}<div class="pbd" style="${S.mob ? "grid-template-columns:1fr" : ""}">${days.map((d) => `<div class="dc${d === S.date ? " on" : ""}" data-drop="${d}" ondragover="event.preventDefault();this.classList.add('over')" ondragleave="this.classList.remove('over')" ondrop="event.preventDefault();window.__dropTo('${d}',event)"><button class="btn" style="font-size:12px;padding:0 6px" data-a="date" data-v="${d}">${W.dd(d)}</button>${ss(d).map((s) => `<div class="scard ax-${s.ax}" draggable="true" ondragstart="event.dataTransfer.setData('text/plain','${s.id}')"><button class="o" data-a="okt" data-v="${s.id}">${s.fra} ${C.esc(s.navn)}</button><div class="row">${C.stChip(s.st)}<button class="btn" data-a="flytt" data-v="${s.id}">Flytt →</button></div></div>`).join("") || `<small>Ingen økter</small>`}</div>`).join("")}</div>`;
 return `${top}${S.view === "kal" ? C.calendar() : board}<section class="card"><h3>Ukens mengde</h3>${C.weekCells(w, C.placed())}</section>`;
}
window.__dropTo = (d, e) => { const id = e.dataTransfer.getData("text/plain"), s = window.__wb.S.sessions.find((x) => x.id === id); if (s && s.dato !== d) { s.dato = d; window.__wb.S.dirty = true; window.__wb.S.toast = "Økt flyttet til " + W.dd(d) + " — ikke lagret"; window.__wb.rend() } };
window.WBK.planbord = K;
})();
