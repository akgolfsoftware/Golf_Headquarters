/* Kandidat 1 · Tidslinje: sesongen dominerer; felles månedsakse for perioder, hendelser og mengde. Detaljpanel bare ved valg. */
(() => {
const W = window.WBD, K = { id: "tidslinje", navn: "Tidslinje" };
const total = (W.P(W.plan.til) - W.P(W.plan.fra)) / W.D + 1, pct = (d) => ((W.P(d) - W.P(W.plan.fra)) / W.D / total * 100), wid = (a, b) => ((W.P(b) - W.P(a)) / W.D + 1) / total * 100;
const months = []; for (let d = W.plan.fra.slice(0, 7) + "-01"; d <= W.plan.til; d = W.F(Date.UTC(+d.slice(0, 4), +d.slice(5, 7), 1))) months.push(d);
K.render = (S, C) => {
 const lv = [["ar", "År", W.plan.fra.slice(0, 4) + "/" + W.plan.til.slice(2, 4)], ["periode", "Periode", C.curPer().navn], ["uke", "Uke", "U" + S.wk.slice(-2)], ["okt", "Økt", S.sid ? "valgt" : ""]];
 const head = `<header class="row" style="justify-content:space-between;align-items:flex-start">${C.who()}<div class="tools"><button class="btn" data-a="sheet" data-v="inng">Innganger</button><button class="btn" data-a="sheet" data-v="bank">Bank</button><button class="btn" data-a="sheet" data-v="maler">Maler</button></div></header>${C.crumb(lv)}`;
 const g = C.gate(); let body;
 if (g) body = g; else if (S.level === "ar") body = S.mob ? ar_m(S, C) : ar_d(S, C); else if (S.level === "periode") body = per(S, C); else if (S.level === "uke") body = uke(S, C); else body = `<div class="card">${C.okt()}</div>`;
 const det = S.sheet && !g ? `<aside>${C.sheetBody()}</aside>` : "";
 return head + C.dirtyBar() + `<div class="main${det ? " det" : ""}"><div style="min-width:0">${body}</div>${det}</div>`;
};
const mx = 700;
function ar_d(S, C) {
 const wkb = W.weeks.map((w) => { const t = W.AX.reduce((s, a) => s + (w.min[a] || 0), 0), kn = W.AX.some((a) => w.min[a] != null); return `<button class="wb" data-a="wk" data-v="${w.key}" aria-label="Uke ${w.key.slice(-2)}, planlagt ${C.fmtMin(kn ? t : null)}" style="left:${pct(w.fra)}%;width:${wid(w.fra, w.til)}%;height:${Math.max(44, t / mx * 84)}px">${kn ? W.AX.map((a) => w.min[a] ? `<i class="i-${a}" style="height:${w.min[a] / mx * 84}px"></i>` : "").join("") : `<span class="unk" style="left:0;right:0"></span>`}</button>` }).join("");
 return `<section class="tl" aria-label="Sesong ${W.plan.navn}"><div class="lab">Måneder</div><div class="ln" style="height:20px">${months.map((m, i) => { const nx = months[i + 1]; if (nx && pct(nx) - Math.max(0, pct(m)) < 4) return ""; return `<span class="mo" style="left:${Math.max(0, pct(m))}%">${W.MND[+m.slice(5, 7) - 1]}${m.slice(5, 7) === "01" ? " " + m.slice(0, 4) : ""}</span>` }).join("")}</div>
 <div style="position:relative"><span class="today" style="left:${pct(W.today)}%" title="I dag ${W.dm(W.today)}"></span>
 <div class="lab">Perioder</div><div class="ln">${W.periods.map((p) => `<button class="pb${p.id === S.per ? " on" : ""}" data-a="per" data-v="${p.id}" style="left:${pct(p.fra)}%;width:${wid(p.fra, p.til)}%" title="${p.navn} ${C.range(p.fra, p.til)}">${p.navn}</button>`).join("")}</div>
 <div class="lab">Hendelser (ikke treningsperioder)</div><div class="ln" style="height:68px">${W.events.map((e) => `<i style="position:absolute;top:0;height:8px;background:var(--text-primary);left:${pct(e.fra)}%;width:${wid(e.fra, e.til)}%"></i><button class="evm" data-a="date" data-v="${e.fra}" style="${pct(e.fra) > 80 ? "right:" + (100 - pct(e.fra) - wid(e.fra, e.til)) + "%;text-align:right" : "left:" + pct(e.fra) + "%;text-align:left"};top:10px;width:auto;min-width:44px;height:44px;border:0;background:none;white-space:nowrap;overflow:visible;padding:0">${e.navn}<br><small>${W.dm(e.fra)}${e.til !== e.fra ? "–" + W.dm(e.til) : ""}</small></button>`).join("")}</div>
 <div class="lab" style="margin-top:4px">Planlagt tid per uke · stablet per akse · prikket = ukjent (uke 36 har ingen satte budsjetter)</div><div class="ln mg">${wkb}</div></div>
 <p class="note" style="margin-top:6px">Bredder følger faktiske datoer. Tall for samme uker står som tabell under Periode. I dag ${W.dm(W.today)}.</p></section>${C.legend()}`;
}
function ar_m(S, C) {
 return `<div class="agenda">${months.map((m) => { const e = W.F(Date.UTC(+m.slice(0, 4), +m.slice(5, 7), 0)), a = m < W.plan.fra ? W.plan.fra : m, ps = W.periods.filter((p) => p.fra <= e && p.til >= a), es = W.events.filter((x) => x.fra <= e && x.til >= a);
  return `<section class="day"><h4>${W.MND[+m.slice(5, 7) - 1]} ${m.slice(0, 4)}</h4>${ps.map((p) => `<button class="wkbtn${p.id === S.per ? " on" : ""}" data-a="per" data-v="${p.id}"><div class="h"><span>${p.navn}</span><small>${C.range(p.fra, p.til)}</small></div><small>${p.fokus}</small></button>`).join("")}${es.map(C.evChip).join("")}</section>` }).join("")}</div>${C.legend()}`;
}
function per(S, C) {
 const p = C.curPer(), ws = W.weeks.filter((w) => w.per === p.id);
 return `<section class="card" style="display:flex;flex-direction:column;gap:10px"><div class="wh"><div><span class="kick">${C.range(p.fra, p.til)} · ${ws.length} uker</span><h2>${p.navn}</h2><p>${p.fokus}</p><p class="note">Mål: ${p.mal}</p></div><div class="row"><button class="btn" data-a="sheet" data-v="per">Detalj</button><button class="btn" data-a="sheet" data-v="ny-per">Rediger</button></div></div>${C.perSumHtml(p.id)}</section>
 <div class="agenda" style="margin-top:12px">${ws.map((w) => `<button class="wkbtn${w.key === S.wk ? " on" : ""}" data-a="wk" data-v="${w.key}"><div class="h"><span>Uke ${w.key.slice(-2)} · ${C.range(w.fra, w.til)}</span><small>${w.cur ? "pågår" : w.future ? "kommer" : "ferdig"}</small></div>${C.weekCells(w, null)}</button>`).join("")}</div>${C.legend()}`;
}
function uke(S, C) {
 const w = C.curWeek();
 return `<div style="display:flex;flex-direction:column;gap:10px">${C.weekHead()}${C.pubBar()}<div class="row" style="justify-content:space-between">${C.viewToggle()}</div>${C.calendar()}<section class="card"><h3>Ukens mengde</h3>${C.weekCells(w, C.placed())}<p class="note" style="margin-top:6px">${C.placed() ? "Antall = budsjett/plassert." : "Plassering ikke åpnet for denne uka i forslaget."}</p></section></div>`;
}
window.WBK.tidslinje = K;
})();
