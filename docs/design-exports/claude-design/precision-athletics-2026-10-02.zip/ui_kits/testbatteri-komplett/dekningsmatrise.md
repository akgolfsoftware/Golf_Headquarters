# Testbatteri · dekningsmatrise 38 + 5 (prototype, kontrollrunde 02.10.2026)

Modul: `ui_kits/testbatteri-komplett/`. Syntetiske spillere A/B/C. Lagring og opplasting er simulert; «Lagret» er ikke backendbevis.
Mål, etiketter, antall og kildeceller kommer fra Codex' lokale uttrekk av Anders' vedlagte NGF v3 (sha256 f9f8ddfeb411b7e2dc84e1935588e7ed950266dda53046e733cbc2d516d03664), lagret uendret i `kilde/ngf-v3-uttrekk.js`. Kildefilene (xlsx/pdf) er **ikke** selvstendig kontrollert i denne prototypen. Språk følger guidelines/treningsplanlegging-master.md (Gjennomført, Lagrer/Lagret/Kunne ikke lagres, «Endringene kunne ikke lagres. Prøv igjen.», «Ingen målinger ennå.», Låst, putting i fot, desimalkomma).

## Filer
index.html · desktop.html (1440) · mobil.html (390) · kilde/ngf-v3-uttrekk.js · katalog.js · calc.js · app.js · screens.js · testdag.js · tb.css. Koblet fra iup-komplett (Stats › Tester og Trener › Tester).

## Rettet i denne runden
- 18-hull-gutter/-jenter: var tegnet som score per hull; uttrekket har mål per slag (m) → PEI-mønster
- standard-sving: oppdiktet standardmål 150 m fjernet; mål = egen medianlengde med 7-jern, registreres i oppsett
- innspill-basis: oppdiktet mål 120 m fjernet; mål registreres per forsøk (ikke i uttrekket)
- Fjernet «Må avklares»-merking der uttrekket gir mål/rekkefølge: golfslag bane gutter/jenter, 18 hull gutter/jenter, wedge variation, PEI St. Leon, St. Cloud, PGA 27, PEI innspill variation, PEI wedge blocked/variation.
- Egenvalgt mål (golfslag-bane-egen, pei-test-bane, pei-slagtest-egen, pei-wedgetest-egen) registreres per forsøk og fylles aldri inn; forsøk uten mål teller ikke.
- Etiketter fra uttrekket vises som mål i scorekortet (f.eks. «<26 (lav) · 40 m ±3», «Slag 27 · fra bunker · 120 m», «Lav · 2 m»).
- Putting vises i fot med omregning fra kildeenhet (m eller cm); kildeverdier og oppsett er uendret. Fysisk ID rettet til fys-club-speed.
- Knapp «Fullfør» → «Marker som gjennomført»; tom tilstand «Ingen målinger ennå.»; sperre → «Låst».
- 8-ball-målrekkefølge var allerede lik uttrekket (kontrollert i appen).

| # | ID | Navn | Forsøk | Skjerm | Mål | Kildecelle (uttrekk) | Status | Fortsatt åpent |
|---|---|---|---|---|---|---|---|---|
| 1 | 8-ball-variation | 8-ball variation | 24 | Scorekort restavstand (m) + neste mål; poeng 0–4 hele; PEI totalt/per type | fra uttrekket (24) | Scorekort GolfslagTester!A4:I35 | Klikkbar | — |
| 2 | 8-ball-blocked | 8-ball blocked | 24 | Scorekort restavstand (m) + neste mål; poeng 0–4 hele; PEI totalt/per type | fra uttrekket (24) | Scorekort GolfslagTester!K4:S35 | Klikkbar | — |
| 3 | golfslag-bane-gutter | Golfslag bane · gutter | 30 | Scorekort rest eller carry+side; PEI % | fra uttrekket (30) | Scorekort GolfslagTester!U4:AG78 | Klikkbar | — |
| 4 | golfslag-bane-jenter | Golfslag bane · jenter | 30 | Scorekort rest eller carry+side; PEI % | fra uttrekket (30) | Scorekort GolfslagTester!U4:AG78 | Klikkbar | — |
| 5 | 18-hull-gutter | 18 hull · gutter | 18 | Scorekort rest eller carry+side; PEI % | fra uttrekket (18) | Scorekort GolfslagTester!BO4:CA53 | Klikkbar | — |
| 6 | 18-hull-jenter | 18 hull · jenter | 18 | Scorekort rest eller carry+side; PEI % | fra uttrekket (18) | Scorekort GolfslagTester!BO4:CA53 | Klikkbar | — |
| 7 | golfslag-bane-egen | Golfslag bane · egen | 30 | Scorekort rest eller carry+side; PEI % | registreres per forsøk | Scorekort GolfslagTester!U86:AG121 | Klikkbar | — |
| 8 | driver-270 | Driver 270 | 5 | Scorekort rest eller carry+side; PEI % | fra uttrekket (5) | Scorekort GolfslagTester!AI4:AR10 | Klikkbar | — |
| 9 | driver-220 | Driver 220 | 5 | Scorekort rest eller carry+side; PEI % | fra uttrekket (5) | Scorekort GolfslagTester!AI15:AR21 | Klikkbar | — |
| 10 | inspill-gutter-145 | Innspill gutter 145 | 5 | Scorekort rest eller carry+side; PEI % | fra uttrekket (5) | Scorekort GolfslagTester!AT4:BC10 | Klikkbar | — |
| 11 | inspill-gutter-160 | Innspill gutter 160 | 5 | Scorekort rest eller carry+side; PEI % | fra uttrekket (5) | Scorekort GolfslagTester!AT15:BC21 | Klikkbar | — |
| 12 | inspill-jenter-125 | Innspill jenter 125 | 5 | Scorekort rest eller carry+side; PEI % | fra uttrekket (5) | Scorekort GolfslagTester!AT26:BC32 | Klikkbar | — |
| 13 | inspill-jenter-145 | Innspill jenter 145 | 5 | Scorekort rest eller carry+side; PEI % | fra uttrekket (5) | Scorekort GolfslagTester!AT37:BC43 | Klikkbar | — |
| 14 | wedge-variation | Wedge variation | 9 | Scorekort rest eller carry+side; PEI % | fra uttrekket (9) | Scorekort GolfslagTester!BE4:BM14 | Klikkbar | — |
| 15 | putt-1-3m | Putt 1–3 m | 25 | Scorekort 1–5+ putter; avstand i fot (m i kilden) | fra uttrekket (25) | Scorekort GolfslagTester!CC4:CI36 | Klikkbar | — |
| 16 | 9-hull-lengde | 9 hull lengde | 9 | Scorekort senket/rest (fot); 6/3/1/0,5/0 | fra uttrekket (9) | Scorekort GolfslagTester!CL4:CR15; Referens!E11:G15 | Klikkbar | Enhet for målserien (meter eller fot): Må avklares før bruk |
| 17 | naerspill-gate | Nærspill Gate | 9 | Scorekort desimalpoeng | etiketter fra uttrekket | Scorekort TeknikTester!A4:F16 | Klikkbar | — |
| 18 | visa-express | VISA Express | 9 | Scorekort desimalpoeng | etiketter fra uttrekket | Scorekort TeknikTester!H4:L16 | Klikkbar | — |
| 19 | wedge-gate | Wedge Gate | 9 | Scorekort to store knapper | etiketter fra uttrekket | Scorekort TeknikTester!A26:F38 | Klikkbar | — |
| 20 | driver-gate | Driver Gate | 6 | Scorekort to store knapper | etiketter fra uttrekket | Scorekort TeknikTester!H26:L35 | Klikkbar | — |
| 21 | putt-gate | Putt Gate | 10 | Scorekort ren gate + lengdesone | etiketter fra uttrekket | Scorekort TeknikTester!N26:S40 | Klikkbar | — |
| 22 | putt-speed-1x5 | Putt Speed 1×5 | 5 | Scorekort cm → fot, kort/lang | fra uttrekket (5) | Scorekort TeknikTester!N4:S12 | Klikkbar | — |
| 23 | putt-speed-3x3 | Putt Speed 3×3 | 9 | Scorekort cm → fot, kort/lang | fra uttrekket (9) | Scorekort TeknikTester!U4:Z16 | Klikkbar | — |
| 24 | pei-test-bane | PEI test bane | 18 | Scorekort rest eller carry+side; PEI % | registreres per forsøk | PEI Test Bane!A3:F22; Forklaring!B4 | Klikkbar | — |
| 25 | pei-slagtest-egen | PEI slagtest egen | 18 | Scorekort rest eller carry+side; PEI % | registreres per forsøk | PEI Tester!A9:G29 | Klikkbar | — |
| 26 | pei-wedgetest-egen | PEI wedgetest egen | 18 | Scorekort rest eller carry+side; PEI % | registreres per forsøk | PEI Tester!I9:O29 | Klikkbar | — |
| 27 | pei-st-leon | PEI St. Leon | 18 | Scorekort rest eller carry+side; PEI % | fra uttrekket (18) | PEI Tester!Q9:W29 | Klikkbar | — |
| 28 | pei-st-cloud | PEI St. Cloud | 18 | Scorekort rest eller carry+side; PEI % | fra uttrekket (18) | PEI Tester!Y9:AE29 | Klikkbar | — |
| 29 | pei-pga27 | PEI PGA 27 | 27 | Scorekort rest eller carry+side; PEI % | fra uttrekket (27) | PEI Tester!AG10:AG36 | Klikkbar | — |
| 30 | pei-inspill-120 | PEI innspill 120 | 5 | Scorekort rest eller carry+side; PEI % | fra uttrekket (5) | PEI Tester!A45:A50 | Klikkbar | — |
| 31 | pei-inspill-160 | PEI innspill 160 | 5 | Scorekort rest eller carry+side; PEI % | fra uttrekket (5) | PEI Tester!A51:A56 | Klikkbar | — |
| 32 | pei-inspill-variation | PEI innspill variation | 10 | Scorekort rest eller carry+side; PEI % | fra uttrekket (10) | PEI Tester!A57:A67 | Klikkbar | — |
| 33 | pei-wedge-blocked | PEI wedge blocked | 9 | Scorekort rest eller carry+side; PEI % | fra uttrekket (9) | PEI Tester!I35:I44 | Klikkbar | — |
| 34 | pei-wedge-variation | PEI wedge variation | 9 | Scorekort rest eller carry+side; PEI % | fra uttrekket (9) | PEI Tester!I45:I54 | Klikkbar | — |
| 35 | standard-sving | Standard sving 7-jern | 10 | Scorekort carry/side mot egen medianlengde (+ tilpasset mål) | egen medianlengde (registreres) | PEI Tester!A34:A44 | Klikkbar | — |
| 36 | teknikktest-a | Teknikktest A | 15 | Scorekort 7 felt + hastighet ball/kølle + impact | — | Teknikktest!B1:N20 | Klikkbar | Impact location: enhet og metode Må avklares før bruk |
| 37 | teknikktest-b | Teknikktest B | 15 | Scorekort 7 felt + hastighet ball/kølle + impact | — | Teknikktest!R1:AD20 | Klikkbar | Impact location: enhet og metode Må avklares før bruk |
| 38 | teknikktest-c | Teknikktest C | 10 | Scorekort 7 felt + hastighet ball/kølle + impact | — | Teknikktest!AG1:AS20 | Klikkbar | Impact location: enhet og metode Må avklares før bruk |
| F1 | fys-benkpress | Benkpress | 1 | Scorekort råverdi; låst for gjennomført | — | Anders28.09 og WANG6-årsløp C47/C61; ikke vedlagt TNv3 | Klikkbar (utkast), låst | Belastning, repetisjoner og validitetsprotokoll: Må avklares før bruk · fullføring sperret |
| F2 | fys-trapbar | Trapbar markløft | 1 | Scorekort råverdi; låst for gjennomført | — | Anders28.09 og WANG6-årsløp C47/C61; ikke vedlagt TNv3 | Klikkbar (utkast), låst | Belastning, repetisjoner og validitetsprotokoll: Må avklares før bruk · fullføring sperret |
| F3 | fys-lengdehopp | Stille lengdehopp | 1 | Scorekort råverdi; låst for gjennomført | — | Anders28.09 og WANG6-årsløp C47/C61; ikke vedlagt TNv3 | Klikkbar (utkast), låst | Belastning, repetisjoner og validitetsprotokoll: Må avklares før bruk · fullføring sperret |
| F4 | fys-rotasjonskast | Rotasjonskast | 1 | Scorekort råverdi; låst for gjennomført | — | Anders28.09 og WANG6-årsløp C47/C61; ikke vedlagt TNv3 | Klikkbar (utkast), låst | Belastning, repetisjoner og validitetsprotokoll: Må avklares før bruk · fullføring sperret |
| F5 | fys-club-speed | Club Speed (driver) | 1 | Scorekort råverdi; låst for gjennomført | — | Anders28.09 og WANG6-årsløp C47/C61; ikke vedlagt TNv3 | Klikkbar (utkast), låst | Belastning, repetisjoner og validitetsprotokoll: Må avklares før bruk · fullføring sperret |
| + | innspill-basis | Innspill Basis (gjennomføringsoppgave) | 10 | Scorekort 2 × 5; delresultat per serie med kilde-ID | gutter 5 × 145 + 5 × 160 m, jenter 5 × 125 + 5 × 145 m (fra inspill-gutter-145/-160, inspill-jenter-125/-145) | via de fire inspill-variantene | Klikkbar | — (tilpasset målavstand per serie er nevner i PEI; standard vises som referanse; merket «Tilpasset målavstand», ikke sammenlignbar med standardserien) |

## Fortsatt åpne valg
- 9 hull lengde: original enhet for målserien 5, 7, 11, 9, 6, 10, 8, 7, 9 (uttrekket: awaiting-target-unit).
- Teknikktest A/B/C: Impact Location-metode/enhet (uttrekket: partially-specified, ingen mål).
- Fysisk (5): protokoll, belastning, repetisjoner (uttrekket: awaiting-physical-protocol; kilde ikke vedlagt TN v3).
- Felles livepublikum/rangering: ikke besluttet; ikke vist.

## Kontroll (fanen Kontroll) — 18 av 18 OK
Innspill Basis gutter (4 % / 3,6 %), jenter (4 % / 3,4 %), tilpasset: standard 145, faktisk 150, carry 144, side 0 → 6/150 = 4 %.
PEI 0,032 → 3,2 % · Driver 270: 8,64/270 = 3,2 % · 0,05 → 5 % · 1,6 → 160 % · 8-ball-grenser 4/3/2/1/0 · 24 × 1 m = 48 av 96 · 8-ball målrekkefølge = uttrekket · antall per ID = uttrekket · egenvalgt mål fylles ikke inn · manuelle 12,5 · Driver Gate 3 av 6 · Putt Gate ren men lang · Putt Speed 10/10 cm = 0,33 fot · Teknikk C 10 · tomt ≠ 0 · carry+side 4,2 %.
