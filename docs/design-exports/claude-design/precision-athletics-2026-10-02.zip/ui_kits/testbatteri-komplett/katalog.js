/* Testbatteri · katalog over 38 varianter + 5 fysiske, med mønster og avklaringsstatus. Kildene (NGF v3, testbeskrivelse 2026) er ikke kontrollert i denne prototypen; detaljer som ikke står i bestillingen er merket «må avklares». */
(() => {
const T8 = [["Chip", 10], ["Chip", 30], ["Wedge", 20], ["Wedge", 40], ["Lobb", 15], ["Lobb", 25], ["Bunker", 10], ["Bunker", 20]];
const seq8 = (blocked) => blocked ? T8.flatMap((t) => [t, t, t]) : [...T8, ...T8, ...T8];
const V = (id, navn, mon, n, x = {}) => ({ id, navn, mon, n, ver: "v3", ...x });
const MA = "Må avklares før bruk";
const vars = [
 V("8-ball-variation", "8-ball variation", "P8", 24, { seq: seq8(false), info: "Hele 8-serien tre ganger." }),
 V("8-ball-blocked", "8-ball blocked", "P8", 24, { seq: seq8(true), info: "Hver slagtype tre ganger etter hverandre." }),
 V("golfslag-bane-gutter", "Golfslag bane · gutter", "PEI", 30, { av: [MA + ": slagtyper og mål per slag ikke kontrollert mot kilden"] }),
 V("golfslag-bane-jenter", "Golfslag bane · jenter", "PEI", 30, { av: [MA + ": slagtyper og mål per slag ikke kontrollert mot kilden"] }),
 V("18-hull-gutter", "18 hull · gutter", "PEI", 18),
 V("18-hull-jenter", "18 hull · jenter", "PEI", 18),
 V("golfslag-bane-egen", "Golfslag bane · egen", "PEI", 30),
 V("driver-270", "Driver 270", "PEI", 5, { mal: 270, carry: true }), V("driver-220", "Driver 220", "PEI", 5, { mal: 220, carry: true }),
 V("inspill-gutter-145", "Innspill gutter 145", "PEI", 5, { mal: 145, carry: true }), V("inspill-gutter-160", "Innspill gutter 160", "PEI", 5, { mal: 160, carry: true }), V("inspill-jenter-125", "Innspill jenter 125", "PEI", 5, { mal: 125, carry: true }), V("inspill-jenter-145", "Innspill jenter 145", "PEI", 5, { mal: 145, carry: true }),
 V("wedge-variation", "Wedge variation", "PEI", 9, { av: [MA + ": avstandsrekkefølge"] }),
 V("putt-1-3m", "Putt 1–3 m", "P13", 25, { dist: [1, 1.5, 2, 2.5, 3] }),
 V("9-hull-lengde", "9 hull lengde", "P9H", 9, { mal9: [5, 7, 11, 9, 6, 10, 8, 7, 9], av: ["Enhet for målserien (meter eller fot): " + MA] }),
 V("naerspill-gate", "Nærspill Gate", "MAN", 9), V("visa-express", "VISA Express", "MAN", 9),
 V("wedge-gate", "Wedge Gate", "GATE", 9, { lab: ["Treff", "Ikke treff"] }), V("driver-gate", "Driver Gate", "GATE", 6, { lab: ["Godkjent", "Ikke godkjent"] }),
 V("putt-gate", "Putt Gate", "PGATE", 10), V("putt-speed-1x5", "Putt Speed 1×5", "SPEED", 5, { malm: [3, 3, 3, 3, 3] }), V("putt-speed-3x3", "Putt Speed 3×3", "SPEED", 9, { malm: [3, 3, 3, 5, 5, 5, 7, 7, 7] }),
 V("pei-test-bane", "PEI test bane", "PEI", 18, { valgbar: true }), V("pei-slagtest-egen", "PEI slagtest egen", "PEI", 18), V("pei-wedgetest-egen", "PEI wedgetest egen", "PEI", 18), V("pei-st-leon", "PEI St. Leon", "PEI", 18, { av: [MA + ": målserie"] }), V("pei-st-cloud", "PEI St. Cloud", "PEI", 18, { av: [MA + ": målserie"] }), V("pei-pga27", "PEI PGA 27", "PEI", 27, { av: [MA + ": målserie"] }),
 V("pei-inspill-120", "PEI innspill 120", "PEI", 5, { mal: 120, carry: true }), V("pei-inspill-160", "PEI innspill 160", "PEI", 5, { mal: 160, carry: true }), V("pei-inspill-variation", "PEI innspill variation", "PEI", 10, { av: [MA + ": målserie"] }), V("pei-wedge-blocked", "PEI wedge blocked", "PEI", 9, { av: [MA + ": målserie"] }), V("pei-wedge-variation", "PEI wedge variation", "PEI", 9, { av: [MA + ": målserie"] }),
 V("standard-sving", "Standard sving 7-jern", "SV", 10),
 V("teknikktest-a", "Teknikktest A", "TEK", 15, { grunn: 5 }), V("teknikktest-b", "Teknikktest B", "TEK", 15, { grunn: 5 }), V("teknikktest-c", "Teknikktest C", "TEK", 10, { grunn: 5 }),
 V("fys-benkpress", "Benkpress", "FYS", 1, { enh: "kg", ver: "Fysisk batteri" }), V("fys-trapbar", "Trapbar markløft", "FYS", 1, { enh: "kg", ver: "Fysisk batteri" }), V("fys-lengdehopp", "Stille lengdehopp", "FYS", 1, { enh: "cm", ver: "Fysisk batteri" }), V("fys-rotasjonskast", "Rotasjonskast", "FYS", 1, { enh: "m", ver: "Fysisk batteri" }), V("fys-club-speed", "Club Speed (driver)", "FYS", 1, { enh: "mph", ver: "Fysisk batteri" }),
 V("innspill-basis", "Innspill Basis (gjennomføringsoppgave, utenfor de 38)", "INN", 10, { carry: true, basis: { gutter: ["inspill-gutter-145", "inspill-gutter-160"], jenter: ["inspill-jenter-125", "inspill-jenter-145"] } })];
vars.filter((v) => v.mon === "FYS").forEach((v) => { v.av = ["Belastning, repetisjoner og validitetsprotokoll: " + MA + " · fullføring sperret"] });
vars.find((v) => v.id === "teknikktest-a").av = vars.find((v) => v.id === "teknikktest-b").av = vars.find((v) => v.id === "teknikktest-c").av = ["Impact location: enhet og metode " + MA];
const MON = { P8: "8-ball: rest (m) → 0–4 hele poeng, PEI totalt og per type", PEI: "PEI: rest ÷ mål per slag (rest = hypot(mål − carry, side) ved carry + side)", BANE: "Score per hull", P13: "Antall putter til hullet per forsøk", P9H: "Senket eller rest (fot) → 6 / 3 / 1 / 0,5 / 0 poeng", MAN: "Manuelle poeng, desimaler bevares", GATE: "Godkjent eller ikke", PGATE: "Godkjent krever ren gate og lengdesone", SPEED: "Absolutt rest til mållinjen (cm), kort/lang separat", SV: "Carry og side mot standardmål (+ tilpasset mål)", TEK: "Grunnmålinger + måleforsøk, 8 felt", FYS: "Råverdi og enhet", INN: "2 serier × 5 slag, delresultat per serie" };
const players = [{ id: "A", navn: "Spiller A (syntetisk)", skole: "wo", tn: ["tnj"] }, { id: "B", navn: "Spiller B (syntetisk)", skole: "wb", tn: [] }, { id: "C", navn: "Spiller C (syntetisk)", skole: null, tn: ["tnj"] }];
const SRC = window.TBSRC, diff = [], missing = [], decH = (s) => s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
diff.push("18-hull-gutter/-jenter: var tegnet som score per hull; uttrekket har mål per slag (m) → PEI-mønster");
diff.push("standard-sving: oppdiktet standardmål 150 m fjernet; mål = egen medianlengde med 7-jern, registreres i oppsett");
diff.push("innspill-basis: oppdiktet mål 120 m fjernet; standard = 2 × 5 slag fra uttrekkets inspill-varianter (gutter 145 + 160 m, jenter 125 + 145 m); eget mål merkes som avvik");
if (SRC) SRC.protocols.forEach((p) => { const v = vars.find((x) => x.id === p.id); if (!v) { missing.push(p.id); return } v.src = p.source; v.status = p.status;
 if (p.count != null && p.count !== v.n) { diff.push(p.id + ": antall " + v.n + " → " + p.count); v.n = p.count }
 if (p.labels.length) v.labels = p.labels.map(decH);
 if (p.targets.length) { v.tg = p.targets;
  if (v.mon === "P8") { const old = v.seq.map((x) => x[1]).join(); if (old !== p.targets.join()) diff.push(p.id + ": målrekkefølge rettet"); v.seq = p.labels.map((l, i) => [l.replace(/\d+$/, ""), p.targets[i]]) }
  if (v.mal != null && p.targets.some((t) => t !== v.mal)) diff.push(p.id + ": mål " + v.mal + " avviker fra uttrekket");
  if (["PEI", "SV"].includes(v.mon) && p.targets.every((t) => t == null)) { if (v.mon === "SV") v.egenMedian = true; else v.egenAtt = true } }
 if (p.status === "specified" && v.av) { v.av = v.av.filter((x) => !/målserie|slagtyper|scoreregel|avstandsrekkefølge/.test(x)); if (!v.av.length) delete v.av } });
window.TBK = { diff, missing, srcSha: SRC ? SRC.sourceSha256 : null,  vars, MON, players, T8, MA, schools: { wo: "WANG Oslo (syntetisk)", wb: "WANG Bergen (syntetisk)" }, groups: { tnj: "Team Norway junior (syntetisk)" } };
})();
