# 8-ball · korrigert poengregel (02.10.2026)

Gjelder bare 8-ball. Nedre grense er inkludert, slik Excel er satt opp:
- rest under 0,1 m (fra 0 til under 0,1) → 4
- fra 0,1 m til under 1 m → 3
- fra 1 m til under 2 m → 2
- fra 2 m til under 3 m → 1
- 3 m eller mer → 0

Fasit: 0,099 / 0,1 / 1 / 2 / 3 m gir 4 / 3 / 2 / 1 / 0. 24 restavstander på 1 m gir 48 av 96. Bare hele poeng.
9 hull beholder vedtatte grenser (senket/≤0,1 fot 6, ≤1 fot 3, ≤2 fot 1, ≤4 fot 0,5, ellers 0).

Status: kun beregningsfunksjonen (calc.js) er rettet. Skjermene for testbatteri-komplett er ikke bygget ennå. Resten av testbestillingen er ikke startet.
