/* Workbench — fire nye retninger · felles syntetisk case og hjelpere. Ingen kobling til appens data. */
(() => {
const D = 864e5, P = (s) => { const [y, m, d] = s.split("-").map(Number); return Date.UTC(y, m - 1, d) }, F = (ms) => new Date(ms).toISOString().slice(0, 10);
const add = (s, n) => F(P(s) + n * D), dow = (s) => (new Date(P(s)).getUTCDay() + 6) % 7, mon = (s) => add(s, -dow(s)), diff = (a, b) => Math.round((P(b) - P(a)) / D);
const wkn = (s) => { const th = P(mon(s)) + 3 * D, y = new Date(th).getUTCFullYear(); return { y, n: Math.floor((th - Date.UTC(y, 0, 1)) / D / 7) + 1 } };
const wkKey = (s) => { const w = wkn(s); return w.y + "-U" + String(w.n).padStart(2, "0") };
const MND = ["jan.", "feb.", "mars", "apr.", "mai", "juni", "juli", "aug.", "sep.", "okt.", "nov.", "des."], MNDL = ["januar", "februar", "mars", "april", "mai", "juni", "juli", "august", "september", "oktober", "november", "desember"];
const DAG = ["man", "tir", "ons", "tor", "fre", "lør", "søn"], DAGL = ["mandag", "tirsdag", "onsdag", "torsdag", "fredag", "lørdag", "søndag"];
const dm = (s) => { const d = new Date(P(s)); return d.getUTCDate() + ". " + MND[d.getUTCMonth()] }, dd = (s) => DAG[dow(s)] + " " + dm(s), ddl = (s) => DAGL[dow(s)] + " " + dm(s);
const rng = (a, b) => dm(a) + (a.slice(0, 4) !== b.slice(0, 4) ? " " + a.slice(0, 4) : "") + "–" + dm(b) + " " + b.slice(0, 4);
const AX = ["fys", "tek", "slag", "spill", "turn"], AXN = { fys: "Fysisk", tek: "Teknisk", slag: "Golfslag", spill: "Spill", turn: "Turnering" }, AXS = { fys: "Fys", tek: "Tek", slag: "Slag", spill: "Spill", turn: "Turn" };
const TODAY = "2026-10-02", SEASON = { navn: "Sesong 2026/27", fra: "2026-08-31", til: "2027-08-29" };
const PT = { grunn: "Grunnperiode", spesial: "Spesialperiode", turnering: "Turneringsperiode", evaluering: "Evaluering", ferie: "Ferie", restitusjon: "Restitusjon" };
const periods = [
 { id: "p1", type: "grunn", tittel: "Base høst", fra: "2026-08-31", til: "2026-11-22", fokus: "Fysisk base og stabil baksving", mal: "Innspill 100–150 m: snitt ≤ 6,0 m fra hull innen mars 2027" },
 { id: "p2", type: "spesial", tittel: "Teknikk vinter", fra: "2026-11-23", til: "2026-12-20", fokus: "Overgang P5.0–P7.0 og treffpunkt", mal: "Treffpunkt innenfor ±2 cm på 7-jern" },
 { id: "p3", type: "ferie", tittel: "Jul", fra: "2026-12-21", til: "2027-01-03", fokus: "Fri, valgfri fysisk aktivitet", mal: "—" },
 { id: "p4", type: "spesial", tittel: "Innspill under press", fra: "2027-01-04", til: "2027-02-28", fokus: "Innspill 100–200 m med mål og press", mal: "70 % innenfor målsone på 30 slag" },
 { id: "p5", type: "turnering", tittel: "Vårsesong", fra: "2027-03-01", til: "2027-06-27", fokus: "Spillplan og turneringsrutiner", mal: "Brutto snitt ≤ 74 i turnering" },
 { id: "p6", type: "restitusjon", tittel: "Sommerpause", fra: "2027-06-28", til: "2027-07-18", fokus: "Restitusjon", mal: "—" },
 { id: "p7", type: "turnering", tittel: "Sommer", fra: "2027-07-19", til: "2027-08-15", fokus: "Turneringsform", mal: "—" },
 { id: "p8", type: "evaluering", tittel: "Sesongevaluering", fra: "2027-08-16", til: "2027-08-29", fokus: "Evaluering og ny plan", mal: "—" }];
const events = [
 { id: "e1", kind: "test", navn: "Testdag golfslag", fra: "2026-10-14", til: "2026-10-14", info: "Innspill Basic, Driver Basic · retest" },
 { id: "e2", kind: "test", navn: "Fystest", fra: "2026-11-11", til: "2026-11-11", info: "Standard batteri" },
 { id: "e3", kind: "samling", navn: "Treningssamling", fra: "2027-01-11", til: "2027-01-15", info: "Spania" },
 { id: "e4", kind: "test", navn: "Testdag golfslag", fra: "2027-02-24", til: "2027-02-24", info: "Retest Innspill Basic" }];
const tours = [
 { id: "t0", navn: "Sesongavslutning (syntetisk)", fra: "2026-09-18", til: "2026-09-20", ut: "2026-09-17", hjem: "2026-09-20", hull: 54, land: "Norge", brutto: [74, 76, 72], power: 30.5, powerAar: 2025, kilde: "WAGR (syntetisk)" },
 { id: "t1", navn: "Høstturnering (syntetisk)", fra: "2026-10-16", til: "2026-10-18", ut: "2026-10-15", hjem: "2026-10-19", hull: 54, land: "Danmark", brutto: null, power: 33.0, powerAar: 2025, kilde: "WAGR (syntetisk)" },
 { id: "t2", navn: "Vårturnering (syntetisk)", fra: "2027-03-19", til: "2027-03-21", ut: "2027-03-18", hjem: "2027-03-21", hull: 54, land: "Norge", brutto: null, power: null, powerAar: null, kilde: null },
 { id: "t3", navn: "Sommerturnering (syntetisk)", fra: "2027-07-23", til: "2027-07-25", ut: "2027-07-22", hjem: "2027-07-26", hull: 54, land: "Sverige", brutto: null, power: 36.0, powerAar: 2026, kilde: "WAGR (syntetisk)" }];
const sessions = [
 { id: "s1", dato: "2026-09-28", fra: "07:00", til: "08:00", ax: "fys", navn: "Styrke bein og kjerne", st: "pub", reg: 60 },
 { id: "s2", dato: "2026-09-29", fra: "15:30", til: "16:30", ax: "tek", navn: "Baksving P3.0–P4.0", st: "pub", reg: 55 },
 { id: "s3", dato: "2026-09-30", fra: "16:00", til: "17:30", ax: "slag", navn: "Innspill 100–150 m", st: "pub", reg: 90 },
 { id: "s4", dato: "2026-10-01", fra: "15:00", til: "16:00", ax: "slag", navn: "Putting 3–10 fot", st: "pub", reg: null },
 { id: "s5", dato: "2026-10-02", fra: "09:00", til: "10:00", ax: "tek", navn: "Overgang P5.0–P6.0", st: "pub", reg: 45, case: true },
 { id: "s6", dato: "2026-10-02", fra: "15:00", til: "16:30", ax: "slag", navn: "Wedge 50–90 m", st: "utkast", reg: null },
 { id: "s7", dato: "2026-10-03", fra: "10:00", til: "12:30", ax: "spill", navn: "9 hull med mål", st: "egen", reg: null }];
const busy = [{ dato: "2026-10-02", fra: "12:00", til: "13:00", navn: "Skole" }];
const tm = (t) => { const [h, m] = t.split(":").map(Number); return h * 60 + m }, dur = (s) => tm(s.til) - tm(s.fra);
const BASE = { grunn: { fys: 180, tek: 150, slag: 240, spill: 150, turn: 0 }, spesial: { fys: 120, tek: 240, slag: 270, spill: 120, turn: 0 }, ferie: { fys: 60, tek: 0, slag: 0, spill: 0, turn: 0 }, turnering: { fys: 90, tek: 90, slag: 180, spill: 240, turn: 0 }, restitusjon: { fys: 60, tek: 0, slag: 60, spill: 0, turn: 0 }, evaluering: { fys: 60, tek: 60, slag: 90, spill: 90, turn: 0 } };
const VAR = [1, .9, 1.1, .85, 1, 1.05, .95], RF = [1, .85, .95, .7, 1, .9, .8, 1];
const perOf = (s) => periods.find((p) => p.fra <= s && s <= p.til);
const r5 = (x) => Math.round(x / 5) * 5;
const weeks = []; { let i = 0; for (let m = SEASON.fra; m <= SEASON.til; m = add(m, 7), i++) {
 const til = add(m, 6), p = perOf(m), key = wkKey(m), plan = {}, reg = {}, past = til < TODAY, cur = m <= TODAY && TODAY <= til;
 AX.forEach((a) => { plan[a] = r5(BASE[p.type][a] * VAR[i % 7]); });
 tours.forEach((t) => { if (t.fra <= til && t.til >= m) plan.turn = Math.round(t.hull / 18) * 270 });
 if (cur) { AX.forEach((a) => { plan[a] = sessions.filter((s) => s.ax === a && s.st !== "utkast").reduce((x, s) => x + dur(s), 0) }); plan.turn = 0 }
 AX.forEach((a) => { reg[a] = past ? r5(plan[a] * RF[(i + a.length) % 8]) : null });
 if (cur) AX.forEach((a) => { const ss = sessions.filter((s) => s.ax === a && s.st === "pub" && s.dato <= TODAY && s.reg != null); reg[a] = ss.reduce((x, s) => x + s.reg, 0) });
 weeks.push({ i, key, n: +key.slice(-2), fra: m, til, per: p.id, plan, reg, past, cur, future: m > TODAY }) } }
const tot = (o) => AX.reduce((s, a) => s + (o[a] || 0), 0);
const fm = (m) => m == null ? "—" : m === 0 ? "0" : m < 60 ? m + " min" : (m % 60 ? Math.floor(m / 60) + " t " + (m % 60) + " min" : m / 60 + " t");
const fh = (m) => m == null ? "—" : m === 0 ? "0" : String(Math.round(m / 6) / 10).replace(".", ",") + " t";
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
const players = [
 { id: "tl", navn: "Tobias Lindvik", init: "TL", grp: "Elite junior", tilgang: "aktiv", note: "Valgt case" },
 { id: "es", navn: "Emma Solberg", init: "ES", grp: "Elite junior", tilgang: "aktiv" },
 { id: "jb", navn: "Jonas Berg", init: "JB", grp: "Elite junior", tilgang: "begrenset", note: "Deler plan, ikke tid" },
 { id: "sk", navn: "Sara Kvam", init: "SK", grp: "Elite junior", tilgang: "aktiv" },
 { id: "om", navn: "Ola Moen", init: "OM", grp: "Elite junior", tilgang: "ingen", note: "Gruppemedlem uten deling" }];
const analysis = {
 obs: { id: "o1", tittel: "Innspill 100–150 m", omr: "slag", tekst: "Snitt avstand til hull etter innspill 100–150 m" },
 tests: [{ dato: "2026-05-12", v: 7.8, n: 20 }, { dato: "2026-07-02", v: 7.1, n: 20 }, { dato: "2026-09-01", v: 7.4, n: 20 }],
 runder: { sg: -0.42, runder: 6, slag: 38, kilde: "Egen registrering 2026", vindu: "jun.–sep. 2026" },
 mal: { tekst: "Snitt ≤ 6,0 m fra hull", frist: "2027-03-01", kilde: "Prosessmål fra sesongevaluering" },
 neste: "2026-10-14" };
const CTX = { D, P, F, add, dow, mon, diff, wkKey, wkn, MND, MNDL, DAG, DAGL, dm, dd, ddl, rng, AX, AXN, AXS, TODAY, SEASON, PT, periods, events, tours, sessions, busy, tm, dur, weeks, perOf, tot, fm, fh, esc, players, analysis, SEL: "2026-10-02", PLAYER: "Tobias Lindvik" };
CTX.weekOf = (d) => weeks.find((w) => w.fra <= d && d <= w.til);
CTX.stLab = { pub: "Publisert", egen: "Eget", utkast: "Trenerutkast" };
CTX.tourDays = (t) => { const c = diff(t.fra, t.til) + 1, r = diff(t.ut, t.hjem) + 1 - c; return { c, r } };
CTX.chip = (a, txt) => `<span class="ax ax-${a}"><i></i>${txt || AXN[a]}</span>`;
CTX.state = new URLSearchParams(location.search).get("state");
CTX.stateView = (k) => ({ tom: `<div class="stv"><b>Ingen plan for sesongen ennå</b><p>Opprett første periode, eller start fra en mal. Spiller, sesong og dato er beholdt.</p><div class="row"><button class="b pri">Ny periode</button><button class="b">Bruk mal</button></div></div>`,
 lagringsfeil: `<div class="stv err" role="alert"><b>Endringen ble ikke lagret</b><p>«Overgang P5.0–P6.0» er fortsatt flyttet lokalt. Ingenting er publisert. Prøv igjen, eller angre flyttingen.</p><div class="row"><button class="b pri">Prøv igjen</button><button class="b">Angre</button></div></div>`,
 "ingen-tilgang": `<div class="stv"><b>Ingen tilgang til Ola Moen</b><p>Gruppemedlemskap gir ikke innsyn. Spilleren må dele med organisasjonen før plan og tid vises.</p></div>` })[k] || "";
CTX.toast = (root, msg, undo) => { let t = root.querySelector(".toast"); if (t) t.remove(); t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status"); t.innerHTML = `<span>${esc(msg)}</span>${undo ? `<button class="b inv">Angre</button>` : ""}`; root.appendChild(t); if (undo) t.querySelector("button").onclick = () => { undo(); t.remove() }; setTimeout(() => t.remove(), 6000) };
CTX.top = (o) => `<header class="top"><div class="brand"><span class="k">AK Golf HQ</span><b>Workbench</b></div><div class="who"><button class="pl" aria-label="Bytt spiller"><span class="av">TL</span><span><b>${CTX.PLAYER}</b><small>${SEASON.navn}</small></span></button></div>${o.crumb || ""}<div class="tact">${o.act || ""}</div></header>`;
CTX.crumb = (lv, d) => { const w = CTX.weekOf(d), p = perOf(d); const L = [["ar", "År", "2026/27"], ["per", "Periode", p ? p.tittel : "—"], ["mnd", "Måned", MNDL[+d.slice(5, 7) - 1]], ["uke", "Uke", w ? String(w.n) : "—"], ["okt", "Økt", ""]]; return `<nav class="crumb" aria-label="Nivå">${L.map(([k, t, v]) => `<button data-lv="${k}" class="${lv === k ? "on" : ""}" aria-current="${lv === k}"><small>${t}</small>${v ? `<b>${esc(v)}</b>` : ""}</button>`).join("")}</nav>` };
const VW = +new URLSearchParams(location.search).get("vw") || 0;
CTX.vw = () => VW || innerWidth;
CTX.fit = (root) => { if (!VW) return; root.style.width = VW + "px"; root.style.minHeight = (VW < 600 ? 844 : 900) + "px"; root.style.setProperty("--vh", (VW < 600 ? 844 : 900) + "px"); const s = Math.min(1, document.documentElement.clientWidth / VW); root.style.transform = s < 1 ? "scale(" + s + ")" : "translateZ(0)"; root.style.height = (VW < 600 ? 844 : 900) + "px"; root.style.overflow = "auto"; root.style.transformOrigin = "0 0"; document.body.style.overflowX = "hidden" };
window.WB4 = { ctx: CTX, k: {} };
})();
