# Navngitt trenerdeling · overlevering (02.10.2026)

Prototype, syntetiske personer, ingen ekte e-post, ingen backend. Utkast, ikke visuelt godkjent. Inngang: PlayerHQ › Meg › Deling › «Åpne navngitt deling» (ingen ny hovedfane).

## Filer
- `index.html` (modul), `desktop.html` (iframe 1440 × 900), `mobil.html` (iframe 390 × 844), `reiser.html` (12 direkte reiser/tilstander)
- `dn.js` (all logikk og tilstand), `dn.css` (stil på Precision-tokens)
- Spørsmål: `kildemateriale/iup-2027-kilde-2026-10-01.json` (2027) og `ui_kits/_shared/data-iup.js` (2025, 34/41/41/38)

## Regler i prototypen
- Spilleren eier IUP og deler hele PlayerHQ-profilen (profil, Mitt team, helse, meldinger, IUP, mål/plan/dagbok, tester) med én navngitt person.
- Under 16: foresatt må godkjenne (status «Venter på foresatt»). Spilleren kan selv trekke tilbake.
- Trenerens e-post må ha eksakt domene: wang.no for WANG-miljø, golfforbundet.no for Team Norway-miljø. Underdomene (team.golfforbundet.no) avvises.
- Aksept krever: gyldig lenke (≤ 7 dager, ikke trukket), innlogget og bekreftet e-post, samme e-post som invitert, aktiv tilknytning til valgt skole/TN-miljø. Lenken alene gir aldri tilgang.
- WANG-elev kan dele med Team Norway uten TN-medlemskap.
- Trekk tilbake: status Trukket straks; trenerens innsyn sjekkes ved hver visning og viser «Tilgang stengt», også i åpen leser.
- Innsyn viser bare leverte besvarelser med originalspørsmål: kildeår, nivå, periode, skala (utviklingssjekk 1–5 i 2025 og 2027; sesongevaluering 1–4). Utkast vises aldri. 2025 og 2027 sammenlignes ikke spørsmål for spørsmål.
- Fullprofil-samtykke utvider ikke gamle gruppesamtykker (vist som egen tabell).
- Én aktiv/ventende deling per e-post. Utløpt lenke kan fornyes (nytt token; gammelt virker ikke).

## Tilstander
Aktiv · Venter på aksept · Venter på foresatt · Lenke utløpt · Trukket · Avslått av foresatt · Lagrer / Lagret / «Endringene kunne ikke lagres. Prøv igjen.» · Validering (domene, navn, samtykke, duplikat) · Ingen aktive delinger · Tilgang stengt · Spørsmålskilden kunne ikke lastes.

## Datakontrakt
`Share { id, pid, trener, epost, env, st (venter|venter-foresatt|aktiv|trukket|avslatt; utløpt avledes av utloper), gittAv, opprettet, utloper (+7 d), aksept, trukket, tok, rev, log[] }`
`TrainerIdentity { navn, epost, bekreftet, tilknytninger[env] }` · `Delivery { ver 2025|2027, type utv|ses, niva, dato, periode }`

## Kodegrunnlag vs. må kobles (vist i trenerens innsyn)
- Kodegrunnlag finnes (oppgitt av Codex): navngitt samtykke, invitasjon/delingslenke, sikker IUP-leser for leverte besvarelser.
- Må kobles: profil og Mitt team, helse, meldinger, mål/plan/dagbok, tester i trenerens fullprofil. Prototypen viser ingen data for disse som om de var i produksjon.

## Prøvd
Desktop 1440 og mobil 390 (ekte iframes): ingen sideoverflyt, ingen treffmål under 44 px. Reiser: ny deling med domenefeil → lagringsfeil → Prøv igjen → lenke og Kopier lenke; aksept med feil person (Jon Dahl) avvist, riktig (Kari Holm) godtatt → innsyn 43 spørsmål (2027 Junior), 41 (2025 Junior), 13 (sesong); trekk tilbake med fokus i dialog → «Tilgang stengt»; +8 dager → «Lenke utløpt», akseptside avviser, ny lenke 7 dager; under 16 → foresatt godkjenner → Venter på aksept; duplikat avvist.
Ikke prøvd: fysisk Tab-gjennomgang av alle visninger (fokus beholdes etter rerender; Escape lukker dialogen); skjermleser.
