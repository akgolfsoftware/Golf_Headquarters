/* IUP og trenerreiser · felles syntetisk modell (R02–R16). Ingen ekte personer, ingen produksjonsdata. */
(() => {
const today = "2026-10-02";
const schools = [{ id: "wo", navn: "WANG Oslo (syntetisk)" }, { id: "wb", navn: "WANG Bergen (syntetisk)" }];
const groups = [{ id: "tnj", navn: "Team Norway junior (syntetisk)" }, { id: "tnu", navn: "Team Norway utvikling (syntetisk)" }];
const players = [
 { id: "tl", navn: "Tobias Lindvik", init: "TL", fodt: 2009, niva: "junior", skole: "wo", trinn: "VG2", tn: ["tnj"], phq: true, src: "ngf-81122", dg: "dg-1025" },
 { id: "es", navn: "Emma Solberg", init: "ES", fodt: 2010, niva: "junior", skole: "wb", trinn: "VG1", tn: [], phq: true, src: "ngf-81133" },
 { id: "jb", navn: "Jonas Berg", init: "JB", fodt: 2008, niva: "junior", skole: null, trinn: null, tn: ["tnj"], phq: true, src: "ngf-81144", konflikt: "ngf-81999" },
 { id: "sk", navn: "Sara Kvam", init: "SK", fodt: 2009, niva: "junior", skole: "wo", trinn: "VG2", tn: ["tnu"], phq: true, src: "ngf-81155" },
 { id: "om", navn: "Ola Moen", init: "OM", fodt: 2011, niva: "ung", skole: "wb", trinn: "10. trinn", tn: [], phq: true, src: "ngf-81166", u16: true },
 { id: "kh", navn: "Kari Haug", init: "KH", fodt: 2007, niva: "amator", skole: null, trinn: null, tn: [], phq: false, src: "ngf-81177" }];
/* Samtykke: mottaker × spiller → { full, test, scope[], st } */
const consent = {
 tl: { wang: { st: "aktiv", type: "full", scope: ["plan", "tid", "iup", "test"], v: "v2 · 15.08.2026" }, tn: { st: "aktiv", type: "full", scope: ["plan", "test", "iup"], v: "v2 · 01.09.2026" } },
 es: { wang: { st: "aktiv", type: "full", scope: ["plan", "tid", "iup", "test"], v: "v2 · 20.08.2026" }, tn: { st: "aktiv", type: "test", scope: ["test"], v: "WANG→TN testavtale v1 · skoleår 2026/27" } },
 jb: { tn: { st: "aktiv", type: "full", scope: ["plan", "tid", "iup", "test"], v: "v2 · 05.09.2026" } },
 sk: { wang: { st: "aktiv", type: "full", scope: ["plan", "tid", "iup", "test", "helse"], v: "v3 · 10.09.2026 (helse uttrykkelig)" }, tn: { st: "trukket", type: "full", scope: [], v: "trukket 28.09.2026" } },
 om: { wang: { st: "venter-foresatt", type: "full", scope: [], v: "venter foresatt (under 16)" }, tn: { st: "aktiv", type: "test", scope: ["test"], v: "WANG→TN testavtale v1" } },
 kh: {} };
/* Testkatalog per resultatfamilie (R09) */
const tests = [
 { id: "ib", navn: "Innspill Basic", fam: "avstand", n: 20, enh: "m", prot: "v3", bedre: "lavere", info: "20 slag 100–150 m. Avstand til hull per slag. Resultat = gjennomsnitt (ikke median)." },
 { id: "wg", navn: "Wedge Gate", fam: "treff", n: 9, prot: "v3", bedre: "høyere", info: "9 slag gjennom port. Treff eller Bom. Resultat = antall treff av 9." },
 { id: "8b", navn: "8-ball", fam: "poeng", n: 24, maks: 96, steg: [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4], prot: "v3", bedre: "høyere", info: "24 forsøk, 0–4 poeng per forsøk i halve poeng. Maks 96." },
 { id: "pe", navn: "PEI innspill", fam: "pei", n: 10, prot: "IUP 2027", bedre: "lavere", info: "10 slag. PEI = restavstand ÷ slaglengde. Vises i prosent (0,05 = 5 %)." },
 { id: "ng", navn: "Nærspill Gate", fam: "manuell", n: 1, prot: "v3", bedre: "høyere", info: "Manuell poengsum etter vedtak. Kan ha halve poeng (f.eks. 12,5)." },
 { id: "cs", navn: "Club Speed (driver)", fam: "fys", n: 5, enh: "mph", prot: "Fysisk batteri", bedre: "høyere", info: "5 slag, beste registreres." }];
const results = [
 { id: "r1", pid: "tl", tid: "ib", dato: "2026-09-01", raw: [7, 8, 6.5, 9, 7.5, 6, 8, 7, 7.5, 8, 6.5, 7, 8.5, 7, 6, 8, 7.5, 7, 8, 7.5], rev: 1, kilde: "Kontrollert (trener)", testdag: null, log: [] },
 { id: "r2", pid: "tl", tid: "wg", dato: "2026-08-20", raw: ["T", "T", "B", "T", "T", "B", "T", "T", "B"], rev: 1, kilde: "Egenført", log: [] },
 { id: "r3", pid: "es", tid: "8b", dato: "2026-09-15", raw: Array.from({ length: 24 }, (_, i) => [3, 2.5, 4, 1.5, 3.5, 2][i % 6]), rev: 1, kilde: "Kontrollert (trener)", log: [] },
 { id: "r4", pid: "es", tid: "pe", dato: "2026-09-15", raw: [0.05, 0.07, 0.04, 0.06, 0.05, 0.08, 0.05, 0.06, 0.04, 0.05], rev: 1, kilde: "Kontrollert (trener)", log: [] },
 { id: "r5", pid: "om", tid: "ng", dato: "2026-09-15", raw: [12.5], rev: 1, kilde: "Kontrollert (trener)", log: [] }];
/* Felles testdag (R11) */
const testdays = [{ id: "td1", navn: "Felles testdag høst (syntetisk)", dato: "2026-10-14", sted: "Syntetisk GK", arr: "Team Norway", skoler: ["wo", "wb"], grupper: ["tnj"], stasjoner: [{ id: "s1", tid: "ib", trener: "Stasjonstrener A", kap: 6 }, { id: "s2", tid: "wg", trener: "Stasjonstrener B", kap: 6 }, { id: "s3", tid: "8b", trener: "Stasjonstrener C", kap: 6 }], puljer: [{ id: "p1", start: "09:00", rot: ["s1", "s2", "s3"] }, { id: "p2", start: "09:00", rot: ["s2", "s3", "s1"] }], start: "09:00", st: "planlagt", tildel: {} }];
/* Samlinger (R13) */
const camps = [{ id: "c1", navn: "Treningssamling Spania (syntetisk)", fra: "2027-01-11", til: "2027-01-15", arr: "Team Norway", grupper: ["tnj"], skoler: [], ver: 1, st: "utkast", prog: [{ d: "2027-01-11", fra: "15:00", til: "17:00", ax: "slag", navn: "Innspill 100–150 m", trener: "TN-trener", sted: "Range" }, { d: "2027-01-12", fra: "08:00", til: "09:00", ax: "fys", navn: "Styrke", trener: "Fysisk trener", sted: "Gym" }, { d: "2027-01-12", fra: "10:00", til: "14:00", ax: "spill", navn: "18 hull med mål", trener: "TN-trener", sted: "Bane" }, { d: "2027-01-13", fra: "09:00", til: "11:00", ax: "tek", navn: "Teknikk P5.0–P6.0", trener: "TN-trener", sted: "Studio" }], inv: {} }];
/* Pipeline-profiler (R14) */
const comp = [
 { src: "ngf-81122", navn: "Tobias Lindvik", klubb: "Syntetisk GK", phq: "tl", res: [{ ev: "Junior Tour 4 (syntetisk)", d: "2026-09-20", hull: 54, br: [74, 76, 72], st: "ok", rev: 1 }, { ev: "NM junior (syntetisk)", d: "2026-08-08", hull: 54, br: [78, 75], st: "CUT", rev: 1 }] },
 { src: "ngf-81144", navn: "Jonas Berg", klubb: "Syntetisk GK", phq: "jb", res: [{ ev: "Junior Tour 4 (syntetisk)", d: "2026-09-20", hull: 54, br: [77, 79, 0], st: "WD", rev: 1 }] },
 { src: "ngf-81999", navn: "Jonas Berg", klubb: "Annen syntetisk klubb", phq: null, res: [{ ev: "Klubbmesterskap (syntetisk)", d: "2026-09-06", hull: 18, br: [81], st: "ok", rev: 1 }] },
 { src: "ngf-81177", navn: "Kari Haug", klubb: "Syntetisk GK", phq: null, res: [{ ev: "Dame Tour 3 (syntetisk)", d: "2026-09-13", hull: 36, br: [73, 75], st: "ok", rev: 1 }] },
 { src: "ngf-81200", navn: "Mina Dahl", klubb: "Syntetisk GK", phq: null, res: [{ ev: "Junior Tour 4 (syntetisk)", d: "2026-09-20", hull: 27, br: [], st: "DNS", rev: 1 }] }];
const sync = { last: "2026-10-02 06:10", ok: true, queue: [{ src: "ngf-81122", ev: "Junior Tour 4 (syntetisk)", felt: "R3", fra: 72, til: 71, grunn: "Kildekorreksjon: feil score hull 14" }] };
/* Mål (R05) */
const MALRAD = [
 ["rank-wagr", "Ranking WAGR", "plass", "WAGR", "auto"], ["rank-ngf", "NGF juniorranking", "plass", "NGF", "auto"], ["br-turn", "Snitt brutto i turnering", "slag", "Turneringsresultater", "auto"], ["br-ut", "Snitt brutto utenfor turnering", "slag", "Egne runder", "egen"], ["br-best", "Beste turneringsscore", "slag", "Turneringsresultater", "auto"], ["br-verst", "Verste turneringsscore", "slag", "Turneringsresultater", "auto"],
 ["sg-tot", "SG totalt", "slag/runde", "Egne runder (Broadie)", "egen"], ["sg-ott", "SG utslag", "slag/runde", "Egne runder", "egen"], ["sg-app", "SG innspill totalt", "slag/runde", "Egne runder", "egen"], ["sg-app1", "SG innspill 100–150 m", "slag/runde", "Egne runder", "egen"], ["sg-app2", "SG innspill 151–200 m", "slag/runde", "Egne runder", "egen"], ["sg-arg", "SG nærspill", "slag/runde", "Egne runder", "egen"], ["sg-putt", "SG putting", "slag/runde", "Egne runder", "egen"],
 ...["0–3", "3–5", "5–10", "10–15", "15–25", "25–40", "40+"].map((x, i) => ["putt" + i, "Putting " + x + " fot", "% hullet", "Egne runder", "egen"]), ["pei", "PEI totalt", "%", "Tester/runder", "egen"], ...["40–80", "80–120", "120–160", "160–200", "200+"].map((x, i) => ["pei" + i, "PEI " + x + " m", "%", "Tester/runder", "egen"]),
 ["len", "Slaglengde (driver carry)", "m", "TrackMan", "auto"], ["side", "Avvik fra mållinje", "m", "TrackMan", "auto"], ["ft", "Fairwaytreff (FT)", "%", "Egne runder", "egen"], ["gir", "GIR", "%", "Egne runder", "egen"], ["scr", "Scrambling", "%", "Egne runder", "egen"], ["konk", "Konkurranser", "antall", "Turneringsresultater", "auto"], ["krund", "Konkurranserunder", "antall", "Turneringsresultater", "auto"], ["tr9", "Treningsrunder 9 hull", "antall", "Egne runder", "egen"], ["tr18", "Treningsrunder 18 hull", "antall", "Egne runder", "egen"], ["golft", "Golftreningstid", "timer", "Dagbok", "auto"], ["fyst", "Fysisk treningstid", "timer", "Dagbok", "auto"]];
const goals = { tl: { "br-turn": { q: [74.0, 74.0, null, null], mal: 72.5, aar: null, n: "3 runder" }, "sg-app1": { q: [-0.55, -0.42, null, null], mal: -0.2, aar: null, n: "38 slag" }, "putt2": { q: [41, 43, null, null], mal: 50, aar: null, n: "44 putter" }, "konk": { q: [3, 1, null, null], mal: 10, aar: null, n: "—" }, "golft": { q: [92.5, 88.0, null, null], mal: 400, aar: null, n: "dagbok" }, "rank-ngf": { q: [41, 37, null, null], mal: 20, aar: null, n: "NGF" } } };
/* Forslag (R12) */
const forslag = [{ id: "fs1", fra: "TN-trener (syntetisk)", org: "Team Norway", pid: "tl", tittel: "+1 innspilløkt i uke 41", grunn: "SG innspill 100–150 m −0,42 (38 slag)", for: "Golfslag 2 t 30 min / uke", etter: "Golfslag 3 t 15 min / uke", base: 3, st: "sendt", sett: false, gyldig: "2026-10-09", hist: [] }];
const planRev = { tl: 3 };
window.IUPD = { today, schools, groups, players, consent, tests, results, testdays, camps, comp, sync, MALRAD, goals, forslag, planRev, log: [], notif: [] };
})();
