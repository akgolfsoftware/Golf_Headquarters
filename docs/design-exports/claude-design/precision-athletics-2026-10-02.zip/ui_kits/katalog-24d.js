/* Skjermer lagt til 29.09.2026 (nattkjøring PlayerHQ): Meg › Utfordringer. Slås inn i AK_KATALOG. Lastes etter katalog.js. */
Object.assign(window.AK_KATALOG, {
  "PH-24D": { name: "Meg › Utfordringer", href: "ui_kits/playerhq/index.html#PH-24D", runde: 35 },
  "PH-24D-DETALJ": { name: "Utfordring · eier, aktiv", href: "ui_kits/playerhq/index.html#PH-24D-DETALJ", runde: 35 },
  "PH-24D-INVITERT": { name: "Utfordring · invitert", href: "ui_kits/playerhq/index.html#PH-24D-INVITERT", runde: 35 },
  "PH-24D-AVSLUTTET": { name: "Utfordring · avsluttet", href: "ui_kits/playerhq/index.html#PH-24D-AVSLUTTET", runde: 35 },
  "PH-24D-NY": { name: "Ny utfordring", href: "ui_kits/playerhq/index.html#PH-24D-NY", runde: 35, krav: ["Retning på score (høyest eller lavest vinner) finnes som DrillChallenge.higherIsBetter i schema.prisma i arbeidskopien; verifiser at feltet er i prod før porting"] },
  "PH-26B": { name: "Utgår: Treningslogg og putte-laboratoriet (forslag)", href: "ui_kits/playerhq/index.html#PH-26B", runde: 35, uavklart: ["Hvor treningslogg og putte-laboratoriet havner. Anders velger; agent har tegnet forslag med anbefaling"] },
});
