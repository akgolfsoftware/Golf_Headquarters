/* Teknisk plan og progresjon (AG-10, AG-TP-01, AG-TP-02, PH-TP-01) — oppdiktede data. Coach Anders Kristiansen, spiller Tobias Lindvik. Dagens dato 27.09.2026. null = ikke registrert («—»). */
window.TP_DATA = (() => {
  const POS = window.AK_VOCAB ? window.AK_VOCAB.P : [["P1.0", "Adresse / Oppstilling"], ["P2.0", "Kølle parallell i baksving"], ["P3.0", "Venstre arm parallell i baksving"], ["P4.0", "Toppen av baksvingen"], ["P5.0", "Venstre arm parallell i nedsving"], ["P6.0", "Kølle parallell i nedsving"], ["P7.0", "Treffpunktet"], ["P8.0", "Kølle parallell i gjennomføring"], ["P9.0", "Høyre arm parallell i oppfølging"], ["P10.0", "Fullføring og balanse"]]; /* Ordmasteren §5 gjelder (Anders 27.09.2026). */
  const PHASES = [["Baksving", "P1–P4", 4], ["Nedsving", "P5–P7", 3], ["Gjennomsving", "P8–P10", 3]];
  const STEPS_FULL = [["UB", "Uten ball"], ["LH25", "Lav hastighet 25 %"], ["LH50", "Lav hastighet 50 %"], ["LH75", "Lav hastighet 75 %"], ["AUTO", "Automatikk"]];
  const STEPS_SAND = [["UBS", "Uten ball i sanden"], ["MB", "Med ball"]];
  const ENV = ["Innendørs golf", "Utendørs treningsområde", "Golfbane"];
  const PRESS = ["Alene", "Observert", "Konkurranse", "Turnering"];
  const GEAR = ["TrackMan", "FlightScope", "Garmin R10", "Mevo+", "Annet", "Uten"];
  const RADAR = ["TrackMan", "FlightScope", "Garmin R10", "Mevo+"];
  const CLUBS = ["Driver", "3-tre", "Hybrid", "4-jern", "5-jern", "6-jern", "7-jern", "8-jern", "9-jern", "PW", "50°", "54°", "58°", "Putter"];
  const PROTO = { rullende: "Rullende vindu", beste: "Beste av N", streak: "Streak", gate: "Økt-gate" };
  const AREAS = { Fullsving: ["Utslag", "Innspill 200 m og lengre", "Innspill 150–200 m", "Innspill 100–150 m", "Innspill 50–100 m"], "Nærspill": ["Chip", "Pitch", "Lob"], Bunker: ["Bunker"], Putting: ["Putting 0–3 fot", "Putting 3–5 fot", "Putting 5–10 fot", "Putting 10–25 fot", "Putting 25–40 fot", "Putting 40+ fot"] };
  const family = (a) => Object.keys(AREAS).find((k) => AREAS[k].includes(a)) || "Fullsving";
  const areaCode = (a) => a === "Utslag" ? "UTSLAG" : a.startsWith("Innspill") ? "INNSPILL" + a.match(/\d+/)[0] : a.startsWith("Putting") ? "PUTTING" + a.replace("Putting ", "").replace(" fot", "") : a.toUpperCase();
  /* AK-formelen: PYRAMIDE_OMRÅDE_MOTORIKK_BELASTNING_PRESS. Ledd som ikke gjelder, utelates. Motorikk bare for fullsving. */
  const formula = ({ area, step, env, press }) => ["TEK", area ? areaCode(area) : null, area && family(area) === "Fullsving" && step ? step.replace(/\d+$/, (m) => m) : null, env ? ({"Innendørs golf":"INNENDØRS","Utendørs treningsområde":"TRENINGSOMRÅDE","Golfbane":"BANE"})[env] || env.toUpperCase() : null, press ? press.toUpperCase() : null].filter(Boolean).join("_");
  const protoText = (p) => !p ? null : p.type === "rullende" ? p.hits + " av de siste " + p.shots + " slagene innenfor målboksen" : p.type === "beste" ? "Minst " + p.hits + " av " + p.shots + " slag innenfor målboksen i én serie" : p.type === "streak" ? p.hits + " slag på rad innenfor målboksen" : "Snitt innenfor målboksen i " + p.hits + " av " + p.shots + " økter";
  const tasks = [
    { id: "t1", pos: "P7.0", title: "Hendene foran ballen i treff", shot: "7-jern lav fade", area: "Innspill 150–200 m", focus: "Treffpunkt", club: "7-jern", step: "LH50", env: "Utendørs treningsområde", press: "Alene", gear: "TrackMan", status: "Aktiv", main: true,
      steps: [["UB", 60, 60], ["LH25", 80, 80], ["LH50", 64, 120], ["LH75", 0, 100], ["AUTO", 0, 140]],
      envs: [["Innendørs golf", 120, 140], ["Utendørs treningsområde", 84, 260], ["Golfbane", 0, 80]],
      src: "LIVE-ØKT · TRACKMAN · MANUELT · 26.09.2026",
      tm: { club: "7-jern", n: 50, src: "TrackMan", date: "24.09.2026", base: "12.08.2026", rows: [
        { k: "Attack Angle", u: "°", d: 1, base: -1.2, lo: -5.0, hi: -3.0, now: -2.1 },
        { k: "Dynamic Loft", u: "°", d: 1, base: 24.8, lo: 19.0, hi: 22.0, now: 22.9 },
        { k: "Face to Path", u: "°", d: 1, base: 0.4, lo: -2.5, hi: -1.0, now: -1.4 },
      ] },
      proto: { type: "rullende", shots: 20, hits: 16, now: 12 },
      qc: { hits: 7, of: 10, date: "24.09.2026", src: "TrackMan" },
      img: { before: { date: "12.08.2026", by: "Anders Kristiansen" }, now: { date: "24.09.2026", by: "Anders Kristiansen" }, note: "Hendene er foran ballen i treff. Skaftet lener mer enn i august. Neste: hold det i 75 % fart.", noteBy: "Anders Kristiansen", noteDate: "24.09.2026" } },
    { id: "t2", pos: "P6.0", title: "Køllen inn fra innsiden", shot: "Driver høy draw", area: "Utslag", focus: "Startretning", club: "Driver", step: "LH25", env: "Innendørs golf", press: "Alene", gear: "TrackMan", status: "Aktiv", main: true,
      steps: [["UB", 60, 60], ["LH25", 48, 80], ["LH50", 0, 80], ["LH75", 0, 80], ["AUTO", 0, 100]],
      envs: [["Innendørs golf", 108, 180], ["Utendørs treningsområde", 0, 160], ["Golfbane", 0, 40]],
      src: "LIVE-ØKT · 25.09.2026",
      tm: { club: "Driver", n: 30, src: "TrackMan", date: "19.09.2026", base: "12.08.2026", rows: [
        { k: "Club Path", u: "°", d: 1, base: -3.4, lo: 1.0, hi: 3.0, now: -0.8 },
      ] },
      proto: { type: "streak", shots: null, hits: 5, now: 2 },
      qc: null,
      img: { before: { date: "12.08.2026", by: "Anders Kristiansen" }, now: null, note: null } },
    { id: "t3", pos: "P4.0", title: "Kortere baksving", shot: "Driver stock", area: "Utslag", focus: "Sikte og oppstilling", club: "Driver", step: "AUTO", env: "Golfbane", press: "Observert", gear: "Uten", status: "Aktiv", main: false,
      steps: [["UB", 40, 40], ["LH25", 60, 60], ["LH50", 60, 60], ["LH75", 60, 60], ["AUTO", 22, 80]],
      envs: [["Innendørs golf", 100, 100], ["Utendørs treningsområde", 120, 120], ["Golfbane", 22, 60]],
      src: "MANUELT · 22.09.2026", tm: null, proto: null, qc: null, img: null },
    { id: "t4", pos: "P7.0", title: "Stabilt treff på pitch 30–50 m", shot: "54° pitch lav", area: "Pitch", focus: "Treffpunkt", club: "54°", step: null, env: "Utendørs treningsområde", press: "Observert", gear: "Uten", status: "Aktiv", main: false,
      steps: [["", 90, 150]], envs: [["Innendørs golf", null, null], ["Utendørs treningsområde", 90, 120], ["Golfbane", 0, 30]],
      src: "LIVE-ØKT · 26.09.2026", tm: null, proto: { type: "beste", shots: 10, hits: 7, now: 6 }, qc: { hits: 6, of: 10, date: "26.09.2026", src: "Manuelt" }, img: null },
    { id: "t5", pos: "P1.0", title: "Stabil inngang i sanden", shot: "58° greenside-bunker", area: "Bunker", focus: "Sandinngang", club: "58°", step: null, env: "Utendørs treningsområde", press: "Alene", gear: "Uten", status: "Aktiv", main: false,
      steps: [["UBS", 40, 40], ["MB", 18, 60]], envs: [["Innendørs golf", null, null], ["Utendørs treningsområde", 58, 100], ["Golfbane", null, null]],
      src: "MANUELT · 20.09.2026", tm: null, proto: null, qc: null, img: null },
  ];
  const posStatus = { "P1.0": "Godkjent", "P2.0": "Godkjent", "P3.0": "Godkjent", "P4.0": "Jobber med", "P5.0": "Ikke startet", "P6.0": "Jobber med", "P7.0": "Jobber med", "P8.0": "Ikke startet", "P9.0": "Ikke startet", "P10.0": "Godkjent" };
  const log = [
    { id: "l1", date: "26.09.2026", task: "t1", reps: 40, step: "LH50", env: "Utendørs treningsområde", src: "Live-økt", cmt: "Kjentes riktig i 50 %. Mistet det mot slutten.", reply: "Bra. Hold 50 % neste økt, ikke gå opp ennå.", replyDate: "26.09.2026" },
    { id: "l2", date: "26.09.2026", task: "t4", reps: 30, step: null, env: "Utendørs treningsområde", src: "Live-økt", cmt: null, reply: null },
    { id: "l3", date: "25.09.2026", task: "t2", reps: 48, step: "LH25", env: "Innendørs golf", src: "Manuelt", cmt: "Speilet hjalp. Usikker på skaftvinkel.", reply: null },
    { id: "l4", date: "24.09.2026", task: "t1", reps: 24, step: "LH50", env: "Innendørs golf", src: "TrackMan", cmt: null, reply: null },
  ];
  /* Tekniske krav per posisjon (coachens sjekkpunkter). Ingen vinkeltall som ikke er målt. */
  const CHECK = { "P1.0": ["Vekten jevnt fordelt mellom føttene", "Ballposisjon tilpasset køllen", "Skuldre, hofter og føtter parallelt med siktelinjen"], "P2.0": ["Køllehodet utenfor hendene", "Skaftet parallelt med siktelinjen", "Køllens tå peker opp"], "P3.0": ["Venstre arm parallell med bakken", "Skaftet peker mot ballinjen", "Håndleddene er hengslet"], "P4.0": ["Full skulderrotasjon, hoftene roterer mindre", "Venstre håndledd flatt", "Høyre albue under hånden"], "P5.0": ["Vinkelen mellom skaft og arm er bevart", "Hoftene åpner før skuldrene", "Vekten flyttes mot venstre side"], "P6.0": ["Skaftet parallelt med siktelinjen", "Hendene foran høyre lår", "Kølleflaten svakt lukket mot banen"], "P7.0": ["Hendene foran ballen, skaftet lener fremover", "Hoftene er åpne", "Mesteparten av vekten på venstre fot"], "P8.0": ["Armene strukket", "Køllens tå peker opp", "Brystet roterer mot målet"], "P9.0": ["Høyre arm parallell med bakken", "Rotasjonen fortsetter", "Hodet følger kroppen"], "P10.0": ["Balansert på venstre fot", "Beltespennen peker mot målet", "Høyre sko på tå"] };
  /* Kortnavn under nodene i svingtidslinjen. Fullt navn (ordmasteren §5) i title og aria. */
  const SHORT = { "P1.0": "Adresse", "P2.0": "Kølle parallell", "P3.0": "Venstre arm parallell", "P4.0": "Toppen", "P5.0": "Venstre arm parallell", "P6.0": "Kølle parallell", "P7.0": "Treffpunktet", "P8.0": "Kølle parallell", "P9.0": "Høyre arm parallell", "P10.0": "Fullføring" };
  /* Milepæler: 28 uker fra 04.08.2026 til måldato 15.02.2027. I dag 27.09.2026 = uke 8. Rep-skjema = mål × 8/28. */
  const MILESTONES = { start: "04.08.2026", target: "15.02.2027", weeks: 28, week: 8, phases: [{ label: "Uten ball og lav hastighet", range: "UKE 1–8", weeks: 8, state: "active" }, { label: "Lav hastighet og TrackMan", range: "UKE 9–18", weeks: 10, state: "planned" }, { label: "Automatikk, bane og konkurranse", range: "UKE 19–28", weeks: 10, state: "planned" }] };
  /* Rullende treffvindu, eldst først. true = innenfor målboksen. */
  const HITS = { t1: [true, false, true, true, false, true, false, true, true, false, true, true, false, true, false, false, true, true, true, false] };
  const sum = (t) => t.steps.reduce((a, s) => [a[0] + (s[1] || 0), a[1] + (s[2] || 0)], [0, 0]);
  const total = tasks.reduce((a, t) => { const s = sum(t); return [a[0] + s[0], a[1] + s[1]]; }, [0, 0]);
  return {
    POS, PHASES, STEPS_FULL, STEPS_SAND, ENV, PRESS, GEAR, RADAR, CLUBS, PROTO, AREAS, family, formula, protoText, sum,
    plan: { id: "tp-2026h", name: "Teknisk plan høst 2026", status: "Aktiv", pub: "18.09.2026", focus: ["P6.0", "P7.0"], coach: "Anders Kristiansen", player: "Tobias Lindvik", done: total[0], goal: total[1], src: "LIVE-ØKT · TRACKMAN · MANUELT", date: "26.09.2026" },
    tasks, posStatus, log, CHECK, SHORT, MILESTONES, HITS,
    /* Denne uka (uke 39, 21.–27.09.2026): sum av registreringene over mot ukemålet. */
    week: { label: "UKE 39", done: log.reduce((a, l) => a + l.reps, 0), goal: 200 },
    next: { task: "t1", step: "LH50" },
    /* Inngang på PH-10 og PH-11-MAL. aktiv · utkast («Utkast fra coach») · ingen. Skjermstatus «tom» = ingen plan. */
    entry: (state) => window.__tpEntry || (state === "tom" ? "ingen" : "aktiv"),
    stepName: (c) => (STEPS_FULL.concat(STEPS_SAND).find((s) => s[0] === c) || [null, null])[1],
  };
})();
