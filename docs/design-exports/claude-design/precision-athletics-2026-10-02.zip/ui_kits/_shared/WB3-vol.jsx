/* Workbench › Volum (runde 37): planlagt og faktisk akkumulert volum, fordeling per akse, belastning (sRPE) og analyse → tiltaksutkast → Workbench → publisering. Oppdiktede data (Tobias Lindvik, uke 36–43). Ingen fastsatte produktregler: årsmål, ACWR-grenser og økningsgrenser er ikke satt av Anders og vises ikke som terskler. Manglende måling vises som «—», aldri 0. Coach bekrefter og publiserer; ingenting sendes automatisk. */
(() => {
const ns = (K) => K.ns();
const fmt = (m) => m == null ? "—" : (Math.round(m / 6) / 10).toFixed(1).replace(".", ",") + " t";
const WK = [[36, { fys: 200, tek: 150, slag: 330, spill: 180 }, 900], [37, { fys: 210, tek: 160, slag: 340, spill: 170 }, 960], [38, { fys: 190, tek: 170, slag: 350, spill: 190 }, 960], [39, { fys: 210, tek: 36, slag: 300, spill: 180 }, 1080], [40, null, 1020], [41, null, 960], [42, null, 960], [43, null, 720]];
const SRPE = { 36: 4680, 37: 5150, 38: 5300 }, SRPE_PLAN = { 39: 5200, 40: 5400, 41: 4900, 42: 3600 };
const tot = (p) => p ? Object.values(p).reduce((a, b) => a + b, 0) : null;
const AXN = { fys: "Fysisk", tek: "Teknisk", slag: "Golfslag", spill: "Spill", turn: "Turnering" };
function Vol({ K, coach, addOkt, go, state }) {
  const { Button, StatusPill, EmptyState, TextInput, Icon } = K.ns(), M = K.Meta, N = window.AKGolfPrecisionAthletics_7d7c29;
  const empty = state === "tom", rows = WK.map(([w, p, pl]) => ({ w, p: empty ? null : p, pl }));
  const accPlan = rows.filter((r) => r.w <= 39).reduce((a, r) => a + r.pl, 0), reg = rows.filter((r) => r.p), accDone = reg.length ? reg.reduce((a, r) => a + tot(r.p), 0) : null;
  const wk39 = rows.find((r) => r.w === 39), axes = ["fys", "tek", "slag", "spill", "turn"];
  const [tiltak, setTiltak] = React.useState(() => window.TILTAK || []), [ask, setAsk] = React.useState(null);
  const sync = (l) => { window.TILTAK = l; setTiltak(l); };
  const sg = ((window.PHQ_AN || {}).sg || { cats: [] }).cats.filter((c) => c[2] < 0).sort((a, b) => a[2] - b[2]);
  const mk = (c) => ({ id: "tk" + Date.now() + c[0], kode: c[0], analyse: "SG " + c[0] + " " + String(c[2]).replace("-", "−").replace(".", ",") + " · 10 runder · baseline kategori D", tekst: c[0] === "APP" ? "Legg til Innspill 50–100 m · lengdekontroll i uke 40" : c[0] === "PUTT" ? "Legg til Putting 3–5 fot · ballstart i uke 40" : "Legg til Nærspill · landingspunkt i uke 40", status: "Utkast", uke: 40 });
  const upd = (id, p) => sync(tiltak.map((t) => t.id === id ? { ...t, ...p } : t));
  const step = (s) => ["Forslag", "Coachens utkast", "I Workbench", "Publisert"].map((n, i) => <span key={n} style={{ font: "500 12px/1.2 var(--font-mono)", color: i <= s ? "var(--text-primary)" : "var(--text-muted)", fontWeight: i === s ? 700 : 500 }}>{i + 1} {n}{i < 3 ? " →" : ""}</span>);
  const sIdx = (t) => t.status === "Publisert" ? 3 : t.status === "I Workbench" ? 2 : 1;
  const Card = ({ k, meta, children }) => <section aria-label={k} className="pa-card" style={{ padding: 16, gap: 12, minWidth: 0 }}><div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>{k}</span>{meta && <M>{meta}</M>}</div>{children}</section>;
  return <div style={{ display: "flex", flexDirection: "column", gap: 16, minWidth: 0 }}>
    <Card k="Akkumulert volum" meta="PLANLAGT MOT GJENNOMFØRT · KILDE TRENINGSREGISTRERING · EKSEMPELDATA">
      {empty ? <EmptyState icon="bar-chart-3" title="Ingen registrert trening ennå" text="Når spilleren registrerer økter, vises planlagt og gjennomført volum her. Manglende uker vises som —." /> : <>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 12 }}>
          {[["Planlagt t.o.m. uke 39", fmt(accPlan)], ["Gjennomført t.o.m. uke 39", fmt(accDone)], ["Årsmål", "ikke satt"]].map(([k, v]) => <div key={k} style={{ display: "flex", flexDirection: "column", gap: 4 }}><M>{k.toUpperCase()}</M><span style={{ font: "600 20px/1.2 var(--font-mono)" }}>{v}</span></div>)}
        </div>
        <N.AxisVolumeBars rows={rows.map((r) => ({ label: "Uke " + r.w, parts: r.p, plan: r.pl }))} unit="min" legend />
        <M>STREK = PLANLAGT · UKE 40–43 ER IKKE REGISTRERT · UKE 39 PÅGÅR</M></>}
    </Card>
    <Card k="Ukebudsjett og fordeling · uke 39" meta="PLANLAGT MOT GJENNOMFØRT PER PYRAMIDE">
      {empty ? <M>—</M> : <div role="list" style={{ display: "flex", flexDirection: "column" }}>{axes.map((a, i) => { const pl = ({ fys: 240, tek: 216, slag: 360, spill: 204, turn: 60 })[a], d = wk39.p[a]; return <div role="listitem" key={a} style={{ display: "grid", gridTemplateColumns: "84px minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 48, borderTop: i ? "1px solid var(--border-hairline)" : "none", boxShadow: "inset 3px 0 0 var(--axis-" + a + ")", paddingLeft: 10 }}><span style={{ font: "500 14px/1.3 var(--font-sans)" }}>{AXN[a]}</span><span aria-hidden="true" style={{ position: "relative", height: 8, background: "var(--surface-sunken)" }}><span style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: (d == null ? 0 : Math.min(100, d / pl * 100)) + "%", background: "var(--axis-" + a + ")" }}></span></span><span style={{ font: "600 13px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums" }}>{fmt(d)} av {fmt(pl)}</span></div>; })}<M>TURNERING: IKKE REGISTRERT DENNE UKA (—)</M></div>}
    </Card>
    <Card k="Belastning · sRPE" meta="MINUTTER × OPPLEVD ANSTRENGELSE (1–10) · GRENSER ER IKKE FASTSATT">
      {empty ? <M>—</M> : <><div role="list" style={{ display: "flex", flexDirection: "column" }}>{rows.map((r, i) => { const v = SRPE[r.w], p = SRPE_PLAN[r.w]; return <div role="listitem" key={r.w} style={{ display: "grid", gridTemplateColumns: "72px minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 44, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ font: "500 13px/1.3 var(--font-mono)" }}>Uke {r.w}</span><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{v != null ? "Registrert av spilleren" : p != null ? "Planlagt av coach" : "Ikke planlagt eller registrert"}</span><span style={{ font: "600 14px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums" }}>{v != null ? v : p != null ? "plan " + p : "—"}</span></div>; })}</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 4, paddingTop: 10, borderTop: "1px solid var(--border-hairline)" }}><M>ACWR (UKAS sRPE MOT SNITT AV FIRE FORRIGE UKER)</M><span style={{ font: "600 20px/1.2 var(--font-mono)" }}>—</span><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Trenger registrering fra fire tidligere uker. Uker uten registrering regnes ikke som 0. Ingen grense er fastsatt, og verdien er ikke en skadediagnose.</span></div></>}
    </Card>
    <Card k="Analyse → tiltak" meta="COACH BEKREFTER · INGENTING SENDES AUTOMATISK">
      {empty || !sg.length ? <M>INGEN ANALYSE Å BYGGE TILTAK PÅ (—)</M> : sg.map((c) => { const t = tiltak.find((x) => x.kode === c[0]); return <div key={c[0]} style={{ display: "flex", flexDirection: "column", gap: 8, paddingTop: 10, borderTop: "1px solid var(--border-hairline)" }}>
        <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span style={{ font: "500 14px/1.3 var(--font-sans)", flex: "1 1 220px" }}>{mk(c).analyse}</span>{t ? <StatusPill tone={t.status === "Publisert" ? "ok" : "neutral"}>{t.status}</StatusPill> : <StatusPill tone="neutral">Forslag</StatusPill>}</div>
        {!t ? (coach ? <div><Button size="sm" variant="secondary" icon="pencil" data-control-id="vol-tiltak-lag-utkast" onClick={() => sync([...tiltak, mk(c)])} style={{ minHeight: 44 }}>Lag utkast</Button></div> : <M>COACHEN VURDERER ANALYSEN</M>) : <>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>{step(sIdx(t))}</div>
          {coach && t.status === "Utkast" ? <TextInput aria-label={"Tiltak for " + c[0]} value={t.tekst} onChange={(e) => upd(t.id, { tekst: e.target.value })} /> : <span style={{ font: "var(--type-body-s)" }}>{t.tekst}</span>}
          {coach && <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {t.status === "Utkast" && <Button size="sm" variant="secondary" icon="layers" data-control-id="vol-tiltak-legg-wb" onClick={() => { addOkt({ id: "tk-" + t.id, axis: c[0] === "PUTT" || c[0] === "ARG" || c[0] === "APP" ? "slag" : "tek", area: c[0] === "APP" ? "Innspill 50–100 m" : c[0] === "PUTT" ? "Putt 3–5 fot" : "Chip", name: t.tekst.replace("Legg til ", ""), min: 20, tiltakId: t.id }); upd(t.id, { status: "I Workbench" }); K.toast("Lagt i Workbench som utkast", "UKE 40 · IKKE PUBLISERT"); }} style={{ minHeight: 44 }}>Legg i Workbench (uke 40)</Button>}
            {t.status === "I Workbench" && (ask === t.id ? <span style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}><M>PUBLISERE TIL TOBIAS LINDVIK?</M><Button size="sm" icon="send" data-control-id="vol-tiltak-bekreft-publiser" onClick={() => { upd(t.id, { status: "Publisert" }); setAsk(null); K.toast("Publisert til spilleren", "UKE 40 · " + c[0]); }} style={{ minHeight: 44 }}>Bekreft og publiser</Button><Button size="sm" variant="ghost" data-control-id="vol-tiltak-avbryt" onClick={() => setAsk(null)} style={{ minHeight: 44 }}>Avbryt</Button></span> : <Button size="sm" icon="send" data-control-id="vol-tiltak-publiser" onClick={() => setAsk(t.id)} style={{ minHeight: 44 }}>Publiser til spiller</Button>)}
            {t.status !== "Publisert" && <Button size="sm" variant="ghost" icon="x" data-control-id="vol-tiltak-forkast" onClick={() => sync(tiltak.filter((x) => x.id !== t.id))} style={{ minHeight: 44 }}>Forkast utkast</Button>}</div>}</>}
      </div>; })}
    </Card>
  </div>;
}
window.WB3_VOL = Vol;
})();
