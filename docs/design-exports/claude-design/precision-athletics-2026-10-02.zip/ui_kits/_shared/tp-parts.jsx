/* Teknisk plan · delte deler for AG-10, AG-TP-01, AG-TP-02, PH-TP-01 og inngangene på PH-10 og PH-11-MAL. Runde 35: bygget på DS-komponentene i components/plan (SwingTimeline, FormulaCode, RepBars, TargetWindow, HitGrid, PhaseTrack). Datamodell: TechnicalPlan · PositionTask · PositionTaskLog · PositionTaskMaal · PositionTaskTmGoal. Farger bare som tokens. */
(() => {
const ns = () => window.AKGolfPrecisionAthletics_7d7c29;
const D = () => window.TP_DATA;
const dec = (v, d = 1) => v == null ? "—" : (v < 0 ? "−" : "") + Math.abs(v).toFixed(d).replace(".", ",");
const num = (v) => v == null ? "—" : String(v).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
const frac = (a, b) => b == null ? "—" : num(a) + " / " + num(b);
const Meta = ({ children, s }) => <span style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)", fontVariantNumeric: "tabular-nums", overflowWrap: "anywhere", ...s }}>{children}</span>;
const Label = ({ children }) => <span className="kicker">{children}</span>;
const Bar = ({ v, of, h = 6 }) => { const p = !of ? 0 : Math.max(0, Math.min(100, (v || 0) / of * 100)); return <span aria-hidden="true" style={{ display: "block", height: h, background: "var(--surface-sunken)", position: "relative", minWidth: 0 }}><span style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: p + "%", background: "var(--text-primary)" }}></span></span>; };
const Formula = ({ children, big, highlight }) => { const F = ns().FormulaCode; return <F code={children} size={big ? "lg" : "md"} highlight={highlight} />; };
const stepLabel = (c) => c ? D().stepName(c) : "Repetisjoner";

/* Posisjonslinje = SwingTimeline (DS). 2 × 5 under 640 px, ruller aldri. Valgt = grafitt. Tekniske krav for valgt posisjon under. */
function PosLine({ tasks, sel, onSel, focus, mob, status }) {
  const T = D(), { SwingTimeline, Button } = ns(), cnt = (p) => tasks.filter((t) => t.pos === p).length;
  const all = T.POS, positions = all.map(([c, n]) => ({ code: c, name: T.SHORT[c] || "", label: n, count: cnt(c), focus: focus.includes(c) }));
  return <div style={{ display: "flex", flexDirection: "column", gap: 10, minWidth: 0 }}>
    <SwingTimeline positions={positions} value={sel} onChange={onSel} phases={[["Baksving", "P1–P4", 1, 4], ["Nedsving", "P5–P7", 5, 7], ["Gjennomsving", "P8–P10", 8, 10]]} />
    <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", minHeight: 44 }}>
      {sel ? <><span style={{ font: "600 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{sel} {(all.find((x) => x[0] === sel) || [])[1]}</span>{status}<Button size="sm" variant="ghost" onClick={() => onSel(null)}>Vis alle posisjoner</Button></> : <Meta>ALLE POSISJONER · TRYKK EN POSISJON FOR Å FILTRERE · TALL = OPPGAVER</Meta>}
    </div>
    {sel && <Checks pos={sel} />}
  </div>;
}
function Checks({ pos }) {
  const L = D().CHECK[pos] || [];
  return <div style={{ display: "flex", flexDirection: "column", gap: 6, paddingTop: 10, borderTop: "1px solid var(--border-hairline)" }}>
    <Label>Tekniske krav · {pos} · {L.length}</Label>
    {L.length ? <ol style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 6 }}>{L.map((s, i) => <li key={i} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr)", gap: 8, alignItems: "baseline" }}><span style={{ font: "500 12px/1.4 var(--font-mono)", color: "var(--text-muted)" }}>{String(i + 1).padStart(2, "0")}</span><span style={{ font: "var(--type-body-s)", color: "var(--text-body)", textWrap: "pretty" }}>{s}</span></li>)}</ol> : <Meta>—</Meta>}
    <Meta>SJEKKPUNKTER FRA ANDERS KRISTIANSEN · VISER RETNING · LÅSER IKKE NESTE STEG</Meta>
  </div>;
}

/* Rep-streker = RepBars (DS). Strek = skjema til nå (uke X av Y). */
function RepBars({ steps, source }) {
  const M = D().MILESTONES, f = M.week / M.weeks, R = ns().RepBars;
  return <R rows={steps.map(([c, d, g]) => ({ label: stepLabel(c), done: d, goal: g, marker: g == null ? null : Math.round(g * f) }))} source={source} />;
}

function EnvGrid({ envs, mob }) {
  return <div style={{ display: "grid", gridTemplateColumns: mob ? "repeat(2,minmax(0,1fr))" : "repeat(4,minmax(0,1fr))", gap: 8 }}>{envs.map(([e, d, g]) => <div key={e} style={{ display: "flex", flexDirection: "column", gap: 6, padding: 10, border: "1px solid var(--border-hairline)", borderRadius: "var(--radius)", minWidth: 0 }}>
    <Meta>{e.toUpperCase()}</Meta><span style={{ font: "500 14px/1.2 var(--font-mono)", fontVariantNumeric: "tabular-nums", color: g == null ? "var(--text-muted)" : "var(--text-primary)" }}>{frac(d, g)}</span>{g != null ? <Bar v={d} of={g} h={4} /> : <Meta>IKKE I PLANEN</Meta>}
  </div>)}</div>;
}

/* TrackMan-mål = TargetWindow (DS): utgangspunkt · målboks · måling nå, med legende. Bare grafitt. */
function TMScale({ r, src }) { const TW = ns().TargetWindow; return <div style={{ paddingTop: 10, borderTop: "1px solid var(--border-hairline)" }}><TW label={r.k} lo={r.lo} hi={r.hi} value={r.now} base={r.base} decimals={r.d} signed={r.u === "°"} unit={r.u} emptyText="Ingen TrackMan-økt registrert." source={src} /></div>; }
function TMBlock({ task }) {
  const T = D(), radar = T.RADAR.includes(task.gear), tm = task.tm;
  if (!radar) return <div style={{ display: "flex", flexDirection: "column", gap: 4 }}><Label>Måleutstyr</Label><Meta>{task.gear === "Uten" ? "UTEN MÅLEUTSTYR · INGEN TRACKMAN-MÅL" : "ANNET MÅLEUTSTYR · INGEN TRACKMAN-MÅL"}</Meta></div>;
  return <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
    <Label>TrackMan-mål · {tm ? tm.rows.length : 0}</Label>
    {!tm || !tm.rows.length ? <><span style={{ font: "500 14px/1.3 var(--font-mono)" }}>—</span><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen TrackMan-økt registrert.</span></> : <>
      {tm.rows.map((r) => <TMScale key={r.k} r={r} />)}
      <Meta>{tm.club.toUpperCase()} · n = {tm.n} SLAG · {tm.src.toUpperCase()} · {tm.date} · UTGANGSPUNKT {tm.base}</Meta>
    </>}
  </div>;
}
const protoNow = (p) => p.type === "rullende" ? p.now + " av " + p.shots : p.type === "beste" ? "beste serie " + p.now + " av " + p.shots : p.type === "streak" ? "lengste rekke " + p.now : p.now + " av " + p.shots + " økter";
/* Treffprotokoll: regel i én setning + nåtall. Rullende vindu vises også som ruter (HitGrid, DS). */
function Protocol({ p, id }) {
  const T = D(), HG = ns().HitGrid, h = id && T.HITS[id];
  return <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
    <Label>Treffprotokoll · {p ? T.PROTO[p.type] : "—"}</Label>
    {!p ? <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen treffprotokoll på denne oppgaven.</span> : p.type === "rullende" && h ? <HG results={h} window={p.shots} required={p.hits} text={T.protoText(p) + "."} /> : <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "baseline" }}><span style={{ font: "500 14px/1.4 var(--font-sans)", color: "var(--text-primary)", flex: "1 1 220px", textWrap: "pretty" }}>{T.protoText(p)}</span><span style={{ font: "600 14px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums" }}>Nå {protoNow(p)}</span></div>}
    {p && <Meta>VISER STATUS · LÅSER IKKE NESTE STEG</Meta>}
  </div>;
}
function QualityCheck({ qc, onStart }) {
  const { Button } = ns();
  return <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
    <Label>Kvalitetssjekk</Label>
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}><span style={{ font: "600 14px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums", flex: "1 1 200px" }}>{qc ? qc.hits + " av " + qc.of + " · " + qc.date + " · " + qc.src : "—"}</span>{onStart && <Button size="sm" variant="secondary" icon="list-checks" onClick={onStart}>Ny kvalitetssjekk</Button>}</div>
    <Meta>{qc ? "VISER STATUS · LÅSER IKKE NESTE LÆRINGSSTEG" : "INGEN KVALITETSSJEKK REGISTRERT · LÅSER IKKE NESTE LÆRINGSSTEG"}</Meta>
  </div>;
}

/* Kvalitetssjekk: registrer en serie som innenfor/utenfor målboksen. Avbrutt serie gir ikke resultat. */
function QCSheet({ open, task, onClose, onSave, outdoor, toast }) {
  const { Sheet, Button, Stepper } = ns();
  const [n, setN] = React.useState(10), [s, setS] = React.useState([]);
  React.useEffect(() => { if (open) { setS([]); setN(10); } }, [open]);
  if (!task) return null;
  const hits = s.filter(Boolean).length, full = s.length >= n, sz = outdoor ? "xl" : "lg";
  const abort = () => { onClose(); if (s.length) toast("Serien er avbrutt", "INGEN RESULTAT LAGRET · " + s.length + " AV " + n + " SLAG VAR REGISTRERT"); };
  return <Sheet open={open} onClose={abort} kicker={"Kvalitetssjekk · " + task.pos} title={task.title} footer={<><Button fullWidth icon="check" disabled={!full} onClick={() => { onSave({ hits, of: n }); }}>{full ? "Lagre " + hits + " av " + n : "Registrer " + (n - s.length) + " slag til"}</Button><Button variant="ghost" fullWidth onClick={abort}>Avbryt serien</Button></>}>
    <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Trykk for hvert slag om det landet innenfor eller utenfor målboksen. Resultatet vises bare. Det låser ikke neste læringssteg.</p>
    <Stepper label="Slag i serien" value={n} min={5} max={30} step={5} onChange={(v) => setN(Math.max(v, s.length))} size={outdoor ? "xl" : "md"} />
    <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 8 }}><Button size={sz} variant="secondary" icon="check" disabled={full} onClick={() => setS((l) => [...l, true])}>Innenfor</Button><Button size={sz} variant="secondary" icon="x" disabled={full} onClick={() => setS((l) => [...l, false])}>Utenfor</Button></div>
    <div aria-live="polite" style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}><span style={{ font: "600 15px/1.3 var(--font-mono)", flex: "1 1 auto" }}>{s.length} av {n} registrert · {hits} innenfor</span>{s.length > 0 && <Button size="sm" variant="ghost" icon="undo-2" onClick={() => setS((l) => l.slice(0, -1))}>Angre siste</Button>}</div>
    <div aria-hidden="true" style={{ display: "grid", gridTemplateColumns: "repeat(10,minmax(0,1fr))", gap: 4 }}>{Array.from({ length: n }, (_, i) => <span key={i} style={{ height: 8, background: i < s.length ? (s[i] ? "var(--text-primary)" : "var(--border-strong)") : "var(--surface-sunken)" }}></span>)}</div>
    <Meta>{(task.tm ? task.tm.src : "MANUELT").toUpperCase()} · 27.09.2026</Meta>
  </Sheet>;
}

/* Før og nå: to daterte bilder. Side om side, eller én ramme med delelinje (dra, piltaster, eller knapper). */
function Frame({ which, data, pos, onUpload }) {
  const { Button } = ns();
  if (!data) return <div style={{ aspectRatio: "4 / 5", minWidth: 0, border: "1px dashed var(--border-control)", borderRadius: "var(--radius)", display: "flex", flexDirection: "column", gap: 10, alignItems: "center", justifyContent: "center", padding: 12, textAlign: "center", boxSizing: "border-box" }}><Meta>{which.toUpperCase()} · {pos}</Meta><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen bilde registrert</span>{onUpload && <Button size="sm" variant="secondary" icon="upload" onClick={onUpload}>Last opp bilde</Button>}</div>;
  return <div style={{ aspectRatio: "4 / 5", minWidth: 0, position: "relative", background: "var(--surface-sunken)", borderRadius: "var(--radius)", outline: "1px solid var(--border-hairline)", outlineOffset: -1, overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>
    {data.url && data.type === "bilde" ? <img src={data.url} alt={which + "-bilde " + pos + " " + data.date} style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : data.url && data.type === "video" ? <video src={data.url} controls muted playsInline preload="metadata" aria-label={which + "-video " + pos + " " + data.date} style={{ width: "100%", height: "100%", objectFit: "cover" }}></video> : <Meta>{data.type === "video" ? "VIDEO" : "BILDE"} · {pos}</Meta>}
    <span style={{ position: "absolute", left: 8, bottom: 8, font: "600 11px/1 var(--font-mono)", letterSpacing: ".04em", background: "var(--surface-card)", color: "var(--text-primary)", border: "1px solid var(--border-hairline)", borderRadius: 999, padding: "5px 8px" }}>{which.toUpperCase()} · {data.date}</span>
  </div>;
}
function BeforeAfter({ img, pos, mob, onUpload }) {
  const { Segmented, Button } = ns();
  const both = img && img.before && img.now, [mode, setMode] = React.useState("side"), [x, setX] = React.useState(50), ref = React.useRef(null), drag = React.useRef(false);
  const hasVid = !!(img && ((img.before && img.before.type === "video") || (img.now && img.now.type === "video"))), m = both && !hasVid ? mode : "side";
  const at = (cx) => { const r = ref.current.getBoundingClientRect(); setX(Math.round(Math.max(0, Math.min(100, (cx - r.left) / r.width * 100)))); };
  const key = (e) => { const k = e.key; if (k === "ArrowLeft" || k === "ArrowDown") { setX((v) => Math.max(0, v - 5)); e.preventDefault(); } else if (k === "ArrowRight" || k === "ArrowUp") { setX((v) => Math.min(100, v + 5)); e.preventDefault(); } else if (k === "Home") { setX(0); e.preventDefault(); } else if (k === "End") { setX(100); e.preventDefault(); } };
  return <div style={{ display: "flex", flexDirection: "column", gap: 12, minWidth: 0 }}>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}><Segmented options={[{ value: "side", label: "Side om side" }, { value: "split", label: "Før og nå" }]} value={m} onChange={(v) => both && setMode(v)} />{!both && <Meta>FØR OG NÅ KREVER TO BILDER</Meta>}{both && hasVid && <Meta>VIDEO VISES SIDE OM SIDE</Meta>}</div>
    {m === "side" ? <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: mob ? 8 : 12, maxWidth: 720 }}><Frame which="Før" data={img && img.before} pos={pos} onUpload={onUpload} /><Frame which="Nå" data={img && img.now} pos={pos} onUpload={onUpload} /></div> : <>
      <div ref={ref} onPointerDown={(e) => { drag.current = true; e.currentTarget.setPointerCapture(e.pointerId); at(e.clientX); }} onPointerMove={(e) => drag.current && at(e.clientX)} onPointerUp={() => { drag.current = false; }} style={{ position: "relative", maxWidth: 480, width: "100%", touchAction: "none", cursor: "ew-resize", userSelect: "none" }}>
        <Frame which="Før" data={img.before} pos={pos} />
        <div style={{ position: "absolute", inset: 0, clipPath: "inset(0 0 0 " + x + "%)" }}><Frame which="Nå" data={img.now} pos={pos} /></div>
        <span aria-hidden="true" style={{ position: "absolute", top: 0, bottom: 0, left: x + "%", width: 2, marginLeft: -1, background: "var(--text-primary)" }}></span>
        <span role="slider" tabIndex={0} aria-label="Delelinje mellom før og nå" aria-valuemin={0} aria-valuemax={100} aria-valuenow={x} aria-valuetext={x + " % før"} onKeyDown={key} style={{ position: "absolute", top: "50%", left: x + "%", width: 44, height: 44, marginLeft: -22, marginTop: -22, borderRadius: 999, background: "var(--surface-card)", border: "1px solid var(--border-ink)", boxShadow: "var(--shadow-pop)", display: "flex", alignItems: "center", justifyContent: "center", boxSizing: "border-box" }}><window.AKGolfPrecisionAthletics_7d7c29.Icon name="chevrons-left-right" size={18} /></span>
      </div>
      <div role="group" aria-label="Vis uten å dra" style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button size="sm" variant="secondary" onClick={() => setX(100)}>Bare før</Button><Button size="sm" variant="secondary" onClick={() => setX(50)}>Midt</Button><Button size="sm" variant="secondary" onClick={() => setX(0)}>Bare nå</Button><Meta s={{ alignSelf: "center" }}>PILTASTER FLYTTER 5 %</Meta></div>
    </>}
    {img && img.note ? <div style={{ display: "flex", flexDirection: "column", gap: 4, paddingTop: 10, borderTop: "1px solid var(--border-hairline)" }}><Label>Notat fra coach</Label><p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-body)", textWrap: "pretty" }}>{img.note}</p><Meta>{img.noteBy.toUpperCase()} · {img.noteDate}</Meta></div> : <Meta>INGEN NOTAT FRA COACH</Meta>}
  </div>;
}

/* Oppgavekort. actions = knapper nederst. open = detaljer vist. */
function TaskCard({ t, mob, wide, open, onToggle, actions, onQC, stripe }) {
  const T = D(), { StatusPill, Button, KeyValue } = ns(), [d, g] = T.sum(t);
  return <div className="pa-card" style={{ padding: 16, gap: 14, minWidth: 0, position: "relative", overflow: "hidden" }}>
    <span aria-hidden="true" style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 4, background: "var(--axis-tek)" }}></span>
    <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span style={{ font: "600 13px/1 var(--font-mono)" }}>{t.pos}</span><span style={{ font: "600 15px/1.3 var(--font-sans)", flex: "1 1 200px", minWidth: 0 }}>{t.title}</span><StatusPill tone="info">{t.status}</StatusPill></div>
    <KeyValue columns={mob ? 1 : 2} items={[["Slag", t.shot, { mono: false }], ["Område", t.area, { mono: false }], ["Teknisk fokus", T.focusOk(t) ? t.focus + (t.focusLegacy ? " · tidligere: " + t.focusLegacy : "") : t.focus + " · ikke gyldig for området", { mono: false }], ["Høyde og skru", /^Putting/.test(t.area) ? "Gjelder ikke putting" : t.hoyde ? T.NIVA.find((n) => n[0] === t.hoyde[0])[1] + " / " + T.NIVA.find((n) => n[0] === t.hoyde[1])[1].toLowerCase() + " · " + t.skru : "—", { mono: false }]]} />
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}><Formula>{T.formula(t)}</Formula><Meta>AK-FORMELEN</Meta></div>
    {!open ? <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}><span style={{ flex: "1 1 180px", display: "flex", flexDirection: "column", gap: 4 }}><span style={{ font: "500 13px/1.3 var(--font-mono)" }}>{frac(d, g)} repetisjoner</span><Bar v={d} of={g} /></span><Meta>{t.proto ? "PROTOKOLL NÅ " + protoNow(t.proto).toUpperCase() : "INGEN PROTOKOLL"}{t.qc ? " · SJEKK " + t.qc.hits + " AV " + t.qc.of : ""}</Meta>{onToggle && <Button size="sm" variant="ghost" iconRight="chevron-down" onClick={onToggle}>Vis detaljer</Button>}</div> : <>
      <div style={{ display: "grid", gridTemplateColumns: wide ? "minmax(0,1fr) minmax(0,1fr)" : "minmax(0,1fr)", gap: wide ? 24 : 18, alignItems: "start" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 12, minWidth: 0 }}>
          <Label>{t.steps.length > 1 ? "Repetisjoner per læringssteg" : "Repetisjoner"}</Label><RepBars steps={t.steps} source={"STREK = SKJEMA UKE " + T.MILESTONES.week + " AV " + T.MILESTONES.weeks} />
          <Label>Fordeling per miljø</Label><EnvGrid envs={t.envs} mob={mob} />
          <Meta>KILDE {t.src}</Meta>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 16, minWidth: 0 }}><TMBlock task={t} /><Protocol p={t.proto} id={t.id} /><QualityCheck qc={t.qc} onStart={onQC} /></div>
      </div>
      {onToggle && <div><Button size="sm" variant="ghost" iconRight="chevron-up" onClick={onToggle}>Skjul detaljer</Button></div>}
    </>}
    {actions && <div style={{ display: "flex", gap: 8, flexWrap: "wrap", paddingTop: 12, borderTop: "1px solid var(--border-hairline)" }}>{actions}</div>}
  </div>;
}

/* Oppsummering: planstatus og publisering hver for seg, hovedfokus, samlet fremdrift, denne uka, milepæler mot måldato (PhaseTrack, DS). */
function Summary({ plan, done, goal, mob, extra, draft }) {
  const T = D(), { StatusPill, PhaseTrack } = ns(), M = T.MILESTONES, wk = T.week;
  const cell = (k, v) => <div style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}><Meta>{k}</Meta>{v}</div>;
  return <div className="pa-card" style={{ padding: 16, gap: 14 }}>
    <div style={{ display: "grid", gridTemplateColumns: mob ? "minmax(0,1fr)" : "repeat(auto-fit,minmax(180px,1fr))", gap: 16 }}>
      {cell("PLANSTATUS", <span style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><StatusPill tone={draft ? "neutral" : "ok"}>{draft ? "Utkast fra coach" : plan.status}</StatusPill><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{draft ? "Ikke publisert" : "Publisert " + plan.pub}</span></span>)}
      {cell("HOVEDFOKUS", <span style={{ font: "600 15px/1.3 var(--font-mono)" }}>{plan.focus.join(" · ")}</span>)}
      {cell("SAMLET FREMDRIFT", <span style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "600 15px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums" }}>{draft ? "—" : frac(done, goal) + " repetisjoner"}</span>{!draft && <Bar v={done} of={goal} />}</span>)}
      {cell("DENNE UKA · " + wk.label, <span style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "600 15px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums" }}>{draft ? "—" : frac(wk.done, wk.goal) + " repetisjoner"}</span>{!draft && <Bar v={wk.done} of={wk.goal} />}</span>)}
      {extra}
    </div>
    <div style={{ display: "flex", flexDirection: "column", gap: 8, paddingTop: 12, borderTop: "1px solid var(--border-hairline)" }}>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "space-between", alignItems: "baseline" }}><Label>Milepæler · {M.weeks} uker</Label><Meta>MÅLDATO {M.target}</Meta></div>
      <PhaseTrack phases={M.phases} today={draft ? null : M.week / M.weeks} todayLabel={"I DAG · UKE " + M.week} start={M.start.slice(0, 5)} end={M.target.slice(0, 5)} />
    </div>
    <Meta>{draft ? "INGEN REGISTRERINGER FØR PLANEN ER PUBLISERT" : "KILDE " + plan.src + " · SIST REGISTRERT " + plan.date}</Meta>
  </div>;
}

/* Siste registreringer (PositionTaskLog). Coach kan svare; spiller leser. */
function LogList({ log, tasks, coach, onReply, toast }) {
  const T = D(), { Button, TextInput } = ns(), [reply, setReply] = React.useState({});
  const name = (id) => (tasks.find((t) => t.id === id) || {}).title || "—";
  return <div className="pa-card" style={{ padding: 16, gap: 0 }}>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "space-between", alignItems: "baseline", paddingBottom: 10 }}><Label>Siste registreringer · {log.length}</Label><Meta>LIVE-ØKT · TRACKMAN · MANUELT</Meta></div>
    {!log.length ? <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen registreringer ennå.</span> : log.map((l) => <div key={l.id} style={{ display: "flex", flexDirection: "column", gap: 6, padding: "12px 0", borderTop: "1px solid var(--border-hairline)" }}>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "baseline" }}><span style={{ font: "600 13px/1.3 var(--font-mono)" }}>{l.date}</span><span style={{ font: "500 14px/1.3 var(--font-sans)", flex: "1 1 200px", minWidth: 0 }}>{name(l.task)}</span><span style={{ font: "600 13px/1.3 var(--font-mono)" }}>{l.reps} rep.</span></div>
      <Meta>{(l.step ? T.stepName(l.step) : "Uten læringssteg").toUpperCase()} · {l.env.toUpperCase()} · {l.src.toUpperCase()}{l.video ? " · VIDEO" : ""}</Meta>
      {l.cmt ? <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-body)", textWrap: "pretty" }}><b style={{ fontWeight: 600 }}>{coach ? "Tobias Lindvik" : "Du"}:</b> {l.cmt}</p> : <Meta>INGEN KOMMENTAR FRA SPILLEREN</Meta>}
      {l.reply ? <p style={{ margin: 0, paddingLeft: 12, boxShadow: "inset 2px 0 0 var(--border-strong)", font: "var(--type-body-s)", color: "var(--text-body)", textWrap: "pretty" }}><b style={{ fontWeight: 600 }}>Anders Kristiansen · {l.replyDate}:</b> {l.reply}</p> : !coach ? (l.cmt ? <Meta>IKKE SVART ENNÅ</Meta> : null) : l.cmt && (reply[l.id] != null ? <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}><div style={{ flex: "1 1 220px", minWidth: 0 }}><TextInput aria-label="Svar til Tobias Lindvik" value={reply[l.id]} onChange={(e) => setReply((r) => ({ ...r, [l.id]: e.target.value }))} placeholder="Skriv kort" /></div><Button size="sm" variant="secondary" icon="send" disabled={!reply[l.id].trim()} onClick={() => { onReply(l.id, reply[l.id]); toast("Svaret er sendt", "TIL TOBIAS LINDVIK"); }}>Send svar</Button></div> : <div><Button size="sm" variant="ghost" icon="message-square" onClick={() => setReply((r) => ({ ...r, [l.id]: "" }))}>Svar</Button></div>)}
    </div>)}
  </div>;
}

/* Inngang til PH-TP-01 fra PH-10 (kort) og PH-11-MAL (rad). Ingen egen primærknapp: hele flaten er lenken. */
function PlanEntry({ entry, variant = "card", onOpen }) {
  const T = D(), { StatusPill, Icon } = ns(), p = T.plan, draft = entry === "utkast", nt = T.tasks.find((x) => x.id === T.next.task), last = T.log[0], wk = T.week;
  if (entry === "ingen") return variant === "row" ? <p style={{ margin: 0, padding: "12px 0", borderTop: "1px solid var(--border-hairline)", font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Teknisk plan: Anders Kristiansen lager planen sammen med deg. Du får varsel når den er publisert.</p> : null;
  const btn = { appearance: "none", font: "inherit", color: "var(--text-primary)", textAlign: "left", cursor: "pointer", width: "100%", boxSizing: "border-box", display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 12, alignItems: "center", minWidth: 0 };
  const aria = "Åpne teknisk plan: " + p.name + (draft ? ", utkast fra coach" : "");
  if (variant === "row") return <button type="button" onClick={onOpen} aria-label={aria} style={{ ...btn, background: "transparent", border: 0, borderTop: "1px solid var(--border-hairline)", borderRadius: 0, padding: "10px 0", minHeight: 56 }}>
    <span style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><StatusPill tone="neutral">{draft ? "Utkast fra coach" : "Teknisk plan"}</StatusPill><span style={{ font: "600 14px/1.3 var(--font-sans)", minWidth: 0 }}>{p.name}</span></span>
      <Meta>FOKUS {p.focus.join(" · ")} · {wk.label} {draft ? "—" : frac(wk.done, wk.goal) + " REP"} · NESTE {nt.pos}</Meta></span>
    <Icon name="chevron-right" size={18} />
  </button>;
  const cell = (k, v, m) => <span style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><Meta>{k}</Meta>{v}{m && <Meta>{m}</Meta>}</span>;
  const val = (s) => <span style={{ font: "600 14px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums", overflowWrap: "anywhere" }}>{s}</span>;
  return <button type="button" onClick={onOpen} aria-label={aria} className="pa-card" style={{ ...btn, padding: 16, gap: 14, minHeight: 44 }}>
    <span style={{ display: "flex", flexDirection: "column", gap: 12, minWidth: 0 }}>
      <span style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><Label>Teknisk plan</Label><StatusPill tone={draft ? "neutral" : "ok"}>{draft ? "Utkast fra coach" : "Aktiv"}</StatusPill></span>
      <span style={{ font: "600 16px/1.3 var(--font-sans)" }}>{p.name}</span>
      <span style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,150px),1fr))", gap: 12 }}>
        {cell("FOKUS", val(p.focus.join(" · ")))}
        {cell("DENNE UKA · " + wk.label, <span style={{ display: "flex", flexDirection: "column", gap: 4 }}>{val(draft ? "—" : frac(wk.done, wk.goal) + " rep.")}{!draft && <Bar v={wk.done} of={wk.goal} h={4} />}</span>)}
        {cell("NESTE OPPGAVE", <span style={{ font: "500 14px/1.3 var(--font-sans)", textWrap: "pretty" }}>{nt.pos} · {nt.title}</span>, T.stepName(T.next.step).toUpperCase())}
        {cell("SISTE REGISTRERING", val(draft ? "—" : last.date.slice(0, 5) + " · " + last.reps + " rep."), draft ? "INGEN FØR PUBLISERING" : (T.stepName(last.step) || "—").toUpperCase())}
      </span>
      {draft && <Meta>ANDERS KRISTIANSEN JOBBER MED PLANEN · DU KAN LESE UTKASTET</Meta>}
    </span>
    <Icon name="chevron-right" size={20} />
  </button>;
}

window.TP = { ns, dec, num, frac, Meta, Label, Bar, Formula, PosLine, Checks, LogList, PlanEntry, RepBars, EnvGrid, TMScale, TMBlock, Protocol, protoNow, QualityCheck, QCSheet, Frame, BeforeAfter, TaskCard, Summary, stepLabel };
})();
