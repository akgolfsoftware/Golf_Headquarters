/* Teknisk plan · delte deler. Faste posisjoner P1.0–P10.0, slagvalg (3×3 høyde og skru) og før/etter-medier. */
(() => {
const ns = () => window.AKGolfPrecisionAthletics_7d7c29, D = () => window.TP_DATA, TP = () => window.TP;
const Meta = (p) => React.createElement(TP().Meta, p);
const two = (n) => String(n).padStart(2, "0"), today = () => { const d = new Date(); return two(d.getDate()) + "." + two(d.getMonth() + 1) + "." + d.getFullYear(); };
const posName = (c) => { const p = D().POS.find((x) => x[0] === c); return p ? p[1] : "Ukjent posisjon"; };

/* Slagvalg: starthøyde × toppunkt som 3×3, skru og startretning. Gjelder ikke putting. */
function StrokeChoice({ t, onChange }) {
  const { ChoicePill } = ns(), T = D(), putt = /^Putting/.test(t.area || "");
  if (putt) return <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Høyde og skru gjelder ikke putting.</p>;
  const [sh, tp] = t.hoyde || ["med", "med"];
  return <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
    <div role="group" aria-label="Høyde: starthøyde og toppunkt" style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "500 13px/1.3 var(--font-sans)" }}>Høyde · starthøyde ↓ · toppunkt →</span>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 6 }}>{T.NIVA.map(([r, rn]) => T.NIVA.map(([c, cn]) => { const on = sh === r && tp === c; return <ChoicePill key={r + c} selected={on} aria-pressed={on} onClick={() => onChange({ hoyde: [r, c] })} style={{ minHeight: 44, justifyContent: "center" }}>{rn + " / " + cn.toLowerCase()}</ChoicePill>; }))}</div></div>
    <div role="group" aria-label="Skru og startretning" style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "500 13px/1.3 var(--font-sans)" }}>Skru og startretning</span><div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{T.SKRU.map((s) => <ChoicePill key={s} selected={t.skru === s} aria-pressed={t.skru === s} onClick={() => onChange({ skru: s })} style={{ minHeight: 44 }}>{s}</ChoicePill>)}</div></div>
  </div>;
}

/* To daterte mediespor: før og etter, hvert med bilde eller video. Alle tilstander tegnes, og resultatet står i komponenten (ikke bare i en toast). */
/* Syntetisk eksempelvideo for demodata uten fil (canvas → MediaRecorder). Bare for prototypen; ekte filer bruker sin egen URL. */
function makeSample(label) { return new Promise((res) => { try { if (!window.MediaRecorder) return res(null); const c = document.createElement("canvas"); c.width = 240; c.height = 300; const g = c.getContext("2d"), st = c.captureStream(15), rec = new MediaRecorder(st), ch = []; rec.ondataavailable = (e) => e.data && ch.push(e.data); rec.onstop = () => res(URL.createObjectURL(new Blob(ch, { type: rec.mimeType || "video/webm" }))); rec.start(); let f = 0; const iv = setInterval(() => { g.fillStyle = "#e6e3dd"; g.fillRect(0, 0, 240, 300); g.fillStyle = "#141413"; g.font = "600 20px monospace"; g.fillText(label, 16, 40); g.fillRect(20 + f * 16, 120, 40, 40); g.font = "13px monospace"; g.fillText("SYNTETISK EKSEMPELVIDEO", 16, 280); if (++f > 12) { clearInterval(iv); rec.stop(); } }, 40); } catch (e) { res(null); } }); }
function Slot({ side, m, sample, busy, err, canEdit, viewer, confirm, onPick, onAsk, onRemove, onCancel, pos }) {
  const { Button, InlineAlert } = ns(), label = side === "for" ? "Før" : "Etter", ref = React.useRef(null);
  const hidden = m && viewer === "spiller" && m.delt === false, missing = m && m.status === "mangler";
  let body;
  if (busy) body = <div role="status" style={{ aspectRatio: "4 / 5", display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid var(--border-hairline)", borderRadius: "var(--radius)" }}><Meta>LASTER OPP {label.toUpperCase()} …</Meta></div>;
  else if (!m) body = <div style={{ aspectRatio: "4 / 5", border: "1px dashed var(--border-control)", borderRadius: "var(--radius)", display: "flex", flexDirection: "column", gap: 8, alignItems: "center", justifyContent: "center", padding: 12, textAlign: "center", boxSizing: "border-box" }}><Meta>{label.toUpperCase()} · {pos}</Meta><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{canEdit ? "Ingen bilde eller video ennå" : "Ingen bilde eller video registrert"}</span></div>;
  else if (hidden) body = <div style={{ aspectRatio: "4 / 5", border: "1px solid var(--border-hairline)", borderRadius: "var(--radius)", display: "flex", flexDirection: "column", gap: 8, alignItems: "center", justifyContent: "center", padding: 12, textAlign: "center", boxSizing: "border-box" }}><Meta>{label.toUpperCase()} · {m.dato}</Meta><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Coachen har ikke delt dette mediet med deg.</span></div>;
  else if (missing) body = <div style={{ aspectRatio: "4 / 5", border: "1px solid var(--border-strong)", borderRadius: "var(--radius)", display: "flex", flexDirection: "column", gap: 8, alignItems: "center", justifyContent: "center", padding: 12, textAlign: "center", boxSizing: "border-box" }}><Meta>{label.toUpperCase()} · {m.dato}</Meta><span style={{ font: "var(--type-body-s)", color: "var(--text-primary)" }}>Filen «{m.navn}» kan ikke hentes.</span><Meta>REFERANSEN ER BEVART</Meta></div>;
  else body = <div style={{ aspectRatio: "4 / 5", position: "relative", background: "var(--surface-sunken)", borderRadius: "var(--radius)", outline: "1px solid var(--border-hairline)", outlineOffset: -1, overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>
    {m.url && m.type === "bilde" ? <img src={m.url} alt={label + "-bilde " + pos + " " + m.dato} style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : (m.url || sample) && m.type === "video" ? <video src={m.url || sample} controls muted playsInline preload="metadata" aria-label={label + "-video " + pos + " " + m.dato} style={{ width: "100%", height: "100%", objectFit: "cover" }}></video> : <Meta>{m.type === "video" ? "VIDEO LASTES …" : "BILDE"} · {pos}</Meta>}
    <span style={{ position: "absolute", left: 8, bottom: 8, font: "600 11px/1 var(--font-mono)", letterSpacing: ".04em", background: "var(--surface-card)", color: "var(--text-primary)", border: "1px solid var(--border-hairline)", borderRadius: 999, padding: "5px 8px" }}>{label.toUpperCase()} · {m.dato}</span></div>;
  return <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker">{label}</span>{m && !hidden && <Meta>{m.type.toUpperCase()} · {m.navn.toUpperCase()}{!m.url && m.type === "video" && sample ? " · SYNTETISK EKSEMPEL" : ""}{m.delt === false ? " · IKKE DELT MED SPILLER" : ""}</Meta>}</div>
    {body}
    {err && <InlineAlert tone="warn" title={err.title}>{err.text}</InlineAlert>}
    {canEdit && !busy && (confirm ? <div role="alertdialog" aria-label={"Fjern " + label.toLowerCase()} style={{ display: "flex", flexDirection: "column", gap: 8, padding: 10, border: "1px solid var(--border-strong)", borderRadius: "var(--radius)" }}><span style={{ font: "var(--type-body-s)" }}>Fjerne {label.toLowerCase()}-mediet? {side === "for" ? "Etter" : "Før"}-mediet beholdes. Dette kan ikke angres i prototypen.</span><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button size="sm" variant="destructive" icon="trash-2" onClick={onRemove} style={{ minHeight: 44 }}>Fjern {label.toLowerCase()}</Button><Button size="sm" variant="ghost" onClick={onCancel} style={{ minHeight: 44 }}>Avbryt</Button></div></div>
      : <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><input ref={ref} type="file" accept="image/*,video/*" data-file-for={side} aria-hidden="true" aria-label={label + ": velg fil"} onChange={(e) => { const f = e.target.files && e.target.files[0]; e.target.value = ""; if (f) onPick(f); }} style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }} tabIndex={-1} /><Button size="sm" variant="secondary" icon="upload" aria-label={(m ? "Erstatt " : "Last opp ") + label.toLowerCase() + "-medie"} onClick={() => ref.current && ref.current.click()} style={{ minHeight: 44 }}>{m ? "Erstatt" : "Last opp"}</Button>{m && <Button size="sm" variant="ghost" icon="trash-2" onClick={onAsk} style={{ minHeight: 44 }}>Fjern</Button>}</div>)}
  </div>;
}
function MediaTrack({ task, media, onChange, canEdit = true, viewer = "coach" }) {
  const { Button } = ns(), TPc = TP();
  const [busy, setBusy] = React.useState({}), [err, setErr] = React.useState({}), [ask, setAsk] = React.useState(null), [cmp, setCmp] = React.useState(false), [at, setAt] = React.useState(null);
  const mRef = React.useRef(media || {}), alive = React.useRef(true), tid = task.id, box = React.useRef(null), [samples, setSamples] = React.useState({});
  React.useEffect(() => { mRef.current = media || {}; }, [media]);
  React.useEffect(() => { ["for", "etter"].forEach((s) => { const x = (media || {})[s]; if (x && x.type === "video" && !x.url && x.status === "ok" && !samples[s]) makeSample(s === "for" ? "FØR " + task.pos : "ETTER " + task.pos).then((u) => alive.current && u && setSamples((o) => ({ ...o, [s]: u }))); }); }, [media && media.for && media.for.navn, media && media.etter && media.etter.navn]);
  React.useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);
  const m = media || {}, both = m.for && m.etter && m.for.status === "ok" && m.etter.status === "ok" && !(viewer === "spiller" && (m.for.delt === false || m.etter.delt === false));
  const say = (msg) => alive.current && setAt(msg + " · " + new Date().toTimeString().slice(0, 5));
  const commit = (next, msg) => { mRef.current = next; onChange(next, tid); say(msg); };
  const set = (side, v, msg) => commit({ ...mRef.current, [side]: v }, msg);
  const off = (fn) => (...a) => { if (alive.current) fn(...a); };
  const pick = (side, f) => {
    const type = f.type.startsWith("video/") ? "video" : f.type.startsWith("image/") ? "bilde" : null;
    if (!type) return setErr((e) => ({ ...e, [side]: { title: "Filtypen støttes ikke", text: "«" + f.name + "» er ikke bilde eller video. Velg JPG, PNG, HEIC, MP4 eller MOV." } }));
    if (f.size > 50e6) return setErr((e) => ({ ...e, [side]: { title: "Filen er for stor", text: "«" + f.name + "» er over 50 MB. Velg en mindre fil eller en kortere video." } }));
    setErr((e) => ({ ...e, [side]: null })); setBusy((b) => ({ ...b, [side]: true })); setAsk(null);
    const sb = off((x) => setBusy((b) => ({ ...b, [side]: x }))), se = off((x) => setErr((e) => ({ ...e, [side]: x })));
    setTimeout(() => { const done = (url) => { sb(false); set(side, { type, navn: f.name, dato: today(), status: "ok", delt: true, url }, (side === "for" ? "Før" : "Etter") + " lastet opp"); };
      if (type === "bilde" && f.size < 3e6) { const r = new FileReader(); r.onerror = () => { sb(false); se({ title: "Filen kunne ikke leses", text: "Ingenting er lagret. Prøv en annen fil." }); }; r.onload = () => done(r.result); r.readAsDataURL(f); } else done(URL.createObjectURL(f)); }, 700);
  };
  const cmpImg = both && { before: { date: m.for.dato, url: m.for.url || samples.for, type: m.for.type }, now: { date: m.etter.dato, url: m.etter.url || samples.etter, type: m.etter.type }, note: null }, vids = [m.for, m.etter].filter((x) => x && x.type === "video").length, playBoth = () => { const vs = [...(box.current ? box.current.querySelectorAll("video") : [])].slice(0, 2); const paused = vs.some((x) => x.paused); vs.forEach((x) => { if (paused) { x.currentTime = 0; const p = x.play(); if (p && p.catch) p.catch(() => {}); } else x.pause(); }); };
  return <div ref={box} style={{ display: "flex", flexDirection: "column", gap: 12, minWidth: 0 }}>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 12, maxWidth: 720 }}>{["for", "etter"].map((s) => <Slot key={s} side={s} m={m[s]} sample={samples[s]} busy={!!busy[s]} err={err[s]} canEdit={canEdit} viewer={viewer} confirm={ask === s} pos={task.pos} onPick={(f) => pick(s, f)} onAsk={() => setAsk(s)} onCancel={() => setAsk(null)} onRemove={() => { setAsk(null); set(s, null, (s === "for" ? "Før" : "Etter") + " fjernet"); }} />)}</div>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
      {canEdit && <Button size="sm" variant="secondary" icon="arrow-left-right" disabled={!(m.for && m.etter)} onClick={() => commit({ ...mRef.current, for: mRef.current.etter, etter: mRef.current.for }, "Før og etter er byttet")} style={{ minHeight: 44 }}>Bytt før og etter</Button>}
      <Button size="sm" variant="secondary" icon="columns-2" disabled={!both} aria-pressed={cmp} onClick={() => setCmp(!cmp)} style={{ minHeight: 44 }}>{cmp ? "Skjul sammenligning" : "Sammenlign"}</Button>
      {vids > 0 && <Button size="sm" variant="secondary" icon="play" disabled={!both} onClick={playBoth} style={{ minHeight: 44 }}>Spill av begge</Button>}{!both && <Meta>SAMMENLIGNING KREVER TO TILGJENGELIGE MEDIER</Meta>}{both && vids > 0 && <Meta>{vids === 2 ? "VIDEO" : "BILDE OG VIDEO"} SAMMENLIGNES SIDE OM SIDE</Meta>}
    </div>
    {cmp && both && <TPc.BeforeAfter img={cmpImg} pos={task.pos} mob={false} />}
    <div aria-live="polite"><Meta>{at ? "SIST: " + at.toUpperCase() : "INGEN ENDRINGER I DENNE ØKTEN"}</Meta></div>
  </div>;
}

/* Fokus: gyldig verdi følger området (master 14.3). Ugyldig eldre verdi bevares som historikk og vises entydig. */
function focusOptions(area) { return (window.AK_VOCAB.dimsFor(area) || []).slice(); }

/* Publisering mellom coach og spiller i prototypen (ingen server/DB). Vertene er egne vinduer, så publisert ØYEBLIKKSBILDE deles via localStorage. Nøkkel: playerId + planId + taskId + rev. Utkast lekker ikke: spilleren ser bare siste publiserte revisjon per oppgave og Scope hindrer blanding av spillere/planer. */
/* Testisolasjon: ?ns=<id> i vert-URL gir egen lagringsnøkkel og syntetisk spiller/plan (playerId p1@ns, planId …@ns). Uten ns brukes p1 / tp-2026h og standardnøkkelen. */
const NS = (() => { try { return new URLSearchParams(location.search).get("ns") || ""; } catch (e) { return ""; } })();
const PUBKEY = "ak-proto-publisert-v2" + (NS ? ":" + NS : "");
const scope = () => ({ playerId: "p1" + (NS ? "@" + NS : ""), planId: ((window.TP_DATA && window.TP_DATA.plan && window.TP_DATA.plan.id) || "tp-2026h") + (NS ? "@" + NS : "") });
const all = () => { try { return JSON.parse(localStorage.getItem(PUBKEY) || "[]"); } catch (e) { return []; } };
const same = (s) => s && s.playerId === scope().playerId && s.planId === scope().planId;
const published = () => all().filter((x) => same(x.scope));
const clean = (o) => JSON.parse(JSON.stringify(o, (k, val) => (typeof val === "string" && val.startsWith("blob:")) ? undefined : val));
const publish = (e) => { const D = window.TP_DATA, t = e.task || (D && D.tasks.find((x) => x.id === e.taskId)); const snap = { scope: scope(), taskId: e.taskId || (t && t.id), rev: e.rev != null ? e.rev : (t && t.rev) || 0, title: e.title || (t && t.title), pos: e.pos || (t && t.pos), uke: e.uke, kilde: e.kilde, task: t ? clean(t) : null, media: t && D && D.MEDIA[t.id] ? clean(D.MEDIA[t.id]) : null, time: new Date().toTimeString().slice(0, 5) }; const l = all().filter((x) => !(same(x.scope) && x.taskId === snap.taskId && x.kilde === snap.kilde)); l.push(snap); try { localStorage.setItem(PUBKEY, JSON.stringify(l)); } catch (x) {} };
/* Siste publiserte revisjon per oppgave (høyeste rev, deretter nyeste). */
const publishedTasks = () => { const m = {}; published().filter((x) => x.task).forEach((x) => { const c = m[x.taskId]; if (!c || x.rev >= c.rev) m[x.taskId] = x; }); return m; };
/* Spillerens oppgaveliste: baseline (seed) overlagt siste publiserte revisjon, pluss nye publiserte oppgaver. */
const playerTasks = (seed) => { const sn = publishedTasks(), base = seed.map((t) => sn[t.id] ? { ...t, ...sn[t.id].task } : t), extra = Object.values(sn).filter((s) => !seed.some((t) => t.id === s.taskId)).map((s) => s.task); return [...base, ...extra]; };
const playerMedia = (id, seedMedia) => { const s = publishedTasks()[id]; return s && s.media ? s.media : (seedMedia || {}); };
window.TP2 = { published, publish, publishedTasks, playerTasks, playerMedia, scope, StrokeChoice, MediaTrack, focusOptions, posName, today };
})();
