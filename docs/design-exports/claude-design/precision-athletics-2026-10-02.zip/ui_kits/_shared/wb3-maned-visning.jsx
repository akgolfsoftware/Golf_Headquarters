/* Ren månedsvisning. Ingen planmodell, lagring, datoallokering eller globale datalesere.
   MonthWeeks({ K, rows, onWeek, selectedWeek, onReset?, showSummary? }).
   rows: { weekKey, aar, uke, fra, til, label?, count:{akse:number|null}, min:{akse:number|null},
           source:{count:{akse:string|null},min:{akse:string|null}}, override:boolean, basisLabel?:string }[].
   onWeek/onReset(weekKey, row): verten eier navigasjonsvakt, fra-måned, lagring, feil og retur.
   Eksisterende uke-rad/rediger-uke/tilbakestill-uke-ID-er beholdes. */
(() => {
  const AX = ["fys", "tek", "slag", "spill", "turn"], PL = { fys: "FYS", tek: "TEK", slag: "SLAG", spill: "SPILL", turn: "TURN" };
  const txt = { font: "var(--type-body-s)", color: "var(--text-primary)", overflowWrap: "anywhere" };
  const meta = { font: "var(--type-meta)", color: "var(--text-muted)", overflowWrap: "anywhere" };
  const stack = { display: "flex", flexDirection: "column", gap: 6, minWidth: 0 };
  const n = (v) => v == null ? "—" : String(v), date = (s) => s ? s.slice(8, 10) + "." + s.slice(5, 7) : "—";
  const value = (r, field, a) => r[field] && r[field][a] != null ? r[field][a] : null;
  const source = (r, field, a) => r.source && r.source[field] && r.source[field][a] ? r.source[field][a] : null;
  const weekLabel = (r) => r.label || "Uke " + r.uke + " · " + r.aar + " · " + date(r.fra) + "–" + date(r.til);
  /* Hele gamle akseteksten står synlig i hver rad, med null≠0. Tillegg skiller tidskilde fra antallskilde. */
  function AxisValue({ row, axis }) {
    const a = value(row, "count", axis), t = value(row, "min", axis), s = source(row, "count", axis), sm = source(row, "min", axis);
    return <div style={stack} data-axis={axis}>
      <span style={{ ...txt, font: "500 13px/1.4 var(--font-mono)", fontVariantNumeric: "tabular-nums" }}><b>{PL[axis]}</b>{" " + n(a) + " / " + n(t) + " min" + (s ? " (" + s + ")" : "")}</span>
      <span style={meta}>Antall: {a == null ? "ikke satt" : s || "kilde ikke oppgitt"} · Tid: {t == null ? "ikke satt" : sm || "kilde ikke oppgitt"}</span>
    </div>;
  }
  function Actions({ K, row, onWeek, onReset }) {
    const { Button } = K.ns();
    return <div style={{ display: "flex", gap: 8, flexWrap: "wrap", minWidth: 0 }}>
      <Button size="sm" variant="secondary" data-control-id={"rediger-uke-" + row.weekKey} data-wb={"mw-" + row.weekKey} data-week-key={row.weekKey} aria-label={"Åpne uke " + row.uke + " " + row.aar} disabled={!onWeek} onClick={() => onWeek && onWeek(row.weekKey, row)} style={{ minHeight: 44, height: "auto", whiteSpace: "normal" }}>Åpne uke</Button>
      {onReset && <Button size="sm" variant="secondary" data-control-id={"tilbakestill-uke-" + row.weekKey} data-week-key={row.weekKey} aria-label={"Tilbakestill uke " + row.uke + " til arvet"} disabled={!row.override} onClick={() => onReset(row.weekKey, row)} style={{ minHeight: 44, height: "auto", whiteSpace: "normal" }}>Tilbakestill til arvet</Button>}
    </div>;
  }
  function Lead({ row, selected, bind }) {
    return <div ref={bind} style={stack}>
      <strong style={{ ...txt, fontWeight: 600 }}>{weekLabel(row)}{row.override ? " · overstyrt" : ""}</strong>
      {selected && <span style={meta}>VALGT UKE</span>}
      {row.basisLabel && <span style={meta}>{row.basisLabel}</span>}
    </div>;
  }
  function Coverage({ rows }) {
    const N = rows.length, sum = (field, a) => {
      const known = rows.map((r) => value(r, field, a)).filter((v) => v != null);
      return { known: known.length, sum: known.reduce((s, v) => s + v, 0) };
    }, label = (field, a, unit) => {
      const s = sum(field, a);
      return (s.known ? "Kjent delsum " + s.sum + " " + unit : "Budsjett —") + " · budsjett mangler i " + (N - s.known) + " av " + N + " uker";
    };
    return <details className="wb3-month-coverage" style={{ borderTop: "1px solid var(--border-hairline)", paddingTop: 8 }}>
      <summary style={{ ...txt, cursor: "pointer", minHeight: 44, display: "list-item", alignContent: "center" }}>Vis kjent delsum og budsjettdekning</summary>
      <div style={{ ...stack, gap: 12, paddingTop: 8 }}>
        <p style={{ ...txt, margin: 0 }}>Bare satte budsjetter i de viste hele ukene summeres. Uker som berører to måneder tas med som hele uker her. Dette er ingen fordeling på månedsdatoer; ukjent budsjett er ikke 0.</p>
        {AX.map((a) => <div key={a} style={stack} data-axis={a}>
          <strong style={txt}>{PL[a]}</strong>
          <span style={txt}>Antall: {label("count", a, "økter")}</span>
          <span style={txt}>Minutter: {label("min", a, "min")}</span>
        </div>)}
      </div>
    </details>;
  }
  function MonthWeeks({ K, rows = [], onWeek, selectedWeek, onReset, showSummary = true }) {
    const { DataTable } = K.ns(), root = React.useRef(null), [width, setWidth] = React.useState(0);
    React.useLayoutEffect(() => {
      const el = root.current; if (!el) return;
      setWidth(el.getBoundingClientRect().width);
      const ro = new ResizeObserver(([e]) => setWidth(e.contentRect.width)); ro.observe(el); return () => ro.disconnect();
    }, []);
    /* DataTable tar ikke rowProps. Ref på første celle merker den faktiske TR-en uten doble/skjulte uke-rader. */
    const bindRow = (r) => (el) => {
      const tr = el && el.closest("tr"); if (!tr) return;
      tr.setAttribute("data-control-id", "uke-rad-" + r.weekKey);
      tr.setAttribute("data-week-key", r.weekKey);
      tr.setAttribute("data-selected", String(r.weekKey === selectedWeek));
    };
    const columns = [{ key: "week", label: "Uke og grunnlag", render: (r) => <Lead row={r} selected={r.weekKey === selectedWeek} bind={bindRow(r)} /> },
      ...AX.map((a) => ({ key: a, label: PL[a] + " · økter / min", render: (r) => <AxisValue row={r} axis={a} /> })),
      { key: "actions", label: "Handling", render: (r) => <Actions K={K} row={r} onWeek={onWeek} onReset={onReset} /> }];
    return <section ref={root} className="wb3-month-weeks" aria-label="Uker i måneden" style={{ ...stack, gap: 12 }}>
      <style>{`.wb3-month-weeks .pa-table th,.wb3-month-weeks .pa-table td{padding-left:8px;padding-right:8px;white-space:normal}.wb3-month-weeks .pa-table tbody tr[data-selected="true"]{box-shadow:inset 2px 0 0 var(--border-ink);background:var(--surface-flat)}.wb3-month-weeks summary:focus-visible{outline:2px solid var(--focus-ring);outline-offset:2px;border-radius:var(--radius)}`}</style>
      <K.Meta>UKER I MÅNEDEN · ARVET OG OVERSTYRT ANTALL ØKTER / MINUTTER PER UKE</K.Meta>
      <p style={{ ...txt, margin: 0 }}>Antall økter / minutter vises per hele kalenderuke. — betyr ikke satt; 0 er et satt budsjett.</p>
      {rows.length === 0 ? <p style={{ ...txt, margin: 0 }} data-control-id="maaned-ingen-uker">Ingen uker i dette månedsutvalget. Velg en måned innenfor årsplanens datoer.</p> : width >= 700 ?
        <DataTable columns={columns} rows={rows} rowKey="weekKey" caption="Uker i måneden · antall økter og minutter per uke" emptyText="Ingen uker i denne måneden" /> :
        <div role="list" style={stack}>{rows.map((r) => <div key={r.weekKey} role="listitem" data-control-id={"uke-rad-" + r.weekKey} data-week-key={r.weekKey} style={{ ...stack, gap: 12, padding: 12, border: "1px solid var(--border-hairline)", borderRadius: "var(--radius)", background: r.weekKey === selectedWeek ? "var(--surface-flat)" : "var(--surface-card)", boxShadow: r.weekKey === selectedWeek ? "inset 2px 0 0 var(--border-ink)" : "none" }}>
          <Lead row={r} selected={r.weekKey === selectedWeek} />
          <div style={{ ...stack, gap: 10 }}>{AX.map((a) => <AxisValue key={a} row={r} axis={a} />)}</div>
          <Actions K={K} row={r} onWeek={onWeek} onReset={onReset} />
        </div>)}</div>}
      {rows.length > 0 && showSummary && <Coverage rows={rows} />}
    </section>;
  }
  window.WB3_MANED_VISNING = { MonthWeeks };
})();
