/* Delt 8-trinns øvelsesskjema (trukket ut av WB3.jsx). Brukes av Workbench (Ny øvelse) og av egne planer (Ny øvelse / Rediger drillInstanceId). */
(() => {
  const W = () => window.WB3, AXL = { fys: "FYS", tek: "TEK", slag: "SLAG", spill: "SPILL", turn: "TURN" };
  const dflt = (axis) => ({ axis, area: W().areas.find((a) => W().bank.some((b) => b.axis === axis && b.area === a)) || W().areas[0], mot: W().motorikk[1], bel: W().belastning[0], press: W().press[0], name: "", gear: "Ikke relevant", way: "Blokk", focus: null, qty: "", goal: "" });
  function ExForm({ K, ex, setEx, title, saveLabel, onSave, onClose }) {
    const { Button, Sheet, TextInput, Select } = K.ns(), M = K.Meta;
    return <Sheet open onClose={onClose} kicker={"Egen øvelse · AK-formel v2 · " + AXL[ex.axis]} title={title} footer={<><Button fullWidth icon="check" data-control-id="ex-lagre" disabled={!ex.name.trim()} onClick={() => onSave(ex)}>{saveLabel}</Button><Button variant="ghost" fullWidth data-control-id="ex-avbryt" onClick={onClose}>Avbryt</Button></>}>
      <M>PYRAMIDE {AXL[ex.axis]} · STYRER KATEGORISERINGEN VIDERE</M>
      <label data-control-id="ex-navn" style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-secondary)" }}>Navn</span><TextInput value={ex.name} onChange={(e) => setEx({ ...ex, name: e.target.value })} placeholder="Innspill 50–100 m · tre mål" /></label>
      <Select label="Område (19)" value={ex.area} onChange={(e) => setEx({ ...ex, area: e.target.value })} options={W().areas} />
      {/^Putt/.test(ex.area) ? <M>LÆRINGSSTEG · — · PUTT FÅR ALDRI LÆRINGSSTEG</M> : <Select label="Motorikk" value={ex.mot} onChange={(e) => setEx({ ...ex, mot: e.target.value })} options={W().motorikk} />}
      <Select label="Treningsmiljø" value={ex.bel} onChange={(e) => setEx({ ...ex, bel: e.target.value })} options={W().belastning} />
      <Select label="Press" value={ex.press} onChange={(e) => setEx({ ...ex, press: e.target.value })} options={W().press} />
      {ex.axis !== "fys" && <Select label="Måleutstyr (trinn 4)" value={ex.gear || "Ikke relevant"} onChange={(e) => setEx({ ...ex, gear: e.target.value })} options={["Med TrackMan", "Uten TrackMan", "Annen radar", "Ikke relevant"]} />}
      {ex.axis !== "fys" && <Select label="Treningsmåte (trinn 5)" value={ex.way || "Blokk"} onChange={(e) => setEx({ ...ex, way: e.target.value })} options={["Blokk", "Variabel", "Konkurranse", "Spill/test"]} />}
      {(ex.axis === "tek" || ex.axis === "slag") && ((window.AK_VOCAB && window.AK_VOCAB.dimsFor(ex.area.replace(/^Putt /, "Putting "))) || []).length > 0 && <Select label="Teknisk fokus (trinn 5 · maks ett)" value={ex.focus || ""} onChange={(e) => setEx({ ...ex, focus: e.target.value || null })} options={[{ value: "", label: "Ingen" }].concat(window.AK_VOCAB.dimsFor(ex.area.replace(/^Putt /, "Putting ")).map((d) => ({ value: d, label: d })))} />}
      <label data-control-id="ex-qty" style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-secondary)" }}>Mengde (trinn 7)</span><TextInput value={ex.qty || ""} onChange={(e) => setEx({ ...ex, qty: e.target.value })} placeholder={ex.axis === "fys" ? "4 serier × 6" : "30 slag"} /></label>
      <label style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-secondary)" }}>Mål og resultatkrav (trinn 8 · valgfritt)</span><TextInput value={ex.goal || ""} onChange={(e) => setEx({ ...ex, goal: e.target.value })} placeholder="20 av 30 innenfor målområdet" /></label>
      <div style={{ display: "flex", flexDirection: "column", gap: 6, paddingTop: 10, borderTop: "1px solid var(--border-hairline)" }}><M>AK-FORMELEN · MERKELAPP AVLEDET AV VALGENE, STYRER IKKE PLANLEGGINGEN</M><window.AKGolfPrecisionAthletics_7d7c29.FormulaCode parts={[AXL[ex.axis], ex.area.toUpperCase().replace(/[ –]/g, ""), /^Putt/.test(ex.area) || ex.axis === "fys" ? null : ex.mot, ex.bel, ex.press].filter(Boolean).map((s) => String(s).toUpperCase().replace(/ /g, ""))} /></div>
    
    </Sheet>;
  }
  window.WB3_EX = { ExForm, dflt };
})();
