/* Teknisk plan · aktive datatillegg. Bare faste posisjoner P1.0–P10.0. Syntetiske eksempeldata. */
(() => {
const D = window.TP_DATA, V = window.AK_VOCAB;
D.NIVA = [["lav", "Lav"], ["med", "Medium"], ["hoy", "Høy"]];
D.SKRU = ["Rett", "Draw", "Fade", "Hook", "Slice", "Push", "Pull"];
const stroke = { t1: [["lav", "lav"], "Fade"], t2: [["hoy", "hoy"], "Draw"], t3: [["med", "med"], "Rett"], t4: [["lav", "lav"], "Rett"], t5: [["med", "hoy"], "Rett"] };
D.tasks = D.tasks.filter((t) => D.POS.some(([p]) => p === t.pos));
D.tasks.forEach((t) => { const s = stroke[t.id] || [["med", "med"], "Rett"]; t.hoyde = s[0]; t.skru = s[1]; });
/* Før og etter. type bilde|video. status ok|mangler. Ingen ekte mediefiler i prototypen. */
D.MEDIA = {
  t1: { for: { type: "bilde", navn: "P7_for.jpg", dato: "12.08.2026", status: "ok", delt: true }, etter: { type: "bilde", navn: "P7_etter.jpg", dato: "24.09.2026", status: "ok", delt: true } },
  t2: { for: { type: "video", navn: "P6_for.mp4", dato: "12.08.2026", status: "ok", delt: true }, etter: null },
  t4: { for: null, etter: { type: "video", navn: "pitch_etter.mp4", dato: "26.09.2026", status: "ok", delt: false } },
  t5: { for: { type: "bilde", navn: "sand_for.jpg", dato: "20.09.2026", status: "mangler", delt: true }, etter: null },
};
D.tasks.forEach((t) => { t.rev = t.rev || 1; }); D.plan.ownerId = D.plan.ownerId || "p1";
D.NYERE = { t1: { rev: (D.tasks.find((t) => t.id === "t1").rev || 1) + 1, tittel: "Hendene foran ballen i treff · presisert", innhold: "Presisert til 7-jern lav fade, tre treff på rad før progresjon", media: "P7_etter_v2.jpg", status: "Kandidat (syntetisk)" } };
D.focusOk = (t) => !t.focus || t.focus === "—" || (V && V.dimsFor ? (V.dimsFor(t.area) || []).includes(t.focus) : true);
D.plan.done = D.tasks.reduce((a, t) => a + D.sum(t)[0], 0); D.plan.goal = D.tasks.reduce((a, t) => a + D.sum(t)[1], 0);
})();
