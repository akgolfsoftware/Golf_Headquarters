/* Workbench over uka — runde 33 (Anders 28.09.2026, bindende). År · Periode · Måned for spiller (PH-11) og coach (AG-11). Oppdiktede data i WB3.yr.
   Årsplan: periodene som tynt tekstbånd over året (farge = bare akse). Veileder «Opprett årsplan» i tre steg. Periode- og månedsskjema: ark på mobil, dialog på desktop.
   Måneden har eget innhold (fokus, mål, timer per uke, tester og turneringer, notat, evaluering). Uka arver timene fra måneden: planlagt mot fordelt. */
(() => {
const W = () => window.WB3, Y = () => window.WB3.yr, DAY = 864e5;
const AX = ["fys", "tek", "slag", "spill", "turn"], AXL = { fys: "FYS", tek: "TEK", slag: "SLAG", spill: "SPILL", turn: "TURN" };
const MN = ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"];
const pd = (s) => { const [d, m, y] = s.split(".").map(Number); return Date.UTC(y, m - 1, d); };
const ds = (t, y) => { const d = new Date(t); return String(d.getUTCDate()).padStart(2, "0") + "." + String(d.getUTCMonth() + 1).padStart(2, "0") + (y ? "." + d.getUTCFullYear() : ""); };
const fmt = (v) => String(Math.round(v * 10) / 10).replace(".", ",");
const num = (s) => { const v = parseFloat(String(s).replace(",", ".")); return isNaN(v) ? 0 : Math.max(0, v); };
const tot = (h) => AX.reduce((a, k) => a + num(h[k]), 0);
const isoW = (t) => { const d = new Date(t); d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7)); return Math.ceil(((d - Date.UTC(d.getUTCFullYear(), 0, 1)) / DAY + 1) / 7); };
const okDate = (s) => /^\d{2}\.\d{2}\.\d{4}$/.test(s || "") && !isNaN(pd(s));
const tname = (k) => (Y().types.find((t) => t[0] === k) || [k, k])[1];
const lane = (k) => (Y().types.find((t) => t[0] === k) || [0, 0, 0])[2];
const mkey = (t) => { const d = new Date(t); return d.getUTCFullYear() + "-" + String(d.getUTCMonth() + 1).padStart(2, "0"); };
const monthsOf = (plan) => { const out = [], a = new Date(pd(plan.from)), b = new Date(pd(plan.to)); let y = a.getUTCFullYear(), m = a.getUTCMonth(); while (y < b.getUTCFullYear() || (y === b.getUTCFullYear() && m <= b.getUTCMonth())) { const t0 = Date.UTC(y, m, 1), t1 = Date.UTC(y, m + 1, 1) - DAY; out.push({ key: y + "-" + String(m + 1).padStart(2, "0"), y, m, t0, t1, name: MN[m] + " " + y, short: MN[m].slice(0, 3).toUpperCase() }); if (++m > 11) { m = 0; y++; } } return out; };
const weeksIn = (t0, t1) => { const out = []; for (let t = t0; t <= t1; t += DAY) if (new Date(t).getUTCDay() === 4) out.push({ w: isoW(t), thu: t, mon: t - 3 * DAY, sun: t + 3 * DAY }); return out; };
const at = (plan, t, ln) => plan.periods.find((p) => lane(p.type) === ln && pd(p.from) <= t && t <= pd(p.to));
const ZERO = { fys: 0, tek: 0, slag: 0, spill: 0, turn: 0 };
const defAlloc = (plan, thu) => { const e = at(plan, thu, 1); if (e && e.type !== "heldag") return e.h; const p = at(plan, thu, 0); return p ? p.h : ZERO; };
const allocOf = (plan, wk) => { const o = (plan.months[mkey(wk.thu)] || {}).alloc; return o && o[wk.w] ? o[wk.w] : defAlloc(plan, wk.thu); };
const srcL = (p, mode, coach, first) => mode === "gruppe" ? "" : p.src === "gruppe" ? "FRA GRUPPA" : p.src === "coach" ? "FRA ANDERS" : coach ? "LAGT INN AV " + first.toUpperCase() : "EGEN";
const byFrom = (a, b) => pd(a.from) - pd(b.from) || lane(a.type) - lane(b.type);
const TODAY = () => pd(Y().today);
const CODE = { grunn: "GP", spesial: "SP", turnering: "TP", evaluering: "EV", restitusjon: "RE", testuke: "TU", samling: "TS", heldag: "HS", ferie: "FE" };
const plabel = (p) => { const n = tname(p.type); return lane(p.type) && p.focus ? (p.focus.indexOf(n) === 0 ? p.focus : n + " · " + p.focus) : n; };
let _cv; const tw = (s) => { _cv = _cv || document.createElement("canvas"); const c = _cv.getContext("2d"); c.font = "500 11px " + (getComputedStyle(document.documentElement).getPropertyValue("--font-mono").trim() || "monospace"); return c.measureText(s).width + s.length * 0.44; };
if (!document.getElementById("wb3-ar-css")) { const st = document.createElement("style"); st.id = "wb3-ar-css"; st.textContent = "@media (max-width:1024px){.pa-sheet.wb3-sheet{min-height:78%;animation-name:wb3-rise}}@keyframes wb3-rise{from{transform:translateY(24px)}to{transform:none}}"; document.head.appendChild(st); }
/* Vannrett bånd (bredde ≥ 700): navnet står i båndet bare når det får plass. Ellers forkortelse i båndet, eller forkortelse under båndet med tynn strek. Aldri «…». */
function YearBand({ K, plan, per, sel, onP, onM }) {
  const M = K.Meta, { Button } = K.ns(), ref = React.useRef(null), [bw, setBw] = React.useState(0);
  React.useLayoutEffect(() => { const el = ref.current; if (!el) return; setBw(el.getBoundingClientRect().width); const ro = new ResizeObserver(([e]) => setBw(e.contentRect.width)); ro.observe(el); return () => ro.disconnect(); }, []);
  const T0 = pd(plan.from), T1 = pd(plan.to) + DAY, span = T1 - T0, pct = (t) => Math.max(0, Math.min(100, (t - T0) / span * 100)), mons = monthsOf(plan);
  const items = per.filter((p) => pd(p.to) >= T0 && pd(p.from) < T1).map((p) => { const l = pct(pd(p.from)), r = pct(pd(p.to) + DAY), px = (r - l) / 100 * bw - 2, name = tname(p.type).toUpperCase(); return { p, l, r, ln: lane(p.type), name, mode: bw && tw(name) + 10 <= px ? "full" : bw && tw(CODE[p.type]) + 10 <= px ? "code" : "out" }; });
  const outs = items.filter((i) => i.mode === "out").sort((x, y) => x.l - y.l), ends = [-99, -99];
  outs.forEach((o) => { const w = tw(CODE[o.p.type]) + 10, cx = (o.l + o.r) / 200 * bw, x = Math.max(0, Math.min(bw - w, cx - w / 2)); let row = ends.findIndex((e) => x > e + 4); if (row < 0) row = 1; o.row = row; o.x = x; o.cx = cx; ends[row] = x + w; });
  const rows = outs.length ? Math.max(...outs.map((o) => o.row)) + 1 : 0, legend = items.filter((i) => i.mode !== "full");
  const lab = { font: "500 11px/1.2 var(--font-mono)", letterSpacing: ".04em", textTransform: "uppercase", color: "var(--text-primary)", whiteSpace: "nowrap" };
  return <div data-band="" style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}>
    <div role="group" aria-label="Måneder" style={{ display: "grid", gridTemplateColumns: mons.map((m) => "minmax(0," + ((Math.min(m.t1 + DAY, T1) - Math.max(m.t0, T0)) / DAY) + "fr)").join(" ") }}>{mons.map((m) => <button key={m.key} type="button" onClick={() => onM(m.key)} aria-label={"Åpne " + m.name} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", minHeight: 44, minWidth: 0, display: "grid", placeItems: "center", borderLeft: "1px solid var(--border-hairline)", font: "600 11px/1 var(--font-mono)", color: m.key === mkey(TODAY()) ? "var(--text-primary)" : "var(--text-muted)", letterSpacing: ".04em" }}>{bw && bw / mons.length < 40 ? m.short[0] : m.short}</button>)}</div>
    <div ref={ref} role="list" aria-label="Perioder på tidslinjen" style={{ position: "relative", height: 96 + rows * 28, minWidth: 0 }}>
      {mons.map((m) => <span key={m.key} aria-hidden="true" style={{ position: "absolute", top: 0, height: 92, left: pct(m.t0) + "%", width: 1, background: "var(--border-hairline)" }}></span>)}
      {items.map((i) => { const on = sel === i.p.id; return <div key={i.p.id} aria-hidden="true" style={{ boxSizing: "border-box", position: "absolute", left: i.l + "%", width: "max(4px, calc(" + (i.r - i.l) + "% - 2px))", top: 4 + i.ln * 46, height: 40, borderTop: (i.ln ? 1 : 2) + "px solid var(--text-primary)", padding: "5px 4px 0", ...lab, background: on ? "var(--surface-flat)" : "transparent", boxShadow: on ? "inset 0 0 0 1px var(--border-ink)" : "none" }}>{i.mode === "full" ? i.name : i.mode === "code" ? CODE[i.p.type] : ""}</div>; })}
      {outs.map((o) => <React.Fragment key={"o" + o.p.id}><span aria-hidden="true" style={{ position: "absolute", left: o.cx, top: 4 + o.ln * 46 + 40, height: 96 - (4 + o.ln * 46 + 40) + o.row * 28 + 2, width: 1, background: "var(--text-primary)" }}></span><div aria-hidden="true" style={{ boxSizing: "border-box", position: "absolute", left: o.x, top: 98 + o.row * 28, height: 24, padding: "0 4px", display: "grid", placeItems: "center", border: "1px solid var(--text-primary)", borderRadius: 4, background: sel === o.p.id ? "var(--surface-flat)" : "var(--surface-card)", ...lab }}>{CODE[o.p.type]}</div></React.Fragment>)}
      {TODAY() >= T0 && TODAY() < T1 && <span aria-hidden="true" style={{ position: "absolute", top: 0, height: 92, left: pct(TODAY()) + "%", width: 0, borderLeft: "1px dashed var(--text-primary)" }}></span>}
    </div>
    <div role="group" aria-label="Åpne periode" style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{items.map((i) => <Button key={"c" + i.p.id} size="sm" variant={sel === i.p.id ? "primary" : "secondary"} aria-pressed={sel === i.p.id} aria-label={plabel(i.p) + ", " + i.p.from + "–" + i.p.to} onClick={() => onP(i.p.id)} style={{ minHeight: 44, minWidth: 44 }}>{plabel(i.p)} · {i.p.from.slice(0, 5)}–{i.p.to.slice(0, 5)}</Button>)}</div>
    {legend.length > 0 && <div role="list" aria-label="Forkortelser" style={{ display: "flex", gap: "4px 16px", flexWrap: "wrap" }}>{legend.map((i) => <span role="listitem" key={i.p.id} style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-primary)" }}><b style={{ fontWeight: 600 }}>{CODE[i.p.type]}</b> {plabel(i.p)} · {i.p.from.slice(0, 5)}{i.p.to !== i.p.from ? "–" + i.p.to.slice(0, 5) : ""}</span>)}</div>}
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}><M>STIPLET LINJE = I DAG {Y().today.slice(0, 5)}</M><M>ØVERST PERIODER · NEDERST SAMLINGER, TESTUKER OG FERIE</M></div>
  </div>;
}
/* Loddrett år (bredde < 700): måneder nedover, periodene som rader med fullt navn. */
function YearList({ K, plan, per, sel, onP, onM }) {
  const M = K.Meta, mons = monthsOf(plan), T = TODAY();
  return <div data-band="" role="list" aria-label="Året måned for måned" style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>{mons.map((m, i) => { const act = per.filter((p) => pd(p.to) >= m.t0 && pd(p.from) <= m.t1), now = T >= m.t0 && T <= m.t1;
    return <div role="listitem" key={m.key} style={{ display: "grid", gridTemplateColumns: "64px minmax(0,1fr)", gap: 8, borderTop: i ? "1px solid var(--border-hairline)" : "none", padding: "4px 0" }}>
      <button type="button" onClick={() => onM(m.key)} aria-label={"Åpne " + m.name} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", minHeight: 44, display: "flex", flexDirection: "column", gap: 3, paddingTop: 10, font: "600 12px/1.2 var(--font-mono)", color: "var(--text-primary)", letterSpacing: ".04em" }}>{m.short} {String(m.y).slice(2)}{now && <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>I DAG {Y().today.slice(0, 5)}</span>}</button>
      <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>{act.length ? act.map((p) => { const a = pd(p.from) >= m.t0, b = pd(p.to) <= m.t1, on = sel === p.id; return <button key={p.id} type="button" onClick={() => onP(p.id)} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", minHeight: 44, display: "flex", flexDirection: "column", justifyContent: "center", gap: 2, paddingLeft: 10, boxShadow: "inset " + (lane(p.type) ? 1 : 2) + "px 0 0 var(--text-primary)" + (on ? ", inset 0 0 0 1px var(--border-ink)" : ""), background: on ? "var(--surface-flat)" : "transparent", minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{plabel(p)}</span><M>{a && b ? p.from.slice(0, 5) + (p.to !== p.from ? "–" + p.to.slice(0, 5) : "") : a ? "FRA " + p.from.slice(0, 5) : b ? "TIL " + p.to.slice(0, 5) : "HELE MÅNEDEN"}</M></button>; }) : <span style={{ minHeight: 44, display: "flex", alignItems: "center" }}><M>INGEN PERIODE</M></span>}</div>
    </div>; })}</div>;
}
const txt = { margin: 0, font: "var(--type-body-s)", color: "var(--text-primary)", textWrap: "pretty" };
const Lbl = ({ t, children }) => <label style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-secondary)" }}>{t}</span>{children}</label>;
const Area = (p) => <textarea className="pa-control" rows={3} {...p} style={{ width: "100%", boxSizing: "border-box", resize: "vertical", font: "var(--type-body)", minHeight: 88, padding: 12 }}></textarea>;
const Head = ({ K, k, children }) => <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", justifyContent: "space-between", paddingTop: 12, borderTop: "1px solid var(--border-hairline)" }}><K.Meta>{k}</K.Meta>{children}</div>;

function useYP({ empty, mode, wiz0, pf0, mf0 }) {
  /* Ren adapter: ingen demo-data. Plan/valg kommer fra WB3_LOKAL; hooket holder bare lokal UI-tilstand for gamle primitiver. */
  const src = () => null;
  const [plan, setPlan] = React.useState(src), [sel, setSel] = React.useState(""), [mk, setMk] = React.useState("");
  const [wiz, setWiz] = React.useState(wiz0 ? { step: 1, src: null, std: null, from: "", to: "", name: "", sum: "" } : null);
  const [pf, setPf] = React.useState(null);
  const [mf, setMf] = React.useState(null);
  const first = React.useRef(true);
  React.useEffect(() => { if (first.current) { first.current = false; return; } setPlan(src()); setPf(null); setMf(null); }, [mode]);
  return { plan, setPlan, sel, setSel, mk, setMk, wiz, setWiz, pf, setPf, mf, setMf };
}
function monthForm(plan, key) {
  const m = monthsOf(plan).find((x) => x.key === key), o = plan.months[key] || {}, wks = weeksIn(m.t0, m.t1), mid = at(plan, m.t0 + 14 * DAY, 0);
  return { key, focus: o.focus != null ? o.focus : mid ? mid.focus : "", goals: o.goals || [], events: o.events || [], note: o.note || "", done: o.done, eval: { coach: "", player: "", ...(o.eval || {}) },
    alloc: Object.fromEntries(wks.map((w) => { const a = allocOf(plan, w); return [w.w, Object.fromEntries(AX.map((k) => [k, fmt(a[k])]))]; })) };
}
const blankP = (plan) => ({ id: "n" + Date.now(), isNew: true, type: "grunn", from: "", to: "", focus: "", h: { fys: "3", tek: "2", slag: "4", spill: "1", turn: "0" }, note: "", src: "egen" });

/* Uka: planlagt (øktene i kalenderen) mot fordelt (fra måneden). */
function WeekAlloc({ K, yp, week, ses }) {
  const M = K.Meta, plan = yp.plan;
  if (!plan) return <M>INGEN ÅRSPLAN · UKA HAR INGEN FORDELTE TIMER</M>;
  const thu = pd(W().weeks[week][3] + ".2026"), wk = { w: week, thu }, a = allocOf(plan, wk), mn = MN[new Date(thu).getUTCMonth()].toUpperCase();
  const pl = Object.fromEntries(AX.map((k) => [k, week === 40 ? ses.filter((s) => s.axis === k).reduce((x, s) => x + s.min, 0) / 60 : null]));
  return <div role="group" aria-label={"Uke " + week + " · planlagt mot fordelt"} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
    <M>ARVET FRA {mn} · {week === 40 ? "PLANLAGT " + fmt(tot(pl)) + " T AV " : "SAMLING · "}{fmt(tot(a))} T FORDELT</M>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(5,minmax(0,1fr))", gap: 6 }}>{AX.map((k) => <div key={k} style={{ display: "flex", flexDirection: "column", gap: 2, padding: "6px 6px 8px", borderRadius: 6, border: "1px solid var(--border-hairline)", boxShadow: "inset 0 -3px 0 var(--axis-" + k + ")", minWidth: 0 }}><span style={{ font: "600 11px/1 var(--font-mono)", color: "var(--text-muted)" }}>{AXL[k]}</span><span style={{ font: "600 13px/1.2 var(--font-mono)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{pl[k] == null ? "—" : fmt(pl[k])} / {fmt(num(a[k]))} t</span></div>)}</div>
    <M>PLANLAGT / FORDELT · ENDRE FORDELINGEN I MÅNEDEN</M>
  </div>;
}

function Dialogs({ K, yp, cw, coach, mode, who, undo }) {
  const { Button, IconButton, ChoicePill, TextInput, Select } = K.ns(), M = K.Meta, fw = cw < 900, first = (who.name || "").split(" ")[0], plan = yp.plan;
  const wang = mode === "gruppe" ? /WANG/.test(who.name) : /WANG/.test((W().groups.find((g) => g.id === who.grp) || {}).name || "");
  const cat = mode === "gruppe" ? "gruppas kategorier" : "kategori " + who.cat;
  const S = [["skole", "Skoleår", "03.08.2026", "27.06.2027", "AUG 2026–JUN 2027" + (wang ? " · FORSLAG FOR WANG" : "")], ["kal", "Kalenderår", "01.01.2027", "31.12.2027", "JAN–DES 2027" + (wang ? "" : " · FORSLAG")]];
  let wizEl = null;
  if (yp.wiz) {
    const z = yp.wiz, set = (o) => yp.setWiz({ ...z, ...o }), close = () => yp.setWiz(null);
    const SRC = [["fjor", "Kopi av fjoråret", Y().lastYear.toUpperCase()], ["std", "Standardplan", "FEM PLANER · KAN VELGES I ALLE KATEGORIER · TILPASSES " + cat.toUpperCase()], mode === "gruppe" ? null : ["gruppe", "Gruppas årsplan", (W().groups.find((g) => g.id === who.grp) || { name: "" }).name.toUpperCase() + " · 2026–27"], ["tom", "Tom plan", "DU LEGGER INN PERIODENE SELV"]].filter(Boolean);
    const dErr = z.step === 2 && z.from && z.to && (!okDate(z.from) || !okDate(z.to) ? "Skriv datoene som dd.mm.åååå." : pd(z.to) <= pd(z.from) ? "Slutt må være etter start." : null);
    const can = z.step === 1 ? z.src && (z.src !== "std" || z.std) : z.step === 2 ? okDate(z.from) && okDate(z.to) && !dErr : z.name.trim();
    const create = () => {
      const base = z.src === "gruppe" ? Y().plans.g1 : Y().plans.p1, stdN = z.src === "std" ? Y().stdPlans[z.std][0] : "";
      const np = { name: z.name.trim(), from: z.from, to: z.to, summary: z.sum.trim(), src: z.src === "fjor" ? "Kopi av " + Y().lastYear.split(" · ")[0].toLowerCase() : z.src === "std" ? "Standardplan · " + stdN + " · tilpasset " + cat : z.src === "gruppe" ? "Gruppas årsplan" : "Tom plan", made: (coach ? "LAGET AV ANDERS" : "LAGET AV " + first.toUpperCase()) + " 28.09.2026", periods: z.src === "tom" ? [] : JSON.parse(JSON.stringify(base.periods)), months: {} };
      const before = plan; yp.setPlan(np); yp.setSel(np.periods[0] ? np.periods[0].id : null); close();
      undo("Årsplanen er opprettet", (np.name + " · " + (mode === "gruppe" ? "RULLES UT TIL " + who.n + " MEDLEMMER" : who.name) + " · " + np.periods.length + " PERIODER").toUpperCase(), () => yp.setPlan(before));
    };
    const radio = (on, onClick, t, sub, key) => <button key={key} type="button" role="radio" aria-checked={on} onClick={onClick} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", width: "100%", display: "grid", gridTemplateColumns: "20px minmax(0,1fr)", gap: 10, alignItems: "start", padding: "12px 12px", minHeight: 56, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--surface-flat)" : "var(--surface-card)" }}><span aria-hidden="true" style={{ width: 16, height: 16, marginTop: 2, borderRadius: 8, border: "1px solid var(--border-strong)", boxShadow: on ? "inset 0 0 0 4px var(--surface-card), inset 0 0 0 8px var(--text-primary)" : "none" }}></span><span style={{ display: "flex", flexDirection: "column", gap: 3, minWidth: 0 }}><span style={{ font: "600 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{t}</span>{sub && <M>{sub}</M>}</span></button>;
    const steps = ["Utgangspunkt", "Tidsrom", "Navn og sammendrag"];
    const foot = <>{z.step === 3 ? <Button fullWidth={fw} icon="check" disabled={!can} onClick={create}>Opprett årsplan</Button> : <Button fullWidth={fw} iconRight="arrow-right" disabled={!can} onClick={() => set({ step: z.step + 1, ...(z.step === 1 && !z.from ? { from: S[wang ? 0 : 1][2], to: S[wang ? 0 : 1][3] } : {}), ...(z.step === 2 && !z.name ? { name: mode === "gruppe" ? who.name + " · " + z.from.slice(-4) + (z.to.slice(-4) !== z.from.slice(-4) ? "–" + z.to.slice(-2) : "") : "Sesong " + z.from.slice(-4) + (z.to.slice(-4) !== z.from.slice(-4) ? "–" + z.to.slice(-2) : "") } : {}) })}>Neste</Button>}{z.step > 1 ? <Button variant="ghost" fullWidth={fw} icon="arrow-left" onClick={() => set({ step: z.step - 1 })}>Tilbake</Button> : <Button variant="ghost" fullWidth={fw} onClick={close}>Avbryt</Button>}</>;
    wizEl = <Pane K={K} cw={cw} kicker={"Steg " + z.step + " av 3 · " + steps[z.step - 1] + " · for " + (mode === "gruppe" ? who.name : coach ? who.name : "deg")} title="Opprett årsplan" footer={foot} onClose={close}>
      <ol aria-label="Steg" style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 6 }}>{steps.map((s, i) => <li key={s} aria-current={z.step === i + 1 ? "step" : undefined} style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span aria-hidden="true" style={{ height: 2, background: i < z.step ? "var(--text-primary)" : "var(--border-hairline)" }}></span><span style={{ font: (z.step === i + 1 ? "600" : "400") + " 12px/1.3 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{s}</span></li>)}</ol>
      {coach && <M>{mode === "gruppe" ? "GRUPPE · " + who.n + " MEDLEMMER" : "SPILLER · " + who.name.toUpperCase()} · BYTT I VELGEREN</M>}
      {z.step === 1 && <><div role="radiogroup" aria-label="Utgangspunkt" style={{ display: "flex", flexDirection: "column", gap: 8 }}>{SRC.map(([k, t, sub]) => radio(z.src === k, () => set({ src: k }), t, sub, k))}</div>
        {z.src === "std" && <><M>VELG STANDARDPLAN · INNHOLDET TILPASSES {cat.toUpperCase()}</M><div role="radiogroup" aria-label="Standardplan" style={{ display: "flex", flexDirection: "column", gap: 6 }}>{Y().stdPlans.map(([n, c], i) => radio(z.std === i, () => set({ std: i }), n, "LAGET FOR " + c + " · KAN VELGES AV ALLE", n))}</div></>}</>}
      {z.step === 2 && <><div role="radiogroup" aria-label="Forslag" style={{ display: "flex", flexDirection: "column", gap: 8 }}>{S.map(([k, t, f, to, sub]) => radio(z.from === f && z.to === to, () => set({ from: f, to }), t, sub, k))}</div>
        <M>ELLER VELG FRITT</M>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 8 }}><Lbl t="Start"><TextInput mono value={z.from} onChange={(e) => set({ from: e.target.value })} placeholder="dd.mm.åååå" style={{ width: "100%", minWidth: 0, boxSizing: "border-box" }} /></Lbl><Lbl t="Slutt"><TextInput mono value={z.to} onChange={(e) => set({ to: e.target.value })} placeholder="dd.mm.åååå" style={{ width: "100%", minWidth: 0, boxSizing: "border-box" }} /></Lbl></div>
        {dErr && <p role="alert" style={{ ...txt, color: "var(--text-primary)", fontWeight: 600 }}>{dErr}</p>}</>}
      {z.step === 3 && <><Lbl t="Navn"><TextInput value={z.name} onChange={(e) => set({ name: e.target.value })} placeholder="Sesong 2026–27" /></Lbl>
        <Lbl t="Sammendrag"><Area value={z.sum} onChange={(e) => set({ sum: e.target.value })} placeholder="Fra kategori D mot C. Scoring 50–100 m og hastighet i vinter." /></Lbl>
        <M>{(SRC.find((s) => s[0] === z.src) || ["", ""])[1].toUpperCase()}{z.src === "std" ? " · " + Y().stdPlans[z.std][0].toUpperCase() : ""} · {z.from}–{z.to}</M>
        {mode === "gruppe" && <M>RULLES UT TIL {who.n} MEDLEMMER · {who.own} MED EGNE PERIODER BEHOLDER DEM</M>}</>}
    </Pane>;
  }
  let pfEl = null;
  if (yp.pf && plan) {
    const f = yp.pf, set = (o) => yp.setPf({ ...f, ...o }), close = () => yp.setPf(null);
    const err = f.from && f.to && (!okDate(f.from) || !okDate(f.to) ? "Skriv datoene som dd.mm.åååå." : pd(f.to) < pd(f.from) ? "Slutt kan ikke være før start." : null);
    const can = okDate(f.from) && okDate(f.to) && !err;
    const save = () => { const p = { ...f, h: Object.fromEntries(AX.map((k) => [k, num(f.h[k])])), src: f.isNew ? (mode === "gruppe" ? "gruppe" : coach ? "coach" : "egen") : f.src }; delete p.isNew; const before = plan; yp.setPlan({ ...plan, periods: f.isNew ? [...plan.periods, p] : plan.periods.map((x) => x.id === p.id ? p : x) }); yp.setSel(p.id); close(); undo(f.isNew ? "Perioden er lagt inn" : "Perioden er lagret", (tname(p.type) + " · " + p.from + "–" + p.to + (mode === "gruppe" ? " · RULLES UT TIL " + who.n : coach ? " · " + first + " ser endringen" : "")).toUpperCase(), () => yp.setPlan(before)); };
    const del = () => { const before = plan; yp.setPlan({ ...plan, periods: plan.periods.filter((x) => x.id !== f.id) }); close(); undo("Perioden er slettet", (tname(f.type) + " · " + f.from + "–" + f.to).toUpperCase(), () => yp.setPlan(before)); };
    pfEl = <Pane K={K} cw={cw} kicker={(f.isNew ? "Ny periode" : "Rediger periode") + " · " + (mode === "gruppe" ? who.name : who.name)} title={f.isNew ? "Ny periode" : tname(f.type)} onClose={close} footer={<><Button fullWidth={fw} icon="check" disabled={!can} onClick={save}>Lagre periode</Button><Button variant="ghost" fullWidth={fw} onClick={close}>Avbryt</Button>{!f.isNew && <Button variant="signal" fullWidth={fw} icon="trash-2" onClick={del}>Slett periode</Button>}</>}>
      <Select label="Type" value={f.type} onChange={(e) => set({ type: e.target.value })} options={Y().types.map(([v, l]) => ({ value: v, label: l }))} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 8 }}><Lbl t="Start"><TextInput mono value={f.from} onChange={(e) => set({ from: e.target.value })} placeholder="dd.mm.åååå" style={{ width: "100%", minWidth: 0, boxSizing: "border-box" }} /></Lbl><Lbl t="Slutt"><TextInput mono value={f.to} onChange={(e) => set({ to: e.target.value })} placeholder="dd.mm.åååå" style={{ width: "100%", minWidth: 0, boxSizing: "border-box" }} /></Lbl></div>
      {err && <p role="alert" style={{ ...txt, fontWeight: 600 }}>{err}</p>}
      <Lbl t="Fokus"><TextInput value={f.focus} onChange={(e) => set({ focus: e.target.value })} placeholder="Styrke og hastighet" /></Lbl>
      <M>TIMER PER UKE · {fmt(tot(f.h))} T</M>
      <HoursRow K={K} h={f.h} label="Timer per uke" onChange={(h) => set({ h })} />
      <Lbl t="Notat"><Area value={f.note} onChange={(e) => set({ note: e.target.value })} placeholder="Hold mengden nede uka før turnering." /></Lbl>
      <M>{mode === "gruppe" ? "RULLES UT TIL " + who.n + " MEDLEMMER · " + who.own + " MED EGEN VERSJON BEHOLDER SIN" : coach ? first.toUpperCase() + " SER ENDRINGEN · MERKET «FRA ANDERS»" : "ANDERS SER ENDRINGEN"}</M>
    </Pane>;
  }
  let mfEl = null;
  if (yp.mf && plan) {
    const f = yp.mf, set = (o) => yp.setMf({ ...f, ...o }), close = () => yp.setMf(null), m = monthsOf(plan).find((x) => x.key === f.key), wks = weeksIn(m.t0, m.t1), over = m.t1 < TODAY();
    const mine = coach ? "coach" : "player", pool = [...Y().eventPool, ...W().turn.map(([d, n]) => [d, n, "TURN"])].filter((e) => !f.events.some((x) => x[1] === e[1]));
    const save = () => { const before = plan; yp.setPlan({ ...plan, months: { ...plan.months, [f.key]: { focus: f.focus, goals: f.goals, events: f.events, note: f.note, done: f.done, eval: f.eval, alloc: Object.fromEntries(Object.entries(f.alloc).map(([w, h]) => [w, Object.fromEntries(AX.map((k) => [k, num(h[k])]))])) } } }); yp.setMk(f.key); close(); undo("Måneden er lagret", (m.name + " · " + fmt(Object.values(f.alloc).reduce((a, h) => a + tot(h), 0)) + " T FORDELT · UKENE ARVER").toUpperCase(), () => yp.setPlan(before)); };
    mfEl = <Pane K={K} cw={cw} kicker={"Måned · " + who.name} title={m.name} onClose={close} footer={<><Button fullWidth={fw} icon="check" onClick={save}>Lagre måned</Button><Button variant="ghost" fullWidth={fw} onClick={close}>Avbryt</Button></>}>
      <Lbl t="Fokus"><TextInput value={f.focus} onChange={(e) => set({ focus: e.target.value })} placeholder="Innspill 50–100 m" /></Lbl>
      <M>MÅLSETNINGER · KOBLET</M>
      <div role="group" aria-label="Målsetninger" style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{W().goals.map((g) => { const on = f.goals.includes(g.id); return <ChoicePill key={g.id} aria-pressed={on} selected={on} onClick={() => set({ goals: on ? f.goals.filter((x) => x !== g.id) : [...f.goals, g.id] })}>{g.name}</ChoicePill>; })}</div>
      <M>TIMER PER AKSE · FORDELT PÅ UKENE · {fmt(Object.values(f.alloc).reduce((a, h) => a + tot(h), 0))} T</M>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>{wks.map((w) => <div key={w.w} style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "600 13px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>Uke {w.w} · {ds(w.mon)}–{ds(w.sun)} <span style={{ font: "var(--type-num-s)", color: "var(--text-muted)" }}>{fmt(tot(f.alloc[w.w]))} t</span></span><HoursRow K={K} h={f.alloc[w.w]} label={"Uke " + w.w} onChange={(h) => set({ alloc: { ...f.alloc, [w.w]: h } })} /></div>)}</div>
      <M>TESTER OG TURNERINGER</M>
      {f.events.length > 0 && <div role="list">{f.events.map(([d, n, t], i) => <div role="listitem" key={n} style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) 44px", gap: 8, alignItems: "center", minHeight: 48, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{n}</span><M>{d} · {t}</M></span><IconButton icon="x" variant="ghost" label={"Fjern " + n} onClick={() => set({ events: f.events.filter((_, j) => j !== i) })} /></div>)}</div>}
      {pool.length > 0 && <Select label="Legg til test eller turnering" value="" onChange={(e) => { const x = pool.find((p) => p[1] === e.target.value); if (x) set({ events: [...f.events, x] }); }} options={[{ value: "", label: "Velg …" }, ...pool.map(([d, n]) => ({ value: n, label: d + " · " + n }))]} />}
      <Lbl t="Notat"><Area value={f.note} onChange={(e) => set({ note: e.target.value })} placeholder="Eksamen tirsdag 29.09." /></Lbl>
      <M>EVALUERING{over ? "" : " · ÅPNER " + ds(m.t1 + DAY, true)}</M>
      {over ? [["coach", "Anders Kristiansen"], ["player", mode === "gruppe" ? "Spillerne" : who.name]].map(([k, n]) => k === mine ? <Lbl key={k} t={"Din evaluering · " + n}><Area value={f.eval[k]} onChange={(e) => set({ eval: { ...f.eval, [k]: e.target.value } })} placeholder="Hva gikk bra, og hva tar du med videre?" /></Lbl> : <div key={k} style={{ display: "flex", flexDirection: "column", gap: 4 }}><M>{n.toUpperCase()}</M>{f.eval[k] ? <p style={txt}>{f.eval[k]}</p> : <M>IKKE SKREVET ENNÅ</M>}</div>) : <M>COACH OG SPILLER SKRIVER HVER SIN NÅR MÅNEDEN ER OVER</M>}
    </Pane>;
  }
  return <>{wizEl}{pfEl}{mfEl}</>;
}
function Mid(props) { const L = window.WB3_LOKAL; return L && window.WB && (props.level === "ar" || props.level === "periode" || props.level === "mnd" || props.level === "uke" || props.level === "okt" || props.level === "vol" || props.level === "mal") ? <L.Panel key={props.mode + ":" + props.subj + ":" + ((window.WB_SEL || {})[props.mode + ":" + props.subj] || {}).planId} {...props} /> : <div role="alert" data-control-id="wb-modell-mangler" style={{ padding: 16, font: "var(--type-body)" }}>Workbench-modellen er ikke lastet. Ingenting vises som demo. Last siden på nytt.</div>; }
window.WB3_AR = { useYP, Mid, Dialogs, WeekAlloc };
})();
