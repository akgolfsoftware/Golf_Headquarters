(() => {
const { ChoicePill, Icon, IconButton } = window.AKGolfPrecisionAthletics_7d7c29;
const { PageHead, pageWrap, sgf } = window.TOS;
const { F, T, PXM, ZONES, PUTT } = window.BANEKART;
const FULL = [0, 0, 1200, 600];
const C = { x: 620, y: 505 };
const bez = (t) => ({ x: (1 - t) ** 2 * T.x + 2 * (1 - t) * t * C.x + t * t * F.x, y: (1 - t) ** 2 * T.y + 2 * (1 - t) * t * C.y + t * t * F.y });
const CURVE = "M" + T.x + " " + T.y + " Q" + C.x + " " + C.y + " " + F.x + " " + F.y;
const SAMPLES = Array.from({ length: 401 }, (_, i) => bez(i / 400));
const onCurve = (m) => SAMPLES.reduce((b, p) => Math.abs(Math.hypot(p.x - F.x, p.y - F.y) - m * PXM) < Math.abs(Math.hypot(b.x - F.x, b.y - F.y) - m * PXM) ? p : b, SAMPLES[0]);
const rot = (p, a) => ({ x: F.x + (p.x - F.x) * Math.cos(a) - (p.y - F.y) * Math.sin(a), y: F.y + (p.x - F.x) * Math.sin(a) + (p.y - F.y) * Math.cos(a) });
const ring = (cx, cy, r1, r2) => "M" + (cx - r2) + " " + cy + "a" + r2 + " " + r2 + " 0 1 0 " + 2 * r2 + " 0a" + r2 + " " + r2 + " 0 1 0 " + -2 * r2 + " 0Z" + (r1 > 0 ? "M" + (cx - r1) + " " + cy + "a" + r1 + " " + r1 + " 0 1 0 " + 2 * r1 + " 0a" + r1 + " " + r1 + " 0 1 0 " + -2 * r1 + " 0Z" : "");
const GR = 36, NAER = [GR + 2, 50 * PXM];
const pos = (v) => v >= 0;
const tone = (v) => pos(v) ? "var(--ok)" : "var(--signal-ink)";
const tint = (v, a) => "color-mix(in srgb, " + (pos(v) ? "var(--ok)" : "var(--rust-400)") + " " + Math.round(a * 100) + "%, transparent)";
const n1 = (v) => String(v).replace(".", ",");
const radFt = (ft) => ft <= 40 ? ft / 40 * 240 : 240 + (ft - 40) / 12 * 40;

function Hole({ zone, setZone, vb, fx }) {
  const [hov, setHov] = React.useState(null);
  const s = vb[2] / 1200, fs = (px) => px * s;
  const Z = (id) => ZONES.find((z) => z.id === id);
  const hit = (id) => ({ role: "button", tabIndex: 0, "aria-label": Z(id).chip, style: { cursor: "pointer", outline: "none" }, onClick: (e) => { e.stopPropagation(); setZone(id); }, onKeyDown: (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setZone(id); } }, onMouseEnter: () => setHov(id), onMouseLeave: () => setHov(null) });
  const op = (id, base) => zone === id ? base * 2.4 : hov === id ? base * 1.8 : zone && zone !== id ? base * .5 : base;
  const tAng = Math.atan2(C.y - T.y, C.x - T.x) * 180 / Math.PI;
  return (
    <svg viewBox={vb.join(" ")} preserveAspectRatio="xMidYMid slice" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", display: "block" }} onClick={() => setZone(null)}>
      <defs>
        <radialGradient id="bk-glow" cx="55%" cy="55%" r="60%"><stop offset="0" stopColor="var(--axis-fys)" stopOpacity=".16" /><stop offset="1" stopColor="var(--axis-fys)" stopOpacity="0" /></radialGradient>
        <pattern id="bk-mow" width="28" height="28" patternUnits="userSpaceOnUse" patternTransform="rotate(-12)"><rect width="28" height="28" fill="var(--course-rough)" /><rect width="14" height="28" fill="var(--course-rough-2)" /></pattern>
        <mask id="bk-corr" maskUnits="userSpaceOnUse" x="-200" y="-200" width="1600" height="1000"><path d={CURVE} stroke="var(--white)" strokeWidth="214" strokeLinecap="round" fill="none" /></mask>
      </defs>
      <rect x="-400" y="-400" width="2000" height="1400" fill="var(--night-950)" />
      <ellipse cx="640" cy="340" rx="720" ry="360" fill="url(#bk-glow)" />
      <path d={CURVE} stroke="var(--night-900)" strokeWidth="214" strokeLinecap="round" fill="none" />
      <path d={CURVE} pathLength="100" strokeDasharray="0 20 73 100" stroke="url(#bk-mow)" strokeWidth="92" strokeLinecap="round" fill="none" />
      <ellipse cx="560" cy="360" rx="34" ry="16" fill="var(--course-bunker)" stroke="var(--night-700)" transform="rotate(8 560 360)" />
      <g mask="url(#bk-corr)">
        {ZONES.filter((z) => z.r).map((z) => <path key={z.id} d={ring(F.x, F.y, z.r[0] * PXM, z.r[1] * PXM)} fillRule="evenodd" fill={tint(z.sg, op(z.id, .1))} {...hit(z.id)} />)}
        {[50, 100, 150, 200].map((m) => <circle key={m} cx={F.x} cy={F.y} r={m * PXM} fill="none" stroke="var(--night-300)" strokeOpacity=".5" strokeDasharray="3 6" vectorEffect="non-scaling-stroke" style={{ pointerEvents: "none" }} />)}
      </g>
      {[50, 100, 150, 200].map((m) => { const p = onCurve(m), a = rot(p, -(96 / (m * PXM))), b = rot(p, 96 / (m * PXM)), q = a.y < b.y ? a : b; return <text key={m} x={q.x} y={q.y} textAnchor="middle" fill="var(--night-300)" style={{ font: "500 " + fs(12) + "px var(--font-mono)", pointerEvents: "none" }}>{m} m</text>; })}
      {ZONES.filter((z) => z.r).map((z) => { const p = onCurve((z.r[0] + Math.min(z.r[1], 260)) / 2); return <g key={z.id} style={{ pointerEvents: "none" }} opacity={zone && zone !== z.id ? .45 : 1}><text x={p.x} y={p.y - fs(4)} textAnchor="middle" fill="var(--sand-100)" style={{ font: "600 " + fs(13) + "px var(--font-sans)" }}>{z.chip}</text><text x={p.x} y={p.y + fs(14)} textAnchor="middle" fill={tone(z.sg)} style={{ font: "600 " + fs(13) + "px var(--font-mono)" }}>{sgf(z.sg)}</text></g>; })}
      <path d={ring(F.x, F.y, NAER[0], NAER[1])} fillRule="evenodd" fill={tint(Z("naer").sg, op("naer", .09))} stroke={zone === "naer" ? tone(Z("naer").sg) : "none"} vectorEffect="non-scaling-stroke" {...hit("naer")} />
      <path d={"M" + (F.x - 58) + " " + (F.y + 34) + "q18 -16 36 -2q6 14 -14 18q-20 2 -22 -16Z"} fill="var(--course-bunker)" stroke="var(--night-700)" style={{ pointerEvents: "none" }} />
      <path d={"M" + (F.x + 30) + " " + (F.y - 56) + "q22 -8 34 8q-2 14 -22 12q-14 -4 -12 -20Z"} fill="var(--course-bunker)" stroke="var(--night-700)" style={{ pointerEvents: "none" }} />
      <circle cx={F.x} cy={F.y} r={GR} fill="var(--course-green)" stroke={zone === "green" || hov === "green" ? "var(--ok)" : "var(--course-green-edge)"} strokeWidth="1.5" vectorEffect="non-scaling-stroke" {...hit("green")} />
      <g style={{ pointerEvents: "none" }}><circle cx={F.x} cy={F.y} r="2.2" fill="var(--night-950)" /><line x1={F.x} y1={F.y} x2={F.x} y2={F.y - 22} stroke="var(--sand-100)" strokeWidth="1.5" vectorEffect="non-scaling-stroke" /><path d={"M" + F.x + " " + (F.y - 22) + "l12 4l-12 4Z"} fill="var(--ok)" /></g>
      <text x={F.x} y={F.y + NAER[1] + fs(18)} textAnchor="middle" fill={tone(Z("naer").sg)} style={{ font: "600 " + fs(12) + "px var(--font-sans)", letterSpacing: ".06em", pointerEvents: "none" }} opacity={zone && zone !== "naer" ? .45 : 1}>NÆRSPILL {sgf(Z("naer").sg)}</text>
      <g {...hit("tee")}>
        <rect x={T.x - 60} y={T.y - 60} width="120" height="120" fill="transparent" />
        <rect x={T.x - 26} y={T.y - 12} width="52" height="24" rx="6" fill={zone === "tee" || hov === "tee" ? tint(.4, .4) : "var(--night-800)"} stroke={tone(.4)} strokeOpacity={zone === "tee" || hov === "tee" ? 1 : .5} vectorEffect="non-scaling-stroke" transform={"rotate(" + tAng + " " + T.x + " " + T.y + ")"} />
        <text x={T.x} y={T.y + 34} textAnchor="middle" fill="var(--sand-100)" style={{ font: "600 " + fs(12) + "px var(--font-sans)", letterSpacing: ".06em" }}>TEE TOTAL</text>
        <text x={T.x} y={T.y + 50} textAnchor="middle" fill={tone(.4)} style={{ font: "600 " + fs(12) + "px var(--font-mono)" }}>{sgf(.4)}</text>
      </g>
    </svg>
  );
}

function GreenDetail({ opacity, fx, band, setBand }) {
  return (
    <svg viewBox={(-1200 * fx) + " -300 1200 600"} preserveAspectRatio="xMidYMid slice" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity, pointerEvents: opacity > .9 ? "auto" : "none", transition: "opacity 120ms" }}>
      <circle cx="0" cy="0" r="282" fill="var(--course-green)" />
      {PUTT.map((b, i) => { const on = band === i, d = b[3] - b[4]; return (
        <path key={b[0]} d={ring(0, 0, radFt(b[1]), radFt(b[2]))} fillRule="evenodd" fill={tint(d, on ? .38 : i % 2 ? .1 : .18)} stroke={on ? tone(d) : "color-mix(in srgb, var(--night-200) 22%, transparent)"} strokeWidth={on ? 2.5 : 1} style={{ cursor: "pointer" }} onClick={() => setBand(i)} role="button" aria-label={b[0]} />); })}
      {PUTT.map((b, i) => {
        const mid = (radFt(b[1]) + radFt(b[2])) / 2, narrow = i < 2, on = band === i;
        const a = narrow ? (i ? 70 : 110) * Math.PI / 180 : (i % 2 ? -20 : 200) * Math.PI / 180;
        const lr = narrow ? 318 : mid, lx = Math.cos(a) * lr, ly = Math.sin(a) * lr;
        return <g key={"l" + i} style={{ pointerEvents: "none" }}>
          {narrow && <line x1={Math.cos(a) * mid} y1={Math.sin(a) * mid} x2={Math.cos(a) * (lr - 16)} y2={Math.sin(a) * (lr - 16)} stroke="var(--night-300)" strokeWidth="1" />}
          <text x={lx} y={ly + 4} textAnchor="middle" fill={on ? "var(--sand-100)" : "var(--night-200)"} style={{ font: (on ? "600 " : "500 ") + "12px var(--font-mono)" }}>{b[0]}</text>
        </g>;
      })}
      <circle cx="0" cy="0" r="6" fill="var(--night-950)" stroke="var(--sand-100)" strokeWidth="1.5" />
      <line x1="0" y1="0" x2="0" y2="-64" stroke="var(--sand-100)" strokeWidth="2" /><path d="M0 -64 l26 9 l-26 9Z" fill="var(--ok)" />
    </svg>
  );
}

const glass = { background: "color-mix(in srgb, var(--night-850) 86%, transparent)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)", border: "1px solid var(--night-700)", borderRadius: 8, boxShadow: "0 18px 48px color-mix(in srgb, var(--night-950) 50%, transparent)", padding: 20, display: "flex", flexDirection: "column", gap: 16, color: "var(--text-body)" };
const Stat = ({ k, v, c }) => <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}><span style={{ font: "var(--type-meta)", color: "var(--text-muted)", whiteSpace: "nowrap" }}>{k.toUpperCase()}</span><span style={{ font: "600 17px/1 var(--font-mono)", color: c || "var(--text-primary)" }}>{v}</span></div>;
function Plan({ p, note }) {
  const [pl, dn, u] = p, pc = Math.round(dn / pl * 100);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, paddingTop: 14, borderTop: "1px solid var(--border-hairline)" }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}><span className="kicker" style={{ flex: 1 }}>Trening denne måneden</span><span style={{ font: "600 13px/1 var(--font-mono)", color: pc >= 100 ? "var(--ok)" : "var(--text-primary)" }}>{pc} %</span></div>
      <div style={{ height: 6, borderRadius: 999, background: "var(--night-700)" }}><div style={{ height: "100%", width: Math.min(100, pc) + "%", borderRadius: 999, background: "var(--ok)", transition: "width 500ms" }}></div></div>
      <span style={{ font: "var(--type-num-s)", color: "var(--text-secondary)" }}>{n1(pl)} {u} planlagt · {n1(dn)} {u} gjennomført{note ? " · " + note : ""}</span>
    </div>
  );
}
const Test = ({ t }) => <div style={{ display: "flex", alignItems: "center", gap: 8, font: "var(--type-body-s)", color: "var(--text-secondary)" }}><Icon name="clipboard-check" size={16} /><span>Siste test: <span style={{ fontFamily: "var(--font-mono)", color: "var(--text-primary)" }}>{t}</span></span></div>;

function Card({ z, onClose, band, setBand }) {
  const [sub, setSub] = React.useState(0);
  React.useEffect(() => setSub(0), [z.id]);
  const head = (
    <header style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
      <div style={{ flex: 1, minWidth: 0 }}><div className="kicker">{z.cat} · {z.area}</div><div style={{ font: "var(--type-title-s)", color: "var(--text-primary)", marginTop: 4 }}>{z.title}</div></div>
      <IconButton icon="x" label="Hele hullet" size="sm" onClick={onClose} />
    </header>
  );
  const sgRow = (label, v, extra) => (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 12, flexWrap: "wrap" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{label}</span><span style={{ font: "var(--type-metric-l)", color: tone(v) }}>{sgf(v)}</span></div>
      {extra}
    </div>
  );
  if (z.id === "naer") { const s = z.sub[sub]; return (
    <div style={glass}>{head}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{z.sub.map((x, i) => <ChoicePill key={x[0]} selected={sub === i} onClick={() => setSub(i)}>{x[0]}</ChoicePill>)}</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>UP-AND-DOWN · {s[0].toUpperCase()}</span><span style={{ font: "var(--type-metric-l)", color: s[1] >= s[3] ? "var(--ok)" : "var(--signal-ink)" }}>{s[1]} %</span></div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 12 }}><Stat k="Norm Kat. D" v={s[3] + " %"} /><Stat k="Slag trent" v={s[2]} /><Stat k="SG ARG" v={sgf(z.sg)} c={tone(z.sg)} /></div>
    </div>); }
  if (z.id === "green") { const b = PUTT[band], d = b[3] - b[4]; return (
    <div style={glass}>{head}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,minmax(0,1fr))", gap: 8 }}>{PUTT.map((x, i) => <ChoicePill key={x[0]} mono selected={band === i} onClick={() => setBand(i)} style={{ padding: 0, minWidth: 0, fontSize: 12 }}>{x[0].replace(" ft", "")}</ChoicePill>)}</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>MAKE-RATE · {b[0].toUpperCase()}</span><span style={{ font: "var(--type-metric-l)", color: tone(d) }}>{b[3]} %</span></div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {[["Emma", b[3], tone(d)], ["Norm Kategori D", b[4], "var(--night-300)"], ["PGA Tour", b[5], "var(--night-500)"]].map(([k, v, c]) => <div key={k} style={{ display: "grid", gridTemplateColumns: "118px minmax(0,1fr) 44px", gap: 8, alignItems: "center" }}><span style={{ font: "var(--type-body-s)", fontSize: 13, color: "var(--text-secondary)" }}>{k}</span><div style={{ height: 6, borderRadius: 999, background: "var(--night-700)" }}><div style={{ height: "100%", width: v + "%", background: c, borderRadius: 999, transition: "width 300ms" }}></div></div><span style={{ font: "600 13px/1 var(--font-mono)", textAlign: "right", color: "var(--text-primary)" }}>{v} %</span></div>)}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 12, paddingTop: 14, borderTop: "1px solid var(--border-hairline)" }}><Stat k="Putter trent · 14 d" v={b[6]} /><Stat k="SG PUTT" v={sgf(z.sg)} c={tone(z.sg)} /></div>
      <Test t={b[7]} />
    </div>); }
  return (
    <div style={glass}>{head}
      {sgRow("SG " + z.cat, z.sg, z.alert && <span style={{ display: "inline-flex", alignItems: "center", gap: 8, height: 26, padding: "0 12px", borderRadius: 999, background: "var(--signal-tint)", color: "var(--signal-ink)", font: "600 12px/1 var(--font-sans)", marginBottom: 8 }}><Icon name="trending-down" size={14} />{z.alert}</span>)}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 12 }}>{z.stats.map(([k, v]) => <Stat key={k} k={k} v={v} />)}</div>
      <Plan p={z.plan} note={z.planNote} />
      <Test t={z.test} />
    </div>
  );
}

function BanekartScreen() {
  const [zone, setZoneRaw] = React.useState(null);
  const [band, setBand] = React.useState(2);
  const [vb, setVb] = React.useState(FULL);
  const [w, setW] = React.useState(1000);
  const box = React.useRef(null), cur = React.useRef(FULL), raf = React.useRef(0);
  React.useLayoutEffect(() => { setW(box.current.getBoundingClientRect().width); const ro = new ResizeObserver(([e]) => setW(e.contentRect.width)); ro.observe(box.current); return () => ro.disconnect(); }, []);
  const wide = w >= 860, fx = wide ? 0.34 : 0.5;
  const target = (id) => {
    const f = (cx, cy, vw) => [cx - vw * fx, cy - vw / 4, vw, vw / 2];
    if (!id) return FULL;
    if (id === "tee") return f(T.x + 40, T.y, 460);
    if (id === "naer") return f(F.x, F.y, 400);
    if (id === "green") return f(F.x, F.y, GR * 2 * 600 / 564 * 2);
    const z = ZONES.find((x) => x.id === id), p = onCurve((z.r[0] + Math.min(z.r[1], 260)) / 2);
    return f(p.x, p.y, Math.max(460, (Math.min(z.r[1], 300) - z.r[0]) * PXM * 3));
  };
  const fly = (to) => {
    cancelAnimationFrame(raf.current);
    const from = cur.current, t0 = performance.now(), dur = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 1 : 800;
    const step = (now) => { const k = Math.min(1, (now - t0) / dur), e = k < .5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2, v = from.map((a, i) => a + (to[i] - a) * e); cur.current = v; setVb(v); if (k < 1) raf.current = requestAnimationFrame(step); };
    raf.current = requestAnimationFrame(step);
  };
  const setZone = (id) => { setZoneRaw(id); fly(target(id)); };
  React.useEffect(() => { fly(target(zone)); }, [wide]);
  const gw = target("green")[2], gOp = zone === "green" ? Math.max(0, Math.min(1, (420 - vb[2]) / (420 - gw))) : 0;
  const z = ZONES.find((x) => x.id === zone);
  const tot = ZONES.reduce((a, x) => a + x.sg, 0), losing = ZONES.filter((x) => x.sg < 0).length;
  const card = z && <Card z={z} onClose={() => setZone(null)} band={band} setBand={setBand} />;
  return (
    <div data-theme="night" style={{ minHeight: "100%", background: "var(--surface-page)", color: "var(--text-body)" }}>
      <div style={pageWrap}>
        <PageHead kicker="Banekart · Treningsanalyse · Emma Solberg · siste 30 dager" title="Hvor vinnes og tapes slagene?" sub={"SG totalt " + sgf(tot) + " per runde. " + losing + " av " + ZONES.length + " soner taper slag. Trykk på en sone."} />
        <div ref={box} style={{ position: "relative", width: "100%", aspectRatio: wide ? "2 / 1" : "4 / 3", borderRadius: 8, overflow: "hidden", border: "1px solid var(--border-hairline)", background: "var(--night-950)" }}>
          <Hole zone={zone} setZone={setZone} vb={vb} fx={fx} />
          <GreenDetail opacity={gOp} fx={fx} band={band} setBand={setBand} />
          {zone === "green" && gOp > .9 && <div style={{ position: "absolute", left: 16, bottom: 14, font: "var(--type-meta)", color: "var(--text-muted)", display: "flex", gap: 16, flexWrap: "wrap" }}><span>PUTTEBÅND I FOT · RADIUS I SKALA</span><span style={{ color: "var(--ok)" }}>● OVER NORM</span><span style={{ color: "var(--signal-ink)" }}>● UNDER NORM</span></div>}
          {wide && card && <div style={{ position: "absolute", top: 16, right: 16, bottom: 16, width: 360, display: "flex", flexDirection: "column", justifyContent: "flex-start", overflow: "auto" }}>{card}</div>}
          {zone && <button type="button" onClick={() => setZone(null)} style={{ position: "absolute", top: 16, left: 16, height: "max(36px, var(--tap))", padding: "0 12px", borderRadius: 8, border: "1px solid var(--night-700)", background: "color-mix(in srgb, var(--night-900) 80%, transparent)", color: "var(--text-primary)", font: "var(--type-button)", display: "inline-flex", alignItems: "center", gap: 8, cursor: "pointer" }}><Icon name="maximize-2" size={16} />Hele hullet</button>}
        </div>
        {!wide && card}
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {ZONES.map((x) => { const on = zone === x.id; return (
            <button key={x.id} type="button" onClick={() => setZone(on ? null : x.id)} aria-pressed={on} style={{ height: "max(40px, var(--tap))", padding: "0 16px", borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--surface-hover)" : "transparent", color: "var(--text-primary)", display: "inline-flex", alignItems: "center", gap: 8, cursor: "pointer", font: "500 14px/1 var(--font-sans)" }}>
              {x.chip}<span style={{ font: "600 13px/1 var(--font-mono)", color: tone(x.sg) }}>{sgf(x.sg)}</span>
            </button>); })}
        </div>
      </div>
    </div>
  );
}
window.BanekartScreen = BanekartScreen;
})();
