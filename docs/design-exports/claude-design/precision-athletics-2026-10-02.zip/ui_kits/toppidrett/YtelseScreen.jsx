(() => {
const { Button, Stepper, Icon } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, Scale, Tag, sgf } = window.TOS;
const PAR = [4, 4, 3, 5, 4, 4, 3, 4, 5, 4, 3, 5, 4, 4, 4, 3, 4, 5];
const DIFF = [0, 0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 0, 1];
const PAIN = ["Vondt i korsrygg", "Stive hofter", "Vondt i håndledd", "Stiv nakke", "Vondt i kne"];
const STRESS = ["Skole", "Eksamen", "Jobb", "Familie", "Reise"];
const FOOD = ["Spiste frokost", "Mat underveis", "Nok drikke"];
const F = [["tek", "Teknikk", "target"], ["fys", "Fysisk / helse", "heart-pulse"], ["men", "Mentalt", "brain"], ["sos", "Sosialt / miljø", "users"], ["sov", "Ernæring og søvn", "moon"]];
const BASE = { tek: 4, fys: 4.2, men: 3.8, sos: 3.6, sov: 4 };
const toggle = (set, v) => { const n = new Set(set); n.has(v) ? n.delete(v) : n.add(v); return n; };
const d1 = (v) => (Math.round(v * 10) / 10).toString().replace(".", ",");

function Radar({ vals }) {
  const S = 360, c = S / 2, r = 118;
  const pt = (i, v) => { const a = (-90 + i * 72) * Math.PI / 180; return [c + Math.cos(a) * r * v / 5, c + Math.sin(a) * r * v / 5]; };
  const poly = (o) => F.map(([k], i) => pt(i, o[k]).map((n) => n.toFixed(1)).join(",")).join(" ");
  return (
    <svg viewBox={"0 0 " + S + " " + S} style={{ width: "100%", maxWidth: 380, height: "auto", display: "block", margin: "0 auto", overflow: "visible" }}>
      {[1, 2, 3, 4, 5].map((l) => <polygon key={l} points={F.map((_, i) => pt(i, l).join(",")).join(" ")} fill="none" stroke="var(--border-hairline)" strokeWidth={l === 5 ? 1.5 : 1} />)}
      {F.map((_, i) => { const [x, y] = pt(i, 5); return <line key={i} x1={c} y1={c} x2={x} y2={y} stroke="var(--border-hairline)" />; })}
      <polygon points={poly(BASE)} fill="none" stroke="var(--text-faint)" strokeWidth="1.5" strokeDasharray="4 4" />
      <polygon points={poly(vals)} fill="var(--text-primary)" fillOpacity=".08" stroke="var(--text-primary)" strokeWidth="2.5" strokeLinejoin="round" style={{ transition: "left 300ms var(--ease-out), width 300ms var(--ease-out), top 300ms var(--ease-out), opacity 300ms var(--ease-out)" }} />
      {F.map(([k, l], i) => {
        const [x, y] = pt(i, vals[k]), low = vals[k] <= 2.5, [lx, ly] = pt(i, 6.3);
        return <g key={k}>
          <circle cx={x} cy={y} r={low ? 7 : 5} fill={low ? "var(--signal)" : "var(--surface-card)"} stroke={low ? "var(--surface-card)" : "var(--text-primary)"} strokeWidth="2" />
          <text x={lx} y={ly - 4} textAnchor="middle" fontFamily="var(--font-sans)" fontSize="12" fontWeight="600" letterSpacing=".06em" fill={low ? "var(--signal-ink)" : "var(--text-secondary)"}>{l.toUpperCase().split(" / ")[0].replace("ERNÆRING OG SØVN", "SØVN / MAT")}</text>
          <text x={lx} y={ly + 12} textAnchor="middle" fontFamily="var(--font-mono)" fontSize="12" fill={low ? "var(--signal-ink)" : "var(--text-muted)"}>{d1(vals[k])}</text>
        </g>;
      })}
    </svg>
  );
}

function Factor({ n, f, low, children }) {
  return (
    <section style={{ background: "var(--surface-card)", border: "1px solid var(--border-hairline)", borderRadius: 8, padding: 20, display: "flex", flexDirection: "column", gap: 16, boxShadow: low ? "inset 3px 0 0 var(--signal)" : "none", transition: "box-shadow 200ms" }}>
      <header style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ font: "var(--type-num-s)", color: "var(--text-faint)" }}>{String(n).padStart(2, "0")}</span>
        <Icon name={f[2]} size={18} />
        <span style={{ font: "var(--type-title-s)", color: "var(--text-primary)", flex: 1 }}>{f[1]}</span>
        {low && <span style={{ font: "var(--type-kicker)", letterSpacing: "var(--tracking-kicker)", color: "var(--signal-ink)" }}>BEGRENSET RESULTATET</span>}
      </header>
      {children}
    </section>
  );
}
const Sub = ({ children }) => <span style={{ font: "var(--type-label)", color: "var(--text-secondary)" }}>{children}</span>;

function YtelseScreen() {
  const [scRef, scW] = window.TOS.useWidth(900);
  const nine = scW < 640;
  const [tek, setTek] = React.useState(4);
  const [pain, setPain] = React.useState(new Set(["Vondt i korsrygg", "Stive hofter"]));
  const [pat, setPat] = React.useState(3), [fok, setFok] = React.useState(2);
  const [stress, setStress] = React.useState(4), [sTags, setSTags] = React.useState(new Set(["Eksamen"]));
  const [sleep, setSleep] = React.useState(5.5), [food, setFood] = React.useState(new Set(["Spiste frokost"]));
  const [energy, setEnergy] = React.useState(13);
  const sovBase = sleep >= 8 ? 5 : sleep >= 7 ? 4 : sleep >= 6 ? 3 : sleep >= 5 ? 2 : 1;
  const vals = { tek, fys: Math.max(1, 5 - pain.size * 1.5), men: (pat + fok) / 2, sos: 6 - stress, sov: Math.max(1, Math.min(5, sovBase - (energy ? 1 : 0) + (food.size >= 2 ? 0.5 : 0))) };
  const total = DIFF.reduce((a, b) => a + b, 0), score = 72 + total;
  const inWin = energy ? DIFF.slice(energy - 1).reduce((a, b) => a + b, 0) : 0;
  const phrase = { fys: pain.has("Vondt i korsrygg") ? "ryggsmerter" : pain.size ? pain.values().next().value.toLowerCase() : "fysiske plager", sov: energy ? "energitap fra hull " + energy : "lite søvn (" + d1(sleep) + " t)", men: "lav tålmodighet og fokus", sos: "stress utenfor banen" + (sTags.size ? " (" + [...sTags].join(", ").toLowerCase() + ")" : ""), tek: "svingen" };
  const lim = F.map((f) => f[0]).filter((k) => vals[k] <= 2.5).sort((a, b) => vals[a] - vals[b]);
  const others = lim.filter((k) => k !== "tek").slice(0, 2).map((k) => phrase[k]);
  const join = (a) => a.length > 1 ? a.slice(0, -1).join(", ") + " og " + a[a.length - 1] : a[0];
  const verdict = !others.length ? "Runden var " + sgf(total, 0) + ". Ingen tydelige påvirkere utenfor svingen." : tek >= 4 ? "Runden var " + sgf(total, 0) + " ikke på grunn av svingen, men på grunn av " + join(others) + "." : "Runden var " + sgf(total, 0) + ". Svingen spilte inn, sammen med " + join(others) + ".";

  return (
    <div style={pageWrap}>
      <PageHead kicker="Ytelsesbilde · Emma Solberg · 25.09.2026" title="Hva påvirket resultatet?" sub="Registrer de fem faktorene bak runden. Coachen ser det samme bildet." actions={<><Button variant="secondary">Lagre utkast</Button><Button icon="send">Del med coach</Button></>} />

      <Panel kicker="Srixon Tour 5 · Gamle Fredrikstad GK · Runde 2" title={<span><span style={{ fontFamily: "var(--font-mono)" }}>{score} slag ({sgf(total, 0)})</span><span style={{ color: "var(--text-muted)", fontWeight: 400 }}> · brutto · par 72</span></span>} action={<span style={{ font: "var(--type-meta)", color: "var(--text-muted)", whiteSpace: "nowrap" }}>TRYKK HULL FOR ENERGIFALL</span>}>
        <div ref={scRef}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(" + (nine ? 9 : 18) + ",minmax(0,1fr))", gap: 4, rowGap: 8 }}>
            {PAR.map((p, i) => {
              const h = i + 1, d = DIFF[i], win = energy && h >= energy;
              return (
                <button key={h} type="button" onClick={() => setEnergy(energy === h ? null : h)} title={"Energifall fra hull " + h} style={{ border: "none", cursor: "pointer", borderRadius: 8, padding: "8px 0 12px", display: "flex", flexDirection: "column", alignItems: "center", gap: 8, background: win ? "var(--warn-tint)" : "var(--surface-sunken)", boxShadow: energy === h ? "inset 0 0 0 1.5px var(--warn)" : "none", marginLeft: i === 9 && !nine ? 8 : 0 }}>
                  <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{h}</span>
                  <span style={{ width: 28, height: 28, display: "grid", placeItems: "center", font: "600 14px/1 var(--font-mono)", color: d < 0 ? "var(--ok)" : "var(--text-primary)", borderRadius: d < 0 ? 999 : 3, border: d === 0 ? "none" : "1.5px solid " + (d < 0 ? "var(--ok)" : "var(--text-primary)"), outline: d >= 2 ? "1.5px solid var(--text-primary)" : "none", outlineOffset: 2 }}>{p + d}</span>
                  <span style={{ font: "var(--type-meta)", color: "var(--text-faint)" }}>P{p}</span>
                </button>
              );
            })}
          </div>
        </div>
        {energy && <div style={{ display: "flex", alignItems: "center", gap: 8, font: "var(--type-body-s)", color: "var(--warn)" }}><Icon name="battery-low" size={16} /><span>Tom for energi hull {energy}–18 · <span style={{ fontFamily: "var(--font-mono)" }}>{sgf(inWin, 0)}</span> av <span style={{ fontFamily: "var(--font-mono)" }}>{sgf(total, 0)}</span> kom i dette vinduet</span></div>}
      </Panel>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,340px),1fr))", gap: 24, alignItems: "start" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <Factor n={1} f={F[0]} low={vals.tek <= 2.5}><Sub>Svingfølelse</Sub><Scale value={tek} onChange={setTek} lo="1 · FREMMED" hi="5 · SOM PÅ RANGEN" /></Factor>
          <Factor n={2} f={F[1]} low={vals.fys <= 2.5}><Sub>Smerte eller stivhet</Sub><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{PAIN.map((t) => <Tag key={t} on={pain.has(t)} onClick={() => setPain(toggle(pain, t))}>{t}</Tag>)}<Tag on={!pain.size} onClick={() => setPain(new Set())}>Ingen plager</Tag></div></Factor>
          <Factor n={3} f={F[2]} low={vals.men <= 2.5}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 16 }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><Sub>Tålmodighet</Sub><Scale value={pat} onChange={setPat} size={40} lo="1 · LAV" hi="5 · HØY" /></div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><Sub>Fokus</Sub><Scale value={fok} onChange={setFok} size={40} lo="1 · SPREDT" hi="5 · SKARPT" /></div>
            </div>
          </Factor>
          <Factor n={4} f={F[3]} low={vals.sos <= 2.5}><Sub>Totalstress utenfor banen</Sub><Scale value={stress} onChange={setStress} lo="1 · ROLIG" hi="5 · MYE" /><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{STRESS.map((t) => <Tag key={t} on={sTags.has(t)} onClick={() => setSTags(toggle(sTags, t))}>{t}</Tag>)}</div></Factor>
          <Factor n={5} f={F[4]} low={vals.sov <= 2.5}>
            <div style={{ display: "flex", gap: 24, flexWrap: "wrap", alignItems: "flex-end" }}>
              <Stepper label="Søvn natt før" value={sleep} onChange={setSleep} step={0.5} min={3} max={11} unit="t" format={d1} />
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><Sub>Energifall</Sub><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{[null, 10, 13, 15].map((h) => <Tag key={String(h)} on={energy === h} onClick={() => setEnergy(h)}>{h ? "Fra hull " + h : "Nei"}</Tag>)}</div></div>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{FOOD.map((t) => <Tag key={t} on={food.has(t)} onClick={() => setFood(toggle(food, t))}>{t}</Tag>)}</div>
          </Factor>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16, position: "sticky", top: 24 }}>
          <Panel kicker="Ytelses-radar" title="Runde 2 mot eget snitt" action={<span style={{ display: "inline-flex", alignItems: "center", gap: 8, font: "var(--type-meta)", color: "var(--text-muted)", whiteSpace: "nowrap" }}><span style={{ width: 16, borderTop: "1.5px dashed var(--text-faint)" }}></span>SNITT 10 RUNDER</span>}>
            <div style={{ padding: "24px 36px 20px" }}><Radar vals={vals} /></div>
          </Panel>
          <Panel inverse pad={24} style={{ gap: 12 }}>
            <div className="kicker" style={{ color: "var(--sand-400)" }}>Det sanne bildet · til coach</div>
            <p style={{ margin: 0, font: "600 21px/1.3 var(--font-sans)", textWrap: "pretty" }}>{verdict}</p>
            {energy && <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--sand-300)" }}>Hull 1–{energy - 1}: <span style={{ fontFamily: "var(--font-mono)", color: "var(--sand-100)" }}>{sgf(total - inWin, 0)}</span>. Hull {energy}–18: <span style={{ fontFamily: "var(--font-mono)", color: "var(--sand-100)" }}>{sgf(inWin, 0)}</span>. Søvn {d1(sleep)} t.</p>}
          </Panel>
        </div>
      </div>
    </div>
  );
}
window.YtelseScreen = YtelseScreen;
})();
