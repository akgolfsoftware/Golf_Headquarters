(() => {
const { Tabs, Icon } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, sgf, Bar } = window.TOS;
const pct = (v) => v + " %";
const m1 = (v) => v.toFixed(1).replace(".", ",") + " m";
const CAT = [["ott", "OTT", "Utslag", -0.3], ["app", "APP", "Innspill", -0.6], ["arg", "ARG", "Nærspill", -0.4], ["putt", "PUTT", "Putting", 0.3]];

function Bench({ label, v, b, unit = " %", sub, worst }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "minmax(84px,120px) minmax(40px,1fr) 56px 56px", gap: 12, alignItems: "center", padding: "12px 0", borderTop: "1px solid var(--border-hairline)" }}>
      <span style={{ font: "500 14px/1.2 var(--font-sans)", color: worst ? "var(--signal-ink)" : "var(--text-primary)" }}>{label}{sub && <span style={{ display: "block", font: "var(--type-meta)", color: "var(--text-muted)", marginTop: 4 }}>{sub}</span>}</span>
      <Bar pct={v} marker={b} h={8} color={worst ? "var(--signal)" : "var(--primary)"} />
      <span style={{ font: "600 14px/1 var(--font-mono)", textAlign: "right", color: worst ? "var(--signal-ink)" : "var(--text-primary)" }}>{v}{unit}</span>
      <span style={{ font: "var(--type-num-s)", textAlign: "right", color: "var(--text-muted)" }}>{b}{unit}</span>
    </div>
  );
}
const BenchHead = ({ a = "SPILLER", b = "PGA TOUR" }) => <div style={{ display: "grid", gridTemplateColumns: "minmax(84px,120px) minmax(40px,1fr) 56px 56px", gap: 12, font: "var(--type-meta)", color: "var(--text-faint)", paddingBottom: 8 }}><span></span><span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><span style={{ width: 2, height: 10, background: "var(--text-primary)" }}></span>BENCHMARK</span><span style={{ textAlign: "right" }}>{a}</span><span style={{ textAlign: "right" }}>{b}</span></div>;
function Kpi({ k, v, sub, tone }) {
  return <div style={{ flex: "1 1 160px", display: "flex", flexDirection: "column", gap: 8, padding: 16, border: "1px solid var(--border-hairline)", borderRadius: 8 }}><span className="kicker">{k}</span><span style={{ font: "var(--type-metric)", color: tone || "var(--text-primary)" }}>{v}</span><span style={{ font: "var(--type-body-s)", fontSize: 13, color: "var(--text-muted)" }}>{sub}</span></div>;
}

function Ott() {
  const split = [["Venstre rough", 18, "var(--graphite-400)"], ["Fairway", 58, "var(--primary)"], ["Høyre rough", 21, "var(--graphite-400)"], ["Straff", 3, "var(--signal)"]];
  return <>
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}><Kpi k="Fairway" v="58 %" sub="PGA Tour 60 %" /><Kpi k="Spredningsbredde" v="34 m" sub="95 % av utslag · driver" /><Kpi k="Straffeslag" v="0,6" sub="per runde · mål 0,3" tone="var(--signal-ink)" /></div>
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <span className="kicker">Hvor utslaget lander</span>
      <div style={{ display: "flex", height: 40, borderRadius: 8, overflow: "hidden", gap: 4 }}>{split.map(([l, v, c]) => <div key={l} style={{ flex: v, background: c, display: "grid", placeItems: "center", font: "600 13px/1 var(--font-mono)", color: "var(--white)", minWidth: 28 }}>{v}</div>)}</div>
      <div style={{ display: "flex", justifyContent: "space-between", font: "var(--type-meta)", color: "var(--text-muted)", flexWrap: "wrap", gap: 8 }}>{split.map(([l]) => <span key={l}>{l.toUpperCase()}</span>)}</div>
    </div>
  </>;
}
function App() {
  const rows = [["50–100 m", 48, 71, 7.9, 5.8, -0.05], ["100–150 m", 82, 58, 10.4, 7.6, -0.12], ["150–200 m", 64, 39, 14.8, 11.2, -0.08], ["200 m+", 22, 18, 21.5, 16.8, -0.04]];
  const worst = rows.reduce((w, r) => r[5] < w[5] ? r : w, rows[0]);
  const [ref, w] = window.TOS.useWidth(700);
  const card = w < 560, g = "96px 48px minmax(0,1fr) minmax(0,1.3fr) 64px";
  const Prox = ({ r, wst }) => <div style={{ position: "relative", height: 6, background: "var(--surface-sunken)", borderRadius: 999 }}><div style={{ position: "absolute", inset: 0, width: r[3] / 25 * 100 + "%", background: wst ? "var(--signal)" : "var(--graphite-500)", borderRadius: 999 }}></div><div style={{ position: "absolute", top: -4, bottom: -4, left: r[4] / 25 * 100 + "%", width: 2, background: "var(--text-primary)" }}></div></div>;
  const num = { font: "var(--type-num-s)", color: "var(--text-primary)" };
  return (
    <div ref={ref} style={{ display: "flex", flexDirection: "column" }}>
      {!card && <div style={{ display: "grid", gridTemplateColumns: g, gap: 16, font: "var(--type-meta)", color: "var(--text-faint)", paddingBottom: 8 }}><span>AVSTAND</span><span style={{ textAlign: "right" }}>SLAG</span><span>GIR</span><span>PROXIMITY · MOT PGA</span><span style={{ textAlign: "right" }}>SG/SLAG</span></div>}
      {rows.map((r) => { const wst = r === worst, tc = wst ? "var(--signal-ink)" : "var(--text-primary)"; return card ? (
        <div key={r[0]} style={{ display: "flex", flexDirection: "column", gap: 12, padding: "16px 0", borderTop: "1px solid var(--border-hairline)" }}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}><span style={{ font: "600 15px/1 var(--font-mono)", color: tc, flex: 1 }}>{r[0]}</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{r[1]} SLAG</span><span style={{ font: "600 15px/1 var(--font-mono)", color: tc, width: 56, textAlign: "right" }}>{sgf(r[5], 2)}</span></div>
          <div style={{ display: "grid", gridTemplateColumns: "56px minmax(0,1fr) 88px", gap: 12, alignItems: "center" }}><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>GIR</span><Bar pct={r[2]} h={6} /><span style={{ ...num, textAlign: "right" }}>{r[2]} %</span></div>
          <div style={{ display: "grid", gridTemplateColumns: "56px minmax(0,1fr) 88px", gap: 12, alignItems: "center" }}><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>PIN</span><Prox r={r} wst={wst} /><span style={{ ...num, textAlign: "right", whiteSpace: "nowrap" }}>{m1(r[3])}</span></div>
        </div>
      ) : (
        <div key={r[0]} style={{ display: "grid", gridTemplateColumns: g, gap: 16, alignItems: "center", padding: "16px 0", borderTop: "1px solid var(--border-hairline)" }}>
          <span style={{ font: "600 14px/1 var(--font-mono)", color: tc }}>{r[0]}</span>
          <span style={{ font: "var(--type-num-s)", color: "var(--text-muted)", textAlign: "right" }}>{r[1]}</span>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}><span style={num}>{r[2]} %</span><Bar pct={r[2]} h={6} /></div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}><span style={{ ...num, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{m1(r[3])} <span style={{ color: "var(--text-muted)" }}>/ {m1(r[4])}</span></span><Prox r={r} wst={wst} /></div>
          <span style={{ font: "600 14px/1 var(--font-mono)", textAlign: "right", color: tc }}>{sgf(r[5], 2)}</span>
        </div>); })}
      <div style={{ marginTop: 12, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Størst tap: <b style={{ color: "var(--signal-ink)", fontWeight: 600 }}>{worst[0]}</b> · {m1(worst[3] - worst[4])} lengre fra flagget enn PGA Tour{card ? " (svart strek)" : ""}.</div>
    </div>
  );
}
function Arg() {
  return <div><BenchHead /><Bench label="Fra fairway" v={64} b={68} sub="42 FORSØK" /><Bench label="Fra rough" v={41} b={52} sub="57 FORSØK" worst /><Bench label="Fra bunker" v={33} b={50} sub="18 FORSØK" /></div>;
}
function Putt() {
  const rows = [["0–3 fot", 97, 99], ["3–5 fot", 78, 88], ["5–10 fot", 44, 56], ["10–25 fot", 18, 22], ["25–40 fot", 5, 6], ["40+ fot", 2, 3]];
  const worst = rows.reduce((w, r) => r[2] - r[1] > w[2] - w[1] ? r : w, rows[0]);
  return <>
    <div><BenchHead />{rows.map((r) => <Bench key={r[0]} label={r[0]} v={r[1]} b={r[2]} worst={r === worst} />)}</div>
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}><Kpi k="3-putt unngåelse" v="94 %" sub="PGA Tour 97 %" /><Kpi k="3-putter" v="0,9" sub="per runde" /><Kpi k="Putter" v="30,4" sub="per runde · brutto" /></div>
  </>;
}

function Tiger5() {
  const T = [["Par 5-bogeys", 0.6, "Bogey eller verre på par 5"], ["Doble bogeys", 0.8, "Dobbel eller verre"], ["3-putter", 0.9, "Tre putter eller mer"], ["Jernbom", 1.1, "Bogey med kort jern fra innspill"], ["Feil under 50 m", 0.7, "Bogey innenfor 50 m"]];
  const tot = T.reduce((a, t) => a + t[1], 0), max = Math.max(...T.map((t) => t[1]));
  return (
    <Panel style={{ flex: "1 1 320px" }} kicker="Tiger 5 · siste 10 runder" title={<span><span style={{ fontFamily: "var(--font-mono)" }}>{tot.toFixed(1).replace(".", ",")}</span> feil per runde <span style={{ color: "var(--text-muted)", fontWeight: 400 }}>· mål 2,0</span></span>}>
      <div style={{ display: "flex", flexDirection: "column" }}>
        {T.map(([l, v, s], i) => { const w = v === max; return (
          <div key={l} style={{ display: "grid", gridTemplateColumns: "24px minmax(0,1fr) 44px", gap: 12, alignItems: "center", padding: "12px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}>
            <span style={{ font: "var(--type-num-s)", color: "var(--text-faint)" }}>{i + 1}</span>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
              <span style={{ font: "500 14px/1.2 var(--font-sans)", color: w ? "var(--signal-ink)" : "var(--text-primary)" }}>{l} <span style={{ font: "var(--type-body-s)", fontSize: 12, color: "var(--text-muted)" }}>{s}</span></span>
              <div style={{ height: 5, background: "var(--surface-sunken)", borderRadius: 999 }}><div style={{ height: "100%", width: v / 1.5 * 100 + "%", background: w ? "var(--signal)" : "var(--graphite-500)", borderRadius: 999 }}></div></div>
            </div>
            <span style={{ font: "600 15px/1 var(--font-mono)", textAlign: "right", color: w ? "var(--signal-ink)" : "var(--text-primary)" }}>{v.toFixed(1).replace(".", ",")}</span>
          </div>); })}
      </div>
      <div style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", padding: "12px 16px", background: "var(--surface-sunken)", borderRadius: 8 }}>Hver feil koster i snitt ca. 1 slag. Halverer du jernbommene, sparer du 0,5 slag per runde.</div>
    </Panel>
  );
}

function SGScreen() {
  const [tab, setTab] = React.useState("app");
  const cur = CAT.find((c) => c[0] === tab);
  return (
    <div style={pageWrap}>
      <PageHead kicker="Strokes Gained · Emma Solberg · 24 runder" title="Dypdykk per spillfase" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(140px,1fr))", gap: 8 }}>
        {CAT.map(([k, c, n, v]) => { const on = tab === k; return (
          <button key={k} type="button" onClick={() => setTab(k)} aria-pressed={on} style={{ textAlign: "left", cursor: "pointer", padding: "16px 16px", borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--surface-card)" : "var(--surface-flat)", boxShadow: on ? "inset 0 -3px 0 var(--primary)" : "none", display: "flex", flexDirection: "column", gap: 8 }}>
            <span style={{ font: "600 12px/1 var(--font-mono)", color: "var(--text-secondary)" }}>{c} <span style={{ fontFamily: "var(--font-sans)", fontWeight: 400, color: "var(--text-muted)" }}>{n}</span></span>
            <span style={{ font: "var(--type-metric)", color: v >= 0 ? "var(--ok)" : "var(--text-primary)" }}>{sgf(v)}</span>
          </button>); })}
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 24, alignItems: "flex-start" }}>
        <Panel kicker={cur[1] + " · " + cur[2]} title={{ ott: "Treff fairway, unngå straff", app: "Gapping-matrise", arg: "Up-and-down per lie", putt: "Make-rate per puttebånd" }[tab]} style={{ flex: "2 1 420px" }}>
          {tab === "ott" && <Ott />}{tab === "app" && <App />}{tab === "arg" && <Arg />}{tab === "putt" && <Putt />}
        </Panel>
        <Tiger5 />
      </div>
    </div>
  );
}
window.SGScreen = SGScreen;
})();
