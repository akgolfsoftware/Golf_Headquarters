(() => {
const { Avatar, Icon, NavRail, MenuBar, NavDrawer } = window.AKGolfPrecisionAthletics_7d7c29;
const sgf = (v, d = 1) => (v > 0.0001 ? "+" : v < -0.0001 ? "−" : "±") + Math.abs(v).toFixed(d).replace(".", ",");
const nf = (v, d = 0) => { const [i, f] = Math.abs(v).toFixed(d).split("."); return (v < 0 ? "−" : "") + i.replace(/\B(?=(\d{3})+(?!\d))/g, " ") + (f ? "," + f : ""); };
function useWidth(init = 1000) {
  const ref = React.useRef(null), [w, setW] = React.useState(init);
  React.useLayoutEffect(() => { if (!ref.current) return; setW(ref.current.getBoundingClientRect().width); const ro = new ResizeObserver(([e]) => setW(e.contentRect.width)); ro.observe(ref.current); return () => ro.disconnect(); }, []);
  return [ref, w];
}

function Panel({ kicker, title, action, children, pad = "var(--card-pad)", style, inverse }) {
  return (
    <section style={{ background: inverse ? "var(--surface-inverse)" : "var(--surface-card)", color: inverse ? "var(--text-inverse)" : "inherit", border: inverse ? "none" : "1px solid var(--border-hairline)", borderRadius: 8, padding: pad, display: "flex", flexDirection: "column", gap: 16, minWidth: 0, ...style }}>
      {(kicker || title || action) && <header style={{ display: "flex", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
        <div style={{ flex: "1 1 200px", minWidth: 0 }}>
          {kicker && <div className="kicker" style={inverse ? { color: "var(--sand-400)" } : null}>{kicker}</div>}
          {title && <div style={{ font: "var(--type-title-s)", color: inverse ? "var(--text-inverse)" : "var(--text-primary)", marginTop: kicker ? 4 : 0, textWrap: "pretty" }}>{title}</div>}
        </div>
        {action}
      </header>}
      {children}
    </section>
  );
}
function PageHead({ kicker, title, sub, actions }) {
  return (
    <header style={{ display: "flex", alignItems: "flex-end", gap: 16, flexWrap: "wrap" }}>
      <div style={{ flex: "1 1 320px", minWidth: 0 }}>
        <div className="kicker" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{kicker}</div>
        <h1 style={{ font: "600 clamp(22px, 1.2vw + 16px, 28px)/1.15 var(--font-sans)", letterSpacing: "var(--tracking-display)", color: "var(--text-primary)", margin: "8px 0 0", textWrap: "balance" }}>{title}</h1>
        {sub && <p style={{ font: "var(--type-body)", color: "var(--text-secondary)", margin: "8px 0 0", maxWidth: 680, textWrap: "pretty" }}>{sub}</p>}
      </div>
      {actions && <div style={{ display: "flex", gap: 8, flexWrap: "wrap", maxWidth: "100%" }}>{actions}</div>}
    </header>
  );
}
function Bar({ pct, color = "var(--primary)", h = 6, marker }) {
  const [on, setOn] = React.useState(false);
  React.useEffect(() => { const t = requestAnimationFrame(() => setOn(true)); return () => cancelAnimationFrame(t); }, []);
  return (
    <div style={{ position: "relative", height: h, background: "var(--surface-sunken)", borderRadius: 999 }}>
      <div style={{ position: "absolute", inset: 0, width: (on ? Math.min(100, pct) : 0) + "%", background: color, borderRadius: 999, transition: "width 900ms cubic-bezier(.2, .8, .2, 1)" }}></div>
      {marker != null && <div title="Plan per i dag" style={{ position: "absolute", top: -4, bottom: -4, left: marker + "%", width: 2, background: "var(--text-primary)", borderRadius: 1 }}></div>}
    </div>
  );
}
function Scale({ value, onChange, lo, hi, size = 44 }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, width: "100%" }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(5,minmax(0,1fr))", gap: 8 }}>
        {[1, 2, 3, 4, 5].map((n) => { const sel = value === n; return <button key={n} type="button" onClick={() => onChange(n)} aria-pressed={sel} style={{ height: Math.max(44, size), borderRadius: 8, border: "1px solid " + (sel ? "var(--primary)" : "var(--border-strong)"), background: sel ? "var(--primary)" : "var(--surface-card)", color: sel ? "var(--text-on-primary)" : "var(--text-primary)", font: "var(--type-num)", cursor: "pointer", transition: "background-color 120ms, border-color 120ms" }}>{n}</button>; })}
      </div>
      {(lo || hi) && <div style={{ display: "flex", justifyContent: "space-between", gap: 8, font: "var(--type-meta)", color: "var(--text-muted)" }}><span>{lo}</span><span style={{ textAlign: "right" }}>{hi}</span></div>}
    </div>
  );
}
const Tag = ({ on, onClick, children }) => (
  <button type="button" onClick={onClick} aria-pressed={on} style={{ height: "var(--tap)", padding: "0 12px", borderRadius: 999, border: "1px solid " + (on ? "var(--primary)" : "var(--border-strong)"), background: on ? "var(--primary)" : "transparent", color: on ? "var(--text-on-primary)" : "var(--text-body)", font: "500 13px/1 var(--font-sans)", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 8, whiteSpace: "nowrap", maxWidth: "100%" }}>{children}</button>
);
const pageWrap = { padding: "var(--page-y) var(--page-x) 48px", display: "flex", flexDirection: "column", gap: 24, maxWidth: 1360, width: "100%", boxSizing: "border-box", minWidth: 0 };

const G = (id, label, icon, items) => ({ id, label, icon, items: items.map(([i, l, ic, href]) => ({ id: i, label: l, icon: ic, href })) });
const NAV = [
  G("idag", "I dag", "sun", [["mal", "Mål og dagens økt", "target"], ["ytelse", "Ytelsesbilde", "radar"]]),
  G("plan", "Planlegging", "calendar-range", [["ovelse", "Workbench · Øvelse", "layers"], ["kalender", "Kalender", "calendar-range"], ["gameplan", "Gameplan", "map"], ["stall", "Stall-matrise", "users"]]),
  G("analyse", "Analyse & Banekart", "chart-spline", [["banekart", "Banekart", "flag"], ["analyse", "Treningsanalyse", "chart-spline"], ["sg", "Strokes Gained", "chart-column"], ["trackman", "TrackMan", "crosshair"]]),
  G("test", "Tester", "clipboard-check", [["test", "Ferdighetstest", "clipboard-check"]]),
  G("profil", "Profil", "user-round", [["onboarding", "Onboarding", "route"], ["baseline", "Baseline", "user-round-plus"], ["kategori", "Kategori A–K", "layers-2"]]),
];
const PAGES = NAV.flatMap((g) => g.items.map((i) => i.id));
const logoFull = <img src="../../assets/logo-ak-golf-hq.svg" alt="AK Golf HQ" style={{ height: 20, display: "block" }} />;
const logoMark = <img src="../../assets/ak-golf-logo-ink.svg" alt="AK Golf HQ" style={{ width: 28, height: 28, objectFit: "contain" }} />;
const Who = () => <div style={{ display: "flex", alignItems: "center", gap: 12 }}><Avatar name="Emma Solberg" size={32} /><div style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span style={{ font: "500 14px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>Emma Solberg</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>SPILLER · KATEGORI D</span></div></div>;

function ToppidrettApp() {
  const [page, setPageRaw] = React.useState(() => { const h = location.hash.slice(1); return PAGES.includes(h) ? h : localStorage.getItem("tos-page") || "ovelse"; });
  const [open, setOpen] = React.useState(false);
  const [ref, w] = useWidth(1280);
  const setPage = (p) => setPageRaw(p);
  React.useEffect(() => { localStorage.setItem("tos-page", page); document.querySelector("main")?.scrollTo(0, 0); }, [page]);
  React.useEffect(() => { window.__tosSetPage = setPageRaw; }, []);
  const rail = w > 1024;
  const vars = { "--page-x": w < 600 ? "16px" : w <= 1024 ? "24px" : "32px", "--page-y": w < 600 ? "20px" : "32px", "--card-pad": w < 600 ? "16px" : "24px", "--tap": w <= 1024 ? "44px" : "36px" };
  const S = { ovelse: OvelseScreen, analyse: AnalyseScreen, baseline: BaselineScreen, mal: MalScreen, ytelse: YtelseScreen, onboarding: OnboardingReise, kategori: KategoriScreen, banekart: BanekartScreen, stall: RosterScreen, kalender: KalenderScreen, gameplan: GameplanScreen, sg: SGScreen, trackman: TrackmanScreen, test: TestScreen }[page] || OvelseScreen;
  return (
    <div ref={ref} style={{ ...vars, position: "relative", display: "flex", flexDirection: rail ? "row" : "column", height: "100vh", width: "100%", overflow: "hidden", background: "var(--surface-page)" }}>
      {rail ? <NavRail brand={logoMark} groups={NAV} active={page} onSelect={setPage} footer={<Avatar name="Emma Solberg" size={32} />} /> : <MenuBar brand={logoFull} onMenu={() => setOpen(true)} open={open} />}
      <main style={{ flex: 1, minWidth: 0, minHeight: 0, overflowY: "auto", overflowX: "hidden" }} data-screen-label={page}><S /></main>
      {!rail && <NavDrawer open={open} onClose={() => setOpen(false)} brand={logoFull} groups={NAV} active={page} onSelect={setPage} footer={<Who />} />}
    </div>
  );
}
Object.assign(window, { TOS: { sgf, nf, Panel, PageHead, Bar, Scale, Tag, pageWrap, useWidth }, ToppidrettApp });
})();
