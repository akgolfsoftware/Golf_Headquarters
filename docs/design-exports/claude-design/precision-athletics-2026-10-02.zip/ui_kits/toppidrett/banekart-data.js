/* Banekart — soner, SG og trening per treningsområde. Tall er eksempeldata for Emma Solberg. */
window.BANEKART = (() => {
  const F = { x: 1060, y: 262 }, T = { x: 118, y: 402 }, PXM = 2.4;
  const len = Math.hypot(T.x - F.x, T.y - F.y), u = { x: (T.x - F.x) / len, y: (T.y - F.y) / len };
  const along = (m) => ({ x: F.x + u.x * m * PXM, y: F.y + u.y * m * PXM });
  const ZONES = [
    { id: "tee", chip: "Tee Total", title: "Tee Total · Utslag", area: "Utslag", cat: "OTT", sg: 0.4, stats: [["Fairway", "64 %"], ["Snitt carry", "248 m"], ["Spredning", "28 m"]], plan: [3, 2.5, "t"], test: "Driver Gate · 8/10 treff" },
    { id: "b200", chip: "200 m+", title: "Innspill ca. 200 m", area: "Innspill ca. 200 m", r: [200, 330], cat: "APP", sg: -0.1, stats: [["Proximity", "18,6 m"], ["GIR", "22 %"], ["Slag registrert", "64"]], plan: [60, 40, "slag"], test: "Innspill 200 m · 3/10 på green" },
    { id: "b150", chip: "150–200 m", title: "Innspill ca. 150 m", area: "Innspill ca. 150 m", r: [150, 200], cat: "APP", sg: -0.2, stats: [["Proximity", "11,9 m"], ["GIR", "41 %"], ["Slag registrert", "118"]], plan: [220, 180, "slag"], test: "Gapping 7-jern · ±5 m" },
    { id: "b100", chip: "100–150 m", title: "Innspill ca. 100 m · 100–150 m", area: "Innspill ca. 100 m", r: [100, 150], cat: "APP", sg: -0.8, stats: [["Proximity", "7,4 m"], ["GIR fra fairway", "58 %"], ["GIR fra rough", "32 %"]], plan: [480, 450, "slag"], planNote: "P3-posisjon · Lav hastighet", test: "CANON v3.5 Test 04 · 31 p", alert: "Her tapes det slag" },
    { id: "b50", chip: "50–100 m", title: "Innspill ca. 50 m", area: "Innspill ca. 50 m", r: [50, 100], cat: "APP", sg: 0.1, stats: [["Proximity", "5,2 m"], ["GIR", "74 %"], ["Slag registrert", "96"]], plan: [150, 160, "slag"], test: "Wedge-matrise · 7/10" },
    { id: "naer", chip: "Nærspill", title: "Nærspill rundt green", area: "Nærspill", cat: "ARG", sg: -0.3, sub: [["Chip", 62, 320, 58], ["Pitch", 48, 210, 50], ["Lob", 35, 80, 38], ["Bunker", 38, 120, 45]] },
    { id: "green", chip: "Green", title: "Putting green", area: "Putting", cat: "PUTT", sg: 0.2 },
  ];
  // [bånd, fra ft, til ft, make-rate, norm Kategori D, PGA Tour, putter trent 14 d, siste test]
  const PUTT = [["0–3 ft", 0, 3, 98, 96, 99, 150, "Putt Gate 3 ft · 10/10"], ["3–5 ft", 3, 5, 81, 76, 88, 180, "Klokka 4 ft · 18/20"], ["5–10 ft", 5, 10, 52, 48, 56, 200, "Putt Gate · 9/10"], ["10–25 ft", 10, 25, 20, 19, 24, 210, "Lengdekontroll 20 ft · 7/10 innenfor 3 ft"], ["25–40 ft", 25, 40, 5, 5, 7, 60, "Lengdekontroll 30 ft · 6/10"], ["40+ ft", 40, 52, 2, 2, 3, 40, "3-putt-test · 1 av 10"]];
  return { F, T, PXM, along, ZONES, PUTT };
})();
