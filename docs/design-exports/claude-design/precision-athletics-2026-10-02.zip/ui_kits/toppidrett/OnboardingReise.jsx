(() => {
const { Button, Stepper, ChoicePill, Icon, AxisBadge } = window.AKGolfPrecisionAthletics_7d7c29;
const { PageHead, pageWrap, sgf } = window.TOS;
const V = window.AK_VOCAB, CATS = V.CATEGORIES;
const catFor = (s) => CATS.findIndex((c) => s < c[2]);
const dec = (v) => v.toFixed(1).replace(".", ",");
const STEPS = [["rolle", "Hvem er du", "user-round"], ["anlegg", "Klubb og fasiliteter", "map-pin"], ["tid", "Tid til trening", "clock"], ["niva", "Nivå i dag", "gauge"], ["sg", "Strokes Gained", "chart-column"], ["mal", "Sesongmål", "target"], ["klar", "Din første plan", "flag"]];
const CLUBS = ["Gamle Fredrikstad GK", "Borregaard GK", "Hvaler GK", "Onsøy GK"];
const FAC = [
  ["range", "Driving range", "goal", V.AREAS.fullsving],
  ["sim", "TrackMan / simulator", "monitor", V.AREAS.fullsving],
  ["naer", "Nærspillsområde", "flag-triangle-right", ["Chip", "Pitch", "Lob"]],
  ["bunker", "Øvingsbunker", "mountain", ["Bunker"]],
  ["green", "Puttinggreen", "circle-dot", V.AREAS.putting],
  ["styrke", "Treningsrom", "dumbbell", ["Styrke"]],
  ["bane", "Bane", "trees", ["Banespill"]],
  ["hall", "Innendørshall", "warehouse", ["Chip", "Pitch", ...V.AREAS.putting.slice(0, 4)]],
];
const ALWAYS = ["Kondisjon", "Bevegelighet"];
const ALL = [...V.AREAS.fullsving, ...V.AREAS.naerspill, ...V.AREAS.putting, ...V.AREAS.fysisk, ...V.AREAS.bane];
const DAYS = ["Man", "Tir", "Ons", "Tor", "Fre", "Lør", "Søn"];
const SGC = [["ott", "OTT", "Utslag"], ["app", "APP", "Innspill"], ["arg", "ARG", "Nærspill"], ["putt", "PUTT", "Putting"]];

function Opt({ on, onClick, icon, title, sub, children }) {
  return (
    <button type="button" onClick={onClick} aria-pressed={on} style={{ textAlign: "left", cursor: "pointer", padding: 16, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--surface-card)" : "var(--surface-flat)", boxShadow: on ? "inset 0 0 0 1px var(--border-ink)" : "none", display: "flex", gap: 12, alignItems: "flex-start", minHeight: 64, transition: "border-color 120ms" }}>
      {icon && <Icon name={icon} size={20} style={{ marginTop: 1, flex: "none" }} />}
      <span style={{ flex: 1, minWidth: 0 }}><span style={{ display: "block", font: "600 15px/1.25 var(--font-sans)", color: "var(--text-primary)" }}>{title}</span>{sub && <span style={{ display: "block", font: "var(--type-body-s)", fontSize: 13, color: "var(--text-muted)", marginTop: 4 }}>{sub}</span>}{children}</span>
      <span style={{ width: 20, height: 20, borderRadius: 8, flex: "none", border: "1.5px solid " + (on ? "var(--primary)" : "var(--border-strong)"), background: on ? "var(--primary)" : "transparent", display: "grid", placeItems: "center" }}>{on && <Icon name="check" size={14} color="var(--text-on-primary)" />}</span>
    </button>
  );
}
const Q = ({ children, sub }) => <div><h2 style={{ margin: 0, font: "var(--type-title-m)", color: "var(--text-primary)", textWrap: "balance" }}>{children}</h2>{sub && <p style={{ margin: "6px 0 0", font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{sub}</p>}</div>;

function OnboardingReise() {
  const [step, setStep] = React.useState(0);
  const [d, setD] = React.useState({ role: "spiller", name: "Emma Solberg", born: 2008, club: CLUBS[0], fac: new Set(["range", "sim", "naer", "green", "bane"]), days: new Set(["Tir", "Tor", "Fre", "Lør"]), hours: 12, hcp: 6.4, avg: 75.2, src: "UpGame", sg: { ott: -0.4, app: -1.8, arg: -0.3, putt: 0.2 }, goal: 1, tour: 15 });
  const up = (o) => setD((x) => ({ ...x, ...o }));
  const tog = (k, v) => { const n = new Set(d[k]); n.has(v) ? n.delete(v) : n.add(v); up({ [k]: n }); };
  const open = new Set([...ALWAYS, ...FAC.filter((f) => d.fac.has(f[0])).flatMap((f) => f[3])]);
  const missing = ALL.filter((a) => !open.has(a));
  const ci = catFor(d.avg), cat = CATS[ci], gi = Math.min(d.goal, ci);
  const worst = SGC.reduce((w, c) => d.sg[c[0]] < d.sg[w[0]] ? c : w, SGC[0]);
  const u16 = 2026 - d.born < 16;
  const summary = [cat && ["Kategori", cat[0] + " · " + cat[1]], ["Anlegg", open.size + " av " + ALL.length + " områder"], ["Tid", d.days.size + " dager · " + d.hours + " t/uke"], ["Største gap", worst[1] + " " + sgf(d.sg[worst[0]])]].filter(Boolean);
  const body = [
    <>
      <Q sub="Vi tilpasser språk, tilganger og hvem som får planen.">Hvem oppretter profilen?</Q>
      <div style={{ display: "grid", gap: 8 }}>
        <Opt on={d.role === "spiller"} onClick={() => up({ role: "spiller" })} icon="user-round" title="Jeg er spiller" sub="Du eier profilen og godkjenner planer selv." />
        <Opt on={d.role === "forelder"} onClick={() => up({ role: "forelder" })} icon="users" title="Jeg er forelder" sub="For spillere under 16 år. Du får kopi av planer og varsler." />
      </div>
      <div style={{ display: "flex", gap: 24, flexWrap: "wrap", alignItems: "flex-end" }}>
        <label style={{ display: "flex", flexDirection: "column", gap: 8, flex: "1 1 220px" }}><span className="pa-field__label">Spillerens navn</span><input value={d.name} onChange={(e) => up({ name: e.target.value })} style={{ height: 44, padding: "0 16px", borderRadius: 8, border: "1px solid var(--border-control)", font: "500 15px/1 var(--font-sans)", color: "var(--text-primary)", background: "var(--surface-card)" }} /></label>
        <Stepper label="Fødselsår" value={d.born} onChange={(v) => up({ born: v })} min={1950} max={2020} />
      </div>
      {u16 && <div style={{ font: "var(--type-body-s)", color: "var(--info)", display: "flex", gap: 8 }}><Icon name="info" size={16} /><span>Under 16 år: en forelder må kobles til profilen før første plan publiseres.</span></div>}
    </>,
    <>
      <Q sub="Planen bruker bare øvelser du faktisk kan gjennomføre.">Hvor trener du, og hva har du tilgang til?</Q>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{CLUBS.map((c) => <ChoicePill key={c} selected={d.club === c} onClick={() => up({ club: c })}>{c}</ChoicePill>)}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))", gap: 8 }}>
        {FAC.map(([k, l, ic, areas]) => <Opt key={k} on={d.fac.has(k)} onClick={() => tog("fac", k)} icon={ic} title={l} sub={areas.length > 3 ? areas.length + " områder" : areas.join(", ")} />)}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: 16, borderRadius: 8, background: "var(--surface-sunken)" }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}><span style={{ font: "600 21px/1 var(--font-mono)", color: "var(--text-primary)" }}>{open.size}/{ALL.length}</span><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>treningsområder tilgjengelige</span></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(20,minmax(0,1fr))", gap: 4 }}>{ALL.map((a) => <span key={a} title={a} style={{ height: 8, borderRadius: 2, background: open.has(a) ? "var(--primary)" : "var(--border-strong)", transition: "background-color 160ms" }}></span>)}</div>
        {missing.length > 0 && <span style={{ font: "var(--type-body-s)", fontSize: 13, color: "var(--text-muted)" }}>Mangler: {missing.map((m) => m.replace("Putting ", "")).join(", ")}</span>}
      </div>
    </>,
    <>
      <Q sub="Coach bygger ukeplanen rundt dagene du velger.">Når kan du trene?</Q>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7,minmax(0,1fr))", gap: 8 }}>{DAYS.map((x) => <ChoicePill key={x} size="lg" selected={d.days.has(x)} onClick={() => tog("days", x)} style={{ padding: 0, minWidth: 0 }}>{x}</ChoicePill>)}</div>
      <Stepper label="Timer per uke" value={d.hours} onChange={(v) => up({ hours: v })} min={2} max={40} unit="t" />
      <span style={{ font: "var(--type-body-s)", color: "var(--text-muted)" }}>Snitt <span style={{ fontFamily: "var(--font-mono)", color: "var(--text-primary)" }}>{d.days.size ? dec(d.hours / d.days.size) : "0"} t</span> per treningsdag · <span style={{ fontFamily: "var(--font-mono)", color: "var(--text-primary)" }}>{(d.hours * 44).toLocaleString("nb-NO").replace(/\u00a0/g, " ")} t</span> på en sesong</span>
    </>,
    <>
      <Q sub="Brutto snitt siste 10 tellende runder avgjør kategorien.">Hvor står du i dag?</Q>
      <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}><Stepper label="HCP" value={d.hcp} onChange={(v) => up({ hcp: v })} step={0.1} min={-5} max={54} format={dec} /><Stepper label="Brutto snittscore" value={d.avg} onChange={(v) => up({ avg: v })} step={0.1} min={60} max={130} format={dec} unit="slag" /></div>
      <div style={{ display: "flex", alignItems: "center", gap: 16, padding: 16, borderRadius: 8, background: "var(--surface-inverse)", color: "var(--text-inverse)" }}>
        <span style={{ font: "600 48px/1 var(--font-sans)" }}>{cat[0]}</span>
        <div><div style={{ font: "600 17px/1.2 var(--font-sans)" }}>Kategori {cat[0]} · {cat[1]}</div><div style={{ font: "var(--type-num-s)", color: "var(--sand-400)", marginTop: 4 }}>{ci > 0 ? dec(d.avg - CATS[ci - 1][2] + 0.1) + " slag til Kategori " + CATS[ci - 1][0] : "Høyeste kategori"}</div></div>
      </div>
    </>,
    <>
      <Q sub="Mot scratch. Velg kilde, eller legg inn et estimat.">Hvor tjener og taper du slag?</Q>
      <div style={{ display: "flex", gap: 8 }}>{["UpGame", "Arccos", "Estimat"].map((s) => <ChoicePill key={s} selected={d.src === s} onClick={() => up({ src: s })}>{s}</ChoicePill>)}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 16 }}>{SGC.map(([k, c, n]) => <Stepper key={k} label={c + " · " + n} value={d.sg[k]} onChange={(v) => up({ sg: { ...d.sg, [k]: v } })} step={0.1} min={-5} max={5} format={(v) => sgf(v)} />)}</div>
      <div style={{ font: "600 15px/1.3 var(--font-sans)", color: "var(--signal-ink)", padding: 16, borderRadius: 8, background: "var(--signal-tint)" }}>Største gap: {worst[2]} ({worst[1]}) {sgf(d.sg[worst[0]])}</div>
    </>,
    <>
      <Q sub="Årsmålet styrer periodene i årshjulet.">Hva vil du nå denne sesongen?</Q>
      <span className="pa-field__label">Målkategori</span>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{CATS.slice(0, ci + 1).map((c, i) => <ChoicePill key={c[0]} size="lg" selected={gi === i} onClick={() => up({ goal: i })} style={{ minWidth: 52 }}>{c[0]}</ChoicePill>)}</div>
      <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Kategori {CATS[gi][0]} · {CATS[gi][1]} krever brutto snitt under <span style={{ fontFamily: "var(--font-mono)", color: "var(--text-primary)" }}>{dec(CATS[gi][2])}</span>. Det er <span style={{ fontFamily: "var(--font-mono)", color: "var(--text-primary)" }}>{dec(Math.max(0, d.avg - CATS[gi][2] + 0.1))} slag</span> fra i dag.</span>
      <Stepper label="Turneringer denne sesongen" value={d.tour} onChange={(v) => up({ tour: v })} min={0} max={40} />
    </>,
    <>
      <Q sub={"Coach " + (d.club === CLUBS[0] ? "Anders Kristiansen" : "på " + d.club) + " ser gjennom og publiserer innen 24 timer."}>Klar. Dette er utgangspunktet ditt.</Q>
      <div style={{ display: "flex", flexDirection: "column" }}>
        {[["slag", "Innspill ca. 100 m · Lav hastighet", "Tirsdag · 45 min"], ["tek", worst[2] + " · P3 · Uten ball", "Torsdag · 30 min"], ["spill", "Banespill · 9 hull · Strategioppgave", "Lørdag · 2 t"]].map(([a, t, m]) => <div key={t} style={{ display: "flex", gap: 12, alignItems: "center", padding: "12px 0", borderTop: "1px solid var(--border-hairline)" }}><AxisBadge axis={a}>{a.toUpperCase()}</AxisBadge><span style={{ flex: 1, font: "500 14px/1.25 var(--font-sans)", color: "var(--text-primary)" }}>{t}</span><span style={{ font: "var(--type-num-s)", color: "var(--text-muted)" }}>{m}</span></div>)}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 8 }}>
        <Opt on={false} onClick={() => {}} title="TALENT · gratis" sub="Profil, testbatteri og analyse" />
        <Opt on onClick={() => {}} title="FULL · 299 kr/mnd" sub="Plan fra coach, Caddie og full analyse" />
      </div>
    </>,
  ];
  const last = step === STEPS.length - 1;
  const box = React.useRef(null), [bw, setBw] = React.useState(1000);
  React.useLayoutEffect(() => { setBw(box.current.getBoundingClientRect().width); const ro = new ResizeObserver(([e]) => setBw(e.contentRect.width)); ro.observe(box.current); return () => ro.disconnect(); }, []);
  const narrow = bw < 780;
  return (
    <div style={pageWrap}>
      <PageHead kicker={"PlayerHQ · Onboarding · Steg " + (step + 1) + " av " + STEPS.length} title="Kom i gang" />
      <div ref={box} style={{ display: "flex", gap: 24, flexDirection: narrow ? "column" : "row", alignItems: narrow ? "stretch" : "flex-start" }}>
        {narrow && <nav aria-label="Onboarding-steg" style={{ display: "grid", gridTemplateColumns: "repeat(" + STEPS.length + ",minmax(0,1fr))", gap: 4 }}>
          {STEPS.map(([k, l], i) => { const done = i < step, on = i === step; return <button key={k} type="button" onClick={() => setStep(i)} title={l} aria-current={on ? "step" : undefined} style={{ border: "none", background: "none", padding: "8px 0", minHeight: 44, cursor: "pointer", display: "flex", flexDirection: "column", justifyContent: "center", gap: 8, alignItems: "stretch" }}><span style={{ height: 4, borderRadius: 999, background: done || on ? "var(--primary)" : "var(--border-strong)", opacity: on ? 1 : done ? .7 : 1 }}></span><span style={{ font: "var(--type-meta)", color: on ? "var(--text-primary)" : "var(--text-muted)", textAlign: "left", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{on ? l.toUpperCase() : i + 1}</span></button>; })}
        </nav>}
        {!narrow && <nav aria-label="Onboarding-steg" style={{ flex: "0 0 240px", display: "flex", flexDirection: "column", gap: 4, position: "sticky", top: 24 }}>
          {STEPS.map(([k, l, ic], i) => { const done = i < step, on = i === step; return (
            <button key={k} type="button" onClick={() => setStep(i)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr)", gap: 12, alignItems: "center", padding: "12px 12px", borderRadius: 8, border: "none", background: on ? "var(--surface-card)" : "transparent", cursor: "pointer", textAlign: "left" }}>
              <span style={{ width: 28, height: 28, borderRadius: 999, display: "grid", placeItems: "center", background: done ? "var(--primary)" : "transparent", border: done ? "none" : "1.5px solid " + (on ? "var(--border-ink)" : "var(--border-strong)"), color: done ? "var(--text-on-primary)" : "var(--text-primary)", font: "600 12px/1 var(--font-mono)" }}>{done ? <Icon name="check" size={14} /> : i + 1}</span>
              <span style={{ font: on ? "600 14px/1.2 var(--font-sans)" : "500 14px/1.2 var(--font-sans)", color: on || done ? "var(--text-primary)" : "var(--text-muted)" }}>{l}</span>
            </button>); })}
          <div style={{ marginTop: 16, padding: "16px 12px", borderTop: "1px solid var(--border-hairline)", display: "flex", flexDirection: "column", gap: 8 }}>
            {summary.map(([k, v]) => <div key={k} style={{ display: "flex", flexDirection: "column", gap: 4 }}><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{k.toUpperCase()}</span><span style={{ font: "var(--type-num-s)", color: "var(--text-primary)" }}>{v}</span></div>)}
          </div>
        </nav>}
        <section style={{ flex: "1 1 0", minWidth: 0, maxWidth: 760, background: "var(--surface-card)", border: "1px solid var(--border-hairline)", borderRadius: 8, overflow: "hidden" }}>
          <div style={{ height: 3, background: "var(--surface-sunken)" }}><div style={{ height: "100%", width: (step + 1) / STEPS.length * 100 + "%", background: "var(--primary)", transition: "width 300ms cubic-bezier(.2, .8, .2, 1)" }}></div></div>
          <div key={step} style={{ padding: 24, display: "flex", flexDirection: "column", gap: 24, animation: "tos-in 260ms cubic-bezier(.2,.8,.2,1)" }}>{body[step]}</div>
          <div style={{ display: "flex", gap: 8, padding: "16px 24px", borderTop: "1px solid var(--border-hairline)", background: "var(--surface-flat)" }}>
            {step > 0 && <Button variant="ghost" icon="arrow-left" onClick={() => setStep(step - 1)}>Tilbake</Button>}
            <span style={{ flex: 1 }}></span>
            <Button iconRight={last ? null : "arrow-right"} icon={last ? "check" : null} onClick={() => !last && setStep(step + 1)}>{last ? "Send til coach" : "Neste"}</Button>
          </div>
        </section>
      </div>
    </div>
  );
}
window.OnboardingReise = OnboardingReise;
})();
