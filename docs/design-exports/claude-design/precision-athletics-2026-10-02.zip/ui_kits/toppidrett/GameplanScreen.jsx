(() => {
const { Button, Icon, StatusPill } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap } = window.TOS;
const BAG = [["Driver", 232], ["3-wood", 214], ["5-wood", 199], ["4-hybrid", 193], ["5-jern", 181], ["6-jern", 170], ["7-jern", 158], ["8-jern", 147], ["9-jern", 135], ["PW", 123], ["50°", 110], ["54°", 97], ["58°", 83]];
const SIDE_SD = { "Driver": 12, "3-wood": 10, "5-wood": 9, "4-hybrid": 8, "5-jern": 7, "6-jern": 6, "7-jern": 5, "8-jern": 5, "9-jern": 4, "PW": 3 };
const HOLES = [
  [4, 352, 9, "3-wood", -3, "Lav", "Venstre halvdel av fairway", [["ob", 1, 0, 352], ["bunker", 1, 220, 245]]],
  [4, 378, 5, "Driver", 4, "Middels", "Høyre kant åpner greenen", [["vann", -1, 200, 300], ["bunker", 1, 240, 260]]],
  [3, 164, 15, "6-jern", -2, "Lav", "Venstre midt green", [["bunker", -1, 150, 165], ["vann", 1, 120, 170]]],
  [5, 488, 3, "Driver", 0, "Middels", "Midt fairway, legg opp til 100 m", [["ob", -1, 0, 488], ["bunker", 1, 250, 275], ["vann", 1, 380, 430]]],
  [4, 331, 13, "5-wood", 0, "Lav", "Midt fairway", [["bunker", -1, 190, 215]]],
  [4, 395, 1, "Driver", -5, "Høy", "Venstre side. Aldri høyre.", [["ob", 1, 0, 395], ["vann", 1, 210, 300], ["bunker", -1, 250, 270]]],
  [3, 148, 17, "8-jern", -2, "Lav", "Midt green", [["bunker", 1, 135, 150]]],
  [4, 362, 7, "3-wood", 3, "Middels", "Høyre halvdel, bort fra vannet", [["vann", -1, 180, 260], ["bunker", 1, 225, 240]]],
  [5, 502, 11, "Driver", 3, "Lav", "Høyre kant", [["bunker", -1, 240, 265], ["bunker", 1, 420, 440]]],
  [4, 344, 10, "3-wood", 0, "Lav", "Midt fairway", [["bunker", 1, 200, 225]]],
  [3, 182, 6, "5-jern", -4, "Høy", "Venstre midt green. Kort er ok.", [["vann", 1, 120, 190], ["bunker", -1, 170, 185]]],
  [5, 470, 16, "Driver", 0, "Lav", "Midt fairway", [["bunker", -1, 230, 250]]],
  [4, 388, 4, "Driver", -4, "Middels", "Venstre halvdel", [["ob", 1, 0, 388], ["bunker", -1, 245, 265]]],
  [4, 356, 8, "3-wood", 2, "Høy", "Midt-høyre. Spis før tee, energifall starter her.", [["vann", -1, 200, 285], ["bunker", 1, 225, 240]]],
  [4, 372, 2, "Driver", -3, "Middels", "Venstre halvdel", [["ob", 1, 0, 372], ["bunker", -1, 260, 280]]],
  [3, 138, 18, "9-jern", 3, "Middels", "Høyre midt green", [["vann", -1, 95, 145], ["bunker", 1, 125, 140]]],
  [4, 340, 12, "4-hybrid", 0, "Lav", "Mellom bunkerne", [["bunker", -1, 180, 205], ["bunker", 1, 190, 210]]],
  [5, 515, 14, "Driver", 4, "Middels", "Høyre kant, legg opp foran vannet", [["vann", -1, 420, 480], ["bunker", 1, 250, 270]]],
];
const RISK = { Lav: "ok", Middels: "warn", Høy: "signal" };
const clubFor = (m) => (BAG.slice().reverse().find((b) => b[1] >= m - 3) || BAG[0])[0];
const NAME = { vann: "Vann", ob: "Out of bounds", bunker: "Bunker" };

function HoleMap({ h }) {
  const [par, len, , club, side, , , hz] = h, carry = BAG.find((b) => b[0] === club)[1], tgt = par === 3 ? len : carry;
  const W = 280, T = 34, Bt = 494, s = (Bt - T) / (len + 20), y = (m) => Bt - m * s, x = (m) => W / 2 + m * s * 1.6, FW = 17;
  const sd = SIDE_SD[club] || 5;
  return (
    <svg viewBox={"0 0 " + W + " 520"} style={{ width: "100%", maxWidth: 300, height: "auto", display: "block", margin: "0 auto" }}>
      <defs><pattern id="never" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="7" height="7" fill="var(--signal-tint)" /><line x1="0" y1="0" x2="0" y2="7" stroke="var(--signal)" strokeWidth="2.5" /></pattern></defs>
      <rect x="0" y="0" width={W} height="520" rx="8" fill="var(--surface-sunken)" />
      {par > 3 && <rect x={x(-FW)} y={y(len - 25)} width={x(FW) - x(-FW)} height={y(150) - y(len - 25)} rx="18" fill="var(--sand-300)" />}
      {par === 3 && <rect x={x(-FW)} y={y(len - 20)} width={x(FW) - x(-FW)} height={20 * s} rx="10" fill="var(--sand-300)" />}
      {hz.map(([t, sd2, a, b], i) => {
        if (t === "ob") return <g key={i}><rect x={sd2 < 0 ? 0 : x(FW + 14)} y={y(b + 10)} width={sd2 < 0 ? x(-FW - 14) : W - x(FW + 14)} height={y(a) - y(b + 10)} fill="url(#never)" /><line x1={x(sd2 * (FW + 14))} x2={x(sd2 * (FW + 14))} y1={y(b + 10)} y2={y(a)} stroke="var(--signal)" strokeWidth="1.5" strokeDasharray="6 4" /></g>;
        if (t === "vann") return <rect key={i} x={sd2 < 0 ? x(-FW - 30) : x(FW - 2)} y={y(b)} width={x(30) - x(0) + 2} height={y(a) - y(b)} rx="10" fill="url(#never)" stroke="var(--signal)" strokeWidth="1.5" />;
        return <rect key={i} x={sd2 < 0 ? x(-FW - 6) : x(FW - 6)} y={y(b)} width={x(12) - x(0)} height={y(a) - y(b)} rx="8" fill="var(--sand-100)" stroke="var(--sand-400)" />;
      })}
      <circle cx={x(0)} cy={y(len)} r={14 * s * 1.3} fill="var(--sand-200)" stroke="var(--graphite-400)" />
      <g transform={"translate(" + x(0) + " " + y(len) + ")"}><line y2="-20" stroke="var(--text-primary)" strokeWidth="1.5" /><path d="M0 -20 L11 -16 L0 -12 Z" fill="var(--text-primary)" /></g>
      <line x1={x(0)} y1={y(0)} x2={x(side)} y2={y(tgt)} stroke="var(--text-primary)" strokeWidth="1.5" strokeDasharray="3 4" />
      <ellipse cx={x(side)} cy={y(tgt)} rx={x(sd * 2) - x(0)} ry={Math.max(8, sd * 1.1 * s)} fill="var(--axis-slag-soft)" stroke="var(--axis-slag)" strokeWidth="1.5" />
      <circle cx={x(side)} cy={y(tgt)} r="5" fill="var(--axis-slag)" stroke="var(--surface-card)" strokeWidth="2" />
      <text x={x(side) + x(sd * 2) - x(0) + 6} y={y(tgt) + 4} fill="var(--axis-slag-fg)" style={{ font: "600 11px var(--font-mono)" }}>{tgt} m</text>
      <rect x={x(-5)} y={y(0) - 4} width={x(10) - x(0)} height="8" rx="2" fill="var(--text-primary)" />
      {[100, 150, 200, 250, 300, 400].filter((m) => m < len - 20).map((m) => <text key={m} x="10" y={y(m) + 4} fill="var(--text-faint)" style={{ font: "11px var(--font-mono)" }}>{m}</text>)}
    </svg>
  );
}

function GameplanScreen() {
  const [hsRef, hsW] = window.TOS.useWidth(900);
  const nine = hsW < 700;
  const [i, setI] = React.useState(13);
  const h = HOLES[i], [par, len, si, club, side, risk, aim, hz] = h, carry = BAG.find((b) => b[0] === club)[1];
  const rem = len - carry, never = hz.filter((z) => z[0] !== "bunker");
  const second = par === 3 ? "Tee-slag rett til green" : par === 4 ? "Inn: " + rem + " m → " + clubFor(rem) : "Legg opp: " + Math.max(0, rem - 100) + " m → " + clubFor(rem - 100) + ", la 100 m igjen";
  return (
    <div style={pageWrap}>
      <PageHead kicker="Gameplan · Srixon Tour 6 · Gamle Fredrikstad GK · 03.10" title="Banetaktikk hull for hull" actions={<><Button variant="secondary" icon="printer">Skriv ut banekort</Button><Button icon="send">Del med spiller</Button></>} />
      <div ref={hsRef} style={{ display: "grid", gridTemplateColumns: "repeat(" + (nine ? 9 : 18) + ",minmax(0,1fr))", gap: 4, rowGap: 8 }}>
        {HOLES.map((x, k) => { const on = k === i; return (
          <button key={k} type="button" onClick={() => setI(k)} aria-pressed={on} style={{ height: 58, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--primary)" : "var(--surface-card)", color: on ? "var(--text-on-primary)" : "var(--text-primary)", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, marginLeft: k === 9 && !nine ? 8 : 0 }}>
            <span style={{ font: "600 15px/1 var(--font-mono)" }}>{k + 1}</span>
            <span style={{ width: 6, height: 6, borderRadius: 999, background: "var(--" + RISK[x[5]] + ")" }}></span>
          </button>); })}
      </div>
      <div style={{ display: "flex", gap: 24, flexWrap: "wrap", alignItems: "flex-start" }}>
        <Panel pad={16} style={{ flex: "0 1 340px" }}><HoleMap h={h} /></Panel>
        <div style={{ flex: "1 1 340px", display: "flex", flexDirection: "column", gap: 16 }}>
          <Panel>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 24, flexWrap: "wrap" }}>
              <div><div className="kicker">Hull</div><div style={{ font: "600 56px/0.9 var(--font-mono)", color: "var(--text-primary)", marginTop: 8 }}>{i + 1}</div></div>
              <div style={{ display: "flex", gap: 24, font: "var(--type-num)", color: "var(--text-secondary)", paddingBottom: 4 }}><span>Par {par}</span><span>{len} m</span><span>Indeks {si}</span></div>
              <span style={{ flex: 1 }}></span>
              <StatusPill tone={RISK[risk]}>Risiko {risk.toLowerCase()}</StatusPill>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 12 }}>
              {[["Kølle fra tee", club, carry + " m carry"], ["Siktemål", (side === 0 ? "Midt" : (side < 0 ? "V " : "H ") + Math.abs(side) + " m"), aim], ["Neste slag", par === 3 ? "Putt" : clubFor(par === 4 ? rem : rem - 100), second]].map(([k, v, s2]) => (
                <div key={k} style={{ padding: 16, borderRadius: 8, background: "var(--surface-sunken)", display: "flex", flexDirection: "column", gap: 8 }}>
                  <span className="kicker">{k}</span><span style={{ font: "600 21px/1.1 var(--font-mono)", color: "var(--text-primary)" }}>{v}</span><span style={{ font: "var(--type-body-s)", fontSize: 13, color: "var(--text-secondary)" }}>{s2}</span>
                </div>))}
            </div>
          </Panel>
          <Panel kicker="Aldri-soner" title={never.length ? never.length + (never.length > 1 ? " soner" : " sone") + " der ballen aldri skal lande" : "Ingen aldri-soner på dette hullet"}>
            {never.length > 0 && <div style={{ display: "flex", flexDirection: "column" }}>{never.map(([t, sd, a, b], k) => (
              <div key={k} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderTop: k ? "1px solid var(--border-hairline)" : "none" }}>
                <span style={{ width: 22, height: 22, borderRadius: 8, background: "repeating-linear-gradient(45deg,var(--signal) 0 2.5px,var(--signal-tint) 2.5px 7px)", flex: "none" }}></span>
                <span style={{ flex: 1, font: "500 14px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{NAME[t]} {sd < 0 ? "venstre" : "høyre"}</span>
                <span style={{ font: "var(--type-num-s)", color: "var(--signal-ink)" }}>{t === "ob" ? "hele hullet" : a + "–" + b + " m"}</span>
              </div>))}</div>}
            <div style={{ display: "flex", gap: 16, flexWrap: "wrap", font: "var(--type-meta)", color: "var(--text-muted)" }}>
              <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}><span style={{ width: 14, height: 10, borderRadius: 999, border: "1.5px solid var(--axis-slag)", background: "var(--axis-slag-soft)" }}></span>DIN SPREDNING 2σ · {club.toUpperCase()}</span>
              <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}><span style={{ width: 14, height: 10, borderRadius: 3, background: "var(--sand-100)", border: "1px solid var(--sand-400)" }}></span>BUNKER</span>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
window.GameplanScreen = GameplanScreen;
})();
