(() => {
const { Button, Stepper, ChoicePill, Icon, AxisBadge } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, sgf, nf } = window.TOS;
// Kategori A–K på brutto snittscore (ak-kategori.ts). Trinn er [min, max): verdien er øvre grense, eksklusiv.
const CATS = window.AK_VOCAB.CATEGORIES;
const catFor = (s) => CATS.findIndex((c) => s < c[2]);
const SGC = [["ott", "OTT", "Utslag", "SLAG · Utslag"], ["app", "APP", "Innspill", "SLAG · Innspill ca. 100–150 m"], ["arg", "ARG", "Nærspill", "SLAG · Chip og pitch"], ["putt", "PUTT", "Putting", "SLAG · Putting 3–10 fot"]];
const dec = (v) => v.toFixed(1).replace(".", ",");

function Step({ n, title, sub, children }) {
  return (
    <section style={{ display: "grid", gridTemplateColumns: "32px minmax(0,1fr)", gap: 16, padding: "24px 0", borderTop: n > 1 ? "1px solid var(--border-hairline)" : "none" }}>
      <span style={{ width: 28, height: 28, borderRadius: 999, border: "1.5px solid var(--border-ink)", display: "grid", placeItems: "center", font: "600 12px/1 var(--font-mono)", color: "var(--text-primary)" }}>{n}</span>
      <div style={{ display: "flex", flexDirection: "column", gap: 16, minWidth: 0 }}>
        <div><div style={{ font: "var(--type-title-s)", color: "var(--text-primary)" }}>{title}</div>{sub && <div style={{ font: "var(--type-body-s)", color: "var(--text-muted)", marginTop: 4 }}>{sub}</div>}</div>
        {children}
      </div>
    </section>
  );
}

function BaselineScreen() {
  const [hcp, setHcp] = React.useState(6.4);
  const [avg, setAvg] = React.useState(75.2);
  const [src, setSrc] = React.useState("UpGame");
  const [sg, setSg] = React.useState({ ott: -0.4, app: -1.8, arg: -0.3, putt: 0.2 });
  const [tn, setTn] = React.useState([["NM Junior", "14.08", 76, "12"], ["Srixon Tour 4", "31.07", 79, "21"], ["Regionsfinale Øst", "19.06", 75, "6"]]);
  const ci = catFor(avg), cat = CATS[ci];
  const worst = SGC.reduce((w, c) => sg[c[0]] < sg[w[0]] ? c : w, SGC[0]);
  const total = Object.values(sg).reduce((a, b) => a + b, 0);
  const lost = Object.values(sg).filter((v) => v < 0).reduce((a, b) => a + b, 0);
  const share = lost < 0 ? Math.round(sg[worst[0]] / lost * 100) : 0;
  const toNext = ci > 0 ? avg - (CATS[ci - 1][2] - 0.1) : 0;
  const lbl = { font: "var(--type-label)", color: "var(--text-secondary)" };
  return (
    <div style={pageWrap}>
      <PageHead kicker="PlayerHQ · Ny spiller" title="Baseline-oppsett" sub="Legg inn der du står i dag. Kategori og største gap kalkuleres mens du skriver." />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,340px),1fr))", gap: 24, alignItems: "start" }}>
        <Panel pad="4px var(--card-pad) 24px">
          <Step n={1} title="Handicap og snittscore" sub="Brutto snitt siste 10 tellende runder.">
            <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
              <Stepper label="HCP" value={hcp} onChange={setHcp} step={0.1} min={-5} max={54} format={dec} />
              <Stepper label="Brutto snittscore" value={avg} onChange={setAvg} step={0.1} min={60} max={130} format={dec} unit="slag" />
            </div>
          </Step>
          <Step n={2} title="Strokes Gained" sub="Mot scratch. Hentes automatisk eller legges inn som estimat.">
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
              {["UpGame", "Arccos", "Estimat"].map((s) => <ChoicePill key={s} selected={src === s} onClick={() => setSrc(s)}>{s}</ChoicePill>)}
              {src !== "Estimat" && <span style={{ display: "inline-flex", alignItems: "center", gap: 8, font: "var(--type-meta)", color: "var(--ok)", marginLeft: 8 }}><Icon name="check" size={14} /><span>SYNKRONISERT · 24 RUNDER</span></span>}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 16 }}>
              {SGC.map(([k, c, n]) => <Stepper key={k} label={c + " · " + n} value={sg[k]} onChange={(v) => setSg((x) => ({ ...x, [k]: v }))} step={0.1} min={-5} max={5} format={(v) => sgf(v)} />)}
            </div>
          </Step>
          <Step n={3} title="Siste turneringer" sub="Brutto score. Tre siste er nok for baseline.">
            <div style={{ display: "flex", flexDirection: "column" }}>
              <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) 88px 44px", gap: 12, font: "var(--type-meta)", color: "var(--text-faint)", paddingBottom: 8 }}><span>TURNERING · DATO</span><span style={{ textAlign: "right" }}>BRUTTO</span><span style={{ textAlign: "right" }}>PLASS</span></div>
              {tn.map((t, i) => (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) 88px 44px", gap: 12, alignItems: "center", padding: "12px 0", borderTop: "1px solid var(--border-hairline)" }}>
                  <span style={{ font: "500 14px/1.2 var(--font-sans)", color: "var(--text-primary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t[0]}<span style={{ display: "block", font: "var(--type-meta)", color: "var(--text-muted)", marginTop: 4 }}>{t[1]}</span></span>
                  <span style={{ font: "var(--type-num-s)", color: "var(--text-primary)", textAlign: "right" }}>{t[2]} ({sgf(t[2] - 72, 0).replace("±0", "E")})</span>
                  <span style={{ font: "var(--type-num-s)", color: "var(--text-secondary)", textAlign: "right" }}>{t[3]}.</span>
                </div>
              ))}
              <button type="button" onClick={() => setTn((x) => [...x, ["Ny turnering", "—", 78, "—"]])} style={{ marginTop: 8, alignSelf: "flex-start", display: "inline-flex", alignItems: "center", gap: 8, border: "none", background: "none", padding: "8px 0", minHeight: 44, font: "var(--type-button)", color: "var(--text-primary)", cursor: "pointer" }}><Icon name="plus" size={16} />Legg til turnering</button>
            </div>
          </Step>
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", paddingTop: 8 }}><Button variant="ghost">Hopp over</Button><Button icon="arrow-right">Opprett profil og baseline</Button></div>
        </Panel>

        <div style={{ display: "flex", flexDirection: "column", gap: 16, position: "sticky", top: 24 }}>
          <Panel inverse pad={28} style={{ gap: 24 }}>
            <div className="kicker" style={{ color: "var(--sand-400)" }}>Umiddelbar diagnose</div>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 24 }}>
              <span style={{ font: "600 96px/0.82 var(--font-sans)", letterSpacing: "-.03em" }}>{cat[0]}</span>
              <div style={{ paddingBottom: 4 }}>
                <div style={{ font: "600 21px/1.2 var(--font-sans)" }}>Kategori {cat[0]} · {cat[1]}</div>
                <div style={{ font: "var(--type-num-s)", color: "var(--sand-400)", marginTop: 4 }}>Brutto snitt {dec(avg)} · HCP {dec(hcp)}</div>
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(11,minmax(0,1fr))", gap: 4 }}>
              {CATS.map((c, i) => <div key={c[0]} style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "center" }}>
                <div style={{ height: i === ci ? 28 : 8, width: "100%", borderRadius: 3, background: i === ci ? "var(--sand-100)" : i < ci ? "var(--graphite-600)" : "var(--graphite-700)", transition: "height 240ms" }}></div>
                <span style={{ font: "600 11px/1 var(--font-mono)", color: i === ci ? "var(--sand-100)" : "var(--graphite-400)" }}>{c[0]}</span>
              </div>)}
            </div>
            {ci > 0 && <div style={{ font: "var(--type-body-s)", color: "var(--sand-300)" }}><span style={{ fontFamily: "var(--font-mono)", color: "var(--sand-100)" }}>{dec(toNext)} slag</span> lavere snitt (under {dec(CATS[ci - 1][2])}) gir Kategori {CATS[ci - 1][0]} · {CATS[ci - 1][1]}.</div>}
          </Panel>

          <Panel kicker="Strokes Gained-profil" title={"Totalt " + sgf(total) + " slag per runde"}>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {SGC.map(([k, c, n]) => {
                const v = sg[k], w = Math.min(50, Math.abs(v) / 2.5 * 50), gap = k === worst[0] && v < 0;
                return (
                  <div key={k} style={{ display: "grid", gridTemplateColumns: "88px minmax(0,1fr) 48px", gap: 12, alignItems: "center" }}>
                    <span style={{ font: gap ? "600 13px/1.2 var(--font-sans)" : "500 13px/1.2 var(--font-sans)", color: gap ? "var(--signal-ink)" : "var(--text-secondary)" }}>{c} <span style={{ fontWeight: 400, color: "var(--text-muted)" }}>{n}</span></span>
                    <div style={{ position: "relative", height: 14 }}>
                      <div style={{ position: "absolute", left: "50%", top: -3, bottom: -3, width: 1, background: "var(--border-strong)" }}></div>
                      <div style={{ position: "absolute", top: 0, bottom: 0, borderRadius: 3, left: v < 0 ? (50 - w) + "%" : "50%", width: w + "%", background: gap ? "var(--signal)" : v < 0 ? "var(--graphite-400)" : "var(--ok)", transition: "left 240ms var(--ease-out), width 240ms var(--ease-out), top 240ms var(--ease-out), opacity 240ms var(--ease-out)" }}></div>
                    </div>
                    <span style={{ font: "600 13px/1 var(--font-mono)", textAlign: "right", color: gap ? "var(--signal-ink)" : "var(--text-primary)" }}>{sgf(v)}</span>
                  </div>
                );
              })}
            </div>
            {sg[worst[0]] < 0 && <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: 16, borderRadius: 8, background: "var(--signal-tint)" }}>
              <div style={{ font: "600 15px/1.3 var(--font-sans)", color: "var(--signal-ink)" }}>Største gap: {worst[2]} ({worst[1]}) {sgf(sg[worst[0]])}</div>
              <div style={{ font: "var(--type-body-s)", color: "var(--text-body)" }}>{share} % av alle tapte slag. Første plan starter her.</div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}><AxisBadge axis="slag">SLAG</AxisBadge><span style={{ font: "500 13px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{worst[3].replace("SLAG · ", "")}</span></div>
            </div>}
          </Panel>
        </div>
      </div>
    </div>
  );
}
window.BaselineScreen = BaselineScreen;
})();
