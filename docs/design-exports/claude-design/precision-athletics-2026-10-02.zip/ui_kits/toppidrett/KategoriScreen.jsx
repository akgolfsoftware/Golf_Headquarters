(() => {
const { Icon, Stepper, Tabs } = window.AKGolfPrecisionAthletics_7d7c29;
const { PageHead, pageWrap, Panel } = window.TOS;
const CATS = window.AK_VOCAB.CATEGORIES;
const dec = (v) => v.toFixed(1).replace(".", ",");
const range = (i) => i === 0 ? "< 68" : CATS[i][2] === Infinity ? CATS[i - 1][2] + "+" : CATS[i - 1][2] + "–" + CATS[i][2];
const STALL = { A: 0, B: 1, C: 3, D: 4, E: 3, F: 3, G: 3, H: 2, I: 1, J: 1, K: 1 };
const LO = 64, HI = 106;
const X = (s) => (Math.min(HI, Math.max(LO, s)) - LO) / (HI - LO) * 100;

function KategoriScreen() {
  const [avg, setAvg] = React.useState(75.2);
  const [sel, setSel] = React.useState(null);
  const [f, setF] = React.useState("alle");
  const ci = CATS.findIndex((c) => avg < c[2]), si = sel ?? ci, s = CATS[si];
  const vis = (c) => f === "alle" || (f === "elite" ? /Elite|U21|U18/.test(c[1]) : f === "klubb" ? /Klubb/.test(c[1]) : /Rekrutt|Nybegynner/.test(c[1]));
  const lower = si === 0 ? null : CATS[si - 1][2], upper = s[2];
  return (
    <div style={pageWrap}>
      <PageHead kicker="Spillerkategorier · Brutto snittscore" title="Kategori A–K" sub="Trinnene inkluderer nedre grense og ekskluderer øvre. Snitt 74,2 er Kategori D." actions={<Tabs tabs={[{ value: "alle", label: "Alle" }, { value: "elite", label: "Elite" }, { value: "klubb", label: "Klubb" }, { value: "rekrutt", label: "Rekrutt" }]} value={f} onChange={setF} />} />

      <Panel pad={24} style={{ gap: 24 }}>
        <div style={{ display: "flex", gap: 24, alignItems: "flex-end", flexWrap: "wrap" }}>
          <Stepper label="Brutto snittscore" value={avg} onChange={(v) => { setAvg(v); setSel(null); }} step={0.1} min={60} max={120} format={dec} unit="slag" />
          <div style={{ flex: 1, minWidth: 220, font: "var(--type-body)", color: "var(--text-secondary)" }}>Emma Solberg · <span style={{ fontFamily: "var(--font-mono)", color: "var(--text-primary)" }}>{dec(avg)}</span> gir <b style={{ color: "var(--text-primary)", fontWeight: 600 }}>Kategori {CATS[ci][0]} · {CATS[ci][1]}</b>{ci > 0 && <>. Neste trinn om <span style={{ fontFamily: "var(--font-mono)", color: "var(--text-primary)" }}>{dec(avg - CATS[ci - 1][2] + 0.1)} slag</span>.</>}</div>
        </div>
        <div style={{ position: "relative", paddingTop: 30 }}>
          <div style={{ position: "absolute", top: 0, left: X(avg) + "%", transform: "translateX(-50%)", display: "flex", flexDirection: "column", alignItems: "center", transition: "left 200ms" }}><span style={{ font: "600 12px/1 var(--font-mono)", padding: "4px 8px", background: "var(--surface-inverse)", color: "var(--text-inverse)", borderRadius: 8 }}>{dec(avg)}</span><span style={{ width: 2, height: 8, background: "var(--text-primary)" }}></span></div>
          <div style={{ display: "flex", height: 44, gap: 4 }}>
            {CATS.map((c, i) => { const a = i === 0 ? LO : CATS[i - 1][2], b = Math.min(HI, c[2]), on = i === si, me = i === ci; return (
              <button key={c[0]} type="button" onClick={() => setSel(i)} title={c[1]} style={{ flex: b - a, minWidth: 0, border: "none", borderRadius: 8, cursor: "pointer", background: on ? "var(--primary)" : me ? "var(--graphite-500)" : "var(--surface-sunken)", color: on || me ? "var(--text-on-primary)" : "var(--text-secondary)", font: "600 13px/1 var(--font-sans)", opacity: vis(c) ? 1 : .35, transition: "background-color 160ms" }}>{c[0]}</button>); })}
          </div>
          <div style={{ position: "relative", height: 16, marginTop: 8 }}>{[68, 72, 76, 80, 85, 90, 95, 100].map((v) => <span key={v} style={{ position: "absolute", left: X(v) + "%", transform: "translateX(-50%)", font: "var(--type-meta)", color: "var(--text-faint)" }}>{v}</span>)}</div>
        </div>
      </Panel>

      <div style={{ display: "flex", gap: 24, flexWrap: "wrap", alignItems: "flex-start" }}>
        <div style={{ flex: "2 1 380px", display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(150px,1fr))", gap: 8 }}>
          {CATS.map((c, i) => { const on = i === si, me = i === ci; return (
            <button key={c[0]} type="button" onClick={() => setSel(i)} aria-pressed={on} style={{ textAlign: "left", cursor: "pointer", padding: 16, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--surface-inverse)" : "var(--surface-card)", color: on ? "var(--text-inverse)" : "var(--text-primary)", display: "flex", flexDirection: "column", gap: 12, opacity: vis(c) ? 1 : .35, minHeight: 132, transition: "background-color 160ms" }}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
                <span style={{ font: "600 40px/0.9 var(--font-sans)", letterSpacing: "-.02em", flex: 1 }}>{c[0]}</span>
                {me && <span style={{ font: "var(--type-kicker)", letterSpacing: "var(--tracking-kicker)", padding: "4px 8px", borderRadius: 999, background: on ? "var(--sand-100)" : "var(--primary)", color: on ? "var(--graphite-900)" : "var(--text-on-primary)" }}>DU</span>}
              </div>
              <span style={{ font: "600 14px/1.25 var(--font-sans)" }}>{c[1]}</span>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginTop: "auto" }}><span style={{ font: "600 15px/1 var(--font-mono)" }}>{range(i)}</span><span style={{ font: "var(--type-meta)", color: on ? "var(--sand-400)" : "var(--text-muted)" }}>{STALL[c[0]]} I STALL</span></div>
            </button>); })}
        </div>
        <Panel kicker="Referansekort" title={"Kategori " + s[0] + " · " + s[1]} style={{ flex: "1 1 300px", position: "sticky", top: 24 }}>
          <div style={{ display: "flex", flexDirection: "column" }}>
            {[["Brutto snitt", range(si) + " slag"], ["Nedre grense", lower == null ? "—" : dec(lower) + " (inkl.)"], ["Øvre grense", upper === Infinity ? "—" : dec(upper) + " (ekskl.)"], ["Spillere i stall", String(STALL[s[0]])]].map(([k, v], i) => <div key={k} style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "12px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{k}</span><span style={{ font: "600 14px/1 var(--font-mono)", color: "var(--text-primary)" }}>{v}</span></div>)}
          </div>
          <div style={{ padding: 16, borderRadius: 8, background: "var(--surface-sunken)", font: "var(--type-body-s)", color: "var(--text-body)" }}>
            {si === ci ? <>Du er her. {ci > 0 ? <>Kategori {CATS[ci - 1][0]} krever snitt under <span style={{ fontFamily: "var(--font-mono)" }}>{dec(CATS[ci - 1][2])}</span>.</> : "Høyeste kategori."}</>
              : si < ci ? <>Fra ditt snitt: <span style={{ fontFamily: "var(--font-mono)" }}>{dec(avg - upper + 0.1)} slag</span> lavere for å nå Kategori {s[0]}.</>
              : <>Kategori {s[0]} er {si - ci} {si - ci === 1 ? "trinn" : "trinn"} under din kategori.</>}
          </div>
          <span style={{ font: "var(--type-meta)", color: "var(--text-faint)" }}>KILDE: AK-KATEGORI.TS</span>
        </Panel>
      </div>
    </div>
  );
}
window.KategoriScreen = KategoriScreen;
})();
