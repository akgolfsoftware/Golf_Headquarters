(() => {
const { Button, AxisBadge, Icon, StatusPill } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, Bar, nf } = window.TOS;

function Tier({ n, label, span, children, last }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr)", gap: 16 }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
        <span style={{ width: 11, height: 11, borderRadius: 999, background: "var(--primary)", marginTop: 4 }}></span>
        {!last && <span style={{ flex: 1, width: 1.5, background: "var(--border-strong)", marginTop: 8 }}></span>}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 16, paddingBottom: last ? 0 : 32, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-title-s)", color: "var(--text-primary)" }}>{label}</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{span}</span></div>
        {children}
      </div>
    </div>
  );
}
function Goal({ kicker, value, of, unit, pct, plan, note, tone, axis, children }) {
  const behind = plan != null && pct < plan - 3;
  return (
    <div style={{ flex: "1 1 220px", minWidth: 0, background: "var(--surface-card)", border: "1px solid var(--border-hairline)", borderRadius: 8, padding: 16, display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>{axis && <AxisBadge axis={axis} size="sm">{axis.toUpperCase()}</AxisBadge>}<span className="kicker" style={{ flex: 1 }}>{kicker}</span>{pct != null && <span style={{ font: "600 13px/1 var(--font-mono)", color: pct >= 100 ? "var(--ok)" : "var(--text-primary)" }}>{Math.round(pct)} %</span>}</div>
      {children || <div style={{ font: "var(--type-metric)", color: "var(--text-primary)" }}>{value}<span style={{ font: "var(--type-num-s)", color: "var(--text-muted)" }}>{" / " + of + " " + unit}</span></div>}
      {pct != null && <Bar pct={pct} marker={plan} color={pct >= 100 ? "var(--ok)" : axis ? "var(--axis-" + axis + ")" : "var(--primary)"} />}
      {note && <span style={{ font: "var(--type-body-s)", fontSize: 13, color: behind ? "var(--warn)" : tone || "var(--text-muted)" }}>{note}</span>}
    </div>
  );
}
const Contributes = ({ children }) => <div style={{ display: "flex", alignItems: "center", gap: 8, font: "var(--type-meta)", color: "var(--text-muted)" }}><Icon name="corner-left-up" size={14} /><span>{children}</span></div>;

function MalScreen() {
  const [done, setDone] = React.useState(false);
  const wkSlag = 360 + (done ? 30 : 0);
  return (
    <div style={pageWrap}>
      <PageHead kicker="Mål · Emma Solberg · Sesong 2026" title="Fra årsmål til dagens økt" sub="Hvert nivå bygger på nivået under. Den svarte streken viser hvor planen sier du skal være i dag." />
      <div>
        <Tier n={1} label="Årsmål" span="JAN–DES 2026 · UKE 39 AV 52">
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            <Goal kicker="Treningstimer" value="812" of="1 200" unit="t" pct={812 / 1200 * 100} plan={73} note="Plan per i dag: 880 t. 68 t bak." />
            <Goal kicker="Turneringer" value="9" of="15" unit="spilt" pct={60} plan={62} note="Neste: Srixon Tour 6 · 03.10" />
            <Goal kicker="Spillerkategori">
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                {[["D", "Nå", true], ["C", "Delmål", false], ["B", "Mål", false]].map(([c, l, cur], i) => <React.Fragment key={c}>
                  {i > 0 && <Icon name="arrow-right" size={16} color="var(--text-faint)" />}
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                    <span style={{ width: 44, height: 44, borderRadius: 8, display: "grid", placeItems: "center", font: "600 22px/1 var(--font-sans)", background: cur ? "var(--primary)" : "transparent", color: cur ? "var(--text-on-primary)" : "var(--text-primary)", border: cur ? "none" : "1.5px " + (c === "B" ? "solid var(--border-ink)" : "dashed var(--border-strong)") }}>{c}</span>
                    <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{l.toUpperCase()}</span>
                  </div>
                </React.Fragment>)}
              </div>
              <span style={{ font: "var(--type-body-s)", fontSize: 13, color: "var(--text-muted)" }}>Snitt 75,2 · B krever under 72,0</span>
            </Goal>
          </div>
        </Tier>
        <Tier n={2} label="Periodemål" span="SPESIALPERIODE · UKE 36–43">
          <Contributes>BIDRAR TIL KATEGORI C</Contributes>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            <Goal axis="slag" kicker="SG Innspill" pct={100} note="Mål −1,0 eller bedre. Nå −0,6." tone="var(--ok)"><div style={{ font: "var(--type-metric)", color: "var(--ok)" }}>−0,6<span style={{ font: "var(--type-num-s)", color: "var(--text-muted)" }}> / −1,0 APP</span></div></Goal>
            <Goal axis="tek" kicker="Slag P3 · Lav hastighet" value="1 640" of="2 400" unit="slag" pct={68} plan={50} note="Foran plan med 440 slag." />
            <Goal axis="turn" kicker="Prestasjonsturneringer" value="1" of="3" unit="spilt" pct={33} plan={50} note="Plan per i dag: 1,5." />
          </div>
        </Tier>
        <Tier n={3} label="Ukesmål" span="UKE 39 · 21.09–27.09 · LIVE">
          <Contributes>BIDRAR TIL 2 400 SLAG P3 · LAV HASTIGHET</Contributes>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            <Goal kicker="Treningstimer" value="11,5" of="16" unit="t" pct={11.5 / 16 * 100} plan={71} note="4,5 t igjen på 3 dager." />
            <Goal axis="tek" kicker="Slag P3 · Lav hastighet" value={String(wkSlag)} of="450" unit="slag" pct={wkSlag / 450 * 100} plan={71} note={done ? "+30 slag fra dagens økt." : "Dagens økt gir +30 slag."} />
            <Goal kicker="Økter" value={done ? "6" : "5"} of="7" unit="gjennomført" pct={(done ? 6 : 5) / 7 * 100} plan={71} />
          </div>
        </Tier>
        <Tier n={4} label="Dagens øktmål" span="FREDAG 25.09 · 16:30 · TRENINGSOMRÅDET" last>
          <Contributes>BYGGER MOT UKESMÅLET: {wkSlag} → {done ? wkSlag : wkSlag + 30} AV 450 SLAG</Contributes>
          <Panel inverse pad={24} style={{ gap: 16 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
              <AxisBadge axis="tek">TEK</AxisBadge>
              <span style={{ font: "var(--type-meta)", color: "var(--sand-400)" }}>INNSPILL CA. 100 M · LAV HASTIGHET · DRAW · P3.0</span>
              <span style={{ flex: 1 }}></span>
              {done ? <StatusPill tone="ok">Gjennomført</StatusPill> : <span style={{ font: "var(--type-num-s)", color: "var(--sand-300)" }}>30 slag · 20 min</span>}
            </div>
            <div style={{ font: "600 clamp(24px,2.6vw,32px)/1.15 var(--font-sans)", letterSpacing: "-.01em", textWrap: "balance" }}>«Bredde i hendene i P3»</div>
            <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
              <div style={{ flex: "1 1 240px", display: "flex", flexDirection: "column", gap: 8 }}>
                <span style={{ font: "var(--type-meta)", color: "var(--sand-400)" }}>ETTER ØKTEN: UKESMÅL {Math.round((wkSlag + (done ? 0 : 30)) / 450 * 100)} %</span>
                <div style={{ height: 6, borderRadius: 999, background: "var(--graphite-700)", position: "relative", overflow: "hidden" }}>
                  <div style={{ position: "absolute", inset: 0, width: (done ? wkSlag : wkSlag + 30) / 450 * 100 + "%", background: "var(--graphite-500)", borderRadius: 999 }}></div>
                  <div style={{ position: "absolute", inset: 0, width: wkSlag / 450 * 100 + "%", background: "var(--axis-tek)", borderRadius: 999 }}></div>
                </div>
              </div>
              {!done ? <button type="button" onClick={() => setDone(true)} style={{ height: 48, padding: "0 24px", borderRadius: 8, border: "none", background: "var(--sand-100)", color: "var(--graphite-900)", font: "600 15px/1 var(--font-sans)", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 8 }}><Icon name="play" size={18} />Start økt</button>
                : <button type="button" onClick={() => setDone(false)} style={{ height: 48, padding: "0 16px", borderRadius: 8, border: "1px solid var(--graphite-600)", background: "transparent", color: "var(--sand-100)", font: "500 14px/1 var(--font-sans)", cursor: "pointer" }}>Angre</button>}
            </div>
          </Panel>
        </Tier>
      </div>
    </div>
  );
}
window.MalScreen = MalScreen;
})();
