(() => {
const { Avatar, Icon, Tabs, Button } = window.AKGolfPrecisionAthletics_7d7c29;
const { PageHead, pageWrap, sgf, useWidth } = window.TOS;
// [navn, kategori, compliance, SG-trend 30 d, ACWR, gruppe, årsak/fokus, siste økt]
const P = [
  ["Emma Solberg", "D", 94, 0.9, 1.42, "f", "ACWR 1,42 · over trygg sone", "I dag 08:00"],
  ["Oliver Lie", "F", 61, -0.6, 0.92, "f", "3 økter hoppet over denne uken", "Mandag"],
  ["Nora Dahl", "C", 88, -0.3, 1.05, "f", "Ryggsmerter registrert etter runde", "I dag 13:00"],
  ["Sander Lunde", "G", 72, 0.1, 1.1, "f", "Plan venter på spiller i 4 dager", "I går"],
  ["Ingrid Bakke", "E", 83, -0.8, 1.0, "f", "SG APP falt 0,8 på 30 dager", "I dag 11:00"],
  ["Jonas Berg", "C", 96, 0.4, 1.12, "p", "SLAG · Utslag kurve", "I dag 10:00"],
  ["Sofie Haugen", "D", 91, 0.3, 1.02, "p", "Putting 3–5 fot", "I dag 10:00"],
  ["Filip Moen", "E", 89, 0.2, 0.98, "p", "Gapping jern", "I dag 09:00"],
  ["Thea Nilsen", "D", 93, 0.6, 1.08, "p", "TEK · P4", "I dag 12:00"],
  ["Henrik Aas", "F", 86, 0.1, 1.15, "p", "TEK · Utslag", "I dag 09:00"],
  ["Magnus Strand", "H", 84, 0.2, 0.95, "p", "Chip · Landingspunkt", "I dag 13:00"],
  ["Maja Eide", "G", 90, 0.4, 1.01, "p", "Banespill 9 hull", "I går"],
  ["Ella Hansen", "I", 82, 0.5, 1.04, "p", "Nærspill · Pitch", "I går"],
  ["Elias Vik", "B", 98, 0.2, 1.1, "p", "TURN · Prestasjonsturnering", "I dag 07:30"],
  ["Frida Holm", "J", 80, 0.7, 0.9, "p", "Putting 0–3 fot", "Onsdag"],
  ["Aksel Nygård", "E", 87, 0.1, 1.06, "p", "Innspill ca. 150 m", "I går"],
  ["Linnea Berge", "K", 81, 0.9, 0.88, "p", "FYS · Bevegelighet", "Onsdag"],
  ["Tobias Myhre", "H", 85, 0.3, 1.0, "p", "Bunker · Sandinngang", "I går"],
  ["Selma Brekke", "D", 0, 0, 0.4, "r", "Skadet · kne · uke 3 av 6", "12.09"],
  ["Isak Ruud", "F", 0, 0, 0.7, "r", "Eksamensperiode til 02.10", "20.09"],
  ["Vilde Sæther", "C", 0, 0, 0.8, "r", "Planlagt hvile etter NM", "22.09"],
  ["Johannes Fjeld", "G", 0, 0, 0.6, "r", "Syk · feber", "21.09"],
];
const G = [["f", "Trenger oppfølging i dag", "signal"], ["p", "Følger planen", "ok"], ["r", "Hviler", "neutral"]];
const COLS = "minmax(160px,1.4fr) 44px minmax(112px,1fr) 56px 56px minmax(120px,1.6fr) 88px 24px";
const d2 = (v) => v.toFixed(2).replace(".", ",");
const ell = { whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", minWidth: 0 };
const Cat = ({ c }) => <span style={{ width: 28, height: 28, flex: "none", borderRadius: 8, display: "grid", placeItems: "center", border: "1px solid var(--border-strong)", font: "600 13px/1 var(--font-sans)", color: "var(--text-primary)" }}>{c}</span>;
const Comp = ({ v }) => <span style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 0, flex: 1 }}><span style={{ flex: 1, height: 6, background: "var(--surface-sunken)", borderRadius: 999 }}><span style={{ display: "block", height: "100%", width: v + "%", borderRadius: 999, background: v < 75 ? "var(--signal)" : "var(--primary)" }}></span></span><span style={{ font: "var(--type-num-s)", color: v < 75 ? "var(--signal-ink)" : "var(--text-primary)", width: 40, textAlign: "right" }}>{v} %</span></span>;
const sgC = (sg, rest) => rest ? "var(--text-faint)" : sg > 0 ? "var(--ok)" : sg < 0 ? "var(--text-primary)" : "var(--text-muted)";

function Row({ p, g, card }) {
  const [n, cat, comp, sg, acwr, , why, last] = p, rest = g === "r", fl = g === "f";
  const whyS = { font: fl ? "500 13px/1.3 var(--font-sans)" : "400 13px/1.3 var(--font-sans)", color: fl ? "var(--signal-ink)" : "var(--text-secondary)", ...ell };
  if (card) return (
    <div role="listitem" style={{ display: "flex", flexDirection: "column", gap: 8, padding: "12px var(--card-pad)", borderTop: "1px solid var(--border-hairline)", boxShadow: fl ? "inset 3px 0 0 var(--signal)" : "none" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, minWidth: 0 }}><Avatar name={n} size={32} /><span style={{ flex: 1, font: "500 15px/1.2 var(--font-sans)", color: "var(--text-primary)", ...ell }}>{n}</span><Cat c={cat} /></div>
      {!rest && <div style={{ display: "flex", alignItems: "center", gap: 12, minWidth: 0 }}><Comp v={comp} /><span style={{ font: "var(--type-num-s)", color: sgC(sg), width: 40, textAlign: "right" }}>{sgf(sg)}</span><span style={{ font: "var(--type-num-s)", color: acwr > 1.3 ? "var(--warn)" : "var(--text-secondary)", width: 36, textAlign: "right" }}>{d2(acwr)}</span></div>}
      <div style={{ display: "flex", gap: 8, alignItems: "baseline", minWidth: 0 }}><span style={{ flex: 1, ...whyS }}>{why}</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)", whiteSpace: "nowrap" }}>{last.toUpperCase()}</span></div>
    </div>
  );
  return (
    <div role="row" style={{ display: "grid", gridTemplateColumns: COLS, gap: 12, alignItems: "center", padding: "8px 16px", borderTop: "1px solid var(--border-hairline)", minHeight: 52, boxShadow: fl ? "inset 3px 0 0 var(--signal)" : "none" }}>
      <span style={{ display: "flex", alignItems: "center", gap: 12, minWidth: 0 }}><Avatar name={n} size={32} /><span style={{ font: "500 14px/1.2 var(--font-sans)", color: "var(--text-primary)", ...ell }}>{n}</span></span>
      <Cat c={cat} />
      {rest ? <span style={{ font: "var(--type-meta)", color: "var(--text-faint)" }}>—</span> : <Comp v={comp} />}
      <span style={{ font: "var(--type-num-s)", textAlign: "right", color: sgC(sg, rest) }}>{rest ? "—" : sgf(sg)}</span>
      <span style={{ font: "var(--type-num-s)", textAlign: "right", color: acwr > 1.3 ? "var(--warn)" : "var(--text-secondary)" }}>{d2(acwr)}</span>
      <span style={whyS}>{why}</span>
      <span style={{ font: "var(--type-meta)", color: "var(--text-muted)", ...ell }}>{last.toUpperCase()}</span>
      <Icon name="chevron-right" size={16} color="var(--text-faint)" />
    </div>
  );
}

function RosterScreen() {
  const [f, setF] = React.useState("alle");
  const [sort, setSort] = React.useState("comp");
  const [ref, w] = useWidth(1000);
  const card = w < 900;
  const active = P.filter((p) => p[5] !== "r");
  const avg = Math.round(active.reduce((a, p) => a + p[2], 0) / active.length);
  const sorters = { comp: (a, b) => a[2] - b[2], cat: (a, b) => a[1].localeCompare(b[1]), acwr: (a, b) => b[4] - a[4] };
  return (
    <div style={pageWrap}>
      <PageHead kicker="Stall · AgencyOS · Anders Kristiansen" title="Stall-matrise" sub={P.length + " spillere · snitt etterlevelse " + avg + " % siste 14 dager"}
        actions={card ? null : <Tabs tabs={[{ value: "alle", label: "Alle", count: P.length }, ...G.map(([k, l]) => ({ value: k, label: l.replace("Trenger oppfølging i dag", "Oppfølging"), count: P.filter((p) => p[5] === k).length }))]} value={f} onChange={setF} />} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 8 }}>
        {G.map(([k, l, t]) => { const c = P.filter((p) => p[5] === k).length; return (
          <button key={k} type="button" onClick={() => setF(f === k ? "alle" : k)} aria-pressed={f === k} style={{ textAlign: "left", cursor: "pointer", padding: "16px", borderRadius: 8, border: "1px solid " + (f === k ? "var(--border-ink)" : "var(--border-hairline)"), background: t === "signal" ? "var(--signal-tint)" : "var(--surface-card)", display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
            <span style={{ font: "600 13px/1.25 var(--font-sans)", color: t === "signal" ? "var(--signal-ink)" : "var(--text-secondary)", display: "flex", alignItems: "flex-start", gap: 8 }}>{t === "signal" && <Icon name="circle-alert" size={16} style={{ flex: "none" }} />}{l}</span>
            <span style={{ font: "var(--type-metric-l)", color: t === "signal" ? "var(--signal-ink)" : "var(--text-primary)" }}>{c}</span>
          </button>); })}
      </div>
      <div ref={ref} style={{ background: "var(--surface-card)", border: "1px solid var(--border-hairline)", borderRadius: 8, overflow: "hidden" }}>
        <div role={card ? "list" : "table"}>
          {card ? <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "12px var(--card-pad)", flexWrap: "wrap" }}>
              <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>SORTER</span>
              {[["comp", "Etterlevelse"], ["cat", "Kategori"], ["acwr", "ACWR"]].map(([k, l]) => <button key={k} type="button" onClick={() => setSort(k)} aria-pressed={sort === k} style={{ height: 44, padding: "0 12px", borderRadius: 999, border: "1px solid " + (sort === k ? "var(--primary)" : "var(--border-strong)"), background: sort === k ? "var(--primary)" : "transparent", color: sort === k ? "var(--text-on-primary)" : "var(--text-body)", font: "500 13px/1 var(--font-sans)", cursor: "pointer" }}>{l}</button>)}
            </div>
            : <div role="row" style={{ display: "grid", gridTemplateColumns: COLS, gap: 12, padding: "12px 16px", font: "var(--type-meta)", color: "var(--text-faint)" }}>
              {[["SPILLER"], ["KAT.", "cat"], ["ETTERLEVELSE", "comp"], ["SG 30 D"], ["ACWR", "acwr"], ["ÅRSAK / FOKUS"], ["SISTE ØKT"], [""]].map(([l, s], i) => <button key={i} type="button" disabled={!s} onClick={() => s && setSort(s)} style={{ all: "unset", cursor: s ? "pointer" : "default", textAlign: i === 3 || i === 4 ? "right" : "left", color: sort === s ? "var(--text-primary)" : "inherit", font: "inherit", ...ell }}>{l}{sort === s ? " ↓" : ""}</button>)}
            </div>}
          {G.filter(([k]) => f === "alle" || f === k).map(([k, l, t]) => {
            const list = P.filter((p) => p[5] === k).sort(sorters[sort]);
            return (
              <div key={k} role="rowgroup">
                <div style={{ padding: "12px var(--card-pad) 8px", borderTop: "1px solid var(--border-hairline)", background: "var(--surface-flat)", display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                  <span style={{ width: 8, height: 8, borderRadius: 999, background: t === "signal" ? "var(--signal)" : t === "ok" ? "var(--ok)" : "var(--graphite-400)" }}></span>
                  <span className="kicker" style={{ color: t === "signal" ? "var(--signal-ink)" : undefined }}>{l}</span>
                  <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{list.length}</span>
                  {k === "f" && <span style={{ marginLeft: "auto" }}><Button size="sm" variant="primary" icon="send">Send oppfølging til {list.length}</Button></span>}
                </div>
                {list.map((p) => <Row key={p[0]} p={p} g={k} card={card} />)}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
window.RosterScreen = RosterScreen;
})();
