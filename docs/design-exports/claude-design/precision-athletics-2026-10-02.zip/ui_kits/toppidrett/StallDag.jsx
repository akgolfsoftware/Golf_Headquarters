(() => {
const { ChoicePill, IconButton } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, useWidth } = window.TOS;
const RES = [["Sim-bås 1", "TrackMan"], ["Sim-bås 2", "TrackMan"], ["Driving range", "Matte 1–6"], ["Putting green", "Nærspill"], ["Coaching · Anders", "Hovedcoach"], ["Coaching · Mari", "Coach"]];
const B = [
  [0, 8, 9.5, "Emma Solberg", "tek", "Innspill 100 m · P3"], [0, 10, 11, "Jonas Berg", "slag", "Utslag · Kurve"], [0, 13, 14.5, "Nora Dahl", "tek", "Innspill 150 m · P6"], [0, 16.5, 18, "Emma Solberg", "slag", "Innspill 100 m · AUTO"],
  [1, 9, 10, "Filip Moen", "slag", "Gapping · jern"], [1, 12, 13.5, "Thea Nilsen", "tek", "Utslag · P4"], [1, 15, 16, "Sander Lunde", "slag", "Innspill 50 m"],
  [2, 8, 10, "Gruppe A · 6 spillere", "slag", "Innspill ca. 150 m"], [2, 14, 16, "Gruppe B · 5 spillere", "slag", "Utslag · Startretning"], [2, 17, 19, "Oliver Lie", "fys", "Oppvarming + styrke"],
  [3, 10, 11.5, "Sofie Haugen", "slag", "Putting 3–5 fot"], [3, 13, 14, "Magnus Strand", "slag", "Chip · Landingspunkt"], [3, 16, 17.5, "Gruppe A · 6 spillere", "spill", "Nærspill-konkurranse"],
  [4, 8, 9.5, "Emma Solberg", "tek", "Coaching · P3-kontroll"], [4, 11, 12, "Ingrid Bakke", "tek", "Videoanalyse"], [4, 13, 14.5, "Nora Dahl", "tek", "Coaching · sim-bås 1"], [4, 15.5, 16.5, "Foreldremøte", null, "Kategori H–K"],
  [5, 9, 10, "Henrik Aas", "tek", "Coaching · utslag"], [5, 14, 16, "Gruppe B · 5 spillere", "slag", "Range-økt"], [5, 17, 18, "Maja Eide", "spill", "Banespill 9 hull"],
];
const H0 = 8, H1 = 20, PX = 56, NOW = 14 + 20 / 60;
const hm = (h) => String(Math.floor(h)).padStart(2, "0") + ":" + String(Math.round((h % 1) * 60)).padStart(2, "0");

function StallDag() {
  const [sel, setSel] = React.useState(null);
  const [ref, w] = useWidth(1000);
  const n = w < 560 ? 1 : w < 920 ? 3 : 6;
  const [pg, setPg] = React.useState(0);
  const pages = Math.ceil(RES.length / n), p = Math.min(pg, pages - 1);
  const vis = RES.map((r, i) => i).slice(p * n, p * n + n);
  const H = (H1 - H0) * PX;
  const used = RES.map((_, r) => B.filter((b) => b[0] === r).reduce((a, b) => a + b[2] - b[1], 0));
  const cols = "48px repeat(" + vis.length + ",minmax(0,1fr))";
  return (
    <div ref={ref} style={{ display: "flex", flexDirection: "column", gap: 16, minWidth: 0 }}>
      {n < 6 && <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
        {n === 1 ? RES.map(([nm], i) => <ChoicePill key={nm} selected={vis[0] === i} onClick={() => setPg(i)}>{nm}</ChoicePill>)
          : <><IconButton icon="chevron-left" label="Forrige ressurser" variant="secondary" disabled={p === 0} onClick={() => setPg(p - 1)} /><span style={{ font: "var(--type-num-s)", color: "var(--text-secondary)", flex: 1, textAlign: "center" }}>{RES[vis[0]][0]} – {RES[vis[vis.length - 1]][0]} · {p + 1}/{pages}</span><IconButton icon="chevron-right" label="Neste ressurser" variant="secondary" disabled={p >= pages - 1} onClick={() => setPg(p + 1)} /></>}
      </div>}
      <Panel pad={0} style={{ overflow: "hidden", gap: 0 }}>
        <div style={{ display: "grid", gridTemplateColumns: cols, borderBottom: "1px solid var(--border-hairline)", background: "var(--surface-card)" }}>
          <span></span>
          {vis.map((i) => <div key={i} style={{ padding: "12px", borderLeft: "1px solid var(--border-hairline)", display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}>
            <span style={{ font: "600 14px/1.2 var(--font-sans)", color: "var(--text-primary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{RES[i][0]}</span>
            <span style={{ font: "var(--type-meta)", color: "var(--text-muted)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{RES[i][1].toUpperCase()} · {String(used[i]).replace(".", ",")} / 12 T</span>
          </div>)}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: cols, position: "relative", height: H }}>
          <div style={{ position: "relative" }}>{Array.from({ length: H1 - H0 }, (_, i) => <span key={i} style={{ position: "absolute", top: i * PX - 6, right: 8, font: "var(--type-meta)", color: "var(--text-faint)" }}>{i ? hm(H0 + i) : ""}</span>)}</div>
          {vis.map((r) => (
            <div key={r} style={{ position: "relative", minWidth: 0, borderLeft: "1px solid var(--border-hairline)", backgroundImage: "repeating-linear-gradient(to bottom, transparent 0, transparent " + (PX - 1) + "px, var(--border-hairline) " + (PX - 1) + "px, var(--border-hairline) " + PX + "px)" }}>
              {B.filter((b) => b[0] === r).map((b, i) => {
                const k = r + "-" + i, on = sel === k, done = b[2] <= NOW, live = b[1] <= NOW && b[2] > NOW;
                return (
                  <button key={k} type="button" title={b[3] + " · " + b[5]} onClick={() => setSel(on ? null : k)} style={{ position: "absolute", left: 4, right: 4, top: (b[1] - H0) * PX + 2, height: (b[2] - b[1]) * PX - 4, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: b[4] ? "var(--axis-" + b[4] + "-bg)" : "var(--surface-sunken)", boxShadow: "inset 3px 0 0 " + (b[4] ? "var(--axis-" + b[4] + ")" : "var(--graphite-500)"), padding: "4px 8px 4px 12px", textAlign: "left", cursor: "pointer", overflow: "hidden", display: "flex", flexDirection: "column", gap: 4, opacity: done ? .55 : 1 }}>
                    <span style={{ font: "var(--type-meta)", color: "var(--text-secondary)", display: "flex", gap: 8, whiteSpace: "nowrap" }}>{hm(b[1])}–{hm(b[2])}{live && <span style={{ color: "var(--signal-ink)", fontWeight: 600 }}>PÅGÅR</span>}</span>
                    <span style={{ font: "600 13px/1.2 var(--font-sans)", color: "var(--text-primary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: "100%" }}>{b[3]}</span>
                    {(b[2] - b[1]) >= 1.5 && <span style={{ font: "400 12px/1.25 var(--font-sans)", color: "var(--text-secondary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: "100%" }}>{b[5]}</span>}
                  </button>
                );
              })}
            </div>
          ))}
          <div style={{ position: "absolute", left: 48, right: 0, top: (NOW - H0) * PX, height: 0, borderTop: "2px solid var(--signal)", pointerEvents: "none", zIndex: 1 }}><span style={{ position: "absolute", left: -46, top: -6, width: 40, textAlign: "right", font: "600 11px/1 var(--font-mono)", color: "var(--signal-ink)" }}>{hm(NOW)}</span></div>
        </div>
      </Panel>
    </div>
  );
}
window.StallDag = StallDag;
})();
