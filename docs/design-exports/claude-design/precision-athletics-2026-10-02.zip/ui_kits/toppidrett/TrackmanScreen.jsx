(() => {
const { ChoicePill, Icon } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap } = window.TOS;
const d1 = (v) => v.toFixed(1).replace(".", ",").replace("-", "−");
const rng = (seed) => () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const CLUBS = { "PW": [123, 3.5, 3, 0.4, 0.8, 18], "7-jern": [158, 5, 5, 1.8, 0.5, 25], "Driver": [232, 9, 12, 3.5, -0.3, 45] };
function shots(club) {
  const [c, sc, ss, bias, rho, R] = CLUBS[club], r = rng(club.length * 97 + 11);
  const n = () => Math.sqrt(-2 * Math.log(r() + 1e-9)) * Math.cos(2 * Math.PI * r());
  return { R, target: c, pts: Array.from({ length: 30 }, () => { const a = n(), b = n(); return [bias + ss * a, c - 1.5 + sc * (rho * a + Math.sqrt(1 - rho * rho) * b)]; }) };
}
const BAG = [["Driver", 232], ["3-wood", 214], ["5-wood", 199], ["4-hybrid", 193], ["5-jern", 181], ["6-jern", 170], ["7-jern", 158], ["8-jern", 147], ["9-jern", 135], ["PW", 123], ["50°", 110], ["54°", 97], ["58°", 83], ["Putter", null]];

function Dispersion() {
  const [club, setClub] = React.useState("7-jern");
  const { R, target, pts } = React.useMemo(() => shots(club), [club]);
  const S = 440, P = 48, k = (S - 2 * P) / (2 * R), X = (s) => S / 2 + s * k, Y = (c) => S / 2 - (c - target) * k;
  const mx = pts.reduce((a, p) => a + p[0], 0) / pts.length, my = pts.reduce((a, p) => a + p[1], 0) / pts.length;
  const a = pts.reduce((s, p) => s + (p[0] - mx) ** 2, 0) / pts.length, c = pts.reduce((s, p) => s + (p[1] - my) ** 2, 0) / pts.length, b = pts.reduce((s, p) => s + (p[0] - mx) * (p[1] - my), 0) / pts.length;
  const q = Math.sqrt(((a - c) / 2) ** 2 + b * b), l1 = (a + c) / 2 + q, l2 = (a + c) / 2 - q, ang = 0.5 * Math.atan2(2 * b, a - c) * 180 / Math.PI;
  const near = Math.round(pts.filter((p) => Math.hypot(p[0], p[1] - target) <= R * 0.4).length / pts.length * 100);
  const grid = [-R, -R / 2, 0, R / 2, R].map((g) => Math.round(g));
  return (
    <Panel kicker="TrackMan · Treningsområde · 30 slag" title="Spredningskart" action={<div style={{ display: "flex", gap: 8 }}>{Object.keys(CLUBS).map((cl) => <ChoicePill key={cl} selected={club === cl} onClick={() => setClub(cl)}>{cl}</ChoicePill>)}</div>} style={{ flex: "1 1 340px" }}>
      <div style={{ display: "flex", gap: 24, flexWrap: "wrap", alignItems: "center" }}>
        <svg viewBox={"0 0 " + S + " " + S} style={{ flex: "1 1 320px", maxWidth: 460, height: "auto", display: "block" }}>
          <rect x={P} y={P} width={S - 2 * P} height={S - 2 * P} fill="var(--surface-sunken)" rx="4" />
          {grid.map((g) => <g key={g}><line x1={X(g)} x2={X(g)} y1={P} y2={S - P} stroke="var(--border-hairline)" strokeDasharray={g ? "2 4" : ""} /><line x1={P} x2={S - P} y1={Y(target + g)} y2={Y(target + g)} stroke="var(--border-hairline)" strokeDasharray={g ? "2 4" : ""} />
            <text x={X(g)} y={S - P + 18} textAnchor="middle" fill="var(--text-muted)" style={{ font: "11px var(--font-mono)" }}>{g === 0 ? "0" : (g < 0 ? "V " : "H ") + Math.abs(g)}</text>
            <text x={P - 8} y={Y(target + g) + 4} textAnchor="end" fill="var(--text-muted)" style={{ font: "11px var(--font-mono)" }}>{Math.round(target + g)}</text></g>)}
          {[2, 1].map((s) => <ellipse key={s} cx={X(mx)} cy={Y(my)} rx={Math.sqrt(l1) * s * k} ry={Math.sqrt(Math.max(l2, .01)) * s * k} transform={"rotate(" + (-ang) + " " + X(mx) + " " + Y(my) + ")"} fill={s === 1 ? "var(--axis-slag-soft)" : "none"} stroke="var(--axis-slag)" strokeWidth={s === 1 ? 2 : 1.25} strokeDasharray={s === 2 ? "4 4" : ""} style={{ transition: "left 300ms var(--ease-out), width 300ms var(--ease-out), top 300ms var(--ease-out), opacity 300ms var(--ease-out)" }} />)}
          {pts.map((p, i) => <circle key={i} cx={X(p[0])} cy={Y(p[1])} r="4" fill="var(--surface-card)" stroke="var(--text-primary)" strokeWidth="1.5" />)}
          <g transform={"translate(" + X(0) + " " + Y(target) + ")"}><line x1="0" y1="0" x2="0" y2="-26" stroke="var(--text-primary)" strokeWidth="2" /><path d="M0 -26 L16 -20 L0 -14 Z" fill="var(--signal)" /><circle r="4" fill="var(--text-primary)" /></g>
          <circle cx={X(mx)} cy={Y(my)} r="5" fill="var(--axis-slag)" stroke="var(--surface-card)" strokeWidth="2" />
          <text x={S / 2} y={P - 12} textAnchor="middle" fill="var(--text-faint)" style={{ font: "600 11px var(--font-sans)", letterSpacing: ".08em" }}>CARRY (M) · SIDEAVVIK (M)</text>
        </svg>
        <div style={{ flex: "1 1 180px", display: "flex", flexDirection: "column" }}>
          {[["Mål", target + " m"], ["Carry snitt", d1(my) + " m"], ["Sideavvik snitt", (mx >= 0 ? "H " : "V ") + d1(Math.abs(mx)) + " m"], ["Spredning (2σ)", Math.round(Math.sqrt(l1) * 4) + " × " + Math.round(Math.sqrt(l2) * 4) + " m"], ["Innenfor " + Math.round(R * 0.4) + " m", near + " %"]].map(([k2, v], i) => (
            <div key={k2} style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 12, padding: "12px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{k2}</span><span style={{ font: "600 15px/1 var(--font-mono)", color: "var(--text-primary)", whiteSpace: "nowrap" }}>{v}</span></div>))}
          <div style={{ display: "flex", gap: 16, marginTop: 12, font: "var(--type-meta)", color: "var(--text-muted)", flexWrap: "wrap" }}><span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}><span style={{ width: 14, height: 10, borderRadius: 999, border: "2px solid var(--axis-slag)", background: "var(--axis-slag-soft)" }}></span>1σ · 68 %</span><span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}><span style={{ width: 14, height: 10, borderRadius: 999, border: "1.25px dashed var(--axis-slag)" }}></span>2σ · 95 %</span></div>
        </div>
      </div>
    </Panel>
  );
}

function Gapping() {
  const max = 250;
  return (
    <Panel kicker="Bag gapping · 14 køller" title="Lengdestige" action={<span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>CARRY · SNITT SISTE 60 DAGER</span>} style={{ flex: "1 1 340px" }}>
      <div style={{ display: "flex", flexDirection: "column" }}>
        {BAG.map(([n, c], i) => {
          const next = BAG[i + 1] && BAG[i + 1][1], gap = c && next ? c - next : null, flag = gap != null && (gap < 8 ? "Overlapp" : gap > 16 ? "Stort gap" : null);
          return (
            <React.Fragment key={n}>
              <div style={{ display: "grid", gridTemplateColumns: "76px minmax(0,1fr) 56px", gap: 12, alignItems: "center", height: 26 }}>
                <span style={{ font: "500 13px/1 var(--font-sans)", color: "var(--text-primary)" }}>{n}</span>
                {c ? <div style={{ height: 10, background: "var(--surface-sunken)", borderRadius: 999 }}><div style={{ width: c / max * 100 + "%", height: "100%", background: "var(--primary)", borderRadius: 999 }}></div></div> : <span style={{ font: "var(--type-meta)", color: "var(--text-faint)" }}>GREEN</span>}
                <span style={{ font: "600 13px/1 var(--font-mono)", color: "var(--text-primary)", textAlign: "right" }}>{c ? c + " m" : "—"}</span>
              </div>
              {gap != null && <div style={{ display: "grid", gridTemplateColumns: "76px minmax(0,1fr) 56px", gap: 12, alignItems: "center", height: 20 }}>
                <span></span>
                <span style={{ font: "var(--type-meta)", color: flag ? "var(--warn)" : "var(--text-faint)", display: "flex", gap: 8, alignItems: "center", paddingLeft: next / max * 100 + "%" }}><span style={{ width: 1, height: 12, background: flag ? "var(--warn)" : "var(--border-strong)" }}></span>{flag ? flag.toUpperCase() : ""}</span>
                <span style={{ font: "500 12px/1 var(--font-mono)", color: flag ? "var(--warn)" : "var(--text-muted)", textAlign: "right" }}>−{gap}</span>
              </div>}
            </React.Fragment>
          );
        })}
      </div>
      <div style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", padding: "12px 16px", background: "var(--surface-sunken)", borderRadius: 8 }}>5-wood og 4-hybrid overlapper (6 m). Vurder å bytte 4-hybrid mot en 2-jern driving iron for å dekke gapet på 18 m under driver.</div>
    </Panel>
  );
}

function TrackmanScreen() {
  return (
    <div style={pageWrap}>
      <PageHead kicker="TrackMan · Emma Solberg" title="Spredning og kølle-gapping" />
      <div style={{ display: "flex", gap: 24, flexWrap: "wrap", alignItems: "flex-start" }}><Dispersion /><Gapping /></div>
    </div>
  );
}
window.TrackmanScreen = TrackmanScreen;
})();
