(() => {
const { Button, AxisBadge, Icon, Tabs } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, sgf, nf } = window.TOS;
const WEEKS = [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39];
const SLAG = [0, 0, 20, 0, 10, 0, 0, 80, 90, 95, 100, 85];
const SG = [-1.8, -1.9, -1.7, -1.8, -1.8, -1.7, -1.8, -1.6, -1.3, -1.1, -0.8, -0.6];
const ROUNDS = [1, 0, 1, 1, 0, 1, 1, 1, 1, 2, 1, 1];
const START = 7;

function Chart() {
  const [hov, setHov] = React.useState(null);
  const [box, bw] = window.TOS.useWidth(760);
  const W = Math.max(300, Math.round(bw)), nar = W < 520, H = nar ? 260 : 300, L = nar ? 40 : 52, R = nar ? 36 : 56, T = 28, B = 40, cw = (W - L - R) / WEEKS.length;
  const x = (i) => L + cw * i + cw / 2;
  const ySG = (v) => T + (0 - v) / 2 * (H - T - B);
  const ySl = (v) => H - B - v / 120 * (H - T - B);
  const pts = SG.map((v, i) => [x(i), ySG(v)]);
  const path = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
  const ink = "var(--text-primary)";
  return (
    <div ref={box} style={{ position: "relative" }}>
      <svg viewBox={"0 0 " + W + " " + H} style={{ width: "100%", height: "auto", display: "block", fontFamily: "var(--font-mono)" }} onMouseLeave={() => setHov(null)}>
        <rect x={L + cw * START} y={T - 12} width={cw * (WEEKS.length - START)} height={H - T - B + 12} fill="var(--axis-tek-soft)" />
        <text x={L + cw * START + 8} y={T + 2} fontSize="11" fill="var(--axis-tek-fg)" fontWeight="600">{nar ? "P3 · LH" : "TRENINGSBLOKK · P3 · LAV HASTIGHET"}</text>
        {[0, -0.5, -1, -1.5, -2].map((v) => <g key={v}><line x1={L} x2={W - R} y1={ySG(v)} y2={ySG(v)} stroke="var(--border-hairline)" strokeDasharray={v === 0 ? "" : "2 4"} /><text x={L - 10} y={ySG(v) + 4} fontSize="11" textAnchor="end" fill="var(--text-muted)">{sgf(v)}</text></g>)}
        {[0, 60, 120].map((v) => <text key={v} x={W - R + 10} y={ySl(v) + 4} fontSize="11" fill="var(--text-faint)">{v}</text>)}
        {SLAG.map((v, i) => v > 0 && <rect key={i} x={x(i) - cw * .28} y={ySl(v)} width={cw * .56} height={H - B - ySl(v)} rx="2" fill="var(--axis-tek)" opacity={hov === i ? .9 : .55} />)}
        <path d={path} fill="none" stroke={ink} strokeWidth="2.5" strokeLinejoin="round" />
        {pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r={i === pts.length - 1 ? 6 : hov === i ? 5 : 3.5} fill={i === pts.length - 1 ? "var(--ok)" : "var(--surface-card)"} stroke={i === pts.length - 1 ? "var(--surface-card)" : ink} strokeWidth="2" />)}
        <text x={pts[0][0]} y={pts[0][1] - 12} fontSize="12" fontWeight="600" textAnchor="middle" fill={ink}>{sgf(SG[0])}</text>
        <text x={pts[11][0] - 10} y={pts[11][1] - 14} fontSize="14" fontWeight="600" textAnchor="end" fill="var(--ok)">{sgf(SG[11])}</text>
        {WEEKS.map((w, i) => (cw >= 30 || i % 2 === 1) && <text key={w} x={x(i)} y={H - B + 20} fontSize="11" textAnchor="middle" fill={hov === i ? ink : "var(--text-muted)"}>{"U" + w}</text>)}
        {WEEKS.map((w, i) => <rect key={"h" + i} x={L + cw * i} y={T - 12} width={cw} height={H - T - B + 12} fill="transparent" onMouseEnter={() => setHov(i)} />)}
      </svg>
      {hov != null && <div style={{ position: "absolute", left: (x(hov) / W * 100) + "%", top: 0, transform: "translate(" + (hov > 8 ? "-104%" : "8%") + ",0)", background: "var(--surface-inverse)", color: "var(--text-inverse)", borderRadius: 8, padding: "12px 12px", pointerEvents: "none", font: "var(--type-num-s)", display: "flex", flexDirection: "column", gap: 4, whiteSpace: "nowrap" }}>
        <span style={{ font: "var(--type-kicker)", letterSpacing: "var(--tracking-kicker)", color: "var(--sand-400)" }}>UKE {WEEKS[hov]}</span>
        <span>SG APP {sgf(SG[hov])}</span><span>{SLAG[hov]} slag P3 · LH</span><span>{ROUNDS[hov]} {ROUNDS[hov] === 1 ? "runde" : "runder"}</span>
      </div>}
    </div>
  );
}

function Loop({ kicker, value, unit, sub, tone }) {
  return (
    <div style={{ flex: "1 1 180px", display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
      <span className="kicker">{kicker}</span>
      <span style={{ font: "var(--type-metric)", color: tone || "var(--text-primary)" }}>{value}<span style={{ font: "var(--type-num-s)", color: "var(--text-muted)", marginLeft: 8 }}>{unit}</span></span>
      <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{sub}</span>
    </div>
  );
}
const Arrow = () => <div style={{ alignSelf: "center", color: "var(--text-faint)", flex: "none" }}><Icon name="arrow-right" size={20} /></div>;

function AnalyseScreen() {
  const [tab, setTab] = React.useState("30");
  const cats = [["OTT", "Utslag", -0.4, -0.3], ["APP", "Innspill", -1.8, -0.6], ["ARG", "Nærspill", -0.3, -0.4], ["PUTT", "Putting", 0.2, 0.3]];
  return (
    <div style={pageWrap}>
      <PageHead kicker="Treningsanalyse · Emma Solberg" title="Lukk sløyfen: planlagt, gjennomført, resultat" actions={<Tabs tabs={[{ value: "30", label: "30 dager" }, { value: "90", label: "90 dager" }, { value: "ar", label: "Sesong" }]} value={tab} onChange={setTab} />} />

      <Panel pad={28} style={{ gap: 24 }}>
        <p style={{ margin: 0, font: "500 clamp(22px,2.4vw,30px)/1.25 var(--font-sans)", letterSpacing: "-.01em", color: "var(--text-primary)", maxWidth: 900, textWrap: "balance" }}>
          Du har trent <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600 }}>450 slag</span> på <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600 }}>P3</span> i lav hastighet siste 30 dager. Strokes Gained Innspill har gått fra <span style={{ fontFamily: "var(--font-mono)" }}>−1,8</span> til <span style={{ fontFamily: "var(--font-mono)", color: "var(--ok)", fontWeight: 600 }}>−0,6</span>.
        </p>
        <div style={{ display: "flex", gap: 24, flexWrap: "wrap", font: "var(--type-meta)", color: "var(--text-muted)" }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><span style={{ width: 18, height: 2.5, background: "var(--text-primary)" }}></span>SG APP PER RUNDE (VENSTRE AKSE)</span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><span style={{ width: 10, height: 10, borderRadius: 2, background: "var(--axis-tek)", opacity: .6 }}></span>SLAG P3 · LAV HASTIGHET PER UKE (HØYRE AKSE)</span>
        </div>
        <Chart />
      </Panel>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,360px),1fr))", gap: 24 }}>
        <Panel kicker="Sløyfen" title="Fra plan til slaggevinst">
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            <Loop kicker="Planlagt" value="480" unit="slag" sub="16 økter · TEK" />
            <Arrow />
            <Loop kicker="Gjennomført" value="450" unit="slag" sub="15 økter · 94 %" />
            <Arrow />
            <Loop kicker="Resultat" value="+1,2" unit="SG APP" sub="per runde · 6 runder" tone="var(--ok)" />
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "flex-start", padding: "12px 16px", borderRadius: 8, background: "var(--surface-sunken)", font: "var(--type-body-s)", color: "var(--text-body)" }}>
            <Icon name="sparkles" size={16} style={{ marginTop: 4, flex: "none" }} />
            <span><b style={{ fontWeight: 600 }}>Caddie:</b> Gevinsten startet uke 36, to uker etter at P3-blokken begynte. Neste steg er å flytte øvelsen til Automatikk med Observert press.</span>
          </div>
        </Panel>

        <Panel kicker="Strokes Gained" title="Kategori for kategori" action={<span style={{ font: "var(--type-meta)", color: "var(--text-muted)", whiteSpace: "nowrap" }}>11 RUNDER</span>}>
          <div style={{ display: "flex", flexDirection: "column" }}>
            {cats.map(([c, n, a, b], i) => {
              const d = b - a, hl = c === "APP";
              return (
                <div key={c} style={{ display: "grid", gridTemplateColumns: "48px minmax(0,1fr) 56px 56px 60px", gap: 8, alignItems: "center", padding: "12px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}>
                  <span style={{ font: "600 13px/1 var(--font-mono)", color: "var(--text-primary)" }}>{c}</span>
                  <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", minWidth: 0 }}>{n}</span>
                  <span style={{ font: "var(--type-num-s)", color: "var(--text-muted)", textAlign: "right" }}>{sgf(a)}</span>
                  <span style={{ font: "var(--type-num-s)", color: "var(--text-primary)", textAlign: "right" }}>{sgf(b)}</span>
                  <span style={{ font: "600 13px/1 var(--font-mono)", textAlign: "right", color: hl ? "var(--ok)" : Math.abs(d) < .15 ? "var(--text-muted)" : d > 0 ? "var(--ok)" : "var(--warn)" }}>{sgf(d)}</span>
                </div>
              );
            })}
            <div style={{ display: "grid", gridTemplateColumns: "48px minmax(0,1fr) 56px 56px 60px", gap: 8, font: "var(--type-meta)", color: "var(--text-faint)", paddingTop: 4 }}><span></span><span></span><span style={{ textAlign: "right" }}>UKE 28</span><span style={{ textAlign: "right" }}>NÅ</span><span style={{ textAlign: "right" }}>ENDRING</span></div>
          </div>
        </Panel>
      </div>
    </div>
  );
}
window.AnalyseScreen = AnalyseScreen;
})();
