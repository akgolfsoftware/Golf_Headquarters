(() => {
const { Button, Stepper, Icon, Avatar, StatusPill } = window.AKGolfPrecisionAthletics_7d7c29;
const { PageHead, pageWrap } = window.TOS;
const DIST = 100, N = 10;
const d1 = (v) => v.toFixed(1).replace(".", ",");
const pei = (m) => m / DIST * 100;
const pts = (p) => p <= 3 ? 5 : p <= 5 ? 4 : p <= 8 ? 3 : p <= 12 ? 2 : p <= 20 ? 1 : 0;
const SCALE = [["≤ 3 %", 5], ["≤ 5 %", 4], ["≤ 8 %", 3], ["≤ 12 %", 2], ["≤ 20 %", 1], ["> 20 %", 0]];
const WIT = [["Anders Kristiansen", "Hovedcoach"], ["Jonas Berg", "Treningspartner"]];
const card = { background: "var(--surface-card)", border: "1px solid var(--border-hairline)", borderRadius: 8, padding: 20, display: "flex", flexDirection: "column", gap: 16, minWidth: 0 };

function Hold({ onDone }) {
  const [p, setP] = React.useState(0), t = React.useRef(null);
  const start = () => { const t0 = performance.now(); const tick = () => { const v = Math.min(1, (performance.now() - t0) / 1400); setP(v); if (v < 1) t.current = requestAnimationFrame(tick); else onDone(); }; t.current = requestAnimationFrame(tick); };
  const stop = () => { cancelAnimationFrame(t.current); if (p < 1) setP(0); };
  return (
    <button type="button" onPointerDown={start} onPointerUp={stop} onPointerLeave={stop} style={{ position: "relative", height: 64, borderRadius: 8, border: "none", background: "var(--primary)", color: "var(--text-on-primary)", font: "600 16px/1 var(--font-sans)", cursor: "pointer", overflow: "hidden", touchAction: "none", userSelect: "none" }}>
      <span style={{ position: "absolute", inset: 0, width: p * 100 + "%", background: "var(--ok)", opacity: .9 }}></span>
      <span style={{ position: "relative", display: "inline-flex", alignItems: "center", gap: 8 }}><Icon name="fingerprint" size={22} />{p > 0 ? "Hold …" : "Hold for å attestere"}</span>
    </button>
  );
}

function TestScreen() {
  const [shots, setShots] = React.useState([2.1, 4.8, 3.2, 1.4, 6.5, 2.9, 3.8]);
  const [cur, setCur] = React.useState(3.0);
  const [wit, setWit] = React.useState(0);
  const [att, setAtt] = React.useState("none");
  const done = shots.length >= N, locked = att === "ok";
  const total = shots.reduce((a, m) => a + pts(pei(m)), 0), avgPei = shots.length ? shots.reduce((a, m) => a + pei(m), 0) / shots.length : 0;
  const add = () => { if (!done) { setShots((s) => [...s, cur]); setCur(3.0); } };
  return (
    <div data-theme="night" style={{ minHeight: "100%", background: "var(--surface-page)", color: "var(--text-body)" }}>
      <div style={pageWrap}>
        <PageHead kicker="Ferdighetstest · CANON v3.5 · Test 04" title="Innspill ca. 100 m · 10 slag" sub="PEI = avstand til hull i prosent av slaglengden. Lavere er bedre." actions={<StatusPill tone={locked ? "ok" : done ? "warn" : "info"}>{locked ? "Attestert" : done ? "Venter på attestering" : "Pågår"}</StatusPill>} />
        <div style={{ display: "flex", flexWrap: "wrap", gap: 24, alignItems: "flex-start" }}>
          <section style={{ ...card, flex: "1 1 340px" }}>
            {!done ? <>
              <div style={{ display: "flex", alignItems: "baseline", gap: 12 }}><span className="kicker" style={{ flex: 1 }}>Slag {shots.length + 1} av {N}</span><span style={{ font: "var(--type-num-s)", color: "var(--text-muted)" }}>AVSTAND {DIST} M</span></div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 16, flexWrap: "wrap" }}>
                <span style={{ font: "var(--type-clock)", color: "var(--text-primary)" }}>{d1(cur)}<span style={{ font: "var(--type-metric)", color: "var(--text-muted)" }}> m</span></span>
                <span style={{ font: "600 21px/1 var(--font-mono)", color: "var(--text-secondary)" }}>PEI {d1(pei(cur))} % · {pts(pei(cur))} p</span>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(6,minmax(0,1fr))", gap: 8 }}>{[1, 2, 3, 5, 8, 12].map((v) => <button key={v} type="button" onClick={() => setCur(v)} style={{ height: 56, borderRadius: 8, border: "1px solid " + (cur === v ? "var(--primary)" : "var(--border-strong)"), background: cur === v ? "var(--primary)" : "transparent", color: cur === v ? "var(--text-on-primary)" : "var(--text-primary)", font: "600 17px/1 var(--font-mono)", cursor: "pointer" }}>{v}</button>)}</div>
              <Stepper size="md" label="Finjuster" value={cur} onChange={setCur} step={0.5} min={0} max={40} unit="m" format={d1} />
              <Button size="xl" fullWidth onClick={add} icon="check">Registrer slag {shots.length + 1}</Button>
            </> : <>
              <span className="kicker">Resultat</span>
              <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}><span style={{ font: "var(--type-clock)", color: "var(--text-primary)" }}>{total}</span><span style={{ font: "var(--type-metric)", color: "var(--text-muted)" }}>/ 50 p</span></div>
              <div style={{ display: "flex", gap: 24, flexWrap: "wrap", font: "var(--type-num)", color: "var(--text-secondary)" }}><span>PEI snitt {d1(avgPei)} %</span><span>Norm Kategori D: 34 p</span></div>
            </>}
            <div style={{ display: "flex", flexDirection: "column" }}>
              {Array.from({ length: N }, (_, i) => { const m = shots[i], has = m != null, p = has ? pei(m) : null; return (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) 64px 64px 36px", gap: 8, alignItems: "center", padding: "8px 0", borderTop: "1px solid var(--border-hairline)", opacity: has ? 1 : .4 }}>
                  <span style={{ font: "var(--type-num-s)", color: "var(--text-faint)" }}>{String(i + 1).padStart(2, "0")}</span>
                  <div style={{ height: 4, background: "var(--surface-hover)", borderRadius: 999 }}>{has && <div style={{ height: "100%", width: Math.min(100, p / 20 * 100) + "%", background: "var(--text-primary)", borderRadius: 999 }}></div>}</div>
                  <span style={{ font: "var(--type-num-s)", textAlign: "right", color: "var(--text-primary)" }}>{has ? d1(m) + " m" : "—"}</span>
                  <span style={{ font: "var(--type-num-s)", textAlign: "right", color: "var(--text-secondary)" }}>{has ? d1(p) + " %" : ""}</span>
                  <span style={{ font: "600 13px/1 var(--font-mono)", textAlign: "right", color: "var(--text-primary)" }}>{has ? pts(p) + "p" : ""}</span>
                </div>); })}
            </div>
            {!locked && shots.length > 0 && <button type="button" onClick={() => { setShots((s) => s.slice(0, -1)); setAtt("none"); }} style={{ alignSelf: "flex-start", border: "none", background: "none", color: "var(--text-secondary)", font: "var(--type-button)", cursor: "pointer", display: "inline-flex", gap: 8, alignItems: "center", padding: 0, minHeight: 44 }}><Icon name="undo-2" size={16} />Angre siste slag</button>}
          </section>

          <div style={{ flex: "1 1 300px", display: "flex", flexDirection: "column", gap: 24 }}>
            <section style={card}>
              <div style={{ display: "flex", alignItems: "baseline" }}><span className="kicker" style={{ flex: 1 }}>Poengskala</span><span style={{ font: "var(--type-num-s)", color: "var(--text-primary)" }}>{total} p · {d1(avgPei)} %</span></div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(6,minmax(0,1fr))", gap: 4 }}>{SCALE.map(([l, p]) => { const c = shots.filter((m) => pts(pei(m)) === p).length; return <div key={p} style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "center", padding: "12px 0", borderRadius: 8, background: "var(--surface-sunken)" }}><span style={{ font: "600 17px/1 var(--font-mono)", color: "var(--text-primary)" }}>{p}p</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{l}</span><span style={{ font: "var(--type-num-s)", color: c ? "var(--text-primary)" : "var(--text-faint)" }}>× {c}</span></div>; })}</div>
            </section>
            <section style={card}>
              <span className="kicker">Vitne-attestering</span>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>{WIT.map(([n, r], i) => <button key={n} type="button" disabled={locked} onClick={() => setWit(i)} style={{ display: "flex", alignItems: "center", gap: 12, padding: 12, borderRadius: 8, border: "1px solid " + (wit === i ? "var(--border-ink)" : "var(--border-hairline)"), background: wit === i ? "var(--surface-hover)" : "transparent", cursor: locked ? "default" : "pointer", textAlign: "left" }}><Avatar name={n} size={36} /><span style={{ flex: 1 }}><span style={{ display: "block", font: "600 15px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{n}</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{r.toUpperCase()}</span></span>{wit === i && <Icon name="check" size={18} />}</button>)}</div>
              {!done && <span style={{ font: "var(--type-body-s)", color: "var(--text-muted)" }}>Attestering åpnes når alle {N} slag er registrert.</span>}
              {done && att === "none" && <><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Gi enheten til {WIT[wit][0].split(" ")[0]}. Vitnet bekrefter at testen er gjennomført etter CANON v3.5.</span><Hold onDone={() => setAtt("ok")} /></>}
              {locked && <div style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: 16, borderRadius: 8, background: "var(--ok-tint)" }}><Icon name="shield-check" size={22} color="var(--ok)" /><div style={{ display: "flex", flexDirection: "column", gap: 4 }}><span style={{ font: "600 15px/1.25 var(--font-sans)", color: "var(--text-primary)" }}>Attestert av {WIT[wit][0]}</span><span style={{ font: "var(--type-meta)", color: "var(--text-secondary)" }}>25.09.2026 16:42 · CANON-3.5 · REF A7F2-04</span><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Resultatet er låst og teller i kategorivurderingen.</span></div></div>}
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
window.TestScreen = TestScreen;
})();
