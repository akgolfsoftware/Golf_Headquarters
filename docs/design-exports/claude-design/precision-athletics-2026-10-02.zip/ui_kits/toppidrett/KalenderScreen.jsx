(() => {
const { Tabs, Icon, InlineAlert, AxisBadge } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap } = window.TOS;
const PER = [["Grunn", 1, 12, "var(--period-grunn)"], ["Spesial", 13, 19, "var(--period-spesial)"], ["Turnering", 20, 35, "var(--period-turnering)"], ["Spesial", 36, 43, "var(--period-spesial)"], ["Evaluering", 44, 46, "var(--period-evaluering)"], ["Grunn", 47, 52, "var(--period-grunn)"]];
const CAMPS = [[6, 7, "Samling Spania"], [15, 15, "Samling Portugal"], [28, 28, "Landslagssamling"], [40, 40, "Høstsamling"]];
const TOURN = [21, 23, 25, 26, 28, 30, 31, 33, 35, 37, 39, 41];
const NOW = 39;
const vol = (w) => { const p = PER.find((x) => w >= x[1] && w <= x[2])[0]; const base = { Grunn: 17, Spesial: 19, Turnering: 13, Evaluering: 8 }[p]; return base + Math.sin(w * 1.7) * 2 + (w % 4 === 0 ? -4 : 0) + (CAMPS.some((c) => w >= c[0] && w <= c[1]) ? 6 : 0); };

function Aarshjul() {
  const [hov, setHov] = React.useState(null);
  const [ref, w] = window.TOS.useWidth(1000);
  const weeks = Array.from({ length: 52 }, (_, i) => i + 1), MAX = 26;
  const cols = { display: "grid", gridTemplateColumns: "repeat(52,minmax(0,1fr))", columnGap: w < 600 ? 1 : 2 };
  const ticks = w < 600 ? [1, 13, 26, 39, 52] : weeks.filter((x) => x === 1 || x % 4 === 0);
  const lab = (t) => <div style={{ font: "var(--type-meta)", color: "var(--text-muted)", margin: "16px 0 8px" }}>{t}</div>;
  const perOf = (x) => PER.find((p) => x >= p[1] && x <= p[2])[0];
  return (
    <Panel kicker="Makroplan · Sesong 2026" title="52-ukers årshjul" action={<span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>UKE {NOW} · 836 T PLANLAGT</span>}>
      <div ref={ref} style={{ position: "relative" }} onMouseLeave={() => setHov(null)}>
        <div aria-hidden="true" style={{ position: "absolute", top: 0, bottom: 24, left: "calc(" + ((NOW - 0.5) / 52 * 100) + "% - 1px)", width: 2, background: "var(--signal)", zIndex: 1, pointerEvents: "none" }}><span style={{ position: "absolute", top: 0, left: 6, font: "600 11px/1 var(--font-mono)", color: "var(--signal-ink)" }}>NÅ</span></div>
        {lab("PERIODE")}
        <div style={cols}>{PER.map(([n, a, b, c], i) => <div key={i} title={n + " · uke " + a + "–" + b} style={{ gridColumn: a + " / " + (b + 1), height: 32, borderRadius: 8, background: c, color: "var(--sand-100)", font: "600 12px/32px var(--font-sans)", padding: "0 8px", overflow: "hidden", whiteSpace: "nowrap", textOverflow: "clip", minWidth: 0 }}>{(b - a + 1) * w / 52 > 80 ? n : ""}</div>)}</div>
        {lab("SAMLING")}
        <div style={cols}>{CAMPS.map(([a, b, n]) => <div key={n} title={n} style={{ gridColumn: a + " / " + (b + 1), height: 20, borderRadius: 8, border: "1.5px solid var(--border-ink)", boxSizing: "border-box" }}></div>)}</div>
        {lab("TURNERING")}
        <div style={cols}>{weeks.map((x) => <div key={x} style={{ height: 12, display: "grid", placeItems: "center" }}>{TOURN.includes(x) && <span style={{ width: 8, height: 8, borderRadius: 999, background: "var(--axis-turn)" }}></span>}</div>)}</div>
        {lab("UKEVOLUM · TIMER")}
        <div style={{ ...cols, height: 96, alignItems: "end" }}>{weeks.map((x) => { const v = vol(x); return <div key={x} onMouseEnter={() => setHov(x)} style={{ height: "100%", display: "flex", alignItems: "flex-end", cursor: "default" }}><div style={{ width: "100%", height: v / MAX * 100 + "%", borderRadius: "2px 2px 0 0", background: x < NOW ? "var(--graphite-500)" : "var(--sand-400)", opacity: hov === x ? 1 : .85 }}></div></div>; })}</div>
        <div style={{ ...cols, height: 24, marginTop: 8 }}>{ticks.map((x) => <span key={x} style={{ gridColumn: x === 52 ? "49 / 53" : x + " / span 1", textAlign: x === 52 ? "right" : "left", font: "var(--type-meta)", color: x === NOW ? "var(--text-primary)" : "var(--text-faint)", whiteSpace: "nowrap" }}>{x}</span>)}</div>
      </div>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", alignItems: "center", font: "var(--type-meta)", color: "var(--text-muted)", minHeight: 20 }}>
        {hov ? <span style={{ color: "var(--text-primary)" }}>UKE {hov} · {perOf(hov).toUpperCase()} · {vol(hov).toFixed(1).replace(".", ",")} T{TOURN.includes(hov) ? " · TURNERING" : ""}{CAMPS.filter((c) => hov >= c[0] && hov <= c[1]).map((c) => " · " + c[2].toUpperCase()).join("")}</span>
          : CAMPS.map(([a, b, n]) => <span key={n}>U{a}{b > a ? "–" + b : ""} {n.toUpperCase()}</span>)}
      </div>
    </Panel>
  );
}

function Acwr() {
  const WK = [32, 33, 34, 35, 36, 37, 38, 39];
  const AC = [2100, 2350, 2400, 2500, 2250, 2700, 3000, 3350], CH = [2200, 2300, 2230, 2270, 2300, 2350, 2340, 2360];
  const R = AC.map((a, i) => a / CH[i]);
  const [box, bw] = window.TOS.useWidth(720);
  const W = Math.max(300, Math.round(bw)), H = W < 520 ? 240 : 260, L = 44, Rr = 16, T = 16, B = 32, cw = (W - L - Rr) / WK.length, x = (i) => L + cw * i + cw / 2;
  const y = (r) => T + (1.8 - r) / 1.2 * (H - T - B);
  const cur = R[R.length - 1], risk = cur > 1.3;
  const fmt = (v) => v.toFixed(2).replace(".", ",");
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 24, alignItems: "flex-start" }}>
      <Panel kicker="Belastningsmåler · Emma Solberg" title="ACWR · akutt mot kronisk belastning" style={{ flex: "2 1 400px" }}>
        <div ref={box}><svg viewBox={"0 0 " + W + " " + H} style={{ width: "100%", height: "auto", display: "block" }}>
          <rect x={L} y={y(1.3)} width={W - L - Rr} height={y(0.8) - y(1.3)} fill="var(--ok-tint)" />
          <rect x={L} y={y(1.8)} width={W - L - Rr} height={y(1.5) - y(1.8)} fill="var(--signal-tint)" />
          {[0.6, 0.8, 1.0, 1.3, 1.5, 1.8].map((v) => <g key={v}><line x1={L} x2={W - Rr} y1={y(v)} y2={y(v)} stroke="var(--border-hairline)" strokeDasharray="2 4" /><text x={L - 8} y={y(v) + 4} textAnchor="end" fill="var(--text-muted)" style={{ font: "11px var(--font-mono)" }}>{v.toFixed(1).replace(".", ",")}</text></g>)}
          <text x={W - Rr - 6} y={y(1.3) + 16} textAnchor="end" fill="var(--ok)" style={{ font: "600 11px var(--font-sans)", letterSpacing: ".08em" }}>TRYGG SONE 0,8–1,3</text>
          <text x={W - Rr - 6} y={y(1.8) + 16} textAnchor="end" fill="var(--signal-ink)" style={{ font: "600 11px var(--font-sans)", letterSpacing: ".08em" }}>SKADERISIKO &gt; 1,5</text>
          <path d={R.map((r, i) => (i ? "L" : "M") + x(i) + " " + y(r)).join(" ")} fill="none" stroke="var(--text-primary)" strokeWidth="2.5" strokeLinejoin="round" />
          {R.map((r, i) => <circle key={i} cx={x(i)} cy={y(r)} r={i === R.length - 1 ? 6 : 3.5} fill={i === R.length - 1 ? (risk ? "var(--warn)" : "var(--ok)") : "var(--surface-card)"} stroke="var(--text-primary)" strokeWidth="2" />)}
          <text x={x(R.length - 1) - 10} y={y(cur) - 12} textAnchor="end" fill="var(--text-primary)" style={{ font: "600 14px var(--font-mono)" }}>{fmt(cur)}</text>
          {WK.map((w, i) => <text key={w} x={x(i)} y={H - 10} textAnchor="middle" fill="var(--text-muted)" style={{ font: "11px var(--font-mono)" }}>U{w}</text>)}
        </svg></div>
      </Panel>
      <div style={{ flex: "1 1 280px", display: "flex", flexDirection: "column", gap: 16 }}>
        {risk && <InlineAlert tone="warn" title={"ACWR " + fmt(cur) + " · over trygg sone"}>Akutt belastning har økt 43 % på tre uker. Reduser SLAG-volumet uke 40 med ca. 20 %.</InlineAlert>}
        <Panel pad={20} style={{ gap: 0 }}>
          {[["Akutt (7 dager)", AC[7], "AU"], ["Kronisk (28 dager snitt)", CH[7], "AU"], ["Ratio", fmt(cur), ""], ["Økt-RPE snitt", "6,4", "av 10"]].map(([k, v, u], i) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", padding: "12px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}>
              <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{k}</span>
              <span style={{ font: "600 15px/1 var(--font-mono)", color: "var(--text-primary)" }}>{typeof v === "number" ? v.toLocaleString("nb-NO").replace(/\u00a0/g, " ") : v}<span style={{ font: "var(--type-meta)", color: "var(--text-muted)", marginLeft: 4 }}>{u}</span></span>
            </div>))}
        </Panel>
        <span style={{ font: "var(--type-meta)", color: "var(--text-faint)" }}>AU = ØKT-RPE × MINUTTER</span>
      </div>
    </div>
  );
}

function KalenderScreen() {
  const [tab, setTab] = React.useState(() => localStorage.getItem("tos-kal") || "ar");
  React.useEffect(() => localStorage.setItem("tos-kal", tab), [tab]);
  return (
    <div style={pageWrap}>
      <PageHead kicker="Kalender · AgencyOS" title={{ ar: "Fra makro til mikro", dag: "Stall-dag · fredag 25.09", acwr: "Belastning og skaderisiko" }[tab]} actions={<Tabs tabs={[{ value: "ar", label: "Årshjul" }, { value: "dag", label: "Stall-dag" }, { value: "acwr", label: "Belastning" }]} value={tab} onChange={setTab} />} />
      {tab === "ar" && <Aarshjul />}
      {tab === "dag" && <StallDag />}
      {tab === "acwr" && <Acwr />}
    </div>
  );
}
window.KalenderScreen = KalenderScreen;
})();
