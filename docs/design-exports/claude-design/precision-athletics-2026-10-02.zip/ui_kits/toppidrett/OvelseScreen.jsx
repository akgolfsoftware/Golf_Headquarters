(() => {
const { ChoicePill, Stepper, Button, AxisBadge, Icon } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap } = window.TOS;
const V = window.AK_VOCAB;
const SHOTS = ["Draw", "Fade", "Rett", "Lav flukt", "Høy flukt"];
const PN = ["Adresse / Oppstilling", "Kølle parallell i baksving", "Venstre arm parallell i baksving", "Toppen av baksvingen", "Venstre arm parallell i nedsving", "Kølle parallell i nedsving", "Treffpunktet", "Kølle parallell i gjennomføring", "Høyre arm parallell i oppfølging", "Fullføring og balanse"];
const CUE = ["Vekt på fotballene", "Kølleblad følger hendene", "Bredde i hendene i P3", "Full skulderrotasjon i P4", "Høyre albue inn mot hofta", "Fri venstre hofte i P6", "Hendene foran ballen i treff", "Armene strekker ut mot mål", "Brystet mot mål i P9", "Hold balansen i tre sekunder"];
const DUR = [10, 15, 20, 30, 45];
const short = (a) => a.replace("Innspill ca. ", "Innspill ").replace(" m", " m");
const code = (s) => s.toUpperCase().replace(/CA\. /g, "").replace(/ M$/, "").replace(/[\s–]+/g, "");

function Row({ n, label, hint, children, off }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "36px minmax(0,1fr)", gap: 12, padding: "16px 0", borderTop: n === 1 ? "none" : "1px solid var(--border-hairline)", opacity: off ? .45 : 1 }}>
      <span style={{ font: "var(--type-num-s)", color: "var(--text-faint)", paddingTop: 1 }}>{String(n).padStart(2, "0")}</span>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "600 14px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{label}</span>{hint && <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{hint}</span>}</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>{children}</div>
      </div>
    </div>
  );
}

function OvelseScreen() {
  const [s, setS] = React.useState({ axis: "tek", area: "Innspill ca. 100 m", motor: "Lav hastighet", shot: "Draw", p: 3, dec: 0, cue: "Bredde i hendene i P3", reps: 30, min: 20 });
  const up = (o) => setS((x) => ({ ...x, ...o }));
  const full = V.AREA_FAMILY[s.area] === "fullsving";
  const pick = (p) => up({ p, cue: s.cue === CUE[s.p - 1] || !s.cue ? CUE[p - 1] : s.cue });
  const pCode = "P" + s.p + "." + s.dec;
  const rate = (s.reps / s.min).toFixed(1).replace(".", ",");
  const formula = [s.axis.toUpperCase(), code(s.area), full ? V.MOTOR_CODE[s.motor] : null, "TRENINGSOMRÅDE", "ALENE"].filter(Boolean).join("_");
  const dna = [["Hva", short(s.area)], ["Hastighet", full ? s.motor : "—"], ["Slagtype", s.shot], ["P-posisjon", full ? pCode : "—"], ["Sving-cue", "«" + (s.cue || "…") + "»"], ["Repetisjoner", s.reps + " slag"], ["Varighet", s.min + " min"]];
  return (
    <div style={pageWrap}>
      <PageHead kicker="Workbench · Emma Solberg · Uke 39" title="Øvelses-DNA" sub="Sju elementer. Samme struktur i Workbench, i økt-briefen og i analysen, slik at hver repetisjon kan spores til et resultat."
        actions={<><Button variant="secondary" icon="copy">Dupliser</Button><Button icon="plus">Legg til i økt</Button></>} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,340px),1fr))", gap: 24, alignItems: "start" }}>
        <Panel kicker="Øvelse 2 av 4 · Tirsdag 29.09" title="Sett opp øvelsen" action={<div style={{ display: "flex", gap: 8 }}>{["tek", "slag"].map((a) => <ChoicePill key={a} axis={a} selected={s.axis === a} onClick={() => up({ axis: a })}>{a.toUpperCase()}</ChoicePill>)}</div>}>
          <div>
            <Row n={1} label="Hva" hint="TRENINGSOMRÅDE">
              {[...V.AREAS.fullsving, ...V.AREAS.naerspill].map((a) => <ChoicePill key={a} selected={s.area === a} onClick={() => up({ area: a })}>{short(a)}</ChoicePill>)}
            </Row>
            <Row n={2} label="Hastighet" hint={full ? "MOTORISK STADIE" : "KUN FULLSVING"} off={!full}>
              {V.MOTORIKK.map((m) => <ChoicePill key={m} disabled={!full} selected={full && s.motor === m} onClick={() => up({ motor: m })}>{m}</ChoicePill>)}
            </Row>
            <Row n={3} label="Slagtype">
              {SHOTS.map((m) => <ChoicePill key={m} selected={s.shot === m} onClick={() => up({ shot: m })}>{m}</ChoicePill>)}
            </Row>
            <Row n={4} label="P-posisjon" hint={full ? pCode + " · " + PN[s.p - 1].toUpperCase() : "KUN FULLSVING"} off={!full}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(52px,1fr))", gap: 8, width: "100%" }}>
                {PN.map((_, i) => <ChoicePill key={i} mono disabled={!full} selected={full && s.p === i + 1} onClick={() => pick(i + 1)} style={{ padding: 0, minWidth: 0 }}>{"P" + (i + 1)}</ChoicePill>)}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ font: "var(--type-meta)", color: "var(--text-muted)", marginRight: 4 }}>FINJUSTERING</span>
                {[0, 5].map((d) => <ChoicePill key={d} mono disabled={!full} selected={s.dec === d} onClick={() => up({ dec: d })}>{"." + d}</ChoicePill>)}
              </div>
            </Row>
            <Row n={5} label="Sving-cue" hint="ETT STIKKORD · MAKS 40 TEGN">
              <div style={{ position: "relative", width: "100%" }}>
                <input value={s.cue} maxLength={40} onChange={(e) => up({ cue: e.target.value })} placeholder="Ett presist fokus" style={{ width: "100%", boxSizing: "border-box", height: 48, padding: "0 64px 0 16px", borderRadius: 8, border: "1px solid var(--border-control)", background: "var(--surface-card)", font: "500 16px/1 var(--font-sans)", color: "var(--text-primary)", outline: "none" }} />
                <span style={{ position: "absolute", right: 14, top: 16, font: "var(--type-meta)", color: "var(--text-faint)" }}>{s.cue.length}/40</span>
              </div>
              {[CUE[s.p - 1], "Fri venstre hofte i P6", "Hendene foran ballen i treff"].filter((c, i, a) => a.indexOf(c) === i && c !== s.cue).map((c) => <button key={c} type="button" onClick={() => up({ cue: c })} style={{ border: "1px dashed var(--border-strong)", background: "transparent", borderRadius: 999, height: "var(--tap)", padding: "0 12px", font: "400 13px/1 var(--font-sans)", color: "var(--text-secondary)", cursor: "pointer" }}>{c}</button>)}
            </Row>
            <Row n={6} label="Repetisjoner" hint="ANTALL SLAG">
              <Stepper value={s.reps} onChange={(v) => up({ reps: v })} step={5} min={5} max={300} unit="slag" />
            </Row>
            <Row n={7} label="Varighet" hint={"≈ " + rate + " SLAG/MIN"}>
              {DUR.map((d) => <ChoicePill key={d} mono selected={s.min === d} onClick={() => up({ min: d })}>{d + " min"}</ChoicePill>)}
            </Row>
          </div>
        </Panel>

        <div style={{ display: "flex", flexDirection: "column", gap: 16, position: "sticky", top: 24 }}>
          <Panel pad={0} style={{ overflow: "hidden", gap: 0 }}>
            <div style={{ padding: "24px 24px 20px", display: "flex", flexDirection: "column", gap: 16, boxShadow: "inset 0 3px 0 var(--axis-" + s.axis + ")" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}><AxisBadge axis={s.axis}>{s.axis.toUpperCase()}</AxisBadge><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>SLIK SER SPILLEREN ØVELSEN</span></div>
              <div style={{ font: "var(--type-title-m)", color: "var(--text-primary)" }}>{short(s.area)}{full && <span style={{ color: "var(--text-muted)", fontWeight: 400 }}>{" · " + s.motor}</span>}</div>
              <blockquote style={{ margin: 0, font: "600 26px/1.15 var(--font-sans)", letterSpacing: "-.01em", color: "var(--text-primary)", textWrap: "balance" }}>«{s.cue || "Ett presist fokus"}»</blockquote>
            </div>
            <dl style={{ margin: 0, display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(130px,1fr))", borderTop: "1px solid var(--border-hairline)" }}>
              {dna.map(([k, v], i) => (
                <div key={k} style={{ padding: "16px 16px", borderRight: "1px solid var(--border-hairline)", borderBottom: "1px solid var(--border-hairline)", marginRight: -1, marginBottom: -1, minWidth: 0 }}>
                  <dt style={{ display: "flex", gap: 8, font: "var(--type-meta)", color: "var(--text-muted)" }}><span style={{ color: "var(--text-faint)" }}>{String(i + 1).padStart(2, "0")}</span>{k.toUpperCase()}</dt>
                  <dd style={{ margin: "6px 0 0", font: i === 3 || i >= 5 ? "var(--type-num)" : "500 15px/1.25 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{v}</dd>
                </div>
              ))}
            </dl>
            {full && <div style={{ padding: "16px 24px 8px" }}>
              <div style={{ position: "relative", height: 34 }}>
                <div style={{ position: "absolute", left: 0, right: 0, top: 10, height: 2, background: "var(--border-hairline)" }}></div>
                {PN.map((_, i) => { const on = s.p === i + 1; return <div key={i} style={{ position: "absolute", left: (i / 9 * 100) + "%", top: on ? 3 : 7, width: on ? 16 : 8, height: on ? 16 : 8, marginLeft: on ? -8 : -4, borderRadius: 999, background: on ? "var(--axis-" + s.axis + ")" : "var(--surface-card)", border: on ? "none" : "2px solid var(--border-strong)", boxSizing: "border-box", transition: "left 200ms var(--ease-out), width 200ms var(--ease-out), top 200ms var(--ease-out), opacity 200ms var(--ease-out)" }}></div>; })}
                <div style={{ position: "absolute", top: 24, left: 0, right: 0, display: "flex", justifyContent: "space-between", font: "var(--type-meta)", color: "var(--text-faint)" }}><span>P1 ADRESSE</span><span>P7 TREFF</span><span>P10</span></div>
              </div>
            </div>}
            <div style={{ padding: "16px 24px", display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap", background: "var(--surface-sunken)", marginTop: 12 }}>
              <code style={{ font: "var(--type-meta)", color: "var(--text-secondary)", flex: 1, minWidth: 0, overflowWrap: "anywhere" }}>{formula}</code>
              <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>TRENINGSOMRÅDE · ALENE</span>
            </div>
          </Panel>

          <Panel kicker="I økt-briefen" pad={20} style={{ gap: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "12px 16px", borderRadius: 8, background: "var(--surface-flat)", boxShadow: "inset 3px 0 0 var(--axis-" + s.axis + ")" }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ font: "600 15px/1.25 var(--font-sans)", color: "var(--text-primary)" }}>{[short(s.area), full ? V.MOTOR_CODE[s.motor] : null, s.shot, full ? pCode : null].filter(Boolean).join(" · ")}</div>
                <div style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", marginTop: 4 }}>«{s.cue}»</div>
              </div>
              <span style={{ font: "var(--type-num-s)", color: "var(--text-primary)", whiteSpace: "nowrap" }}>{s.reps} slag · {s.min} min</span>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
window.OvelseScreen = OvelseScreen;
})();
