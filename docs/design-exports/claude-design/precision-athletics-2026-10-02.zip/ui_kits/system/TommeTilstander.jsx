(() => {
const { Button, Icon, EmptyState } = window.AKGolfPrecisionAthletics_7d7c29;
const { PageHead, pageWrap, Panel, Grid } = window.KIT;

function TommeTilstander() {
  const [made, setMade] = React.useState(false);
  return (
    <div style={pageWrap}>
      <PageHead kicker="Systemtilstand · Tomme lister" title="Når det ikke finnes noe ennå" sub="Én setning om hvorfor listen er tom, og én knapp for neste logiske handling. Aldri illustrasjoner." />
      <Grid min={300}>
        <Panel kicker="Kalender · Uke 40" title="Planlagte økter">
          {made ? <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: 16, border: "1px solid var(--border-hairline)", borderRadius: 8 }}><span style={{ font: "var(--type-num-s)", color: "var(--text-primary)" }}>MAN 28.09 · 16:30</span><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>Ny økt · uten innhold</span><div><Button variant="ghost" size="sm" onClick={() => setMade(false)}>Angre</Button></div></div>
            : <EmptyState icon="calendar-range" title="Ingen planlagte økter denne uken" text="Legg inn første økt, eller kopier forrige ukes plan." action="Opprett første økt" onAction={() => setMade(true)} secondary="Kopier uke 39" />}
        </Panel>
        <Panel kicker="Tester" title="Ferdighetstester">
          <EmptyState icon="clipboard-check" title="Ingen tester utført ennå" text="Baseline-testen tar 45 minutter og gir kategorien din." action="Start baseline-test" actionIcon="play" />
        </Panel>
        <Panel kicker="Økonomi" title="Fakturaer">
          <EmptyState icon="receipt" title="Ingen fakturaer" text="Fakturaer og kvitteringer vises her når du har betalt for første gang." action="Se medlemskap" actionIcon="arrow-right" />
        </Panel>
      </Grid>
    </div>
  );
}
window.EmptyState = EmptyState;
window.TommeTilstander = TommeTilstander;
})();
