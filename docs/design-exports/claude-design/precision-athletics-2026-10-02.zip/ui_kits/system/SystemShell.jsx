(() => {
const { KitShell, G } = window.KIT;
const NAV = [
  G("tilstand", "Systemtilstander", "triangle-alert", [["offline", "Offline-banner", "wifi-off"], ["feil", "Feilside 404/500", "circle-alert"], ["tomme", "Tomme tilstander", "inbox"]]),
];
function SystemShell() {
  return <KitShell nav={NAV} store="sys-page" fallback="offline" who={{ name: "Emma Solberg", role: "SPILLER · KATEGORI D" }} screens={{ offline: OfflineScreen, feil: Feilside, tomme: TommeTilstander }} />;
}
window.SystemShell = SystemShell;
})();
