(() => {
const KINDS = {
  offline: { icon: "wifi-off", k: "Offline", t: "Du er uten nett", s: "Det du registrerer nå lagres på enheten og sendes når nettet er tilbake. Ingenting går tapt.", code: "OFFLINE · 3 ENDRINGER VENTER", act: "Prøv igjen", meta: "SIST SYNKET 26.09 15:12" },
  vedlikehold: { icon: "wrench", k: "Vedlikehold", t: "AK Golf HQ oppdateres", s: "Vi er tilbake kl. 06:00. Planer, bookinger og resultater er lagret. Live-økter som pågår fortsetter på enheten.", code: "VEDLIKEHOLD · 27.09 04:00–06:00", act: "Sjekk status", meta: "PLANLAGT · VARSLET 20.09" },
  404: { icon: "map-pin-off", k: "404", t: "Siden finnes ikke", s: "Lenken kan være feil eller utløpt. Gå til forsiden, eller søk etter det du leter etter.", code: "FEIL 404 · /portal/okt/ukjent", act: "Til forsiden", meta: "—" },
  500: { icon: "server-crash", k: "500", t: "Noe gikk galt hos oss", s: "Feilen er registrert. Prøv igjen om litt. Hvis det skjer igjen, send feilkoden til support.", code: "FEIL 500 · REF 7F3A-26", act: "Prøv igjen", meta: "LOGGET 26.09 15:40" },
};
function SY01({ state }) {
  const { Button, Segmented, LoadingState, Icon } = window.AGQ.ns(), A = window.AGQ, { mob } = A.useW();
  const [kind, setKind] = React.useState("offline"), K = KINDS[state === "feil" ? 500 : state === "tom" ? 404 : kind];
  return <div style={{ minHeight: "100%", display: "flex", flexDirection: "column", alignItems: "center", padding: mob ? "24px 16px 40px" : "48px 24px", boxSizing: "border-box", gap: 24 }}>
    <div style={{ width: "100%", maxWidth: 560, display: "flex", flexDirection: "column", gap: 20 }}>
      <img src="../../assets/logo-ak-golf-hq.svg" alt="AK Golf HQ" style={{ height: 22, alignSelf: "flex-start" }} />
      {state === "data" && <div style={{ maxWidth: "100%" }}><Segmented options={["Offline", "Vedlikehold", "404", "500"]} value={KINDS[kind].k} onChange={(v) => setKind(Object.keys(KINDS).find((x) => KINDS[x].k === v))} /></div>}
      {state === "laster" ? <LoadingState text="Prøver å koble til igjen …" /> : <div className="pa-card" style={{ padding: mob ? 20 : 28, gap: 14 }}>
        <span style={{ width: 48, height: 48, borderRadius: 8, display: "grid", placeItems: "center", background: "var(--surface-sunken)", color: "var(--text-primary)" }}><Icon name={K.icon} size={24} /></span>
        <span className="kicker">{K.k}</span>
        <h1 style={{ margin: 0, font: "600 26px/1.2 var(--font-sans)", textWrap: "balance" }}>{K.t}</h1>
        <p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-secondary)", textWrap: "pretty" }}>{K.s}</p>
        <div style={{ padding: "10px 12px", borderRadius: 6, background: "var(--surface-flat)", border: "1px solid var(--border-hairline)", font: "500 13px/1.3 var(--font-mono)", overflowWrap: "anywhere" }}>{K.code}</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button icon={K.k === "404" ? "house" : "rotate-ccw"} onClick={() => A.toast(K.act, K.code)}>{K.act}</Button>{(K.k === "404" || K.k === "500") && <Button variant="ghost" icon="copy" onClick={() => A.toast("Feilkoden er kopiert", K.code)}>Kopier feilkode</Button>}</div>
        <A.Meta>{K.meta}</A.Meta>
      </div>}
    </div>
  </div>;
}
window.FO_SCREENS = window.FO_SCREENS || {};
window.FO_SCREENS["SY-01"] = { id: "SY-01", name: "Systemtilstander", route: "/offline, /vedlikehold, /404, /500", bare: true, Component: SY01 };
})();
