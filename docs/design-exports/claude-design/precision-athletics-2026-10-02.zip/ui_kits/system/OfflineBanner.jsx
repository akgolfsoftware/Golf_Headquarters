(() => {
const { Button, Icon, Segmented, StatusPill } = window.AKGolfPrecisionAthletics_7d7c29;
const { PageHead, pageWrap, Panel, Mono, useW } = window.KIT;

function OfflineBanner({ state = "offline", shots = 14, tests = 2, onRetry }) {
  const off = state === "offline", sync = state === "sync";
  return (
    <div role="status" aria-live="polite" style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap", padding: "12px 16px", minHeight: 56, boxSizing: "border-box", background: off ? "var(--surface-inverse)" : sync ? "var(--info-tint)" : "var(--ok-tint)", color: off ? "var(--text-inverse)" : "var(--text-primary)", borderRadius: 8 }}>
      <span style={{ width: 32, height: 32, borderRadius: 999, flexShrink: 0, display: "grid", placeItems: "center", background: off ? "var(--graphite-700)" : "transparent", color: off ? "var(--sand-100)" : sync ? "var(--info)" : "var(--ok)" }}><Icon name={off ? "wifi-off" : sync ? "refresh-cw" : "check"} size={18} /></span>
      <div style={{ flex: "1 1 220px", minWidth: 0, display: "flex", flexDirection: "column", gap: 2 }}>
        <span style={{ font: "600 14px/1.3 var(--font-sans)" }}>{off ? "Ingen nettforbindelse" : sync ? "Synkroniserer" : "Tilkoblet igjen"}</span>
        <span style={{ font: "400 13px/1.4 var(--font-sans)", color: off ? "var(--sand-300)" : "var(--text-secondary)", textWrap: "pretty" }}>
          {off ? <><Mono s={{ color: "var(--sand-100)" }}>{shots}</Mono> slag og <Mono s={{ color: "var(--sand-100)" }}>{tests}</Mono> tester er trygt lagret lokalt på telefonen. Synkroniseres automatisk når nettet er tilbake.</>
            : sync ? <>Sender <Mono>{shots}</Mono> slag og <Mono>{tests}</Mono> tester…</> : <><Mono>{shots}</Mono> slag og <Mono>{tests}</Mono> tester er synkronisert.</>}
        </span>
      </div>
      {off && onRetry && <button type="button" onClick={onRetry} style={{ height: 44, padding: "0 16px", borderRadius: 8, border: "1px solid var(--graphite-600)", background: "transparent", color: "var(--sand-100)", font: "500 14px/1 var(--font-sans)", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 8 }}><Icon name="refresh-cw" size={16} />Prøv igjen</button>}
    </div>
  );
}

function OfflineScreen() {
  const w = useW();
  const [st, setSt] = React.useState("offline");
  const [n, setN] = React.useState(14);
  const retry = () => { setSt("sync"); setTimeout(() => setSt("online"), 1400); };
  return (
    <div style={pageWrap}>
      <PageHead kicker="Systemtilstand · Offline" title="Tap av nettforbindelse på treningsfeltet" sub="Stripen legger seg øverst i Live-økt og slagregistrering. All registrering fortsetter lokalt."
        actions={<Segmented options={[{ value: "offline", label: "Frakoblet" }, { value: "sync", label: "Synkroniserer" }, { value: "online", label: "Tilkoblet" }]} value={st} onChange={setSt} size="lg" />} />
      <div data-theme="night" style={{ background: "var(--surface-page)", borderRadius: 12, padding: w < 600 ? 12 : 24, display: "flex", flexDirection: "column", gap: 16, maxWidth: 480, width: "100%", boxSizing: "border-box", alignSelf: w < 600 ? "stretch" : "flex-start" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}><span className="kicker" style={{ color: "var(--text-muted)" }}>Live-økt · Range</span><StatusPill tone="live" dot>Live</StatusPill></div>
        <OfflineBanner state={st} shots={n} onRetry={retry} />
        <div style={{ background: "var(--surface-card)", borderRadius: 8, padding: 20, display: "flex", flexDirection: "column", gap: 16 }}>
          <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>INNSPILL 100 M · P3.0 · SLAG {n + 1}</span>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 8 }}>
            {["Kort", "Treff", "Lang"].map((l) => <button key={l} type="button" onClick={() => setN(n + 1)} style={{ height: 64, borderRadius: 8, border: "1px solid var(--border-strong)", background: "var(--surface-flat)", color: "var(--text-primary)", font: "600 16px/1 var(--font-sans)", cursor: "pointer" }}>{l}</button>)}
          </div>
          <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Trykk for å registrere. Telleren i stripen øker.</span>
        </div>
      </div>
      <Panel kicker="Lyst tema" title="Samme stripe i planleggingsflatene"><OfflineBanner state="offline" shots={14} tests={2} onRetry={() => {}} /></Panel>
    </div>
  );
}
window.OfflineBanner = OfflineBanner;
window.OfflineScreen = OfflineScreen;
})();
