(() => {
const { Button, Segmented } = window.AKGolfPrecisionAthletics_7d7c29;
const { useW } = window.KIT;
const COPY = {
  404: { k: "Siden finnes ikke", t: "Vi fant ikke denne siden", s: "Lenken kan være gammel, eller siden er flyttet. Treningsdataene dine er ikke påvirket.", sec: ["Gå tilbake", "arrow-left"] },
  500: { k: "Teknisk feil", t: "Noe gikk galt hos oss", s: "Feilen er registrert og vi ser på den. Det du registrerte før feilen er lagret.", sec: ["Prøv igjen", "refresh-cw"] },
};

function Feilside({ code: c0 }) {
  const w = useW();
  const [code, setCode] = React.useState(c0 || 404);
  const c = COPY[code];
  return (
    <div style={{ minHeight: "100%", display: "flex", flexDirection: "column", boxSizing: "border-box", padding: "var(--page-y) var(--page-x) 24px", gap: 24 }}>
      <div style={{ display: "flex", justifyContent: "flex-end" }}><Segmented options={[{ value: "404", label: "404" }, { value: "500", label: "500" }]} value={String(code)} onChange={(v) => setCode(+v)} /></div>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", maxWidth: 560, width: "100%", margin: "0 auto", gap: 24, paddingBottom: 48 }}>
        <img src="../../assets/ak-golf-logo-ink.svg" alt="" aria-hidden="true" style={{ width: 40, height: 40, objectFit: "contain", opacity: 0.9 }} />
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <span className="kicker">{c.k}</span>
          <h1 style={{ margin: 0, font: "600 clamp(26px,3vw,36px)/1.15 var(--font-sans)", letterSpacing: "var(--tracking-display)", color: "var(--text-primary)", textWrap: "balance" }}>{c.t}</h1>
          <p style={{ margin: 0, font: "400 16px/1.5 var(--font-sans)", color: "var(--text-secondary)", textWrap: "pretty" }}>{c.s}</p>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <Button size="lg" icon="sun">Gå til I dag</Button>
          <Button size="lg" variant="secondary" icon={c.sec[1]} onClick={() => code === 404 && history.back()}>{c.sec[0]}</Button>
        </div>
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "4px 16px", font: "var(--type-meta)", color: "var(--text-muted)" }}>
        <span>FEILKODE {code}</span><span>REF {code === 404 ? "7F3A-21C9" : "E5B0-94D2"}</span><span>25.09.2026 14:32:07</span>{w >= 600 && <span>{code === 404 ? "/plan/uke-52-2025" : "GET /api/okter/uke/39"}</span>}
      </div>
    </div>
  );
}
window.Feilside = Feilside;
})();
