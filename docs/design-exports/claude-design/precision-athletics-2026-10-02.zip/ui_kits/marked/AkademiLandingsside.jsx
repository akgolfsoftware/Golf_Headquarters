(() => {
const { useWidth, WCtx } = window.KIT;
function AkademiLandingsside() {
  const [ref, w] = useWidth(1280);
  React.useEffect(() => { window.__kitSetPage = () => {}; }, []);
  return (
    <WCtx.Provider value={w}>
      <div ref={ref} style={{ height: "100vh", width: "100%", overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <main style={{ flex: 1, minHeight: 0, overflowY: "auto", overflowX: "hidden" }} data-screen-label="forside"><Forside /></main>
      </div>
    </WCtx.Provider>
  );
}
window.AkademiLandingsside = AkademiLandingsside;
})();
