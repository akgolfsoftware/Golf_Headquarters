(() => {
const { Icon } = window.AKGolfPrecisionAthletics_7d7c29;
const { useW } = window.KIT;
const C = { ground: "var(--sand-200)", card: "var(--sand-100)", ink: "var(--graphite-900)", body: "var(--graphite-800)", muted: "var(--graphite-500)", line: "var(--sand-300)", signal: "var(--rust-600)" };
const GRID = `linear-gradient(to right, color-mix(in srgb, var(--graphite-900) 6%, transparent) 1px, transparent 1px) 0 0/56px 56px, linear-gradient(to bottom, color-mix(in srgb, var(--graphite-900) 6%, transparent) 1px, transparent 1px) 0 0/56px 56px, ${C.ground}`;
const PYR = [
  ["turn", "TURN", "Turnering", "Prestasjon når det teller. Planlagte toppformer og evaluering etter hver turnering."],
  ["spill", "SPILL", "Spill", "Banestrategi, beslutninger og scoring under press. Gameplan for hver bane."],
  ["slag", "SLAG", "Slag", "Avstandskontroll og slagvariasjon. Målt med TrackMan og Strokes Gained."],
  ["tek", "TEK", "Teknikk", "Svingen bygges posisjon for posisjon, P1.0–P10.0, med tydelige kontrollpunkter."],
  ["fys", "FYS", "Fysisk", "Styrke, mobilitet og rotasjonskraft. Grunnmuren alt annet står på."],
];
const PLANS = [
  { id: "TALENT", p: "1 490", for: "For spillere som vil bygge et strukturert grunnlag.", f: [["2 økter i uken", true], ["Fellestrening med trener", true], ["Individuell årsplan", true], ["PlayerHQ-appen", true], ["TrackMan-økter", false], ["Testbatteri 4 ganger i året", false], ["Turneringsoppfølging", false]] },
  { id: "FULL", p: "2 890", for: "For spillere som satser mot kategori A–C og toppidrett.", f: [["4 økter i uken", true], ["Fellestrening med trener", true], ["Individuell årsplan", true], ["PlayerHQ-appen", true], ["TrackMan-økter", true], ["Testbatteri 4 ganger i året", true], ["Turneringsoppfølging", true]] },
];
const lbl = { font: "500 13px/1.3 var(--font-sans)", color: C.body };
const inp = { height: 48, boxSizing: "border-box", width: "100%", minWidth: 0, borderRadius: 8, border: "1px solid var(--graphite-400)", background: "var(--white)", padding: "0 14px", font: "400 15px/1 var(--font-sans)", color: C.ink, outline: "none" };
const Field = ({ label, children }) => <label style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}><span style={lbl}>{label}</span>{children}</label>;
const Kick = ({ n, children }) => <div style={{ display: "flex", alignItems: "center", gap: 12, font: "600 11px/1 var(--font-mono)", letterSpacing: ".1em", color: C.muted }}><span style={{ color: C.signal }}>{n}</span><span style={{ width: 24, height: 1, background: C.line }}></span>{children}</div>;
const btn = (primary) => ({ height: 52, padding: "0 24px", borderRadius: 8, border: primary ? "none" : "1px solid " + C.ink, background: primary ? C.ink : "transparent", color: primary ? "var(--white)" : C.ink, font: "600 15px/1 var(--font-sans)", cursor: "pointer", display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8, textDecoration: "none" });

function Forside() {
  const w = useW();
  const pad = w < 600 ? 16 : w <= 1024 ? 32 : 56;
  const [plan, setPlan] = React.useState("FULL");
  const [sent, setSent] = React.useState(false);
  const [year, setYear] = React.useState("2010");
  const minor = +year > 2008;
  const formRef = React.useRef(null);
  const toForm = (p) => { if (p) setPlan(p); const m = document.querySelector("main"); if (m && formRef.current) m.scrollTo({ top: formRef.current.offsetTop - 16, behavior: "smooth" }); };
  const sec = { padding: `${w < 600 ? 56 : 96}px ${pad}px`, maxWidth: 1280, margin: "0 auto", boxSizing: "border-box", width: "100%", display: "flex", flexDirection: "column", gap: 40 };
  const h2 = { margin: 0, font: `600 ${w < 600 ? 28 : 40}px/1.1 var(--font-sans)`, letterSpacing: "-.02em", color: C.ink, textWrap: "balance", maxWidth: 760 };
  return (
    <div style={{ background: GRID, color: C.ink, minHeight: "100%" }}>
      <header style={{ position: "sticky", top: 0, zIndex: 2, background: "color-mix(in srgb, var(--sand-200) 94%, transparent)", borderBottom: "1px solid " + C.line, backdropFilter: "blur(8px)" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto", padding: `0 ${pad}px`, minHeight: 64, boxSizing: "border-box", display: "flex", alignItems: "center", gap: w < 400 ? 12 : 24, minWidth: 0 }}>
          <img src="../../assets/logo-ak-golf-academy.svg" alt="AK Golf Academy" style={{ height: w < 400 ? 20 : 24, maxWidth: w < 400 ? 150 : "none", width: "auto", display: "block", minWidth: 0, flexShrink: 1 }} />
          <span style={{ flex: 1 }}></span>
          {w >= 900 && <nav style={{ display: "flex", gap: 24 }}>{[["Metoden", "pyramide"], ["Medlemskap", "medlemskap"], ["Booking", null]].map(([l, id]) => <a key={l} href={id ? "#" + id : "../booking/index.html"} onClick={(e) => { if (!id) return; e.preventDefault(); const m = document.querySelector("main"), el = document.getElementById(id); m && el && m.scrollTo({ top: el.offsetTop - 64, behavior: "smooth" }); }} style={{ font: "500 14px/1 var(--font-sans)", color: C.body, textDecoration: "none" }}>{l}</a>)}</nav>}
          <a href="../konto/index.html#innlogging" style={{ font: "500 14px/1 var(--font-sans)", color: C.body, textDecoration: "none" }}>Logg inn</a>
          {w >= 600 && <a href="../booking/index.html" style={{ ...btn(true), height: 40, padding: "0 16px", fontSize: 14 }}>Book time</a>}
        </div>
      </header>

      <section style={{ ...sec, paddingTop: w < 600 ? 48 : 96 }}>
        <div style={{ display: "grid", gridTemplateColumns: w > 1024 ? "minmax(0,1.15fr) minmax(0,1fr)" : "minmax(0,1fr)", gap: w < 600 ? 32 : 56, alignItems: "end" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 28 }}>
            <Kick n="00">AK GOLF ACADEMY · FREDRIKSTAD</Kick>
            <h1 style={{ margin: 0, font: `600 ${w < 380 ? 30 : w < 600 ? 38 : w <= 1024 ? 56 : 68}px/1.05 var(--font-sans)`, letterSpacing: "-.03em", textWrap: "balance", overflowWrap: "break-word", hyphens: "auto" }} lang="nb">Presisjonsutvikling for ambisiøse golfspillere.</h1>
            <p style={{ margin: 0, font: `400 ${w < 600 ? 16 : 18}px/1.55 var(--font-sans)`, color: C.body, maxWidth: 560, textWrap: "pretty" }}>Hver økt har et mål, hvert slag blir målt. Du trener etter en plan som bygger fra fysisk grunnlag til turneringsprestasjon.</p>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <a href="../booking/index.html" style={btn(true)}>Book time<Icon name="arrow-right" size={18} /></a>
              <button type="button" onClick={() => toForm()} style={btn(false)}>Søk plass i akademiet</button>
            </div>
          </div>
          <div style={{ position: "relative", aspectRatio: w > 1024 ? "4/5" : "16/10", borderRadius: 8, overflow: "hidden", background: "var(--sand-400)" }}>
            <img src="../../assets/photos/hero-bunker-shot.jpg" alt="Spiller slår ut av bunker" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
            <div style={{ position: "absolute", left: 12, bottom: 12, right: 12, display: "flex", gap: 8, flexWrap: "wrap" }}>
              {[["62", "SPILLERE"], ["5", "TRENERE"], ["1 200", "TIMER PER SESONG"]].map(([n, l]) => <span key={l} style={{ background: "color-mix(in srgb, var(--graphite-900) 82%, transparent)", color: "var(--sand-100)", borderRadius: 999, padding: "8px 12px", font: "500 12px/1 var(--font-mono)", fontVariantNumeric: "tabular-nums", letterSpacing: ".04em" }}>{n} {l}</span>)}
            </div>
          </div>
        </div>
      </section>

      <section id="pyramide" style={{ ...sec, borderTop: "1px solid " + C.line }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}><Kick n="01">AK-PYRAMIDEN</Kick><h2 style={h2}>Fem nivåer. Hvert nivå bygger på det under.</h2></div>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          {PYR.map(([ax, code, name, text], i) => (
            <div key={ax} style={{ display: "grid", gridTemplateColumns: w < 700 ? "minmax(0,1fr)" : "minmax(0,1fr) minmax(0,1fr)", gap: w < 700 ? 8 : 40, alignItems: "center", padding: w < 700 ? "12px 0" : 0 }}>
              <div style={{ display: "flex", justifyContent: "center" }}>
                <div style={{ width: `${40 + i * 15}%`, minWidth: 120, height: w < 600 ? 48 : 60, background: `var(--axis-${ax})`, color: "var(--white)", display: "flex", alignItems: "center", justifyContent: "center", gap: 12, font: "600 15px/1 var(--font-mono)", letterSpacing: ".08em" }}>{code}</div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span style={{ font: "600 17px/1.2 var(--font-sans)" }}>{name}</span><span style={{ font: "400 15px/1.5 var(--font-sans)", color: C.body, textWrap: "pretty" }}>{text}</span></div>
            </div>
          ))}
        </div>
      </section>

      <section id="medlemskap" style={{ ...sec, borderTop: "1px solid " + C.line }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}><Kick n="02">MEDLEMSKAP</Kick><h2 style={h2}>TALENT eller FULL.</h2><p style={{ margin: 0, font: "400 16px/1.5 var(--font-sans)", color: C.body, maxWidth: 560 }}>Ingen bindingstid. Én måneds oppsigelse. Bytt nivå når du vil.</p></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,320px),1fr))", gap: 16 }}>
          {PLANS.map((p) => { const full = p.id === "FULL"; return (
            <div key={p.id} style={{ background: full ? C.ink : C.card, color: full ? "var(--sand-100)" : C.ink, border: full ? "none" : "1px solid " + C.line, borderRadius: 8, padding: w < 600 ? 24 : 32, display: "flex", flexDirection: "column", gap: 24, minWidth: 0 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}><span style={{ font: "600 13px/1 var(--font-mono)", letterSpacing: ".12em" }}>{p.id}</span>{full && <span style={{ font: "500 11px/1 var(--font-mono)", letterSpacing: ".08em", border: "1px solid var(--graphite-500)", borderRadius: 999, padding: "6px 10px" }}>MEST VALGT</span>}</div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "600 44px/1 var(--font-mono)", fontVariantNumeric: "tabular-nums", letterSpacing: "-.02em" }}>{p.p}</span><span style={{ font: "500 13px/1 var(--font-mono)", color: full ? "var(--sand-400)" : C.muted }}>KR / MND</span></div>
              <span style={{ font: "400 15px/1.5 var(--font-sans)", color: full ? "var(--sand-300)" : C.body }}>{p.for}</span>
              <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column" }}>
                {p.f.map(([t, on]) => <li key={t} style={{ display: "flex", gap: 12, alignItems: "center", padding: "10px 0", borderTop: "1px solid " + (full ? "var(--graphite-700)" : C.line), font: "400 15px/1.3 var(--font-sans)", color: on ? "inherit" : full ? "var(--graphite-400)" : "var(--graphite-400)" }}><Icon name={on ? "check" : "minus"} size={16} />{t}</li>)}
              </ul>
              <button type="button" onClick={() => toForm(p.id)} style={{ ...btn(false), marginTop: "auto", borderColor: full ? "var(--sand-100)" : C.ink, color: full ? "var(--sand-100)" : C.ink }}>Søk om {p.id}</button>
            </div>); })}
        </div>
      </section>

      <section ref={formRef} style={{ ...sec, borderTop: "1px solid " + C.line }}>
        <div style={{ display: "grid", gridTemplateColumns: w > 1024 ? "minmax(0,1fr) minmax(0,1.3fr)" : "minmax(0,1fr)", gap: 40, alignItems: "start" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <Kick n="03">SØKNAD</Kick><h2 style={h2}>Søk om plass i akademiet.</h2>
            <p style={{ margin: 0, font: "400 16px/1.5 var(--font-sans)", color: C.body, textWrap: "pretty" }}>Vi svarer innen 5 virkedager og inviterer til en baseline-test på 45 minutter. Testen er gratis og uforpliktende.</p>
          </div>
          <div style={{ background: C.card, border: "1px solid " + C.line, borderRadius: 8, padding: w < 600 ? 20 : 32, display: "flex", flexDirection: "column", gap: 20, minWidth: 0 }}>
            {sent ? <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <span style={{ width: 44, height: 44, borderRadius: 999, background: "var(--green-700)", color: "var(--white)", display: "grid", placeItems: "center" }}><Icon name="check" size={22} /></span>
              <span style={{ font: "600 21px/1.25 var(--font-sans)" }}>Søknaden er mottatt</span>
              <span style={{ font: "400 15px/1.5 var(--font-sans)", color: C.body }}>Referanse <span style={{ fontFamily: "var(--font-mono)", color: C.ink }}>SØK-2026-0147</span>. Vi tar kontakt innen 02.10.2026.</span>
              <div><button type="button" onClick={() => setSent(false)} style={{ ...btn(false), height: 44 }}>Send en ny søknad</button></div>
            </div> : <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} style={{ display: "flex", flexDirection: "column", gap: 20 }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><span style={lbl}>Medlemskap</span>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 8 }}>{["TALENT", "FULL"].map((p) => <button key={p} type="button" aria-pressed={plan === p} onClick={() => setPlan(p)} style={{ height: 48, borderRadius: 8, border: "1px solid " + (plan === p ? C.ink : "var(--graphite-400)"), background: plan === p ? C.ink : "var(--white)", color: plan === p ? "var(--sand-100)" : C.ink, font: "600 13px/1 var(--font-mono)", letterSpacing: ".1em", cursor: "pointer" }}>{p}</button>)}</div></div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,200px),1fr))", gap: 16 }}>
                <Field label="Spillerens fulle navn"><input required style={inp} autoComplete="name" /></Field>
                <Field label="Fødselsår"><input required style={{ ...inp, fontFamily: "var(--font-mono)" }} inputMode="numeric" value={year} onChange={(e) => setYear(e.target.value.replace(/\D/g, "").slice(0, 4))} /></Field>
                <Field label="Klubb"><input style={inp} placeholder="Gamle Fredrikstad GK" /></Field>
                <Field label="Snitt brutto score siste sesong"><input style={{ ...inp, fontFamily: "var(--font-mono)" }} inputMode="decimal" placeholder="82,4" /></Field>
                <Field label="E-post"><input required type="email" style={inp} autoComplete="email" /></Field>
                <Field label="Mobil"><input style={{ ...inp, fontFamily: "var(--font-mono)" }} inputMode="tel" autoComplete="tel" /></Field>
              </div>
              {minor && <Field label="Foresattes e-post (spillere under 18)"><input required type="email" style={inp} /></Field>}
              <Field label="Hva vil du bli bedre på?"><textarea rows={3} style={{ ...inp, height: "auto", padding: 14, lineHeight: 1.5, resize: "vertical" }}></textarea></Field>
              <button type="submit" style={{ ...btn(true), width: "100%" }}>Send søknad</button>
              <span style={{ font: "400 12px/1.4 var(--font-mono)", color: C.muted }}>VI BRUKER OPPLYSNINGENE KUN TIL Å BEHANDLE SØKNADEN.</span>
            </form>}
          </div>
        </div>
      </section>

      <footer style={{ borderTop: "1px solid " + C.line }}>
        <div style={{ maxWidth: 1280, margin: "0 auto", padding: `32px ${pad}px`, display: "flex", gap: "12px 32px", flexWrap: "wrap", font: "400 12px/1.4 var(--font-mono)", color: C.muted }}>
          <span>AK GOLF AS · ORG.NR 900 000 000</span><span>STABBURVEIEN 18, 1617 FREDRIKSTAD</span><span style={{ flex: 1 }}></span><a href="../konto/index.html#personvern" style={{ color: C.muted }}>PERSONVERN</a>
        </div>
      </footer>
    </div>
  );
}
window.Forside = Forside;
})();
