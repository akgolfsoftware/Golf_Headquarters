(() => {
const { Button, IconButton, Segmented, Icon } = window.AKGolfPrecisionAthletics_7d7c29;
const { PageHead, pageWrap, Mono, Panel, useW } = window.KIT;

function slotsFor(dayIdx, d, svc, loc) {
  const wk = d.getDay() === 0 || d.getDay() === 6;
  const hrs = wk ? [9, 10, 11, 12, 13, 14, 15] : [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19];
  return hrs.map((h) => {
    const t = String(h).padStart(2, "0") + ":00";
    const seed = (dayIdx * 31 + h * 17 + svc.length * 7 + loc.length * 3) % 11;
    const past = dayIdx === 0 && h < 16;
    return { t, busy: past || seed < 4 };
  });
}

function Slot({ s, on, onPick, compact }) {
  return (
    <button type="button" disabled={s.busy} aria-pressed={on} onClick={onPick} aria-label={s.busy ? s.t + " opptatt" : s.t + " ledig"}
      style={{ height: compact ? 44 : 56, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : s.busy ? "transparent" : "var(--border-strong)"), background: on ? "var(--primary)" : s.busy ? "var(--surface-sunken)" : "var(--surface-card)", color: on ? "var(--text-on-primary)" : s.busy ? "var(--text-faint)" : "var(--text-primary)", cursor: s.busy ? "not-allowed" : "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 2, minWidth: 0, transition: "background-color 120ms, transform 80ms" }}
      onPointerDown={(e) => !s.busy && (e.currentTarget.style.transform = "scale(var(--press-scale))")} onPointerUp={(e) => (e.currentTarget.style.transform = "")} onPointerLeave={(e) => (e.currentTarget.style.transform = "")}>
      <span style={{ font: "500 15px/1 var(--font-mono)", fontVariantNumeric: "tabular-nums", textDecoration: s.busy ? "line-through" : "none" }}>{s.t}</span>
      {!compact && <span style={{ font: "400 11px/1 var(--font-sans)", color: on ? "var(--text-on-primary)" : "var(--text-muted)" }}>{s.busy ? "Opptatt" : "Ledig"}</span>}
    </button>
  );
}

function BookingTidspunkt({ b, set, svc, loc, price, go, dayAt, dd, longDate, DAYN, kr, date }) {
  const w = useW();
  const [view, setView] = React.useState("Dag");
  const [off, setOff] = React.useState(Math.floor(b.day / 7) * 7);
  const days = Array.from({ length: 7 }, (_, i) => off + i);
  const pickDay = (i) => set({ day: i, time: null });
  const slots = slotsFor(b.day, date, svc.id, loc.id);
  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%" }}>
      <div style={pageWrap}>
        <PageHead kicker="Booking · Steg 2 av 3" title="Velg tidspunkt" sub={svc.n + " · " + b.dur + " min · " + loc.n}
          actions={<Segmented options={["Dag", "Uke"]} value={view} onChange={setView} size="lg" />} />
        <Panel pad={16} style={{ gap: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <IconButton icon="chevron-left" label="Forrige uke" disabled={off === 0} onClick={() => setOff(Math.max(0, off - 7))} />
            <span style={{ flex: 1, textAlign: "center", font: "var(--type-num-s)", color: "var(--text-primary)" }}>{dd(dayAt(off))}–{dd(dayAt(off + 6))}</span>
            <IconButton icon="chevron-right" label="Neste uke" disabled={off >= 14} onClick={() => setOff(off + 7)} />
          </div>
          {view === "Dag" && <div style={{ display: "grid", gridTemplateColumns: "repeat(7,minmax(0,1fr))", gap: 4 }}>
            {days.map((i) => { const d = dayAt(i), on = i === b.day, free = slotsFor(i, d, svc.id, loc.id).filter((s) => !s.busy).length; return (
              <button key={i} type="button" aria-pressed={on} onClick={() => pickDay(i)} style={{ minHeight: 64, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "transparent"), background: on ? "var(--primary)" : "transparent", color: on ? "var(--text-on-primary)" : "var(--text-primary)", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, padding: 2, minWidth: 0 }}>
                <span style={{ font: "500 12px/1 var(--font-sans)", color: on ? "var(--text-on-primary)" : "var(--text-muted)" }}>{DAYN[d.getDay()]}</span>
                <span style={{ font: "600 17px/1 var(--font-mono)" }}>{d.getDate()}</span>
                <span style={{ font: "400 10px/1 var(--font-mono)", color: on ? "var(--sand-300)" : free ? "var(--text-muted)" : "var(--text-faint)" }}>{free ? free + " LEDIG" : "FULL"}</span>
              </button>); })}
          </div>}
        </Panel>
        {view === "Dag" ? (
          <Panel kicker={longDate(date)} title={slots.filter((s) => !s.busy).length + " ledige tider"}>
            <div style={{ display: "grid", gridTemplateColumns: `repeat(auto-fill,minmax(${w < 600 ? 96 : 112}px,1fr))`, gap: 8 }}>
              {slots.map((s) => <Slot key={s.t} s={s} on={b.time === s.t} onPick={() => set({ time: s.t })} />)}
            </div>
            <div style={{ display: "flex", gap: 16, flexWrap: "wrap", font: "var(--type-meta)", color: "var(--text-muted)" }}>
              <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}><span style={{ width: 14, height: 14, borderRadius: 4, background: "var(--surface-card)", border: "1px solid var(--border-strong)" }}></span>LEDIG</span>
              <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}><span style={{ width: 14, height: 14, borderRadius: 4, background: "var(--surface-sunken)" }}></span>OPPTATT</span>
            </div>
          </Panel>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,132px),1fr))", gap: 8 }}>
            {days.map((i) => { const d = dayAt(i), sl = slotsFor(i, d, svc.id, loc.id); return (
              <div key={i} style={{ background: "var(--surface-card)", border: "1px solid " + (i === b.day ? "var(--border-ink)" : "var(--border-hairline)"), borderRadius: 8, padding: 8, display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 4, padding: "4px 4px 8px" }}><span style={{ font: "600 14px/1 var(--font-sans)", color: "var(--text-primary)" }}>{DAYN[d.getDay()]}</span><Mono s={{ color: "var(--text-muted)", fontSize: 12 }}>{dd(d)}</Mono></div>
                {sl.map((s) => <Slot key={s.t} s={s} compact on={b.day === i && b.time === s.t} onPick={() => set({ day: i, time: s.t })} />)}
              </div>); })}
          </div>
        )}
      </div>
      <window.BK.FlowFoot left={b.time ? <><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{longDate(date).replace(/^./, (c) => c.toUpperCase())}</span><Mono s={{ color: "var(--text-muted)" }}>KL. {b.time} · {b.dur} MIN · {kr(price)}</Mono></> : <span style={{ font: "var(--type-body-s)", color: "var(--text-muted)" }}>Velg et ledig tidspunkt</span>}>
        <Button variant="ghost" size="lg" icon="arrow-left" onClick={() => go("tjenester")}>Tilbake</Button>
        <Button size="lg" iconRight="arrow-right" disabled={!b.time} onClick={() => go("kasse")}>Gå til kasse</Button>
      </window.BK.FlowFoot>
    </div>
  );
}
window.BookingTidspunkt = BookingTidspunkt;
})();
