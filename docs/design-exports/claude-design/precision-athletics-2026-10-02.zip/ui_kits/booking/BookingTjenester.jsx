(() => {
const { Button, Icon, ChoicePill, Segmented } = window.AKGolfPrecisionAthletics_7d7c29;
const { PageHead, pageWrap, Grid, Mono, Panel } = window.KIT;
const Label = ({ children }) => <span style={{ font: "var(--type-label)", color: "var(--text-secondary)" }}>{children}</span>;

function BookingTjenester({ b, set, svc, price, go, SERVICES, LOCS, kr }) {
  const pick = (s) => set({ svc: s.id, dur: s.durs[s.durs.length - 1][0], coach: s.coaches[0] || null, time: null });
  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%" }}>
      <div style={pageWrap}>
        <PageHead kicker="Booking · Steg 1 av 3" title="Hva vil du booke?" sub="Alle priser inkluderer mva. Gratis avbestilling frem til 24 timer før." />
        <Grid min={280}>
          {SERVICES.map((s) => { const on = s.id === b.svc; return (
            <div key={s.id} role="radio" aria-checked={on} tabIndex={0} onClick={() => !on && pick(s)} onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && pick(s)}
              style={{ textAlign: "left", background: "var(--surface-card)", border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), boxShadow: on ? "inset 0 0 0 1px var(--border-ink)" : "var(--shadow-card)", borderRadius: 8, padding: 20, display: "flex", flexDirection: "column", gap: 16, cursor: "pointer", minWidth: 0, transition: "border-color 120ms" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <span style={{ width: 40, height: 40, borderRadius: 8, background: on ? "var(--primary)" : "var(--surface-sunken)", color: on ? "var(--text-on-primary)" : "var(--text-primary)", display: "grid", placeItems: "center", flexShrink: 0 }}><Icon name={s.icon} size={20} /></span>
                <span style={{ flex: 1 }}></span>
                <span style={{ width: 20, height: 20, borderRadius: 999, border: "1.5px solid " + (on ? "var(--border-ink)" : "var(--border-strong)"), display: "grid", placeItems: "center" }}>{on && <span style={{ width: 10, height: 10, borderRadius: 999, background: "var(--primary)" }}></span>}</span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}><span style={{ font: "var(--type-title-s)", color: "var(--text-primary)" }}>{s.n}</span><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{s.d}</span></div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4, marginTop: "auto" }}>
                {s.durs.map(([m, p]) => <div key={m} style={{ display: "flex", justifyContent: "space-between", gap: 8 }}><Mono s={{ color: "var(--text-secondary)" }}>{m} min</Mono><Mono s={{ color: "var(--text-primary)", fontWeight: 600 }}>{kr(p)}</Mono></div>)}
              </div>
            </div>); })}
        </Grid>
        <Panel kicker="Detaljer" title={svc.n}>
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            {svc.durs.length > 1 && <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><Label>Varighet</Label>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{svc.durs.map(([m, p]) => <ChoicePill key={m} size="lg" selected={b.dur === m} onClick={() => set({ dur: m })}>{m} min · {kr(p)}</ChoicePill>)}</div></div>}
            {svc.bays && <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><Label>Simulatorbås</Label>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(88px,1fr))", gap: 8, maxWidth: 480 }}>{svc.bays.map((x) => <ChoicePill key={x} size="lg" mono selected={b.bay === x} onClick={() => set({ bay: x })}>{x}</ChoicePill>)}</div></div>}
            {svc.coaches.length > 0 && <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><Label>Coach</Label>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{svc.coaches.map((c) => <ChoicePill key={c} size="lg" selected={b.coach === c} onClick={() => set({ coach: c })}>{c}</ChoicePill>)}</div></div>}
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><Label>Lokasjon</Label>
              <Grid min={260} gap={8}>{LOCS.map((l) => { const on = b.loc === l.id; return (
                <button key={l.id} type="button" aria-pressed={on} onClick={() => set({ loc: l.id, time: null })} style={{ textAlign: "left", minHeight: 64, padding: "12px 16px", borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-strong)"), background: on ? "var(--surface-sunken)" : "var(--surface-card)", cursor: "pointer", display: "flex", gap: 12, alignItems: "center", minWidth: 0 }}>
                  <Icon name="map-pin" size={18} /><span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{l.n}</span><span style={{ font: "400 13px/1.3 var(--font-sans)", color: "var(--text-muted)" }}>{l.a}</span></span>
                </button>); })}</Grid></div>
          </div>
        </Panel>
      </div>
      <window.BK.FlowFoot left={<><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{svc.n}</span><Mono s={{ color: "var(--text-muted)" }}>{b.dur} MIN · {kr(price)}</Mono></>}>
        <Button size="lg" iconRight="arrow-right" onClick={() => go("tidspunkt")}>Velg tidspunkt</Button>
      </window.BK.FlowFoot>
    </div>
  );
}
window.BookingTjenester = BookingTjenester;
})();
