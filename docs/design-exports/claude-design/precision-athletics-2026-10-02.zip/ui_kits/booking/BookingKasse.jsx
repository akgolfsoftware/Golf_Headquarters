(() => {
const { Button, Icon, Input, Segmented, InlineAlert, Checkbox, StatusPill } = window.AKGolfPrecisionAthletics_7d7c29;
const { PageHead, pageWrap, Grid, Mono, Panel, Kv, useW, download } = window.KIT;
const fieldS = { border: "none", outline: "none", background: "transparent", font: "500 15px/1 var(--font-mono)", fontVariantNumeric: "tabular-nums", color: "var(--text-primary)", minWidth: 0, height: 44, padding: 0 };

function StripeCard() {
  const [f, setF] = React.useState(false);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <span style={{ font: "var(--type-label)", color: "var(--text-secondary)" }}>Kortinformasjon</span>
      <div onFocus={() => setF(true)} onBlur={() => setF(false)} style={{ display: "flex", alignItems: "center", flexWrap: "wrap", columnGap: 12, padding: "0 12px", borderRadius: 8, border: "1px solid " + (f ? "var(--border-ink)" : "var(--border-control)"), boxShadow: f ? "0 0 0 1px var(--border-ink)" : "none", background: "var(--surface-card)", transition: "border-color 120ms" }}>
        <Icon name="credit-card" size={18} color="var(--text-muted)" />
        <input aria-label="Kortnummer" inputMode="numeric" placeholder="1234 1234 1234 1234" style={{ ...fieldS, flex: "1 1 180px" }} />
        <input aria-label="Utløpsdato" inputMode="numeric" placeholder="MM / ÅÅ" style={{ ...fieldS, width: 72, flex: "0 0 72px" }} />
        <input aria-label="CVC" inputMode="numeric" placeholder="CVC" style={{ ...fieldS, width: 48, flex: "0 0 48px" }} />
      </div>
      <span style={{ display: "inline-flex", gap: 8, alignItems: "center", font: "var(--type-meta)", color: "var(--text-muted)" }}><Icon name="lock" size={14} />KRYPTERT AV STRIPE · VI LAGRER IKKE KORTNUMMER</span>
    </div>
  );
}

function BookingKasse({ b, set, svc, loc, price, go, longDate, date, kr }) {
  const w = useW();
  const [busy, setBusy] = React.useState(false);
  const [terms, setTerms] = React.useState(true);
  const pay = () => { setBusy(true); setTimeout(() => { set({ ref: "AKG-B-" + String(date.getDate()).padStart(2, "0") + String(date.getMonth() + 1).padStart(2, "0") + "-4817" }); setBusy(false); go("bekreftet"); }, 900); };
  const two = w > 1024;
  return (
    <div style={pageWrap}>
      <PageHead kicker="Booking · Steg 3 av 3" title="Kasse" />
      <div style={{ display: "grid", gridTemplateColumns: two ? "minmax(0,1fr) 380px" : "minmax(0,1fr)", gap: 24, alignItems: "start" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 24, minWidth: 0 }}>
          <Panel kicker="Kontakt" title="Hvem kommer?">
            <Grid min={220} gap={12}><Input label="Fullt navn" autoComplete="name" defaultValue="Emma Solberg" /><Input label="Mobil" mono autoComplete="tel" defaultValue="+47 412 34 567" /></Grid>
            <Input label="E-post" type="email" autoComplete="email" defaultValue="kari.solberg@example.no" hint="Kvittering og kalenderinvitasjon sendes hit" />
          </Panel>
          <Panel kicker="Betaling" title="Velg betalingsmåte">
            <Segmented options={[{ value: "kort", label: "Kort", icon: "credit-card" }, { value: "vipps", label: "Vipps", icon: "smartphone" }]} value={b.pay} onChange={(v) => set({ pay: v })} size="lg" fullWidth />
            {b.pay === "kort" ? <StripeCard /> : (
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <Input label="Mobilnummer for Vipps" mono inputMode="tel" defaultValue="412 34 567" prefix="+47" />
                <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Du får et varsel i Vipps-appen. Godkjenn betalingen der, så kommer du tilbake hit.</span>
              </div>
            )}
            <Checkbox checked={terms} onChange={(e) => setTerms(e.target.checked)} label="Jeg godtar avbestillingsvilkårene" />
            <Button size="lg" fullWidth disabled={!terms || !b.time} loading={busy} loadingText={b.pay === "kort" ? "BEHANDLER BETALING…" : "VENTER PÅ VIPPS…"} onClick={pay}>{b.pay === "kort" ? "Betal " + kr(price) : "Fortsett til Vipps · " + kr(price)}</Button>
          </Panel>
        </div>
        <Panel kicker="Bestillingssammendrag" title={svc.n} style={two ? { position: "sticky", top: 0 } : { order: -1 }}>
          <div>
            <Kv k="Dato" v={longDate(date).replace(/^./, (c) => c.toUpperCase())} mono={false} />
            <Kv k="Klokkeslett" v={b.time ? b.time + "–" + String(+b.time.slice(0, 2) + (b.dur === 45 ? 0 : 1)).padStart(2, "0") + ":" + (b.dur === 45 ? "45" : "00") : "—"} />
            <Kv k="Varighet" v={b.dur + " min"} />
            {svc.bays && <Kv k="Bås" v={b.bay} />}
            {b.coach && <Kv k="Coach" v={b.coach} mono={false} />}
            <Kv k="Lokasjon" v={loc.n} mono={false} />
            <Kv k="Totalt inkl. mva" v={kr(price)} last />
          </div>
          <div style={{ background: "var(--surface-sunken)", borderRadius: 8, padding: 12, display: "flex", gap: 12 }}>
            <Icon name="clock" size={18} />
            <div style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>Avbestilling</span><span style={{ font: "400 13px/1.4 var(--font-sans)", color: "var(--text-secondary)", textWrap: "pretty" }}>Gratis frem til 24 timer før. Senere avbestilling eller uteblivelse belastes fullt.</span></div>
          </div>
          <Button variant="ghost" icon="arrow-left" onClick={() => go("tidspunkt")}>Endre tidspunkt</Button>
        </Panel>
      </div>
    </div>
  );
}

function BookingBekreftet({ b, svc, loc, price, go, date, longDate, kr }) {
  const ref = b.ref || "AKG-B-2809-4817";
  const [h, m] = (b.time || "10:00").split(":").map(Number);
  const pad = (n) => String(n).padStart(2, "0");
  const ymd = date.getFullYear() + pad(date.getMonth() + 1) + pad(date.getDate());
  const endMin = h * 60 + m + b.dur, st = ymd + "T" + pad(h) + pad(m) + "00", en = ymd + "T" + pad(Math.floor(endMin / 60)) + pad(endMin % 60) + "00";
  const ics = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//AK Golf//Booking//NO", "BEGIN:VEVENT", "UID:" + ref + "@akgolf.no", "DTSTAMP:20260925T120000Z", "DTSTART;TZID=Europe/Oslo:" + st, "DTEND;TZID=Europe/Oslo:" + en, "SUMMARY:" + svc.n, "LOCATION:" + loc.n + ", " + loc.a, "DESCRIPTION:Referanse " + ref + ". Gratis avbestilling frem til 24 timer før.", "END:VEVENT", "END:VCALENDAR"].join("\r\n");
  const gcal = "https://calendar.google.com/calendar/render?action=TEMPLATE&text=" + encodeURIComponent(svc.n) + "&dates=" + st + "/" + en + "&ctz=Europe/Oslo&location=" + encodeURIComponent(loc.n + ", " + loc.a) + "&details=" + encodeURIComponent("Referanse " + ref);
  return (
    <div style={{ ...pageWrap, maxWidth: 760, margin: "0 auto" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 16, alignItems: "flex-start" }}>
        <span style={{ width: 48, height: 48, borderRadius: 999, background: "var(--ok)", color: "var(--white)", display: "grid", placeItems: "center" }}><Icon name="check" size={24} /></span>
        <PageHead kicker="Booking bekreftet" title="Vi sees snart" sub={"Kvittering er sendt på e-post. " + svc.n + (b.coach && b.coach !== "Uten coach" ? " med " + b.coach : "") + "."} />
      </div>
      <Panel>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}><span className="kicker">Referansenummer</span><span style={{ font: "600 clamp(22px,4vw,28px)/1.1 var(--font-mono)", fontVariantNumeric: "tabular-nums", letterSpacing: ".02em", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{ref}</span></div>
        <div>
          <Kv k="Når" v={longDate(date).replace(/^./, (c) => c.toUpperCase()) + " · " + (b.time || "10:00")} mono={false} />
          <Kv k="Hvor" v={loc.n} mono={false} />
          <Kv k="Betalt" v={kr(price) + (b.pay === "vipps" ? " · Vipps" : " · Kort")} last />
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <Button icon="calendar-plus" onClick={() => download(ref + ".ics", ics, "text/calendar")}>Legg til i Apple Kalender</Button>
          <Button variant="secondary" icon="calendar-plus" onClick={() => window.open(gcal, "_blank", "noopener")}>Google Kalender</Button>
        </div>
      </Panel>
      <Panel kicker="Oppmøte-guide" title={loc.n}>
        <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", display: "inline-flex", gap: 8, alignItems: "center" }}><Icon name="map-pin" size={16} />{loc.a}</span>
        <ol style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 12 }}>
          {loc.guide.map((g, i) => <li key={i} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr)", gap: 12, alignItems: "baseline" }}><Mono s={{ color: "var(--text-muted)" }}>{pad(i + 1)}</Mono><span style={{ font: "var(--type-body)", color: "var(--text-body)" }}>{g}</span></li>)}
        </ol>
      </Panel>
      <div><Button variant="ghost" icon="plus" onClick={() => go("tjenester")}>Book en ny time</Button></div>
    </div>
  );
}
window.BookingKasse = BookingKasse;
window.BookingBekreftet = BookingBekreftet;
})();
