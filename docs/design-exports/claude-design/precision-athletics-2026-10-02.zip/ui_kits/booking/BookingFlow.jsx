(() => {
const { Icon, StatusPill } = window.AKGolfPrecisionAthletics_7d7c29;
const { useWidth, WCtx, shellVars, kr } = window.KIT;
const SERVICES = [
  { id: "privat", n: "Privattime med Coach Anders", d: "Teknisk trening, slag eller spill. TrackMan og video inkludert.", durs: [[45, 950], [60, 1250]], coaches: ["Anders Kristiansen"], icon: "user-round" },
  { id: "sim", n: "TrackMan Simulatorbås", d: "Egen bås med full TrackMan. Øvelser, baner og tester.", durs: [[60, 450]], bays: ["Bay 1", "Bay 2", "Bay 3", "Bay 4"], coaches: [], icon: "crosshair" },
  { id: "lab", n: "Nærspill & Putting Lab", d: "Innendørs green og chippematter. Med eller uten coach.", durs: [[45, 650]], coaches: ["Uten coach", "Anders Kristiansen", "Markus Holm"], icon: "flag" },
];
const LOCS = [
  { id: "studio", n: "AK Golf Studio", a: "Stabburveien 18, 1617 Fredrikstad", guide: ["Parker gratis foran bygget, merket AK Golf.", "Inngang på kortsiden. Ring på ved ytterdøren.", "Kom 10 minutter før. Ta med egne køller og innesko."] },
  { id: "gfgk", n: "Gamle Fredrikstad Golfklubb", a: "Torsnesveien 16, 1630 Gamle Fredrikstad", guide: ["Parker på klubbens hovedparkering.", "Meld deg i proshopen. Coachen møter deg på rangen.", "Kom 15 minutter før for oppvarming. Rangeballer er inkludert."] },
];
const START = new Date(2026, 8, 25);
const DAYN = ["Søn", "Man", "Tir", "Ons", "Tor", "Fre", "Lør"];
const MON = ["jan", "feb", "mar", "apr", "mai", "jun", "jul", "aug", "sep", "okt", "nov", "des"];
const dayAt = (i) => { const d = new Date(START); d.setDate(d.getDate() + i); return d; };
const dd = (d) => String(d.getDate()).padStart(2, "0") + "." + String(d.getMonth() + 1).padStart(2, "0");
const longDate = (d) => DAYN[d.getDay()].toLowerCase() + " " + d.getDate() + ". " + MON[d.getMonth()] + " " + d.getFullYear();
const STEPS = [["tjenester", "Tjeneste"], ["tidspunkt", "Tidspunkt"], ["kasse", "Kasse"]];

function Stepper({ page, go, w, canTime, canPay }) {
  const idx = page === "bekreftet" ? 3 : STEPS.findIndex((s) => s[0] === page);
  const can = [true, canTime, canPay];
  if (w < 600) return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0, flex: 1 }}>
      <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{idx < 3 ? `STEG ${idx + 1} AV 3 · ${STEPS[idx][1].toUpperCase()}` : "BEKREFTET"}</span>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 4 }}>{STEPS.map((s, i) => <div key={s[0]} style={{ height: 3, background: i <= idx ? "var(--primary)" : "var(--border-hairline)" }}></div>)}</div>
    </div>
  );
  return (
    <ol style={{ display: "flex", gap: 8, listStyle: "none", margin: 0, padding: 0, alignItems: "center", minWidth: 0 }}>
      {STEPS.map(([id, l], i) => { const done = i < idx, on = i === idx, ok = idx < 3 && can[i]; return (
        <li key={id} style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 0 }}>
          {i > 0 && <span style={{ width: 24, height: 1, background: "var(--border-strong)" }}></span>}
          <button type="button" disabled={!ok || on} onClick={() => go(id)} style={{ display: "inline-flex", alignItems: "center", gap: 8, height: 36, padding: "0 12px 0 6px", borderRadius: 999, border: "1px solid " + (on ? "var(--border-ink)" : "transparent"), background: "transparent", cursor: ok && !on ? "pointer" : "default", color: on || done ? "var(--text-primary)" : "var(--text-muted)", font: "500 14px/1 var(--font-sans)" }}>
            <span style={{ width: 24, height: 24, borderRadius: 999, display: "grid", placeItems: "center", background: done || on ? "var(--primary)" : "var(--surface-sunken)", color: done || on ? "var(--text-on-primary)" : "var(--text-muted)", font: "500 12px/1 var(--font-mono)" }}>{done ? <Icon name="check" size={14} /> : i + 1}</span>{l}
          </button>
        </li>); })}
    </ol>
  );
}

function BookingFlow() {
  const P = ["tjenester", "tidspunkt", "kasse", "bekreftet"];
  const [page, setPage] = React.useState(() => { const h = location.hash.slice(1); if (P.includes(h)) return h; const s = localStorage.getItem("bk-page"); return P.includes(s) ? s : "tjenester"; });
  const [b, setB] = React.useState({ svc: "privat", dur: 60, bay: "Bay 1", coach: "Anders Kristiansen", loc: "studio", day: 3, time: "10:00", pay: "kort", ref: null });
  const [ref, w] = useWidth(1280);
  React.useEffect(() => { localStorage.setItem("bk-page", page); document.querySelector("main")?.scrollTo(0, 0); }, [page]);
  React.useEffect(() => { window.__kitSetPage = setPage; }, []);
  const set = (p) => setB((o) => ({ ...o, ...p }));
  const svc = SERVICES.find((s) => s.id === b.svc), loc = LOCS.find((l) => l.id === b.loc);
  const price = (svc.durs.find((d) => d[0] === b.dur) || svc.durs[0])[1];
  const ctx = { b, set, svc, loc, price, go: setPage, date: dayAt(b.day), SERVICES, LOCS, dayAt, dd, longDate, DAYN, kr };
  const S = { tjenester: BookingTjenester, tidspunkt: BookingTidspunkt, kasse: BookingKasse, bekreftet: BookingBekreftet }[page];
  return (
    <WCtx.Provider value={w}>
      <div ref={ref} style={{ ...shellVars(w), display: "flex", flexDirection: "column", height: "100vh", width: "100%", overflow: "hidden", background: "var(--surface-page)" }}>
        <header style={{ minHeight: 64, display: "flex", alignItems: "center", gap: 24, padding: "8px var(--page-x)", background: "var(--surface-flat)", borderBottom: "1px solid var(--border-hairline)", flexShrink: 0 }}>
          <a href="../marked/index.html" style={{ display: "flex", alignItems: "center", gap: 12, textDecoration: "none", flexShrink: 0 }}><img src="../../assets/logo-ak-golf-hq.svg" alt="AK Golf" style={{ height: 20, display: "block" }} />{w >= 900 && <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>BOOKING</span>}</a>
          <div style={{ flex: 1, minWidth: 0, display: "flex", justifyContent: w < 600 ? "stretch" : "center" }}><Stepper page={page} go={setPage} w={w} canTime={true} canPay={!!b.time} /></div>
          {w >= 900 && <span style={{ font: "var(--type-meta)", color: "var(--text-muted)", flexShrink: 0 }}>SPØRSMÅL? 69 00 00 00</span>}
        </header>
        <main style={{ flex: 1, minWidth: 0, minHeight: 0, overflowY: "auto", overflowX: "hidden" }} data-screen-label={"booking-" + page}><S {...ctx} /></main>
      </div>
    </WCtx.Provider>
  );
}
function FlowFoot({ left, children }) {
  return (
    <div style={{ position: "sticky", bottom: 0, marginTop: "auto", background: "var(--surface-flat)", borderTop: "1px solid var(--border-hairline)", padding: "12px var(--page-x)", display: "flex", gap: 16, alignItems: "center", justifyContent: "space-between", flexWrap: "wrap" }}>
      <div style={{ minWidth: 0, flex: "1 1 200px", display: "flex", flexDirection: "column", gap: 4 }}>{left}</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{children}</div>
    </div>
  );
}
window.BookingFlow = BookingFlow;
window.BK = { FlowFoot };
})();
