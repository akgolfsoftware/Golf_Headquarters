/* Stall og Spiller 360 — runde 27 (Anders 28.09.2026). Oppdiktede data. Coach Anders Kristiansen. Lørdag 26.09.2026 10:24. */
window.STALL = {
  today: [
    { id: "p1", t: "10:00", who: "Tobias Lindvik", what: "Privattime · Studio 1" },
    { id: "p2", t: "11:15", who: "Magnus Aasheim", what: "Privattime · Studio 1" },
    { id: "g1", t: "14:30", who: "Junior elite · 6 spillere", what: "Gruppeøkt · nærspill" },
    { id: "p4", t: "17:00", who: "Thea Nilsen", what: "Videoanalyse · digitalt" },
  ],
  live: [
    { id: "p3", who: "Ida Berg", what: "Putting 3–5 fot · ballstart", where: "Puttinggreen", start: "10:02", drill: 2, drills: 3, reps: 64, plan: 90, cur: "Port-øvelse 4 fot", done: [["Oppvarming 0–3 fot", 30, 30], ["Port-øvelse 4 fot", 34, 50], ["Lengdekontroll 20 fot", 0, 10]] },
    { id: "p8", who: "Henrik Dahl", what: "Styrke bein og kjerne", where: "WANG · styrkerom", start: "09:40", drill: 4, drills: 5, reps: 13, plan: 18, cur: "Pallof press", done: [["Knebøy", 4, 4], ["Rumensk markløft", 3, 3], ["Utfall", 3, 3], ["Pallof press", 3, 3], ["Planke", 0, 3]] },
  ],
  quick: ["Bra jobba!", "Husk rutinen før hvert slag", "Senk farten til 50 %", "Ta en pause på 5 min", "Send meg en video av neste slag"],
  groups: [["f", "Trenger deg"], ["p", "Følger planen"], ["r", "Hviler"]],
  players: [
    { id: "p5", name: "Oskar Nilsen", cat: "F", grp: "Junior elite", g: "f", adh: 55, sg: [-3.1, -3.0, -3.4, -3.6], last: "12.09", turn: null, why: "Under 70 % tre uker på rad", planDays: 3, clip: [0, 4, "01.10.2026"], born: 2010 },
    { id: "p1", name: "Tobias Lindvik", cat: "D", grp: "WANG Toppidrett", g: "f", adh: 94, sg: [-2.9, -2.6, -2.4, -2.2], last: "26.09", turn: "Srixon Tour · om 7 dager", why: "Ønsker planendring uke 40", planDays: 34, clip: [3, 4, "01.10.2026"], born: 2009 },
    { id: "p4", name: "Thea Nilsen", cat: "E", grp: "Junior elite", g: "f", adh: 81, sg: [-3.4, -3.2, -3.3, -3.1], last: "25.09", turn: "Regionfinale · i morgen", why: "Ubesvart spørsmål i 20 t", planDays: 12, clip: [1, 4, "01.10.2026"], born: 2011 },
    { id: "p7", name: "Sara Holm", cat: "E", grp: "WANG Toppidrett", g: "f", adh: 66, sg: [-3.0, -3.1, -3.2, -3.3], last: "24.09", turn: null, why: "Under 70 % to uker · skolestress", planDays: 20, clip: [2, 4, "01.10.2026"], born: 2009 },
    { id: "p2", name: "Magnus Aasheim", cat: "C", grp: "WANG Toppidrett", g: "p", adh: 88, sg: [-1.2, -1.0, -0.9, -0.7], last: "25.09", turn: "Srixon Tour · om 7 dager", why: null, planDays: 41, clip: [2, 4, "01.10.2026"], born: 2008 },
    { id: "p3", name: "Ida Berg", cat: "D", grp: "Junior elite", g: "p", adh: 91, sg: [-2.4, -2.2, -2.1, -1.9], last: "I dag", turn: null, why: null, planDays: 55, clip: [4, 4, "01.10.2026"], born: 2008 },
    { id: "p6", name: "Jonas Lie", cat: "F", grp: "Junior elite", g: "p", adh: 72, sg: [-3.6, -3.5, -3.5, -3.4], last: "17.09", turn: null, why: null, planDays: 28, clip: null, born: 2009 },
    { id: "p8", name: "Henrik Dahl", cat: "C", grp: "WANG Toppidrett", g: "p", adh: 97, sg: [-0.9, -0.8, -0.8, -0.6], last: "I dag", turn: null, why: null, planDays: 62, clip: [1, 4, "01.10.2026"], born: 2007 },
    { id: "p9", name: "Emil Sand", cat: "G", grp: "Basis", g: "r", adh: null, sg: null, last: "10.09", turn: null, why: "Skadet · kne · til 04.10", planDays: null, clip: null, born: 2012 },
  ],
  src: "ETTERLEVELSE: ØKTLOGG 4 UKER · SG PER RUNDE MOT KATEGORI C (BROADIE) · ENDRING = SISTE RUNDE MOT FØRSTE SISTE 30 DAGER · ESTIMAT · 26.09.2026 08:10",
  /* Spiller 360 */
  p360: {
    needs: [["Ønsker planendring uke 40", "Eksamen tirsdag 29.09 · flytt innspillsøkta", "AG-04"], ["Ny svingvideo fra range", "07:52 · er hendene foran nå?", "AG-04"], ["Forslag fra motoren", "Gjør uke 40 lettere · 134 % og 131 %", "AG-04"]],
    week: [["Man 21.09", "Styrke · WANG morgenøkt", "FYS", "Gjennomført"], ["Tir 22.09", "Innspill 50–100 m", "SLAG", "Gjennomført"], ["Ons 23.09", "Privattime · Anders", "TEK", "Gjennomført"], ["Tor 24.09", "TrackMan · wedge-lengder", "SLAG", "Gjennomført"], ["Fre 25.09", "WANG morgenøkt · nærspill", "SLAG", "Hoppet over"], ["Lør 26.09", "Innspill og nærspill", "SLAG", "Planlagt"], ["Søn 27.09", "Treningsturnering 18 hull", "SPILL", "Planlagt"]],
    planEffect: { src: "ESTIMAT · FOR LITE DATA · 26.09.2026", rows: [["Konkurransespilleren", "C–E", 42, "−1,1 slag på 12 mnd", true], ["Junior-aspirant", "E–G", 57, "−2,4 slag på 12 mnd", true], ["Klubbspilleren", "F–H", 23, "−0,9 slag på 12 mnd", true], ["Practice like the pros", "A–C", 6, "—", false], ["Weekend Warrior", "H–K", 11, "—", false]] },
    stall: { tee: -0.6, innspill: -1.4, naer: -0.7, putt: -0.8, src: "SNITT STALLEN · 31 SPILLERE · 20.09.2026" },
    talks: [
      { kind: "IUP-samtale", t: "Sesongplan høst", at: "12.09.2026", meta: "45 min · referat godkjent" },
      { kind: "Opptak", t: "Privattime · P6.0", at: "25.09.2026", meta: "52:10 · sammendrag sendt" },
      { kind: "Notat", t: "Eksamen uke 40 · redusere mengde", at: "25.09.2026", meta: "Anders" },
      { kind: "Video", t: "P7.0 fra siden", at: "24.09.2026", meta: "0:38 · fra Tobias" },
    ],
    memory: [
      ["m1", "Liker korte, konkrete beskjeder. Ett fokus per økt.", "FRA 6 SAMTALER"],
      ["m2", "Blir stiv i korsryggen etter lange bussturer.", "FRA HELSE · 02.09.2026"],
      ["m3", "Har eksamen i uke 40 og 48.", "FRA MELDING · 25.09.2026"],
      ["m4", "Målsetning: WANG-landslagsuttak G17 i 2027.", "FRA IUP-SAMTALE · 12.09.2026"],
    ],
    radar: [["FYS", 6.2], ["TEK", 5.8], ["SLAG", 6.6], ["SPILL", 5.4], ["TURN", 4.8]], radarRef: [7.0, 6.8, 7.2, 6.6, 6.4], radarSrc: "TESTER OG RUNDER · 20.09.2026 · ESTIMAT",
  },
};
