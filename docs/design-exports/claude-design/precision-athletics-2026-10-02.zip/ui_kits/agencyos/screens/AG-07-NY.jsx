/* AG-07-NY Ny spiller (skjema). TEGNET 30.09.2026 I NATT: Anders må se skjermen (port 7).
   Erstatter arket «Ny spiller» i AG-07 med egen side /admin/spillere/ny, samme løsning som AG-08 Rediger.
   Alle feltene appen krever: program, navn, e-post, fødselsdato, HCP, hjemmeklubb, kategori, app-nivå,
   foresatte (bare under 18), velkomstmelding og invitasjon. Barn: samtykke og barnevern-regler uendret.
   Ikke lagt i katalog.js eller screen.html (ikke våre filer): forhåndsvises i AG-07-NY-forhaand.html.
   Rettet etter kontroll: ingen hardkodet pris og ikke navnet «AI-coach» i app-nivåteksten. */
(() => {
const KAT = [["A1", "Toppspiller, landslag eller elite"], ["A2", "Talent, regional elite"], ["B1", "Etablert, klubb-elite"], ["B2", "Utvikling, junior med ambisjon"], ["C", "Bredde, fritid og nybegynner"]];
const PROG = ["AK Golf Academy", "AK Golf Academy Junior", "WANG Toppidrett Fredrikstad", "WANG Ung Fredrikstad", "GFGK Mini", "GFGK Bredde/Utvikling", "GFGK Jenter", "GFGK Elite", "Selvbetjent (ingen coach)"];
function AG07NY({ state, go }) {
  const { PageHeader, Button, FormField, TextInput, Select, InlineAlert, StatusPill, Segmented } = window.AGQ.ns();
  const A = window.AGQ, { mob } = A.useW();
  const fyllt = state !== "tom";
  const [f, setF] = React.useState(fyllt
    ? { prog: PROG[1], navn: "Eira Solvang", epost: "eira@demo.no", fod: "2011-03-14", hcp: "18,4", klubb: "Nordre GK", kat: "B2", tier: "Gratis", fNavn: "Kari Solvang", fEpost: "kari@demo.no", fTlf: "", msg: "Velkommen til AK Golf Academy. Vi gleder oss til å trene sammen med deg.", inv: true }
    : { prog: PROG[0], navn: "", epost: "", fod: "", hcp: "", klubb: "", kat: "B2", tier: "Gratis", fNavn: "", fEpost: "", fTlf: "", msg: "Velkommen til AK Golf Academy. Vi gleder oss til å trene sammen med deg.", inv: true });
  const [tried, setTried] = React.useState(false);
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  const alder = f.fod ? Math.floor((Date.UTC(2026, 8, 30) - Date.parse(f.fod)) / 31557600000) : null;
  const barn = alder != null && alder < 18;
  const err = {};
  if (tried) { if (f.navn.trim().length < 2) err.navn = "Navn må være minst 2 tegn."; if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.epost)) err.epost = "Ugyldig e-postadresse."; if (!f.fod) err.fod = "Fødselsdato er påkrevd."; if (barn && f.fNavn.trim().length < 2) err.fNavn = "Foresattes navn er påkrevd under 18 år."; if (barn && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.fEpost)) err.fEpost = "Foresattes e-post er påkrevd under 18 år."; }
  const antall = Object.keys(err).length;
  const Sek = ({ k, aside, children }) => <A.Card gap={12}><A.Head k={k} aside={aside} />{children}</A.Card>;
  const rad = { display: "grid", gridTemplateColumns: mob ? "minmax(0,1fr)" : "repeat(2,minmax(0,1fr))", gap: 12 };
  return <A.Page max={960}>
    <PageHeader kicker="Stall · Ny spiller" title="Ny spiller" sub="Spilleren får invitasjon på e-post hvis du sender den nå. Spillere under 18 trenger en foresatt." actions={<><Button variant="ghost" icon="arrow-left" onClick={() => go("AG-07")}>Avbryt</Button><Button icon="check" onClick={() => setTried(true)}>Opprett spiller</Button></>} />
    <A.Gate state={state} loading="Åpner skjemaet …" error={{ title: "Spilleren ble ikke opprettet", text: "Ingenting er lagret. Prøv igjen.", code: "FEIL 502 · OPPRETT SPILLER" }}>
      {antall > 0 && <InlineAlert tone="warn" title={antall === 1 ? "Ett felt må rettes" : antall + " felt må rettes"}>Spilleren er ikke lagret.</InlineAlert>}
      <Sek k="Identitet" aside="PÅKREVD">
        <Select label="Program" value={f.prog} onChange={(e) => set("prog", e.target.value)} options={PROG} />
        <div style={rad}>
          <FormField label="Fullt navn" required error={err.navn}><TextInput value={f.navn} onChange={(e) => set("navn", e.target.value)} autoComplete="off" /></FormField>
          <FormField label="E-post" required hint="Brukes som innloggings-ID." error={err.epost}><TextInput type="email" value={f.epost} onChange={(e) => set("epost", e.target.value)} placeholder="spiller@demo.no" /></FormField>
          <FormField label="Fødselsdato" required error={err.fod}><TextInput mono type="date" value={f.fod} onChange={(e) => set("fod", e.target.value)} /></FormField>
          <FormField label="Alder"><div style={{ minHeight: 44, display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-num)", color: "var(--text-primary)" }}>{alder == null ? "—" : alder + " år"}</span>{barn && <StatusPill tone="warn">Foresatt påkrevd</StatusPill>}</div></FormField>
        </div>
      </Sek>
      <Sek k="Golf-profil" aside="VALGFRITT">
        <div style={rad}>
          <FormField label="Handicap (HCP)" hint="Bruk komma · f.eks. 12,3"><TextInput mono inputMode="decimal" value={f.hcp} onChange={(e) => set("hcp", e.target.value)} placeholder="—" /></FormField>
          <FormField label="Hjemmeklubb"><TextInput value={f.klubb} onChange={(e) => set("klubb", e.target.value)} /></FormField>
        </div>
        <FormField label="Kategori" hint="Styrer AK Golf-segmenteringen."><Segmented options={KAT.map((k) => k[0])} value={f.kat} onChange={(v) => set("kat", v)} /></FormField>
        <A.Meta>{f.kat + " · " + KAT.find((k) => k[0] === f.kat)[1].toUpperCase()}</A.Meta>
      </Sek>
      <Sek k="App-nivå og foresatte">
        <FormField label="App-nivå"><Segmented options={["Gratis", "Full"]} value={f.tier} onChange={(v) => set("tier", v)} /></FormField>
        <A.Meta>{f.tier === "Full" ? "FULL · PLAYERHQ MED PLANER" : "GRATIS · PLAYERHQ MED RUNDEREGISTRERING OG ENKEL STATISTIKK"}</A.Meta>
        {barn ? <div style={rad}>
          <FormField label="Foresatt: navn" required error={err.fNavn}><TextInput value={f.fNavn} onChange={(e) => set("fNavn", e.target.value)} /></FormField>
          <FormField label="Foresatt: e-post" required error={err.fEpost}><TextInput type="email" value={f.fEpost} onChange={(e) => set("fEpost", e.target.value)} /></FormField>
          <FormField label="Foresatt: telefon (valgfri)"><TextInput mono type="tel" value={f.fTlf} onChange={(e) => set("fTlf", e.target.value)} /></FormField>
        </div> : <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{alder == null ? "Fyll inn fødselsdato for å se om foresatt trengs." : "Spilleren er myndig. Ingen foresatt nødvendig."}</p>}
        {barn && <A.Meta>SAMTYKKE SENDES TIL FORESATT. INGEN DATA DELES FØR DET ER GITT.</A.Meta>}
      </Sek>
      <Sek k="Velkomst">
        <FormField label="Velkomstmelding" hint="Vises i spillerens innboks og i invitasjonen."><textarea rows={4} value={f.msg} onChange={(e) => set("msg", e.target.value)} style={{ minHeight: 96, padding: "10px 12px", width: "100%", boxSizing: "border-box", borderRadius: "var(--radius)", border: "1px solid var(--border-control)", background: "var(--surface-card)", color: "var(--text-primary)", font: "var(--type-body)" }} /></FormField>
        <FormField label="Invitasjon"><Segmented options={["Send nå", "Send senere"]} value={f.inv ? "Send nå" : "Send senere"} onChange={(v) => set("inv", v === "Send nå")} /></FormField>
        <A.Meta>{f.inv ? "SPILLEREN FÅR E-POST MED INNLOGGING NÅR DU OPPRETTER" : "OPPRETT NÅ, INVITER SENERE FRA PROFILEN"}</A.Meta>
      </Sek>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}><Button variant="ghost" onClick={() => go("AG-07")}>Avbryt</Button><Button icon="check" onClick={() => setTried(true)}>{f.inv ? "Opprett og send invitasjon" : "Opprett spiller"}</Button></div>
    </A.Gate>
  </A.Page>;
}
window.AG_SCREENS["AG-07-NY"] = { id: "AG-07-NY", parent: "AG-07", name: "Ny spiller (skjema)", route: "/admin/spillere/ny", Component: AG07NY };
})();
