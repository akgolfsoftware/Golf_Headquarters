/* AG-15 tillegg: Normer (DataGolf-synk) og Tildel test som side. TEGNET I NATT 30.09.2026 av Claude Code fra koden. Anders maa se den (port 7).
   Ikke registrert i katalog.js eller screen.html (delte filer, ikke rort). Data er syntetiske. */
(() => {
const A = () => window.AGQ;
const NORMER = { sist: "28.09.26", ventende: [{ id: "t1", navn: "9 hull lengde", pct: "4,2", why: "Drift over 3 %-grensen fra mandagskjøringen", niv: [["Nivå 1", "180", "184"], ["Nivå 2", "200", "200"], ["Nivå 3", "220", "226"]] }], alle: [["9 hull lengde", "Auto", "datagolf-godkjent-2026-09-21", "180 · 200 · 220"], ["Putt Speed", "Følger driver", "ngf-2026", "1,6 · 1,8 · 2,0"], ["Wedge Gate", "Referanse", "referanse", "10 · 14 · 18"]] };
function AG15Normer({ state }) {
  const AQ = A();
  const { PageHeader, Button, EmptyState, DataTable, InlineAlert } = A().ns(), empty = state === "tom";
  const v = empty ? [] : NORMER.ventende, alle = empty ? [] : NORMER.alle;
  return <AQ.Page>
    <PageHeader kicker="Tester · normer" title="Normer og nivåstiger" sub="Nivåene per test, hentet fra DataGolf hver mandag kl. 08:00. Endringer under 3 % skrives automatisk. Større utslag venter her på godkjenning." actions={<Button variant="secondary" icon="refresh-cw">Kjør synk nå</Button>} />
    <AQ.Gate state={state} loading="Henter testene …" error={{ title: "Testene kunne ikke hentes", text: "Ingenting er endret. Prøv igjen.", code: "FEIL 502 · TESTER" }}>
      {empty ? <EmptyState icon="target" title="Ingen normer ennå" text="Kjør synk for å hente nivåene fra DataGolf, eller legg til tester." /> : <AQ.Stack>
        {v.map((r) => <AQ.Card key={r.id} gap={12}><AQ.Head k={r.navn} aside={r.pct + " % ENDRING"} /><InlineAlert tone="warn" title="Venter på godkjenning.">{r.why}</InlineAlert>
          {r.niv.map(([n, a, b], i) => <div key={n} style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) auto auto auto", gap: 12, alignItems: "center", minHeight: 44, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ font: "500 14px/1.3 var(--font-sans)" }}>{n}</span><span style={{ font: "var(--type-num-s)" }}>{a}</span><span aria-hidden="true">→</span><span style={{ font: "var(--type-num-s)", fontWeight: a === b ? 500 : 700 }}>{b}</span></div>)}
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button icon="check">Godkjenn</Button><Button variant="ghost" icon="x">Avvis og behold dagens</Button></div></AQ.Card>)}
        <DataTable caption={"Tester med norm · " + alle.length} rowKey="n" columns={[{ key: "n", label: "Test" }, { key: "m", label: "Synk" }, { key: "k", label: "Kilde", mono: true }, { key: "v", label: "Nivåer", mono: true, align: "right" }]} rows={alle.map(([n, m, k, vv]) => ({ n, m, k, v: vv }))} />
        <AQ.Meta>{alle.length} TESTER MED NORM · {v.length} VENTER GODKJENNING · POWERED BY DATA GOLF</AQ.Meta>
      </AQ.Stack>}
    </AQ.Gate>
  </AQ.Page>;
}
function AG15TildelSide({ state }) {
  const AQ = A();
  const { PageHeader, Button, AxisBadge, InlineAlert, SearchField, TextInput } = A().ns();
  const [q, setQ] = React.useState(""), [sel, setSel] = React.useState("a");
  const tests = [["a", "9 hull lengde", "Total lengde på ni driver-slag", "SLAG"], ["b", "Putt Speed", "Hastighet på putt fra 3 m", "SPILL"], ["c", "Knebøy 1RM", "", "FYS"], ["d", "Wedge Gate", "Lengdekontroll 50–100 m", "TEK"]];
  return <AQ.Page max={720}>
    <PageHeader kicker="Tester · tildel" title="Tildel test til Test Spiller" sub="Spilleren får varsel i appen. Resultatet teller først når alle forsøk er registrert." />
    <AQ.Gate state={state} loading="Henter testene …" error={{ title: "Testene kunne ikke hentes", text: "Ingenting er endret. Prøv igjen.", code: "FEIL 502 · TESTER" }}>
      <AQ.Stack>
        <AQ.Card gap={12}><AQ.Head k="Velg test" aside="4 I BIBLIOTEKET" /><SearchField value={q} onChange={setQ} placeholder="Søk test" />
          <div role="radiogroup" aria-label="Test" style={{ display: "flex", flexDirection: "column", gap: 8 }}>{tests.filter((t) => t[1].toLowerCase().includes(q.toLowerCase())).map(([id, n, d, ax]) => <button key={id} type="button" role="radio" aria-checked={sel === id} onClick={() => setSel(id)} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", minHeight: 56, padding: "10px 12px", borderRadius: "var(--radius)", border: "1px solid " + (sel === id ? "var(--border-ink)" : "var(--border-hairline)"), display: "grid", gridTemplateColumns: "auto minmax(0,1fr)", gap: 12, alignItems: "center" }}><AxisBadge axis={ax.toLowerCase()} /><span style={{ display: "flex", flexDirection: "column", gap: 2 }}><span style={{ font: "500 14px/1.3 var(--font-sans)" }}>{n}</span>{d && <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{d}</span>}</span></button>)}</div></AQ.Card>
        <AQ.Card gap={12}><label style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-secondary)" }}>Frist (valgfritt)</span><TextInput type="date" /></label>
          <label style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-secondary)" }}>Notat til spilleren (valgfritt)</span><TextInput placeholder="Hva skal spilleren ha i tankene før testen?" /></label>
          <InlineAlert tone="info">Testen ligger i spillerens testliste. Planen endres ikke.</InlineAlert>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button icon="check">Tildel test</Button><Button variant="ghost">Avbryt</Button></div></AQ.Card>
      </AQ.Stack>
    </AQ.Gate>
  </AQ.Page>;
}
window.AG_SCREENS["AG-15-NORMER"] = { id: "AG-15-NORMER", parent: "AG-15", name: "Tester · normer (DataGolf-synk)", route: "/admin/tester/benchmarks", Component: AG15Normer };
window.AG_SCREENS["AG-15-TILDEL"] = { id: "AG-15-TILDEL", parent: "AG-15", name: "Tester · tildel til spiller (side)", route: "/admin/tester/tildel/[spillerId]", Component: AG15TildelSide };
})();
