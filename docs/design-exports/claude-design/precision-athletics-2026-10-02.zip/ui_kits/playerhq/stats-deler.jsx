/* Stats › Strokes Gained · Trening · Tester (runde 22). */
(() => {
const Q_NotEnough = (p) => React.createElement(window.STATSP.NotEnough, p);
const Q_Top = (p) => React.createElement(window.STATSP.Top, p);
const Q_Compare = (p) => React.createElement(window.STATSP.Compare, p);
const Q_NeedTag = (p) => React.createElement(window.STATSP.NeedTag, p);
const Q_Lbl = (p) => React.createElement(window.STATSP.Lbl, p);
const Q_SGBar = (p) => React.createElement(window.STATSP.SGBar, p);
const Q_FilterBar = (p) => React.createElement(window.STATSP.FilterBar, p);
const Q_Sec = (p) => React.createElement(window.STATSP.Sec, p);
const Q_Row = (p) => React.createElement(window.STATSP.Row, p);
const P = () => window.PHQ, ns = () => window.PHQ.ns(), S = () => window.STATS_DATA, Q = () => window.STATSP;
const cmpL = (pga) => pga ? "PGA TOUR" : "KATEGORI C · ESTIMAT";
const allRows = () => S().sg.flatMap((g) => g.rows.map((r) => ({ ...r, g: g.g, gl: g.label })));
const nm = (r) => r.g === "tee" ? "Tee" : r.g === "innspill" ? "Innspill " + r.label : r.g === "putt" ? "Putting " + r.label : r.label;

/* ---------- Strokes Gained ---------- */
function SG({ state, go, pga, setPga, cols }) {
  const Pp = P(), empty = state === "tom", n = empty ? 0 : S().n.rounds, rows = allRows();
  if (empty) return <Q_NotEnough n={0} go={go} what="Strokes Gained" />;
  const v = (r) => pga ? r.pga : r.c;
  const best = rows.filter((r) => r.d != null && r.d > 0).sort((a, b) => b.d - a.d)[0];
  const trend = best && { title: nm(best) + ": " + Pp.sg(best.d) + " slag per runde", meta: "SISTE 10 RUNDER MOT DE 10 FØR · " + S().sgSrc };
  const worst = [...rows].sort((a, b) => v(a) - v(b)).filter((r) => v(r) < 0).slice(0, 5);
  return <>
    <Q_Top trend={trend} losses={worst.map((r) => ({ label: nm(r), v: v(r), meta: r.n + " SLAG" + (pga && r.prox ? " · DU " + Q().d1(r.prox[0]) + " M · PGA " + Q().d1(r.prox[1]) + " M ESTIMAT" : "") }))} lossMeta={"PER RUNDE MOT " + cmpL(pga)} />
    <Q_Compare pga={pga} setPga={setPga} />
    <Pp.Cols tpl={cols}>{[S().sg.slice(0, 2), S().sg.slice(2)].map((gs, ci) => <Pp.Stack key={ci}>{gs.map((g) => { const sum = Math.round(g.rows.reduce((a, r) => a + v(r), 0) * 10) / 10; return <section key={g.g} aria-label={"Strokes Gained " + g.label} className="pa-card" style={{ padding: 16, gap: 8, minWidth: 0 }}>
      <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>{g.label}</span><Q_NeedTag n={n} area={g.g} /><Pp.Num s={{ font: "600 15px/1 var(--font-mono)" }}>{Pp.sg(sum)}</Pp.Num></div>
      <div role="list">{g.rows.map((r, i) => <div role="listitem" key={r.id} aria-label={r.label + " " + Pp.sg(v(r))} style={{ display: "flex", flexDirection: "column", gap: 4, padding: "8px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none", minWidth: 0 }}>
        <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1.1fr) minmax(56px,1fr) auto", gap: 12, alignItems: "center", minHeight: 36 }}><Q_Lbl sub={r.n + " SLAG" + (r.d == null ? "" : " · TREND " + Pp.sg(r.d))}>{r.label}</Q_Lbl><Q_SGBar v={v(r)} /><Pp.Num s={{ font: "600 14px/1 var(--font-mono)", minWidth: 44, textAlign: "right" }}>{Pp.sg(v(r))}</Pp.Num></div>
        {pga && r.prox && <span style={{ font: "400 13px/1.35 var(--font-sans)", color: "var(--text-secondary)" }}>Nærhet til hull fra {r.g === "naer" ? r.label.toLowerCase() : r.label}: PGA {Q().d1(r.prox[1])} m (ESTIMAT), du {Q().d1(r.prox[0])} m</span>}
      </div>)}</div>
    </section>; })}</Pp.Stack>)}</Pp.Cols>
    <Pp.Meta>SG PER RUNDE MED FORTEGN · MØRK STREK = TAP · LYS = GEVINST · {pga ? S().cmp.pga.src : S().cmp.c.src} · HULLKART KOMMER SENERE</Pp.Meta>
  </>;
}

/* ---------- Trening ---------- */
function Spredning({ club }) {
  const Pp = P(), pts = (window.PHQ_AN.tm.shots[club] || []), m = Math.max(4, ...pts.flatMap(([x, y]) => [Math.abs(x), Math.abs(y)])) * 1.15, W = 240, c = W / 2;
  const sx = (x) => c + x / m * (c - 8), sy = (y) => c - y / m * (c - 8);
  const mx = pts.reduce((a, p) => a + p[0], 0) / (pts.length || 1), my = pts.reduce((a, p) => a + p[1], 0) / (pts.length || 1);
  const sdx = Math.sqrt(pts.reduce((a, p) => a + (p[0] - mx) ** 2, 0) / (pts.length || 1)), sdy = Math.sqrt(pts.reduce((a, p) => a + (p[1] - my) ** 2, 0) / (pts.length || 1));
  return <div style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}>
    <svg role="img" aria-label={"Spredning " + club + ": " + pts.length + " slag, sideveis ±" + Q().d1(sdx) + " m, lengde ±" + Q().d1(sdy) + " m"} viewBox={"0 0 " + W + " " + W} style={{ width: "100%", maxWidth: 260, height: "auto", display: "block", margin: "0 auto" }}>
      <rect x="0.5" y="0.5" width={W - 1} height={W - 1} fill="none" stroke="var(--border-hairline)" />
      <line x1={c} y1="0" x2={c} y2={W} stroke="var(--border-hairline)" /><line x1="0" y1={c} x2={W} y2={c} stroke="var(--border-hairline)" />
      <ellipse cx={sx(mx)} cy={sy(my)} rx={sdx / m * (c - 8) * 2} ry={sdy / m * (c - 8) * 2} fill="none" stroke="var(--text-muted)" strokeDasharray="4 3" />
      {pts.map(([x, y], i) => <circle key={i} cx={sx(x)} cy={sy(y)} r="3.5" fill="var(--text-primary)" fillOpacity=".7" />)}
    </svg>
    <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><Pp.Meta>SIDE ±{Q().d1(sdx)} M</Pp.Meta><Pp.Meta>LENGDE ±{Q().d1(sdy)} M</Pp.Meta><Pp.Meta>STIPLET = 2 SD</Pp.Meta></div>
  </div>;
}
function Trening({ state, go, cols }) {
  const Pp = P(), { EmptyState, ChoicePill, AxisBadge } = ns(), empty = state === "tom", T = S().tren, Y = S().pyr, TM = S().tm, AX = { fys: "FYS", tek: "TEK", slag: "SLAG", spill: "SPILL", turn: "TURN" };
  const [f, setF] = Q().useFilters(), [club, setClub] = React.useState("7i");
  if (empty) return <><Q_FilterBar f={f} setF={setF} empty /><EmptyState icon="activity" title="Ingen trening registrert ennå" text="Treningsmengde, TrackMan og pyramidefordeling vises når du har logget økter. Bygg øktene i Plan, eller importer fra TrackMan." action="Bygg økter i Workbench" actionIcon="layers" onAction={() => go("PH-11")} secondary="Velg treningsplan" onSecondary={() => go("PH-12")} /></>;
  const rows = allRows(), best = [...T].sort((a, b) => b.d - a.d)[0];
  const hOf = (id) => (T.find((t) => t.id === id) || {}).h;
  const worst = [...rows].sort((a, b) => a.c - b.c).slice(0, 3);
  const maxH = Math.max(...T.map((t) => t.h)) || 1;
  const gap = Y.rows.map(([a, u, p]) => ({ a, u, p, g: Math.abs(u - p) })).sort((x, y) => y.g - x.g)[0];
  return <>
    <Q_Top trend={{ title: best.label + ": " + P().sg(best.d) + " slag per runde etter " + Q().d1(best.h) + " t trening", meta: "SISTE 10 RUNDER MOT DE 10 FØR · " + S().trenSrc }} losses={worst.map((r) => ({ label: nm(r), v: r.c, meta: (hOf(r.id) == null ? "—" : Q().d1(hOf(r.id)) + " T") + " TRENT SISTE 8 UKER" }))} lossMeta="MOT KATEGORI C · ESTIMAT" />
    <Q_FilterBar f={f} setF={setF} />
    <Pp.Cols tpl={cols}>
      <Pp.Stack>
        <Q_Sec k="Treningsmengde mot SG-utvikling" meta={S().trenSrc} label="Treningsmengde mot SG">
          <div role="list">{T.map((t, i) => <Q_Row key={t.id} first={!i} tpl="minmax(0,1fr) minmax(64px,0.8fr) auto" label={t.label + " " + Q().d1(t.h) + " timer, SG " + P().sg(t.d)}>
            <Q_Lbl sub={Q().d1(t.h) + " T"}>{t.label}</Q_Lbl>
            <span aria-hidden="true" style={{ height: 8, background: "var(--surface-sunken)", position: "relative" }}><span style={{ position: "absolute", inset: 0, width: (t.h / maxH * 100) + "%", background: "var(--primary)" }}></span></span>
            <Pp.Num s={{ font: "600 14px/1 var(--font-mono)", minWidth: 44, textAlign: "right" }}>{P().sg(t.d)}</Pp.Num>
          </Q_Row>)}</div>
          <Pp.Meta>STREK = TIMER TRENT · TALL = SG-ENDRING SISTE 10 MOT 10 FØR</Pp.Meta>
        </Q_Sec>
        <Q_Sec k="Pyramide mot ønsket" meta={"SISTE 8 UKER · " + Q().d1(Y.hours) + " T"} label="Pyramidefordeling">
          <p style={{ margin: 0, font: "500 15px/1.4 var(--font-sans)", color: "var(--text-primary)", textWrap: "pretty" }}>Du trener {gap.u} % {AX[gap.a]}, planen sier {gap.p} %.</p>
          <div role="list">{Y.rows.map(([a, u, p], i) => <Q_Row key={a} first={!i} tpl="64px minmax(0,1fr) auto" label={AX[a] + " " + u + " prosent, plan " + p + " prosent"}>
            <span><AxisBadge axis={a} size="sm" /></span>
            <span aria-hidden="true" style={{ position: "relative", height: 8, background: "var(--surface-sunken)" }}><span style={{ position: "absolute", top: 0, bottom: 0, left: 0, width: (u / 50 * 100) + "%", background: "var(--primary)" }}></span><span style={{ position: "absolute", top: -4, bottom: -4, width: 2, left: "calc(" + (p / 50 * 100) + "% - 1px)", background: "var(--text-muted)" }}></span></span>
            <Pp.Num s={{ font: "var(--type-num-s)", textAlign: "right" }}>{u} / {p} %</Pp.Num>
          </Q_Row>)}</div>
          <Pp.Meta>STREK = DU · MERKE = PLAN · {Y.src}</Pp.Meta><Pp.Meta>{Y.planSrc}</Pp.Meta>
        </Q_Sec>
      </Pp.Stack>
      <Q_Sec k="TrackMan · spredning og parametere" meta={TM.n[club] + " SLAG · " + TM.src} label="TrackMan">
        <div role="group" aria-label="Kølle" style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{TM.clubs.map((c) => <ChoicePill key={c} selected={club === c} onClick={() => setClub(c)}>{c}</ChoicePill>)}</div>
        <Spredning club={club} />
        <div role="list">{TM.params[club].map(([k, u, avg, sd, mal], i) => <Q_Row key={k} first={!i} tpl="minmax(0,1fr) auto auto" label={k}>
          <Q_Lbl sub={mal ? "MÅL " + mal.toUpperCase() : "MÅL —"}>{k}</Q_Lbl>
          <Pp.Num s={{ font: "600 14px/1 var(--font-mono)", textAlign: "right" }}>{(avg > 0 && u === "°" ? "+" : "") + Q().d1(avg)}{u === "°" ? "°" : " " + u}</Pp.Num>
          <Pp.Meta s={{ minWidth: 56, textAlign: "right" }}>±{Q().d1(sd)}</Pp.Meta>
        </Q_Row>)}</div>
        <Pp.Meta>SNITT · ±1 SD · {TM.malSrc}</Pp.Meta>
      </Q_Sec>
    </Pp.Cols>
  </>;
}

/* ---------- Tester ---------- */
function testFmt(t, v) { return v == null ? "—" : (t.dec ? Q().d1(v, t.dec) : String(v)) + " " + t.unit; }
function Tester({ state, go, wide }) {
  const Pp = P(), { EmptyState, Sheet, Button, Sparkline } = ns(), empty = state === "tom", L = S().tests;
  const [open, setOpen] = React.useState(null);
  if (empty) return <EmptyState icon="clipboard-check" title="Ingen tester tatt ennå" text="Tester viser siste resultat, snitt, progresjon og nivå mot neste kategori. Start med Team Norway-testbatteriet sammen med Anders." action="Gjennomfør test" actionIcon="play" onAction={() => go("PH-15")} />;
  const avg = (t) => t.hist.reduce((a, b) => a + b, 0) / t.hist.length, last = (t) => t.hist[t.hist.length - 1];
  const rel = (t) => (last(t) - t.hist[0]) / Math.abs(t.hist[0] || 1);
  const best = [...L].sort((a, b) => rel(b) - rel(a))[0];
  const far = L.filter((t) => t.norm != null).map((t) => ({ t, g: (t.norm - last(t)) / t.norm })).filter((x) => x.g > 0).sort((a, b) => b.g - a.g);
  return <>
    <Q_Top trend={{ title: best.name + ": fra " + testFmt(best, best.hist[0]) + " til " + testFmt(best, last(best)), meta: best.hist.length + " TESTER · " + best.dates[0] + "–" + best.dates[best.dates.length - 1] + ".2026 · " + best.src }} lossK="Lengst fra Kategori C" losses={far.map(({ t }) => ({ label: t.name, valText: testFmt(t, last(t)), meta: "NORM " + testFmt(t, t.norm).toUpperCase() + " · ESTIMAT" }))} lossMeta="SISTE RESULTAT" />
    <section aria-label="Tester" className="pa-card" style={{ padding: 16, gap: 4, minWidth: 0 }}>
      <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>Tester</span><Pp.Meta>ETT BATTERI · AK GOLF · WANG · TEAM NORWAY · {L.length} TESTER</Pp.Meta></div>
      <div role="list">{L.map((t, i) => { const l = last(t), d = l - t.hist[t.hist.length - 2], gapN = t.norm == null ? null : t.norm - l; return <button key={t.id} type="button" role="listitem" onClick={() => setOpen(t)} aria-label={t.name + " siste " + testFmt(t, l)} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", width: "100%", display: "grid", gridTemplateColumns: wide ? "minmax(0,1.4fr) repeat(4,minmax(0,1fr)) minmax(72px,0.8fr)" : "minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 64, borderTop: i ? "1px solid var(--border-hairline)" : "none", padding: "8px 0" }}>
        <Q_Lbl sub={t.sub.toUpperCase() + " · " + t.by.toUpperCase()}>{t.name}</Q_Lbl>
        {wide ? <>
          <span style={{ display: "flex", flexDirection: "column", gap: 2 }}><Pp.Meta>SISTE</Pp.Meta><Pp.Num s={{ font: "600 14px/1 var(--font-mono)" }}>{testFmt(t, l)}</Pp.Num></span>
          <span style={{ display: "flex", flexDirection: "column", gap: 2 }}><Pp.Meta>SNITT</Pp.Meta><Pp.Num s={{ font: "var(--type-num-s)" }}>{testFmt(t, Math.round(avg(t) * 10) / 10).replace(/(\d)\.(\d)/, "$1,$2")}</Pp.Num></span>
          <span style={{ display: "flex", flexDirection: "column", gap: 2 }}><Pp.Meta>NIVÅ A–K</Pp.Meta><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{t.lvl ? "Kategori " + t.lvl : "—"}</span><Pp.Meta>{gapN == null ? "C: —" : gapN <= 0 ? "PÅ C" : "C: " + testFmt(t, t.norm).toUpperCase()}</Pp.Meta></span>
          <span style={{ display: "flex", flexDirection: "column", gap: 2 }}><Pp.Meta>LANDSLAG {S().tnClass}</Pp.Meta><Pp.Num s={{ font: "var(--type-num-s)" }}>{S().isTN ? testFmt(t, t.tn) : "—"}</Pp.Num></span>
          <span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><Sparkline values={t.hist} height={24} label={"Progresjon " + t.name} /><Pp.Meta>{(d > 0 ? "+" : d < 0 ? "−" : "±") + (t.dec ? Q().d1(Math.abs(d)) : Math.abs(d))} SIST</Pp.Meta></span>
        </> : <span style={{ display: "flex", flexDirection: "column", gap: 3, alignItems: "flex-end" }}><Pp.Num s={{ font: "600 15px/1 var(--font-mono)" }}>{testFmt(t, l)}</Pp.Num><Pp.Meta>{"NIVÅ " + (t.lvl || "—") + " · " + (S().isTN ? S().tnClass + ": " + (t.tn == null ? "—" : testFmt(t, t.tn).toUpperCase()) : "C: " + (t.norm == null ? "—" : testFmt(t, t.norm).toUpperCase()))}</Pp.Meta></span>}
      </button>; })}</div>
      <Pp.Meta>KONTROLLERT = COACHREGISTRERT · EGENREGISTRERT = SPILLERREGISTRERT · {S().normSrc}{S().isTN ? " · " + S().tnSrc : ""} · VITNEGODKJENNING KOMMER SENERE</Pp.Meta>
    </section>
    {open && <Sheet open onClose={() => setOpen(null)} kicker={"Test · " + open.sub} title={open.name} footer={<><Button fullWidth icon="play" onClick={() => go("PH-15")}>Gjennomfør test</Button><Button variant="ghost" fullWidth onClick={() => setOpen(null)}>Lukk</Button></>}>
      <div role="list">{[["Siste resultat", testFmt(open, last(open))], ["Snitt", testFmt(open, Math.round(avg(open) * 10) / 10).replace(/(\d)\.(\d)/, "$1,$2")], ["Progresjon", testFmt(open, open.hist[0]) + " → " + testFmt(open, last(open))], ["Nivå A–K", open.lvl ? "Kategori " + open.lvl : "—"], ["Norm Kategori C", open.norm == null ? "—" : testFmt(open, open.norm) + " · ESTIMAT"], ...(S().isTN ? [["Landslagsnivå " + S().tnClass, open.tn == null ? "—" : testFmt(open, open.tn) + " · ESTIMAT"]] : []), ["Registrert", open.by === "Kontrollert" ? "Kontrollert · coachregistrert" : "Egenregistrert · spillerregistrert"]].map(([k, v], i) => <Q_Row key={k} first={!i} min={44} label={k}><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{k}</span><Pp.Num s={{ font: "600 14px/1 var(--font-mono)" }}>{v}</Pp.Num></Q_Row>)}</div>
      <Sparkline values={open.hist} height={48} label={"Progresjon " + open.name} />
      <div role="list">{open.hist.map((v, i) => ({ v, d: open.dates[i] })).reverse().map(({ v, d }, i) => <Q_Row key={d} first={!i} min={40} label={d}><Pp.Num s={{ font: "var(--type-num-s)" }}>{d}.2026</Pp.Num><Pp.Num s={{ font: "600 14px/1 var(--font-mono)" }}>{testFmt(open, v)}</Pp.Num></Q_Row>)}</div>
      <Pp.Meta>KILDE {open.src} · {open.norm == null ? "NORM MANGLER FOR DENNE TESTEN" : S().normSrc} · VITNEGODKJENNING KOMMER SENERE</Pp.Meta>
    </Sheet>}
  </>;
}
const TesterTN = (p) => <>{React.createElement(Tester, p)}{p.state !== "tom" && window.TN_SKALA ? React.createElement(window.TN_SKALA, { Meta: P().Meta }) : null}</>;
window.STATS_DELER = { SG, Trening, Tester: TesterTN };
})();
