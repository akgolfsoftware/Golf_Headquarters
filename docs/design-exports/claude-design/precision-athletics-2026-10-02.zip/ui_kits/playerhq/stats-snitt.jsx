/* Stats › Snittscore (runde 22): øverst trend og tapte slag · kategori A–K med «X slag til neste kategori» ·
   Ytelsesbilde samlet (krever samtykke) · Tiger 5 · runder med scorekort og Ytelsesbilde per runde · turneringsresultater fra AK Golf pipelines. */
(() => {
const Q_Sec = (p) => React.createElement(window.STATSP.Sec, p);
const Q_Row = (p) => React.createElement(window.STATSP.Row, p);
const Q_Lbl = (p) => React.createElement(window.STATSP.Lbl, p);
const Q_Muted = (p) => React.createElement(window.STATSP.Muted, p);
const Q_Radar = (p) => React.createElement(window.STATSP.Radar, p);
const Q_NotEnough = (p) => React.createElement(window.STATSP.NotEnough, p);
const Q_Top = (p) => React.createElement(window.STATSP.Top, p);
const Q_Compare = (p) => React.createElement(window.STATSP.Compare, p);
const P = () => window.PHQ, ns = () => window.PHQ.ns(), S = () => window.STATS_DATA, Q = () => window.STATSP;
const CATS = () => window.AK_VOCAB.CATEGORIES;
const t5sum = (t) => t ? Object.values(t).reduce((a, b) => a + b, 0) : null;
const groupSum = (pga) => S().sg.map((g) => ({ label: g.label, v: Math.round(g.rows.reduce((a, r) => a + (pga ? r.pga : r.c), 0) * 10) / 10, n: g.rows.reduce((a, r) => a + r.n, 0), g: g.g }));

function Kategori({ empty }) {
  const Pp = P(), s = S().snitt, C = CATS(), ci = C.findIndex((c) => s.avg < c[2]), cur = C[ci], nxt = C[ci - 1];
  const gap = Math.round((s.avg - nxt[2] + 0.1) * 10) / 10;
  const LO = 64, HI = 100, X = (v) => (Math.min(HI, Math.max(LO, v)) - LO) / (HI - LO) * 100;
  return <Q_Sec k="Kategori A–K" meta={empty ? "—" : s.src} label="Kategori">
    <div style={{ display: "flex", alignItems: "baseline", gap: 12, flexWrap: "wrap" }}><span style={{ font: "600 44px/1 var(--font-mono)", fontVariantNumeric: "tabular-nums", color: "var(--text-primary)" }}>{empty ? "—" : Q().d1(s.avg)}</span><span style={{ font: "500 15px/1.3 var(--font-sans)", color: "var(--text-secondary)" }}>{empty ? "slag i snitt" : "slag i snitt · Kategori " + cur[0] + " · " + cur[1]}</span></div>
    <p style={{ margin: 0, font: "600 17px/1.35 var(--font-sans)", color: "var(--text-primary)" }}>{empty ? "Registrer 4 runder til for å få kategori." : Q().d1(gap) + " slag til Kategori " + nxt[0]}</p>
    <div aria-hidden="true" style={{ position: "relative", paddingTop: 14 }}>
      {!empty && <span style={{ position: "absolute", top: 0, left: "calc(" + X(s.avg) + "% - 1px)", width: 2, height: 40, background: "var(--text-primary)" }}></span>}
      <div style={{ display: "flex", gap: 2, height: 24 }}>{C.map((c, i) => { const a = i === 0 ? LO : C[i - 1][2], b = Math.min(HI, c[2] === Infinity ? HI : c[2]); if (b <= a) return null; const me = !empty && i === ci, nx = !empty && i === ci - 1; return <span key={c[0]} style={{ flex: b - a, minWidth: 0, display: "grid", placeItems: "center", background: me ? "var(--primary)" : nx ? "var(--graphite-400)" : "var(--surface-sunken)", color: me || nx ? "var(--text-on-primary)" : "var(--text-muted)", font: "600 11px/1 var(--font-sans)" }}>{c[0]}</span>; })}</div>
    </div>
    <div style={{ display: "flex", justifyContent: "space-between" }}>{[64, 72, 80, 90, 100].map((v) => <Pp.Meta key={v}>{v}</Pp.Meta>)}</div>
    {!empty && <><div><Pp.Meta>SNITT SISTE 8 MÅNEDER</Pp.Meta><div style={{ marginTop: 6 }}>{React.createElement(ns().Sparkline, { values: s.trend.map((x) => -x), height: 36, label: "Snittscore over tid, lavere er bedre" })}</div></div><Pp.Meta>KATEGORI {nxt[0]} KREVER SNITT UNDER {Q().d1(nxt[2])} · KILDE AK-KATEGORI 2026</Pp.Meta></>}
  </Q_Sec>;
}

function ybAvg(rs) { const F = S().ybFactors, l = rs.filter((r) => r.yb); if (!l.length) return null; return Object.fromEntries(F.map(([k]) => [k, l.reduce((a, r) => a + r.yb[k], 0) / l.length])); }
function YbSamlet({ consent, empty, go }) {
  const Pp = P(), { EmptyState, Button } = ns();
  if (!consent) return <Q_Sec k="Ytelsesbilde" meta="IKKE AKTIVERT" label="Ytelsesbilde">
    <Q_Muted>Ytelsesbildet viser hva som påvirket runden utenom svingen: fysisk form, mentalt, miljø, søvn og mat. Det krever at du samtykker til at disse opplysningene lagres og deles med Anders.</Q_Muted>
    <div><Button variant="secondary" icon="shield-check" onClick={() => go("PH-25")}>Les om samtykke</Button></div>
  </Q_Sec>;
  const av = ybAvg(S().rounds), F = S().ybFactors, low = F.map(([k, l]) => [k, l, av[k]]).sort((a, b) => a[2] - b[2])[0];
  return <Q_Sec k="Ytelsesbilde · samlet" meta={S().ybSrc} label="Ytelsesbilde samlet">
    <Q_Radar vals={av} base={{ tek: 5, fys: 5, men: 5, sos: 5, sov: 5 }} label={"Ytelsesbilde snitt: " + F.map(([k, l]) => l + " " + Q().d1(av[k])).join(", ")} />
    <p style={{ margin: 0, font: "500 15px/1.4 var(--font-sans)", color: "var(--text-primary)", textWrap: "pretty" }}>Lavest i snitt: {low[1].toLowerCase()} ({Q().d1(low[2])} av 5). Energifall kom i 6 av 8 runder, oftest fra hull 12–15.</p>
    <Pp.Meta>SKALA 1–5 · STIPLET = 5 · TRYKK EN RUNDE FOR YTELSESBILDET</Pp.Meta>
  </Q_Sec>;
}

function Tiger({ empty }) {
  const Pp = P(), L = S().t5Labels, T = S().t5Season, rs = S().rounds;
  const tot = Object.keys(T).filter((k) => k !== "rounds" && k !== "src").reduce((a, k) => a + T[k], 0);
  return <Q_Sec k="Tiger 5" meta={empty ? "—" : tot + " I SESONGEN · " + Q().d1(tot / T.rounds) + " PER RUNDE"} label="Tiger 5">
    <div role="list">{L.map(([k, l], i) => <Q_Row key={k} first={!i} tpl="minmax(0,1fr) auto auto" label={l}><Q_Lbl>{l}</Q_Lbl><Pp.Meta>{empty ? "—" : Q().d1(T[k] / T.rounds) + " / RUNDE"}</Pp.Meta><Pp.Num s={{ font: "600 15px/1 var(--font-mono)", minWidth: 32, textAlign: "right" }}>{empty ? "—" : T[k]}</Pp.Num></Q_Row>)}</div>
    <Pp.Meta>{empty ? "—" : "SUM " + T.src + " · SISTE RUNDE " + t5sum(rs[0].t5)}</Pp.Meta>
  </Q_Sec>;
}

function Runder({ onOpen, pga }) {
  const Pp = P(), rs = S().rounds;
  return <Q_Sec k="Runder" meta={"10 SISTE AV " + S().n.rounds + " · SG MOT " + (pga ? "PGA TOUR" : "KATEGORI C · ESTIMAT")} label="Runder" gap={4}>
    <div role="list">{rs.map((r, i) => <button key={r.id} type="button" role="listitem" onClick={() => onOpen(r)} aria-label={r.date + " " + r.course + " " + r.score + " slag"} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", width: "100%", display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 60, borderTop: i ? "1px solid var(--border-hairline)" : "none", padding: "8px 0" }}>
      <span style={{ display: "flex", flexDirection: "column", gap: 3, minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{r.turn ? r.turn.name : r.course}</span><Pp.Meta>{r.date.slice(0, 5)} · {r.turn ? r.course.toUpperCase() : r.kind.toUpperCase()} · TIGER 5: {t5sum(r.t5)}{r.yb ? "" : " · YTELSESBILDE —"}</Pp.Meta></span>
      <span style={{ display: "flex", flexDirection: "column", gap: 3, alignItems: "flex-end" }}><Pp.Num s={{ font: "600 15px/1 var(--font-mono)" }}>{r.score} ({Pp.toPar(r.score - r.par)})</Pp.Num><Pp.Meta>SG {Pp.sg(pga ? r.sg - 2.1 : r.sg)}{pga ? " · ESTIMAT" : ""}</Pp.Meta></span>
    </button>)}</div>
  </Q_Sec>;
}

function Turneringer() {
  const Pp = P(), l = S().rounds.filter((r) => r.turn);
  return <Q_Sec k="Turneringsresultater" meta="AK GOLF PIPELINES" label="Turneringsresultater">
    <div role="list">{l.map((r, i) => <Q_Row key={r.id} first={!i} label={r.turn.name}><Q_Lbl sub={r.turn.src}>{r.turn.name} · {r.course}</Q_Lbl><span style={{ display: "flex", flexDirection: "column", gap: 3, alignItems: "flex-end" }}><Pp.Num s={{ font: "600 15px/1 var(--font-mono)" }}>{r.score} ({Pp.toPar(r.score - r.par)})</Pp.Num><Pp.Meta>{r.turn.place.toUpperCase()}</Pp.Meta></span></Q_Row>)}</div>
  </Q_Sec>;
}

function Scorekort({ r }) {
  const Pp = P(), half = (a) => [a.slice(0, 9), a.slice(9)];
  const [pf, pb] = half(r.pars), [sf, sb] = half(r.card);
  const cell = (s, p) => { const d = s - p; return { font: "600 13px/1 var(--font-mono)", color: "var(--text-primary)", display: "grid", placeItems: "center", height: 28, borderRadius: d < 0 ? 999 : 2, boxShadow: d < 0 ? "inset 0 0 0 1.5px var(--text-primary)" : d === 1 ? "inset 0 0 0 1.5px var(--text-muted)" : d >= 2 ? "inset 0 0 0 1.5px var(--text-muted), inset 0 0 0 3.5px var(--surface-card), inset 0 0 0 5px var(--text-muted)" : "none" }; };
  const Block = ({ lab, off, pars, sc }) => <div role="table" aria-label={"Scorekort " + lab} style={{ display: "grid", gridTemplateColumns: "44px repeat(9,minmax(0,1fr)) 36px", rowGap: 4, columnGap: 2, alignItems: "center", minWidth: 0 }}>
    <Pp.Meta>HULL</Pp.Meta>{pars.map((_, i) => <Pp.Meta key={i} s={{ textAlign: "center" }}>{off + i + 1}</Pp.Meta>)}<Pp.Meta s={{ textAlign: "center" }}>{lab.toUpperCase()}</Pp.Meta>
    <Pp.Meta>PAR</Pp.Meta>{pars.map((p, i) => <Pp.Meta key={i} s={{ textAlign: "center" }}>{p}</Pp.Meta>)}<Pp.Meta s={{ textAlign: "center" }}>{pars.reduce((a, b) => a + b, 0)}</Pp.Meta>
    <Pp.Meta>SLAG</Pp.Meta>{sc.map((s, i) => <span key={i} style={cell(s, pars[i])}>{s}</span>)}<span style={{ font: "600 13px/1 var(--font-mono)", textAlign: "center", color: "var(--text-primary)" }}>{sc.reduce((a, b) => a + b, 0)}</span>
  </div>;
  return <div style={{ display: "flex", flexDirection: "column", gap: 12 }}><Block lab="Ut" off={0} pars={pf} sc={sf} /><Block lab="Inn" off={9} pars={pb} sc={sb} /><Pp.Meta>RING = BIRDIE · FIRKANT = BOGEY · DOBBEL = DOBBELTBOGEY ELLER VERRE</Pp.Meta></div>;
}

function RoundSheet({ r, onClose, consent, go }) {
  const { Sheet, Button } = ns(), Pp = P(), F = S().ybFactors, L = S().t5Labels;
  if (!r) return null;
  const yb = r.yb;
  const H = ({ children, meta }) => <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap", borderTop: "1px solid var(--border-hairline)", paddingTop: 12 }}><span className="kicker" style={{ flex: "1 1 auto" }}>{children}</span>{meta && <Pp.Meta>{meta}</Pp.Meta>}</div>;
  return <Sheet open onClose={onClose} kicker={r.date + " · " + r.course + " · " + (r.turn ? r.turn.name : r.kind)} title={r.score + " slag (" + Pp.toPar(r.score - r.par) + ")"} footer={<><Button variant="secondary" fullWidth icon="pencil" onClick={() => go("PH-RD-09")}>Rediger runde</Button><Button variant="ghost" fullWidth onClick={onClose}>Lukk</Button></>}>
    <Scorekort r={r} />
    <KV rows={[["SG Tee · ESTIMAT", P().sg(r.sg * 0.05)], ["SG Innspill · ESTIMAT", P().sg(r.sg * 0.45)], ["SG Nærspill · ESTIMAT", P().sg(r.sg * 0.22)], ["SG Putting · ESTIMAT", P().sg(r.sg * 0.28)], ["SG totalt mot Kategori C", P().sg(r.sg) + " · ESTIMAT"], ["Kilde", (r.turn ? "GolfBox via AK Golf pipelines" : "Manuell") + " · " + r.date]]} />
    <H meta={t5sum(r.t5) + " AV 5 TYPER"}>Tiger 5</H>
    <div role="list">{L.map(([k, l], i) => <Q_Row key={k} first={!i} min={40} label={l}><span style={{ font: "400 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{l}</span><Pp.Num s={{ font: "600 14px/1 var(--font-mono)" }}>{r.t5[k]}</Pp.Num></Q_Row>)}</div>
    <H meta={yb ? "FYLT UT ETTER RUNDEN" : null}>Ytelsesbilde</H>
    {!consent ? <Q_Muted>Ytelsesbilde er ikke aktivert. Det krever samtykke.</Q_Muted> : !yb ? <><Q_Muted>Ikke fylt ut for denne runden.</Q_Muted><div><Button variant="secondary" icon="pencil" onClick={() => Pp.toast("Ytelsesbilde åpnet", r.date + " · " + r.course.toUpperCase())}>Fyll ut ytelsesbilde</Button></div></> : <>
      <Q_Radar vals={yb} size={200} base={{ tek: 5, fys: 5, men: 5, sos: 5, sov: 5 }} label={"Ytelsesbilde: " + F.map(([k, l]) => l + " " + yb[k]).join(", ")} />
      <div role="list">{F.map(([k, l], i) => <Q_Row key={k} first={!i} min={40} tpl="minmax(0,1fr) 96px auto" label={l + " " + yb[k] + " av 5"}><span style={{ font: "400 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{l}</span><span aria-hidden="true" style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 2 }}>{[1, 2, 3, 4, 5].map((n) => <span key={n} style={{ height: 8, background: n <= yb[k] ? "var(--primary)" : "var(--surface-sunken)" }}></span>)}</span><Pp.Num s={{ font: "600 14px/1 var(--font-mono)" }}>{yb[k]}</Pp.Num></Q_Row>)}</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        <span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{yb.energy ? "Energifall fra hull " + yb.energy : "Ingen energifall"}</span>
        <div role="img" aria-label={yb.energy ? "Energi lav fra hull " + yb.energy + " til 18" : "Jevn energi alle hull"} style={{ display: "grid", gridTemplateColumns: "repeat(18,minmax(0,1fr))", gap: 2 }}>{Array.from({ length: 18 }, (_, i) => <span key={i} style={{ height: 16, background: yb.energy && i + 1 >= yb.energy ? "var(--surface-sunken)" : "var(--primary)" }}></span>)}</div>
        <div style={{ display: "flex", justifyContent: "space-between" }}><Pp.Meta>HULL 1</Pp.Meta><Pp.Meta>MØRK = ENERGI OK · LYS = LAV</Pp.Meta><Pp.Meta>18</Pp.Meta></div>
      </div>
      <KV rows={[["Søvn natta før", Q().d1(yb.sleep) + " t"], ["Mat og drikke", yb.food.length ? yb.food.join(" · ") : "—"]]} />
    </>}
  </Sheet>;
}
const KV = ({ rows }) => <div role="list">{rows.map(([k, v], i) => <Q_Row key={k} first={!i} min={40} label={k}><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{k}</span><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", textAlign: "right" }}>{v}</span></Q_Row>)}</div>;

function Snittscore({ state, go, pga, setPga, consent, openId, cols }) {
  const Pp = P(), empty = state === "tom", s = S().snitt, n = empty ? 0 : S().n.rounds;
  const [open, setOpen] = React.useState(() => openId ? S().rounds.find((r) => r.id === openId) : null);
  const gs = groupSum(pga).sort((a, b) => a.v - b.v).filter((g) => g.v < 0);
  const trend = empty ? null : { title: "Snittscoren er ned " + Q().d1(s.prev - s.avg) + " slag", meta: Q().d1(s.avg) + " SISTE 10 RUNDER MOT " + Q().d1(s.prev) + " DE 10 FØR · " + s.src };
  return <>
    {empty ? <Q_NotEnough n={0} go={go} what="Snittscore, kategori og Tiger 5" /> : <Q_Top trend={trend} losses={gs.map((g) => ({ label: g.label, v: g.v, meta: g.n + " SLAG I GRUNNLAGET" }))} lossMeta={"SLAG PER RUNDE MOT " + (pga ? "PGA TOUR" : "KATEGORI C · ESTIMAT")} />}
    {!empty && <Q_Compare pga={pga} setPga={setPga} />}
    <Pp.Cols tpl={cols}>
      <Pp.Stack><Kategori empty={empty} />{!empty && <Runder onOpen={setOpen} pga={pga} />}</Pp.Stack>
      <Pp.Stack><YbSamlet consent={consent && !empty} empty={empty} go={go} />{!empty && <Tiger empty={empty} />}{!empty && <Turneringer />}</Pp.Stack>
    </Pp.Cols>
    {open && <RoundSheet r={open} consent={consent} onClose={() => setOpen(null)} go={go} />}
  </>;
}
window.STATS_SNITT = { Snittscore, groupSum };
})();
