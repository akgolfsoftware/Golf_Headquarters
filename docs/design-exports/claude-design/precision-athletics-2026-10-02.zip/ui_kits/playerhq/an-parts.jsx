(() => {
const P = () => window.PHQ;
const sgc = (v) => v == null ? "—" : (v > 0.04 ? "+" : v < -0.04 ? "−" : "±") + Math.abs(v).toFixed(1).replace(".", ",");
/* Divergerende SG-stolpe. Grafitt for alle verdier — fortegnet bærer betydningen, ikke fargen. */
function SGBar({ label, sub, v, max = 1.5 }) {
  const w = v == null ? 0 : Math.min(50, Math.abs(v) / max * 50);
  return <div style={{ display: "grid", gridTemplateColumns: "minmax(64px,120px) minmax(0,1fr) 56px", gap: 12, alignItems: "center", minHeight: 44 }}>
    <span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "600 13px/1 var(--font-mono)", color: "var(--text-primary)" }}>{label}</span>{sub && <span style={{ font: "var(--type-body-s)", fontSize: 12, color: "var(--text-muted)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{sub}</span>}</span>
    <span style={{ position: "relative", height: 14, background: "var(--surface-sunken)" }} aria-hidden="true">
      <span style={{ position: "absolute", left: "50%", top: -4, bottom: -4, width: 1, background: "var(--border-ink)" }}></span>
      {v != null && <span style={{ position: "absolute", top: 0, bottom: 0, background: v < 0 ? "var(--text-secondary)" : "var(--text-primary)", left: v < 0 ? (50 - w) + "%" : "50%", width: w + "%", transition: "left 200ms var(--ease-out), width 200ms var(--ease-out), top 200ms var(--ease-out), opacity 200ms var(--ease-out)" }}></span>}
    </span>
    <span style={{ font: "600 15px/1 var(--font-mono)", color: "var(--text-primary)", textAlign: "right" }}>{sgc(v)}</span>
  </div>;
}
const Src = ({ children, est }) => <span style={{ display: "inline-flex", gap: 8, alignItems: "center", flexWrap: "wrap", font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)" }}>{children}{est && <span style={{ padding: "2px 6px", borderRadius: 4, border: "1px solid var(--border-strong)", color: "var(--text-secondary)" }}>ESTIMAT</span>}</span>;
const DG = () => <span style={{ display: "inline-flex", alignItems: "center", gap: 6, font: "500 11px/1 var(--font-sans)", color: "var(--text-secondary)", padding: "4px 8px", borderRadius: 4, border: "1px solid var(--border-hairline)", background: "var(--surface-flat)" }}>Powered by Data Golf</span>;
/* Spredningskart: x = sideavvik (m), y = lengdeavvik (m). */
function Scatter({ pts, range = 6, label, height = 280 }) {
  const n = pts.length, mx = n ? pts.reduce((a, p) => a + p[0], 0) / n : 0, my = n ? pts.reduce((a, p) => a + p[1], 0) / n : 0;
  const sx = n ? Math.sqrt(pts.reduce((a, p) => a + (p[0] - mx) ** 2, 0) / n) : 0, sy = n ? Math.sqrt(pts.reduce((a, p) => a + (p[1] - my) ** 2, 0) / n) : 0;
  const S = 100 / range;
  return <div style={{ position: "relative", width: "100%", height, background: "var(--surface-flat)", borderRadius: 8, border: "1px solid var(--border-hairline)", overflow: "hidden" }}>
    <svg viewBox="-100 -100 200 200" preserveAspectRatio="xMidYMid meet" style={{ position: "absolute", inset: 8, width: "calc(100% - 16px)", height: "calc(100% - 16px)" }} role="img" aria-label={label}>
      {[1, 2, 3].map((r) => <circle key={r} cx="0" cy="0" r={r * 100 / 3} fill="none" stroke="var(--border-hairline)" vectorEffect="non-scaling-stroke" />)}
      <line x1="-100" x2="100" y1="0" y2="0" stroke="var(--border-strong)" vectorEffect="non-scaling-stroke" />
      <line y1="-100" y2="100" x1="0" x2="0" stroke="var(--border-strong)" vectorEffect="non-scaling-stroke" />
      {n > 2 && <ellipse cx={mx * S} cy={-my * S} rx={sx * 2 * S} ry={sy * 2 * S} fill="var(--surface-sunken)" stroke="var(--text-secondary)" strokeDasharray="4 3" vectorEffect="non-scaling-stroke" />}
      {pts.map((p, i) => <circle key={i} cx={Math.max(-98, Math.min(98, p[0] * S))} cy={Math.max(-98, Math.min(98, -p[1] * S))} r="3.4" fill="var(--text-primary)" />)}
      <circle cx="0" cy="0" r="4" fill="none" stroke="var(--border-ink)" strokeWidth="2" vectorEffect="non-scaling-stroke" />
    </svg>
    <span style={{ position: "absolute", left: 10, top: 8, font: "var(--type-meta)", color: "var(--text-muted)" }}>LENGRE</span>
    <span style={{ position: "absolute", left: 10, bottom: 8, font: "var(--type-meta)", color: "var(--text-muted)" }}>KORTERE · RINGER {P().dec(range / 3, 0)} M</span>
    <span style={{ position: "absolute", right: 10, bottom: 8, font: "var(--type-meta)", color: "var(--text-muted)" }}>STIPLET = 2 SD</span>
  </div>;
}
function Tabs({ value, onChange, options }) {
  const { Tabs: T } = P().ns();
  return <T tabs={options} value={value} onChange={onChange} />;
}
window.PHQA = { sgc, SGBar, Src, DG, Scatter, Tabs };
})();
