/* Plan — visninger (runde 21). År · Måned · Uke · Dag. Samme data for se-modus (PH-10) og Workbench (PH-11). */
(() => {
const Ic = (p) => React.createElement(window.PHQ.ns().Icon, p), Opt = (p) => React.createElement(window.PLANV.Opptatt, p);
const P = () => window.PHQ, ns = () => window.PHQ.ns(), PD = () => window.PLAN_DATA, D = () => window.PHQ_DATA;
const toMin = (t) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };
const hhmm = (m) => String(Math.floor(m / 60)).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0");
const dd = (d) => String(d.getDate()).padStart(2, "0") + "." + String(d.getMonth() + 1).padStart(2, "0");
const hatch = "repeating-linear-gradient(135deg, var(--surface-sunken) 0 6px, var(--surface-flat) 6px 12px)";
const AX = ["fys", "tek", "slag", "spill", "turn"];
const dateOf = (a) => new Date(a[0], a[1], a[2]);
const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

/* Alle elementer i en uke, filtrert på lag. */
function weekItems(week, layers, extra) {
  const d = D(), pd = PD(), dates = d.wk(week), on = (l) => !layers || layers[l];
  let ses = [];
  if (week === 39) ses = d.plan.sessions.map((s) => ({ kind: "okt", id: s.id, day: s.day, t: s.t, min: s.min, axis: s.axis, title: s.title, place: s.place, status: s.status, by: pd.by[s.id] || "meg", ex: pd.fysEx[s.id] }));
  else if (week === 40 && window.PM) ses = window.PM.sessions.map((s) => ({ kind: "okt", id: "w40" + s.id, day: s.day, t: s.t, min: window.PM.sessionMin(s), axis: window.PM.sessionAxis(s) || "fys", title: window.PM.sessionTitle(s), place: "—", status: "Planlagt", by: "coach" }));
  if (week === 39 || week === 40) ses = ses.concat(pd.wang.map((w) => ({ kind: "okt", id: w.id + "-" + week, day: w.day, t: w.t, min: w.min, axis: w.axis, title: w.title, place: w.place, status: week === 39 && w.day < pd.today.day ? "Gjennomført" : "Planlagt", by: "wang", group: pd.wangGroup })));
  if (extra) ses = extra(week, ses);
  ses = ses.filter((s) => s.axis === "fys" ? on("fys") : s.axis === "turn" ? on("turn") : true);
  const busy = on("opptatt") && (week === 39 || week === 40) ? pd.busy.map((b) => ({ ...b, kind: "busy", sub: b.kind })) : [];
  const goog = on("google") && week === 39 && (layers ? layers.__google : true) ? pd.google.map((g) => ({ ...g, kind: "google" })) : [];
  const allday = [];
  if (on("turn")) pd.tournaments.forEach((t) => { const a = dateOf(t.from), b = dateOf(t.to); const ds = dates.map((x, i) => x >= new Date(a.getFullYear(), a.getMonth(), a.getDate()) && x <= b ? i : -1).filter((i) => i >= 0); if (ds.length) allday.push({ kind: "turn", id: t.id, from: ds[0], to: ds[ds.length - 1], title: t.name, meta: t.course, ref: t }); });
  if (on("samling")) pd.camps.forEach((c) => { const a = dateOf(c.from), b = dateOf(c.to); const ds = dates.map((x, i) => x >= a && x <= b ? i : -1).filter((i) => i >= 0); if (ds.length) allday.push({ kind: "samling", id: c.id, from: ds[0], to: ds[ds.length - 1], title: c.name, meta: c.place, ref: c }); });
  return { ses, busy, goog, allday, dates };
}
const clashOf = (s, list) => list.find((b) => b.day === s.day && toMin(s.t) < toMin(b.t) + b.min && toMin(s.t) + s.min > toMin(b.t));

function AllDay({ a, onOpen, compact }) {
  const Pp = P(), turn = a.kind === "turn";
  return <button type="button" onClick={() => onOpen(a)} aria-label={(turn ? "Turnering " : "Treningssamling ") + a.title} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", display: "flex", flexDirection: "column", gap: 2, minHeight: 44, padding: "6px 8px 6px 12px", borderRadius: 6, background: "var(--surface-card)", border: "1px solid " + (turn ? "var(--border-hairline)" : "var(--border-strong)"), boxShadow: turn ? "inset 4px 0 0 var(--axis-turn)" : "inset 4px 0 0 var(--text-primary)", minWidth: 0 }}>
    <Pp.Meta s={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{turn ? "TURNERING" : "TRENINGSSAMLING"}{compact ? "" : " · " + a.meta.toUpperCase()}</Pp.Meta>
    <span style={{ font: "500 13px/1.25 var(--font-sans)", color: "var(--text-primary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{a.title}</span>
  </button>;
}
function Okt({ s, onOpen, conflict, h }) {
  const Pp = P(), done = s.status === "Gjennomført", skip = s.status === "Hoppet over", tall = h == null || h >= 34;
  return <button type="button" onClick={() => onOpen(s)} aria-label={s.t + " " + s.title + " · " + s.status + (conflict ? " · krasjer med " + conflict.label : "")} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", display: "flex", flexDirection: "column", gap: 2, width: "100%", height: h, minHeight: h == null ? 52 : undefined, padding: h != null && h < 34 ? "2px 6px 2px 10px" : "6px 8px 6px 12px", borderRadius: 6, background: "var(--surface-card)", border: "1px solid var(--border-hairline)", boxShadow: "inset 4px 0 0 var(--axis-" + s.axis + ")", overflow: "hidden", opacity: skip ? .6 : 1, outline: conflict ? "2px dashed var(--warn)" : "none", outlineOffset: -2, minWidth: 0 }}>
    <span style={{ display: "flex", gap: 6, alignItems: "baseline", minWidth: 0 }}><span style={{ font: "500 11px/1.2 var(--font-mono)", color: "var(--text-secondary)", whiteSpace: "nowrap" }}>{s.t}{h == null ? "–" + hhmm(toMin(s.t) + s.min) : ""}</span>{!tall && <span style={{ font: "500 11px/1.2 var(--font-sans)", color: "var(--text-primary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.title}</span>}</span>
    {tall && <span style={{ font: "500 13px/1.25 var(--font-sans)", color: "var(--text-primary)", textDecoration: skip ? "line-through" : "none", display: "-webkit-box", WebkitLineClamp: h == null ? 2 : Math.max(1, Math.floor((h - 22) / 16)), WebkitBoxOrient: "vertical", overflow: "hidden", overflowWrap: "anywhere" }}>{s.title}</span>}
    {h == null && <Pp.Meta s={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.axis.toUpperCase()} · {s.min} MIN{done ? " · GJENNOMFØRT" : skip ? " · HOPPET OVER" : ""}{s.by === "coach" ? " · FRA ANDERS" : s.by === "wang" ? " · ARVET · WANG" : ""}</Pp.Meta>}
    {conflict && (h == null || h >= 52) && <span style={{ display: "flex", gap: 4, alignItems: "center", font: "600 10px/1.1 var(--font-mono)", color: "var(--warn)", letterSpacing: ".04em" }}><Ic name="triangle-alert" size={12} />KRASJER · {conflict.label.toUpperCase()}</span>}
  </button>;
}
function Opptatt({ b, h }) {
  const g = b.kind === "google", kind = g ? "GOOGLE" : (PD().busyKinds[b.sub] || "Opptatt").toUpperCase();
  return <div aria-label={(g ? "Fra Google: " : "Opptatt: ") + b.label + " " + b.t + "–" + hhmm(toMin(b.t) + b.min)} style={{ boxSizing: "border-box", height: h, minHeight: h == null ? 40 : undefined, display: "flex", flexDirection: h == null ? "row" : "column", alignItems: h == null ? "center" : "stretch", gap: h == null ? 8 : 2, padding: "4px 8px", borderRadius: 6, background: g ? "var(--surface-card)" : hatch, border: "1px dashed var(--border-strong)", overflow: "hidden", minWidth: 0 }}>
    {h == null && <span style={{ display: "inline-flex", color: "var(--text-muted)" }}><Ic name={g ? "calendar" : b.sub === "reise" ? "bus" : b.sub === "jobb" ? "briefcase" : b.sub === "booking" ? "calendar-check" : "school"} size={16} /></span>}
    <span style={{ font: "500 11px/1.2 var(--font-mono)", color: "var(--text-muted)", whiteSpace: "nowrap" }}>{b.t}–{hhmm(toMin(b.t) + b.min)}</span>
    <span style={{ flex: 1, minWidth: 0, font: "500 12px/1.25 var(--font-sans)", color: "var(--text-secondary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{b.label}</span>
    <span style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)", whiteSpace: "nowrap" }}>{kind}</span>
  </div>;
}

/* Uke som liste per dag (mobil og nettbrett). */
function WeekList({ week, layers, onOpen, onDay, extra, focusDay }) {
  const Pp = P(), d = D(), pd = PD(), { ses, busy, goog, allday, dates } = weekItems(week, layers, extra), blockers = [...busy, ...goog];
  return <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,320px),1fr))", gap: 12, minWidth: 0 }}>
    {dates.map((dt, di) => { const today = week === pd.today.week && di === pd.today.day, rows = [...ses.filter((s) => s.day === di), ...blockers.filter((b) => b.day === di)].sort((a, b) => a.t.localeCompare(b.t)), ad = allday.filter((a) => di >= a.from && di <= a.to), mins = ses.filter((s) => s.day === di).reduce((a, s) => a + s.min, 0);
      return <section key={di} aria-label={d.dayNames[di] + " " + dd(dt)} className="pa-card" style={{ padding: 12, gap: 8, minWidth: 0, boxShadow: today || focusDay === di ? "inset 0 0 0 1px var(--border-ink)" : undefined, borderColor: today || focusDay === di ? "var(--border-ink)" : undefined }}>
        <button type="button" onClick={() => onDay && onDay(di)} style={{ all: "unset", cursor: onDay ? "pointer" : "default", display: "flex", alignItems: "center", gap: 8, minHeight: 44 }}><span style={{ font: "600 15px/1 var(--font-sans)", color: "var(--text-primary)" }}>{d.dayNames[di]}</span><Pp.Num s={{ font: "var(--type-num-s)", color: "var(--text-muted)" }}>{dd(dt)}</Pp.Num>{today && <Pp.Meta s={{ color: "var(--text-primary)" }}>I DAG</Pp.Meta>}<span style={{ flex: 1 }}></span><Pp.Meta>{mins ? d.plan && window.PHQ.hm(mins).toUpperCase() : "—"}</Pp.Meta></button>
        {ad.map((a) => <AllDay key={a.id} a={a} onOpen={onOpen} />)}
        {rows.length === 0 && ad.length === 0 && <Pp.Meta>INGEN ØKTER</Pp.Meta>}
        {rows.map((x) => x.kind === "okt" ? <Okt key={x.id} s={x} onOpen={onOpen} conflict={x.status === "Planlagt" && clashOf(x, blockers)} /> : <Opptatt key={x.id} b={x} />)}
      </section>; })}
  </div>;
}

/* Tidsrutenett for én eller sju dager (skrivebord, og Dag på alle bredder). */
function TimeGrid({ week, days, layers, onOpen, extra, PX = 40 }) {
  const Pp = P(), d = D(), pd = PD(), { ses, busy, goog, allday, dates } = weekItems(week, layers, extra), blockers = [...busy, ...goog];
  const H0 = 7, H1 = 22, hours = Array.from({ length: H1 - H0 }, (_, i) => H0 + i), cols = "40px repeat(" + days.length + ",minmax(0,1fr))";
  const top = (t) => (toMin(t) - H0 * 60) / 60 * PX, ht = (m) => Math.max(20, m / 60 * PX - 2);
  const ad = allday.filter((a) => days.some((di) => di >= a.from && di <= a.to));
  return <div className="pa-card" style={{ padding: 0, overflow: "hidden", minWidth: 0 }}>
    <div style={{ display: "grid", gridTemplateColumns: cols, borderBottom: "1px solid var(--border-hairline)", background: "var(--surface-flat)" }}>
      <span></span>{days.map((di) => { const on = week === pd.today.week && di === pd.today.day; return <div key={di} style={{ padding: "8px 6px", display: "flex", gap: 4, alignItems: "baseline", minWidth: 0, borderLeft: "1px solid var(--border-hairline)", boxShadow: on ? "inset 0 -2px 0 var(--border-ink)" : "none" }}><span style={{ font: "600 13px/1 var(--font-sans)", color: "var(--text-primary)" }}>{d.dayNames[di]}</span><span style={{ font: "var(--type-num-s)", color: on ? "var(--text-primary)" : "var(--text-muted)" }}>{dd(dates[di])}</span></div>; })}
    </div>
    {ad.length > 0 && <div style={{ display: "grid", gridTemplateColumns: cols, gap: 4, padding: "6px 0", borderBottom: "1px solid var(--border-hairline)" }}><Pp.Meta s={{ padding: "0 4px", alignSelf: "center" }}>HELE DAGEN</Pp.Meta>{ad.map((a) => { const f = Math.max(a.from, days[0]), t = Math.min(a.to, days[days.length - 1]); return <div key={a.id} style={{ gridColumn: (days.indexOf(f) + 2) + " / " + (days.indexOf(t) + 3), minWidth: 0, padding: "0 2px" }}><AllDay a={a} onOpen={onOpen} compact={t - f < 1} /></div>; })}</div>}
    <div style={{ display: "grid", gridTemplateColumns: cols }}>
      <div>{hours.map((h) => <div key={h} style={{ height: PX, font: "var(--type-meta)", color: "var(--text-muted)", textAlign: "right", padding: "0 6px", boxSizing: "border-box", transform: "translateY(-6px)" }}>{h > H0 ? String(h).padStart(2, "0") : ""}</div>)}</div>
      {days.map((di) => <div key={di} style={{ position: "relative", height: hours.length * PX, borderLeft: "1px solid var(--border-hairline)", backgroundImage: "repeating-linear-gradient(to bottom, transparent 0 " + (PX - 1) + "px, var(--border-hairline) " + (PX - 1) + "px " + PX + "px)" }}>
        {blockers.filter((b) => b.day === di).map((b) => <div key={b.id} style={{ position: "absolute", left: 2, right: 2, top: top(b.t), zIndex: 1 }}><Opptatt b={b} h={ht(b.min)} /></div>)}
        {ses.filter((s) => s.day === di).map((s) => <div key={s.id} style={{ position: "absolute", left: 6, right: 2, top: top(s.t), zIndex: 2 }}><Okt s={s} h={ht(s.min)} onOpen={onOpen} conflict={s.status === "Planlagt" && clashOf(s, blockers)} /></div>)}
        {week === pd.today.week && di === pd.today.day && <span aria-hidden="true" style={{ position: "absolute", left: 0, right: 0, top: top(pd.today.now), height: 2, background: "var(--border-ink)", zIndex: 3 }}></span>}
      </div>)}
    </div>
  </div>;
}

/* Måned: dager med aksemerker, turneringer og samlinger som stripe. */
function MonthGrid({ year, month, layers, onPickDay }) {
  const Pp = P(), d = D(), pd = PD(), { mob } = Pp.useW();
  const first = new Date(year, month, 1), start = new Date(first); start.setDate(1 - ((first.getDay() + 6) % 7));
  const cells = Array.from({ length: 42 }, (_, i) => { const x = new Date(start); x.setDate(start.getDate() + i); return x; });
  const rows = [0, 1, 2, 3, 4, 5].filter((r) => cells[r * 7].getMonth() === month || cells[r * 7 + 6].getMonth() === month);
  const wkOf = (x) => { const t = new Date(Date.UTC(x.getFullYear(), x.getMonth(), x.getDate())); const dn = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - dn); const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1)); return Math.ceil(((t - y0) / 864e5 + 1) / 7); };
  const cache = {}; const itemsFor = (w) => cache[w] || (cache[w] = weekItems(w, layers));
  const pseudo = (w, di) => w >= 36 && w <= 38 ? [["fys"], ["slag", "fys"], ["tek"], ["slag"], ["spill"], [], ["spill"]][(w + di) % 7] : [];
  return <div className="pa-card" style={{ padding: 0, overflow: "hidden", minWidth: 0 }}>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(7,minmax(0,1fr))", background: "var(--surface-flat)", borderBottom: "1px solid var(--border-hairline)" }}>{d.dayNames.map((n) => <span key={n} style={{ padding: "8px 6px", font: "var(--type-meta)", color: "var(--text-muted)" }}>{n.toUpperCase()}</span>)}</div>
    {rows.map((r) => { const w = wkOf(cells[r * 7]), it = itemsFor(w); return <div key={r} style={{ display: "grid", gridTemplateColumns: "repeat(7,minmax(0,1fr))", borderBottom: "1px solid var(--border-hairline)" }}>
      {cells.slice(r * 7, r * 7 + 7).map((dt, di) => { const other = dt.getMonth() !== month, today = w === pd.today.week && di === pd.today.day, axes = [...new Set(it.ses.filter((s) => s.day === di).map((s) => s.axis))].concat(it.ses.length ? [] : pseudo(w, di)), ad = it.allday.filter((a) => di >= a.from && di <= a.to);
        return <button key={di} type="button" onClick={() => onPickDay(w, di)} aria-label={dt.getDate() + ". " + d.monthNames[dt.getMonth()] + (axes.length ? " · " + axes.map((a) => a.toUpperCase()).join(" ") : " · ingen økter") + (ad.length ? " · " + ad.map((a) => a.title).join(", ") : "")} style={{ minHeight: mob ? 60 : 84, border: 0, borderLeft: di ? "1px solid var(--border-hairline)" : 0, background: today ? "var(--surface-flat)" : "transparent", boxShadow: today ? "inset 0 0 0 2px var(--border-ink)" : "none", padding: 4, display: "flex", flexDirection: "column", alignItems: "stretch", gap: 4, cursor: "pointer", minWidth: 0, textAlign: "left" }}>
          <span style={{ font: "600 12px/1 var(--font-mono)", color: other ? "var(--text-faint)" : "var(--text-primary)", padding: "2px 2px 0" }}>{dt.getDate()}</span>
          {axes.length > 0 && <span style={{ display: "flex", gap: 3, flexWrap: "wrap", padding: "0 2px" }}>{axes.map((a) => <span key={a} style={{ width: 6, height: 6, borderRadius: 999, background: "var(--axis-" + a + ")" }}></span>)}</span>}
          {ad.map((a) => <span key={a.id} style={{ display: "block", height: mob ? 6 : 18, borderRadius: 2, background: "var(--surface-card)", border: "1px solid var(--border-hairline)", boxShadow: "inset 3px 0 0 " + (a.kind === "turn" ? "var(--axis-turn)" : "var(--text-primary)"), font: "500 10px/16px var(--font-mono)", color: "var(--text-secondary)", paddingLeft: 6, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{mob ? "" : di === a.from || di === 0 ? (a.kind === "turn" ? "TURN" : "SAMLING") : ""}</span>)}
        </button>; })}
    </div>; })}
  </div>;
}

/* År: 52 uker i perioder (grafitt-trinn), turneringer og samlinger som merker. */
function YearView({ onPickPeriod, week }) {
  const Pp = P(), pd = PD(), T = pd.periodTypes, { mob } = Pp.useW();
  const wkOf = (t) => t.week;
  const marks = [...pd.tournaments.map((t) => ({ w: t.week, k: "turn", label: t.name })), ...pd.camps.map((c) => ({ w: c.week, k: "samling", label: c.name }))];
  return <section aria-label="Året" className="pa-card" style={{ padding: 16, gap: 12, minWidth: 0 }}>
    <div role="img" aria-label="Periodene uke 1–52" style={{ display: "grid", gridTemplateColumns: "repeat(52,minmax(0,1fr))", gap: 1, minWidth: 0 }}>
      {Array.from({ length: 52 }, (_, i) => { const w = i + 1, p = pd.periods.find((x) => w >= x.from && w <= x.to); return <span key={w} style={{ height: 36, background: T[p.type].tok, boxShadow: w === week ? "0 0 0 2px var(--surface-card), 0 0 0 4px var(--border-ink)" : "none", position: "relative", zIndex: w === week ? 1 : 0 }}></span>; })}
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(52,minmax(0,1fr))", gap: 1, height: 12, minWidth: 0 }}>{Array.from({ length: 52 }, (_, i) => { const m = marks.find((x) => x.w === i + 1); return <span key={i} title={m ? m.label : undefined} style={{ height: m ? 12 : 0, background: m ? (m.k === "turn" ? "var(--axis-turn)" : "var(--text-primary)") : "transparent" }}></span>; })}</div>
    <div style={{ display: "flex", justifyContent: "space-between", gap: 4, minWidth: 0 }}>{(mob ? ["JAN", "APR", "JUL", "OKT", "DES"] : ["JAN", "FEB", "MAR", "APR", "MAI", "JUN", "JUL", "AUG", "SEP", "OKT", "NOV", "DES"]).map((m) => <Pp.Meta key={m}>{m}</Pp.Meta>)}</div>
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>{Object.values(T).map((t) => <span key={t.name} style={{ display: "inline-flex", gap: 6, alignItems: "center" }}><span style={{ width: 12, height: 12, background: t.tok }}></span><Pp.Meta>{t.name.toUpperCase()}</Pp.Meta></span>)}<span style={{ display: "inline-flex", gap: 6, alignItems: "center" }}><span style={{ width: 4, height: 12, background: "var(--axis-turn)" }}></span><Pp.Meta>TURNERING</Pp.Meta></span><span style={{ display: "inline-flex", gap: 6, alignItems: "center" }}><span style={{ width: 4, height: 12, background: "var(--text-primary)" }}></span><Pp.Meta>SAMLING</Pp.Meta></span></div>
    <div role="list">{pd.periods.map((p) => { const cur = week >= p.from && week <= p.to; return <button role="listitem" key={p.id} type="button" onClick={() => onPickPeriod(p)} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", width: "100%", display: "grid", gridTemplateColumns: "12px minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 52, borderTop: "1px solid var(--border-hairline)", padding: "6px 0" }}>
      <span style={{ width: 12, height: 28, background: T[p.type].tok }}></span>
      <span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: (cur ? "600" : "500") + " 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{T[p.type].name}{cur ? " · nå" : ""}</span><Pp.Meta>UKE {p.from}–{p.to}{marks.filter((m) => m.w >= p.from && m.w <= p.to).map((m) => " · " + m.label.toUpperCase()).join("")}</Pp.Meta></span>
      <Pp.Num s={{ font: "var(--type-num-s)", textAlign: "right" }}>{p.done == null ? "—" : p.done} / {p.plan || "—"} t</Pp.Num>
    </button>; })}</div>
    <Pp.Meta>TIMER GJENNOMFØRT / PLAN · {pd.yearSrc}</Pp.Meta>
  </section>;
}

window.PLANV = { toMin, hhmm, dd, hatch, AX, weekItems, clashOf, WeekList, TimeGrid, MonthGrid, YearView, Okt, Opptatt, AllDay };
})();
