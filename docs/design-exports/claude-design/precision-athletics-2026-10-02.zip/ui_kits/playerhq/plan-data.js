/* Plan (PH-10/PH-11) — runde 21, Anders 28.09.2026. Oppdiktede data for Tobias Lindvik. Dagens dato lørdag 26.09.2026, uke 39. */
window.PLAN_DATA = {
  today: { week: 39, day: 5, now: "08:14" },
  periodTypes: {
    grunn: { name: "Grunnperiode", tok: "var(--period-grunn)" },
    spesial: { name: "Spesialperiode", tok: "var(--period-spesial)" },
    turnering: { name: "Turneringsperiode", tok: "var(--period-turnering)" },
    evaluering: { name: "Evaluering", tok: "var(--period-evaluering)" },
    ferie: { name: "Ferie", tok: "var(--period-ferie)" },
    restitusjon: { name: "Restitusjon", tok: "var(--period-restitusjon)" },
  },
  periods: [
    { id: "p1", type: "grunn", from: 1, to: 14, plan: 238, done: 231 },
    { id: "p2", type: "spesial", from: 15, to: 20, plan: 108, done: 104 },
    { id: "p3", type: "turnering", from: 21, to: 29, plan: 135, done: 128 },
    { id: "p4", type: "ferie", from: 30, to: 31, plan: 0, done: 4 },
    { id: "p5", type: "turnering", from: 32, to: 40, plan: 144, done: 118 },
    { id: "p6", type: "evaluering", from: 41, to: 42, plan: 24, done: null },
    { id: "p7", type: "restitusjon", from: 43, to: 45, plan: 18, done: null },
    { id: "p8", type: "grunn", from: 46, to: 52, plan: 126, done: null },
  ],
  yearSrc: "ÅRSPLAN 2026 · TOBIAS LINDVIK · SIST ENDRET 21.09.2026",
  /* Gjennomført mot plan per uke (grunnlag for forslag: over 130 % eller under 70 % to uker på rad) */
  weekPct: [[35, 96], [36, 102], [37, 134], [38, 131], [39, null]],
  weekPctSrc: "ØKTLOGG · UKE 35–38 · 26.09.2026",
  /* Økter uke 39 utover PHQ_DATA.plan.sessions: hvem la dem inn, FYS-innhold */
  by: { p1: "coach", p2: "coach", p3: "coach", p4: "meg", p5: "coach", p6: "coach", p7: "coach", p8: "meg", p9: "coach", p10: "coach", p11: "coach" },
  fysEx: { p1: [["Knebøy", "4 × 6 @ 40 kg", "RIR 2"], ["Rumensk markløft", "3 × 8 @ 30 kg", "RIR 3"], ["Pallof press", "3 × 10 per side", "RIR 2"]], p10: [["Knebøy", "4 × 6 @ 42,5 kg", "RIR 2"], ["Utfall med rotasjon", "3 × 8 per side", "RIR 3"], ["Pallof press", "3 × 10 per side", "RIR 2"], ["Planke", "3 × 45 s", "—"]], p4: [["Hofte og thorax", "15 min", "—"]], p8: [["Hofte og thorax", "15 min", "—"]] },
  busy: [
    ...[0, 1, 2, 3, 4].map((d) => ({ id: "s" + d, kind: "skole", day: d, t: d === 1 || d === 3 ? "10:00" : "08:15", min: d === 4 ? 330 : d === 1 || d === 3 ? 300 : 405, label: "Skole" })),
    { id: "j1", kind: "jobb", day: 4, t: "17:30", min: 180, label: "Jobb · proshop" },
    { id: "b1", kind: "booking", day: 1, t: "18:00", min: 45, label: "Booking · fysioterapeut" },
    { id: "r1", kind: "reise", day: 6, t: "07:45", min: 60, label: "Reise · Borregaard GK" },
  ],
  google: [
    { id: "g1", day: 2, t: "19:00", min: 120, label: "Familiemiddag", cal: "Tobias (privat)" },
    { id: "g2", day: 5, t: "17:00", min: 120, label: "Bursdag Oskar", cal: "Tobias (privat)" },
    { id: "g3", day: 3, t: "19:30", min: 60, label: "Tannlege", cal: "Tobias (privat)" },
  ],
  googleCals: [["Tobias (privat)", true], ["Skole · timeplan", true], ["Familie", false]],
  layers: [
    { id: "golf", label: "Golføkter", fixed: true },
    { id: "fys", label: "Fysisk" },
    { id: "turn", label: "Turneringer" },
    { id: "samling", label: "Samlinger" },
    { id: "opptatt", label: "Opptatt tid" },
    { id: "google", label: "Google" },
  ],
  /* WANG-elev: morgenøktene arves fra gruppeplanen. Eleven registrerer oppmøte og gjennomføring. */
  wang: [{ id: "w1", day: 1, t: "08:15", min: 90, axis: "fys", title: "WANG morgenøkt · styrke", place: "WANG · styrkerom" }, { id: "w2", day: 3, t: "08:15", min: 90, axis: "slag", title: "WANG morgenøkt · nærspill", place: "Fredrikstad GK · chippinggreen" }],
  wangGroup: "WANG Toppidrett Fredrikstad · VG2 · Marte Vik",
  busyKinds: { skole: "Skole", jobb: "Jobb", reise: "Reise", booking: "Booking" },
  tournaments: [
    { id: "t1", name: "Srixon Tour · runde 6", course: "Larvik GK", from: [2026, 9, 3], to: [2026, 9, 4], week: 40, type: "Konkurranse", rounds: [["Runde 1", "Lør 03.10 · tee 1 · 09:40"], ["Runde 2", "Søn 04.10 · tee 10 · 08:50"]], by: "coach",
      prep: [["Tir 29.09", "Innspill 50–100 m · lengdekontroll", true], ["Tor 01.10", "Øvingsrunde Larvik GK · 18 hull", false], ["Fre 02.10", "Reise 15:00 · pakk bagen kvelden før", false], ["Fre 02.10", "Søvn 22:30 · 8 timer", false], ["Lør 03.10", "Oppvarming 60 min før start", false]],
      par: 71, score: [null, null], eval: null },
  ],
  camps: [
    { id: "c1", name: "Høstsamling · Sør-Spania", from: [2026, 9, 6], to: [2026, 9, 10], week: 41, place: "Treningsanlegg · 5 dager", sessions: 9, hours: 22, lead: "Anders Kristiansen", program: [["Tir 06.10", "Reise · innspill kveld"], ["Ons 07.10", "TEK formiddag · SPILL 9 hull"], ["Tor 08.10", "SLAG nærspill · FYS styrke"], ["Fre 09.10", "SPILL 18 hull · evaluering"], ["Lør 10.10", "Hjemreise"]] },
  ],
  suggestion: { kind: "lettere", weeks: [37, 38], pct: [134, 131], target: 40, text: "Uke 37 og 38 gjennomførte du 134 % og 131 % av planen. Vil du gjøre uke 40 lettere?", effect: "Uke 40 går fra 14,5 til 11,5 t. Turneringen er uendret." },
  help: {
    "År": ["Året i perioder", "Grunnperiode, Spesialperiode, Turneringsperiode, Evaluering, Ferie og Restitusjon. Turneringer og samlinger ligger oppå. Trykk en periode for å se månedene."],
    "Måned": ["Måneden", "Hver dag viser aksene som er planlagt. Turneringer og samlinger ligger som striper over dagene. Trykk en dag for å se den."],
    "Uke": ["Uka", "Golføkter, fysisk trening, turneringer og opptatt tid i samme plan. Trykk en økt for å se den eller starte den."],
    "Dag": ["Dagen", "Timeplan for én dag. Opptatt tid og hendelser fra Google vises med stiplet kant, øktene med aksestripe."],
    "Rediger": ["Workbench", "Velg akse i pyramiderekkefølge: FYS, TEK, SLAG, SPILL, TURN. Legg økter på en dag og dra dem. Du kan endre alt selv."],
  },
  guide: [
    { k: "Sesong", t: "Når er sesongen?", text: "Velg første og siste turnering. Resten av året fordeles rundt dem." },
    { k: "Turneringer", t: "Hvilke turneringer skal du spille?", text: "Legg inn de du vet om nå. Du kan legge til flere senere." },
    { k: "Perioder", t: "Periodene", text: "Forslaget bygger på turneringene. Du kan flytte grensene etterpå." },
    { k: "Treningsplan", t: "Velg treningsplan", text: "Fem standardplaner, tilpasset kategori D. Planen fyller ukene med økter." },
    { k: "Opptatt tid", t: "Skole, jobb og kalender", text: "Legg inn fast opptatt tid, eller koble Google-kalenderen så vises alt i Plan." },
  ],
};
