/* Live-økt og runde — runde 24 (Anders 28.09.2026). Oppdiktede data. Lørdag 26.09.2026. */
window.LIVE_DATA = {
  head: { who: "Tobias Lindvik", coach: "Anders Kristiansen", title: "Innspill og nærspill", axes: ["slag", "tek"], formel: "SLAG_INNSPILL50-100_LH-AUTO_TRENINGSOMRÅDE_OBSERVERT", time: "14:30–15:45", min: 75, place: "Range 3 · Fredrikstad GK" },
  drills: [
    { id: "d1", n: "Innspill 100–150 m · Lengdekontroll", axis: "slag", club: "PW", min: 20, code: "SLAG_INNSPILL100_AUTO_TRENINGSOMRÅDE_OBSERVERT",
      plan: { ub: 0, lh: 10, auto: 0, slag: 30 },
      desc: "Tre mål på 90, 100 og 110 m. Ti lav-hastighetssving uten mål først. Deretter 30 slag: ti mot hvert mål i tilfeldig rekkefølge. Rutine før hvert slag. Noter om ballen lander innenfor 6 m.",
      tech: { pos: "P7.0", title: "Hendene foran ballen i treff", text: "Kjenn at hendene er foran ballen når køllen treffer. Hold 50 % fart til det sitter.", video: "0:42", img: "../../assets/photos/academy-30.webp", from: "Anders Kristiansen · 23.09.2026" } },
    { id: "d2", n: "Innspill 50–100 m · Lengdekontroll", axis: "slag", club: "54°", min: 20, code: "SLAG_INNSPILL50_LH_TRENINGSOMRÅDE_ALENE",
      plan: { ub: 10, lh: 20, auto: 0, slag: 40 },
      desc: "Ti svinger uten ball med kort baksving. Tjue i lav hastighet mot 50 m. Førti slag der du veksler mellom 45, 50 og 55 m. Mål: innenfor 4 m." },
    { id: "d3", n: "Pitch · Landingspunkt", axis: "slag", club: "58°", min: 15, code: "SLAG_PITCH_TRENINGSOMRÅDE_OBSERVERT",
      plan: { ub: 0, lh: 0, auto: 0, slag: 30 },
      desc: "Legg et håndkle 5 m inn på greenen. Tretti pitcher fra 20–30 m. Tell treff på håndkleet." },
    { id: "d4", n: "Putting 3–5 fot · Ballstart", axis: "slag", club: "Putter", min: 20, code: "SLAG_PUTTING3-5_TRENINGSOMRÅDE_KONKURRANSE",
      plan: { ub: 0, lh: 0, auto: 0, slag: 50 },
      desc: "Port med to tees en putterbredde foran ballen. Femti putter fra 3, 4 og 5 fot. Ballen skal gå rent gjennom porten." },
  ],
  /* Demo: drill 1 ferdig, drill 2 pågår. */
  demo: { cur: 1, total: 1452, drillSec: 512, done: { d1: { sec: 1118, c: { ub: 0, lh: 10, auto: 0, slag: 30 } } }, counts: { d2: { ub: 10, lh: 14, auto: 0, slag: 16 } } },
  counters: [["ub", "Uten ball"], ["lh", "Lav hastighet"], ["auto", "Automatikk"], ["slag", "Slag"]],
  /* Fysisk økt (PH-06): følger programmet, spilleren fyller inn vekt og kan endre reps og serier. */
  fys: { title: "Styrke bein og kjerne", meta: "BLOKK STYRKE · GRUNNPERIODE · UKE 4 AV 6", time: "17:30–18:15", min: 45, place: "Styrkerommet", from: "Program fra Anders Kristiansen · 21.09.2026",
    ex: [
      { id: "f1", n: "Knebøy", sets: 4, reps: 6, kg: 40, rir: 2, last: "40 kg · 21.09" },
      { id: "f2", n: "Rumensk markløft", sets: 3, reps: 8, kg: 30, rir: 3, last: "30 kg · 21.09" },
      { id: "f3", n: "Utfall med rotasjon", sets: 3, reps: 8, kg: 8, rir: 3, last: "8 kg · 19.09", per: "per side" },
      { id: "f4", n: "Pallof press", sets: 3, reps: 10, kg: null, rir: 2, last: "—", per: "per side" },
    ] },
  /* Etter økt (PH-07) */
  after: { total: 4386, plan: 4500, per: [["d1", 1118, 1200, 40, 40], ["d2", 1245, 1200, 58, 70], ["d3", 902, 900, 30, 30], ["d4", 1121, 1200, 44, 50]] },
  /* Runde */
  round: { course: "Fredrikstad GK", tee: "Gul tee", date: "26.09.2026", start: "09:40",
    bag: ["Driver", "3W", "5W", "4H", "5i", "6i", "7i", "8i", "9i", "PW", "50°", "54°", "58°", "Putter"],
    lies: [["TEE", "Tee"], ["FAIRWAY", "Fairway"], ["SEMI", "Semi"], ["ROUGH", "Rough"], ["BUNKER", "Bunker"], ["TRÆR", "Trær"], ["GREEN", "Green"]],
    breaks: ["Venstre → høyre", "Høyre → venstre", "Oppover", "Nedover"],
    hole: 7, par: 3, len: 138, played: [[4, 4], [5, 5], [3, 4], [4, 5], [4, 4], [5, 5]],
    /* Hull 7 så langt: utslag lagret, ballen på green. */
    shots: [{ id: "s1", dist: 138, unit: "m", lie: "TEE", club: "8i", pen: 0 }],
    next: { dist: 24, unit: "fot", lie: "GREEN" },
    /* Putt-demo for PH-RD-04 */
    putts: [{ id: "p1", dist: 24, unit: "fot", lie: "GREEN", club: "Putter", brk: "Høyre → venstre", fart: "Kort", miss: "Høyre", pen: 0 }],
    nextPutt: { dist: 3, unit: "fot", lie: "GREEN" },
  },
  roundDone: { score: 76, par: 72, toPar: 4, putts: 32, fw: "9 av 14", gir: "8 av 18",
    sg: [["Tee", -0.2], ["Innspill", -1.3], ["Nærspill", -0.4], ["Putting", -0.7]], base: "MOT KATEGORI C · BROADIE · ESTIMAT",
    t5: [["Bogey på par 5", 1], ["Dobbeltbogey eller verre", 1], ["3-putt", 2], ["Bogey fra innenfor 130 m", 1], ["Bom på enkel opp-og-ned", 1]],
    agent: [["Runde lagret", "09:40–14:02 · 18 hull · 76 slag", true], ["SG regnet ut", "4 kategorier · 71 slag · 32 putter", true], ["Planen din oppdateres", "Runde-agenten ser på innspill 100–150 m og 3-putter", false], ["Forslag i innboksen", "Du godtar eller avviser selv", false]] },
};

/* Økter per sessionId (runde 37). Live og oppsummering følger window.PHQ_SEL.sessionId. okt-2609 = den opprinnelige golføkta. put-2609 og fys-2609 er egne økter. Oppdiktede data. */
(() => {
  const L = window.LIVE_DATA;
  L.sessions = {
    "okt-2609": { head: L.head, drills: L.drills, demo: L.demo, after: L.after },
    "put-2609": {
      head: { who: "Tobias Lindvik", coach: "Anders Kristiansen", title: "Putting 3–5 fot og 5–10 fot", axes: ["slag"], formel: "SLAG_PUTTING3-5_TRENINGSOMRÅDE_OBSERVERT", time: "09:00–09:45", min: 45, place: "Puttinggreen · Fredrikstad GK" },
      drills: [
        { id: "p1", n: "Putting 3–5 fot · Ballstart", axis: "slag", club: "Putter", min: 20, code: "SLAG_PUTTING3-5_TRENINGSOMRÅDE_OBSERVERT", plan: { ub: 0, lh: 0, auto: 0, slag: 50 }, desc: "Port med to tees en putterbredde foran ballen. Femti putter fra 3, 4 og 5 fot. Ballen skal gå rent gjennom porten." },
        { id: "p2", n: "Putting 5–10 fot · Lengdekontroll", axis: "slag", club: "Putter", min: 25, code: "SLAG_PUTTING5-10_TRENINGSOMRÅDE_OBSERVERT", plan: { ub: 0, lh: 0, auto: 0, slag: 40 }, desc: "Fire tees i en rekke på 5, 6,5, 8 og 10 fot. Ti putter mot hver. Ballen skal stoppe innenfor 60 cm forbi hullet." },
      ],
      demo: { cur: 0, total: 0, drillSec: 0, done: {}, counts: {} },
      after: null,
    },
  };
  L.fysSessions = { "fys-2609": L.fys };
})();
