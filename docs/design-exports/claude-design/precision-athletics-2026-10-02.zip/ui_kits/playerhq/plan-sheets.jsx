/* Plan — ark og rader (runde 21): økt, turneringsreise (B3), treningssamling (B7), Google-kalender, veileder, «?», be coach endre planen (B8), forslag. */
(() => {
const Ic = (p) => React.createElement(window.PHQ.ns().Icon, p), Opt = (p) => React.createElement(window.PLANV.Opptatt, p);
const P = () => window.PHQ, ns = () => window.PHQ.ns(), PD = () => window.PLAN_DATA, D = () => window.PHQ_DATA, V = () => window.PLANV;
const Muted = ({ children }) => <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{children}</p>;
/* Diskré varsel: coach får beskjed. Grafitt, liten, aldri sperre. */
const CoachNote = ({ children }) => <span style={{ display: "inline-flex", gap: 6, alignItems: "flex-start", font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)" }}><span style={{ display: "inline-flex", paddingTop: 1 }}><Ic name="bell" size={12} /></span><span>{children}</span></span>;
const TONE = { "Gjennomført": "ok", "Hoppet over": "warn", "Pågår": "info", "Avlyst": "warn" };

/* WANG-morgenøkt: arvet fra gruppeplanen. Eleven registrerer oppmøte og gjennomføring. */
function WangReg({ s }) {
  const { ChoicePill, Button } = ns(), Pp = P();
  const [m, setM] = React.useState(s.status === "Gjennomført" ? "Møtte" : null), [g, setG] = React.useState(s.status === "Gjennomført" ? "Hele økta" : null);
  const G = ({ label, opts, v, set }) => <div role="group" aria-label={label} style={{ display: "flex", flexDirection: "column", gap: 6 }}><Pp.Meta>{label.toUpperCase()}</Pp.Meta><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{opts.map((o) => <ChoicePill key={o} selected={v === o} onClick={() => set(o)}>{o}</ChoicePill>)}</div></div>;
  return <div style={{ display: "flex", flexDirection: "column", gap: 12, paddingTop: 12, borderTop: "1px solid var(--border-hairline)" }}>
    <span style={{ font: "500 14px/1.35 var(--font-sans)", color: "var(--text-primary)" }}>Arvet fra gruppeplanen. Du kan ikke flytte den, men du registrerer oppmøte og gjennomføring.</span>
    <G label="Oppmøte" opts={["Møtte", "Møtte ikke"]} v={m} set={setM} />
    <G label="Gjennomføring" opts={["Hele økta", "Delvis", "Ikke gjennomført"]} v={g} set={setG} />
    <div><Button variant="secondary" icon="check" disabled={!m || (m === "Møtte" && !g)} onClick={() => Pp.toast("Registrert", (m + (m === "Møtte" ? " · " + g : "")).toUpperCase() + " · SENDES TIL MARTE VIK · WANG")}>Registrer</Button></div>
  </div>;
}
function OktSheet({ s, week, onClose, go, blockers }) {
  const { Sheet, Button, AxisBadge, StatusPill, KeyValue } = ns(), Pp = P(), d = D(), v = V();
  if (!s) return null;
  const dates = d.wk(week), clash = s.status === "Planlagt" && v.clashOf(s, blockers || []), done = s.status === "Gjennomført";
  return <Sheet open onClose={onClose} kicker={d.dayNames[s.day] + " " + v.dd(dates[s.day]) + " · " + s.t + "–" + v.hhmm(v.toMin(s.t) + s.min)} title={s.title}
    footer={<>{!done && <Button fullWidth size="xl" icon="play" onClick={() => go("PH-04")}>Start økt</Button>}<Button variant={done ? "primary" : "secondary"} fullWidth icon="list" onClick={() => go("PH-03")}>Se økta</Button><Button variant="ghost" fullWidth icon="pencil" onClick={() => go("PH-11")}>Rediger i Workbench</Button></>}>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><AxisBadge axis={s.axis} /><StatusPill tone={TONE[s.status] || "neutral"}>{s.status}</StatusPill></div>
    <KeyValue items={[["Tid", Pp.hm(s.min)], ["Sted", s.place, { mono: false }], ["Lagt inn av", s.by === "coach" ? "Anders Kristiansen" : s.by === "wang" ? "Gruppeplan · " + s.group : "Deg", { mono: false }]]} />
    {s.by === "wang" && <WangReg s={s} />}
    {s.ex && <div role="list">{s.ex.map(([n, q, r]) => <div role="listitem" key={n} style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) auto auto", gap: 12, alignItems: "center", minHeight: 44, borderTop: "1px solid var(--border-hairline)" }}><span style={{ font: "400 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{n}</span><Pp.Num s={{ font: "var(--type-num-s)" }}>{q}</Pp.Num><Pp.Meta>{r}</Pp.Meta></div>)}</div>}
    {clash && <div style={{ display: "flex", gap: 8, alignItems: "flex-start", padding: 12, borderRadius: 8, background: "var(--warn-tint)" }}><span style={{ color: "var(--warn)", display: "inline-flex", paddingTop: 2 }}><Ic name="triangle-alert" size={16} /></span><span style={{ font: "var(--type-body-s)", color: "var(--text-primary)" }}>Krasjer med {clash.label} {clash.t}–{v.hhmm(v.toMin(clash.t) + clash.min)}{clash.kind === "google" ? " (Google)" : ""}. Flytt økta i Workbench, eller behold den.</span></div>}
    {s.by === "coach" && <CoachNote>ANDERS LA INN DENNE ØKTA · ENDRER DU DEN, FÅR HAN BESKJED</CoachNote>}
  </Sheet>;
}

/* B3 Turneringsreise: forberedelse → runde → brutto score → evaluering. */
function TurnSheet({ t, onClose, go }) {
  const { Sheet, Button, Checkbox, FormField, TextInput } = ns(), Pp = P();
  const [chk, setChk] = React.useState(() => t ? Object.fromEntries(t.prep.map((p, i) => [i, p[2]])) : {});
  const [sc, setSc] = React.useState(["", ""]);
  if (!t) return null;
  const n = Object.values(chk).filter(Boolean).length, tot = sc[0] && sc[1] ? +sc[0] + +sc[1] : null, par = t.par * 2;
  const toPar = (x) => x > 0 ? "+" + x : x < 0 ? "−" + Math.abs(x) : "±0";
  const step = n < t.prep.length ? 0 : !sc[0] ? 1 : !tot ? 2 : 3;
  const Step = ({ i, k, meta, children }) => <section aria-label={k} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr)", gap: 12, paddingTop: 12, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}>
    <span style={{ width: 28, height: 28, borderRadius: 999, display: "grid", placeItems: "center", font: "600 13px/1 var(--font-mono)", background: i < step ? "var(--primary)" : "var(--surface-card)", color: i < step ? "var(--text-on-primary)" : "var(--text-primary)", border: "1px solid " + (i <= step ? "var(--border-ink)" : "var(--border-hairline)") }}>{i < step ? <Ic name="check" size={14} /> : i + 1}</span>
    <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}><div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span style={{ font: "600 15px/1.3 var(--font-sans)", color: "var(--text-primary)", flex: "1 1 auto" }}>{k}</span><Pp.Meta>{meta}</Pp.Meta></div>{children}</div>
  </section>;
  return <Sheet open onClose={onClose} kicker={"Turnering · " + t.type + " · uke " + t.week} title={t.name + " · " + t.course}
    footer={<><Button variant="secondary" fullWidth icon="map" onClick={() => go("PH-20")}>Gameplan</Button><Button variant="ghost" fullWidth icon="move" onClick={() => { onClose(); Pp.toast("Turneringen er flyttet i Plan", "ANDERS FÅR BESKJED"); }}>Flytt turnering</Button><Button variant="ghost" fullWidth icon="trash-2" onClick={() => { onClose(); Pp.toast("Turneringen er fjernet fra Plan", "ANDERS FÅR BESKJED · KAN ANGRES"); }}>Fjern fra plan</Button></>}>
    <Pp.Meta>03.10–04.10.2026 · 2 RUNDER · PAR {t.par}</Pp.Meta>
    <Step i={0} k="Forberedelse" meta={n + " AV " + t.prep.length}>{t.prep.map(([dag, what], i) => <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, minHeight: 44, minWidth: 0 }}><div style={{ flex: 1, minWidth: 0 }}><Checkbox checked={!!chk[i]} onChange={() => setChk((c) => ({ ...c, [i]: !c[i] }))} label={what} /></div><Pp.Meta s={{ flex: "none" }}>{dag.toUpperCase()}</Pp.Meta></div>)}</Step>
    <Step i={1} k="Runder" meta={t.rounds.length + " RUNDER"}>{t.rounds.map(([r, when]) => <div key={r} style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "baseline" }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", minWidth: 72 }}>{r}</span><Pp.Num s={{ font: "var(--type-num-s)" }}>{when}</Pp.Num></div>)}</Step>
    <Step i={2} k="Brutto score" meta={tot == null ? "—" : tot + " SLAG (" + toPar(tot - par) + ")"}><div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 12 }}>{[0, 1].map((i) => <FormField key={i} label={"Runde " + (i + 1)}><TextInput mono inputMode="numeric" placeholder="—" value={sc[i]} onChange={(e) => { const v = e.target.value.replace(/\D/g, "").slice(0, 3); setSc((s) => s.map((x, j) => j === i ? v : x)); }} /></FormField>)}</div><Pp.Meta>KILDE: MANUELL · GOLFBOX HENTES AUTOMATISK NÅR DEN ER KOBLET</Pp.Meta></Step>
    <Step i={3} k="Evaluering" meta={tot == null ? "ETTER SISTE RUNDE" : "KLAR"}><Muted>Hva gikk bra, og hva tar du med til neste turnering? Anders ser evalueringen i Innboks.</Muted>{tot != null && <div><Button variant="secondary" icon="pencil" onClick={() => go("PH-18")}>Skriv evaluering</Button></div>}</Step>
    <CoachNote>LEGGER DU TIL, FJERNER ELLER FLYTTER EN TURNERING, FÅR ANDERS BESKJED</CoachNote>
  </Sheet>;
}

/* B7 Treningssamling: egen blokk i plan og kalender. */
function CampSheet({ c, onClose }) {
  const { Sheet, Button, KeyValue } = ns(), Pp = P();
  if (!c) return null;
  return <Sheet open onClose={onClose} kicker={"Treningssamling · uke " + c.week} title={c.name} footer={<Button variant="secondary" fullWidth icon="x" onClick={onClose}>Lukk</Button>}>
    <KeyValue items={[["Dato", "06.10–10.10.2026"], ["Sted", c.place, { mono: false }], ["Økter", c.sessions + " økter · " + c.hours + " t"], ["Ansvarlig", c.lead, { mono: false }]]} />
    <div role="list">{c.program.map(([dag, what]) => <div role="listitem" key={dag} style={{ display: "grid", gridTemplateColumns: "88px minmax(0,1fr)", gap: 12, alignItems: "center", minHeight: 44, borderTop: "1px solid var(--border-hairline)" }}><Pp.Num s={{ font: "var(--type-num-s)" }}>{dag}</Pp.Num><span style={{ font: "400 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{what}</span></div>)}</div>
    <Pp.Meta>ØKTENE LEGGES I UKE 41 NÅR ANDERS PUBLISERER PROGRAMMET · VISES OGSÅ I GOOGLE</Pp.Meta>
  </Sheet>;
}

/* Google-kalender: to veier. Inn = hele kalenderen som opptatt tid. Ut = øktene i egen kalender. */
function GoogleSheet({ open, onClose, connected, setConnected }) {
  const { Sheet, Button, Checkbox, Switch } = ns(), Pp = P(), pd = PD();
  const [cals, setCals] = React.useState(() => Object.fromEntries(pd.googleCals));
  const [out, setOut] = React.useState(true), [busy, setBusy] = React.useState(false);
  if (!open) return null;
  const connect = () => { setBusy(true); setTimeout(() => { setBusy(false); setConnected(true); Pp.toast("Google-kalender er koblet", "3 HENDELSER DENNE UKA · ØKTENE LEGGES UT"); }, 500); };
  return <Sheet open onClose={onClose} kicker={connected ? "Koblet · sist synkronisert 08:14" : "Kalender"} title={connected ? "Google-kalender" : "Koble Google-kalender"}
    footer={connected ? <><Button variant="secondary" fullWidth onClick={() => { Pp.toast("Synkroniserer", "HENTER FRA GOOGLE"); }}>Synkroniser nå</Button><Button variant="ghost" fullWidth onClick={() => { setConnected(false); Pp.toast("Google-kalender er koblet fra", "HENDELSENE ER FJERNET FRA PLAN"); }}>Koble fra</Button></> : <><Button fullWidth icon="link" disabled={busy} onClick={connect}>{busy ? "Kobler til …" : "Koble til Google"}</Button><Button variant="ghost" fullWidth onClick={onClose}>Ikke nå</Button></>}>
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "grid", gridTemplateColumns: "24px minmax(0,1fr)", gap: 12 }}><Ic name="arrow-down-to-line" size={18} /><div style={{ display: "flex", flexDirection: "column", gap: 4 }}><span style={{ font: "600 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>Inn i Plan</span><Muted>Hendelsene fra kalenderne du velger vises i Plan med stiplet kant og merket GOOGLE. Coachen ser bare at tiden er opptatt, ikke hva det er.</Muted></div></div>
      <div role="group" aria-label="Kalendere som vises i Plan" style={{ paddingLeft: 36 }}>{Object.keys(cals).map((k) => <div key={k} style={{ minHeight: 44, display: "flex", alignItems: "center" }}><Checkbox checked={cals[k]} onChange={() => setCals((c) => ({ ...c, [k]: !c[k] }))} label={k} /></div>)}</div>
      <div style={{ display: "grid", gridTemplateColumns: "24px minmax(0,1fr)", gap: 12, borderTop: "1px solid var(--border-hairline)", paddingTop: 12 }}><Ic name="arrow-up-from-line" size={18} /><div style={{ display: "flex", flexDirection: "column", gap: 8 }}><span style={{ font: "600 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>Ut til Google</span><Muted>Øktene dine legges i en egen kalender, «AK Golf · økter». Endrer du en økt her, endres den i Google.</Muted><Switch label="Legg øktene ut i Google" checked={out} onChange={() => setOut((x) => !x)} /></div></div>
      <span style={{ display: "block", borderTop: "1px solid var(--border-hairline)", paddingTop: 8 }}><Pp.Meta>{connected ? "TOBIAS.LINDVIK@EPOST.NO · 2 KALENDERE INN · 1 UT" : "APPLE-KALENDER KOMMER SENERE"}</Pp.Meta></span>
      <div aria-label="Slik ser en importert hendelse ut" style={{ display: "flex", flexDirection: "column", gap: 6 }}><Pp.Meta>SLIK VISES DET I PLAN</Pp.Meta><Opt b={{ kind: "google", id: "demo", t: "19:00", min: 120, label: "Familiemiddag" }} /><Opt b={{ kind: "busy", sub: "skole", id: "demo2", t: "08:15", min: 405, label: "Skole" }} /></div>
    </div>
  </Sheet>;
}

/* Veileder første gang årsplanen lages. Kan hoppes over på hvert trinn. */
function GuideSheet({ open, onClose, onDone, go }) {
  const { Sheet, Button, ChoicePill } = ns(), Pp = P(), pd = PD(), G = pd.guide;
  const [i, setI] = React.useState(0), [pick, setPick] = React.useState({});
  if (!open) return null;
  const g = G[i], last = i === G.length - 1, next = () => last ? onDone() : setI(i + 1);
  const opts = [["Mars", "April", "Mai"], ["Srixon Tour · 6 runder", "Klubbmesterskap", "Juniortour"], Object.values(pd.periodTypes).map((t) => t.name), window.AK_IA ? window.AK_IA.treningsplaner : [], ["Koble Google-kalender", "Legg inn skole", "Senere"]][i];
  return <Sheet open onClose={onClose} kicker={"Årsplan · trinn " + (i + 1) + " av " + G.length + " · " + g.k} title={g.t}
    footer={<><Button fullWidth icon={last ? "check" : "arrow-right"} onClick={next}>{last ? "Lag årsplan" : "Neste"}</Button><div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 8 }}><Button variant="ghost" disabled={!i} onClick={() => setI(i - 1)}>Tilbake</Button><Button variant="ghost" onClick={next}>Hopp over</Button></div></>}>
    <div role="progressbar" aria-valuemin={1} aria-valuemax={G.length} aria-valuenow={i + 1} style={{ display: "grid", gridTemplateColumns: "repeat(" + G.length + ",minmax(0,1fr))", gap: 4 }}>{G.map((x, j) => <span key={x.k} style={{ height: 4, background: j <= i ? "var(--primary)" : "var(--surface-sunken)" }}></span>)}</div>
    <Muted>{g.text}</Muted>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{opts.map((o) => <ChoicePill key={o} selected={i === 2 || (pick[i] || []).includes(o)} onClick={() => i !== 2 && setPick((p) => ({ ...p, [i]: (p[i] || []).includes(o) ? p[i].filter((x) => x !== o) : [...(p[i] || []), o] }))}>{o}</ChoicePill>)}</div>
    {i === 2 && <Pp.Meta>FORSLAG · ESTIMAT FRA TURNERINGENE · DU FLYTTER GRENSENE ETTERPÅ</Pp.Meta>}
    <Pp.Meta>ALT KAN ENDRES SENERE · «?» PÅ HVERT NIVÅ FORKLARER</Pp.Meta>
  </Sheet>;
}

function HelpSheet({ level, onClose, onGuide }) {
  const { Sheet, Button } = ns(), h = level && PD().help[level];
  if (!h) return null;
  return <Sheet open onClose={onClose} kicker={"Hjelp · " + level} title={h[0]} footer={<><Button variant="secondary" fullWidth onClick={onClose}>Lukk</Button>{onGuide && <Button variant="ghost" fullWidth icon="route" onClick={onGuide}>Åpne veilederen</Button>}</>}><Muted>{h[1]}</Muted></Sheet>;
}

/* B8 Be coach endre planen: spilleren skriver hva, coach svarer i Innboks. */
function AskSheet({ open, onClose }) {
  const { Sheet, Button, ChoicePill, FormField } = ns(), Pp = P();
  const [txt, setTxt] = React.useState(""), [about, setAbout] = React.useState("Uke 40"), [tried, setTried] = React.useState(false);
  if (!open) return null;
  const send = () => { setTried(true); if (!txt.trim()) return; onClose(); Pp.toast("Sendt til Anders", "SVARET KOMMER I INNBOKS"); setTxt(""); setTried(false); };
  return <Sheet open onClose={onClose} kicker="Til Anders Kristiansen" title="Be coach endre planen" footer={<><Button fullWidth icon="send" onClick={send}>Send til Anders</Button><Button variant="ghost" fullWidth onClick={onClose}>Avbryt</Button></>}>
    <FormField label="Gjelder"><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{["Uke 40", "Turneringsperiode", "Srixon Tour", "Hele planen"].map((o) => <ChoicePill key={o} selected={about === o} onClick={() => setAbout(o)}>{o}</ChoicePill>)}</div></FormField>
    <FormField label="Hva vil du endre?" required error={tried && !txt.trim() ? "Skriv kort hva du vil endre." : null}><textarea className="pa-input" rows={4} value={txt} onChange={(e) => setTxt(e.target.value)} placeholder="Jeg har eksamen tirsdag 29.09 og vil flytte innspillsøkta." style={{ width: "100%", boxSizing: "border-box", resize: "vertical", font: "var(--type-body)", minHeight: 96, padding: 12 }}></textarea></FormField>
    <Pp.Meta>DU KAN OGSÅ ENDRE ALT SELV I REDIGER</Pp.Meta>
  </Sheet>;
}

/* Forslag når gjennomført tid er over 130 % eller under 70 % to uker på rad. Aldri sperre. */
function Suggestion({ onDismiss }) {
  const { Button } = ns(), Pp = P(), S = PD().suggestion;
  const [st, setSt] = React.useState(null);
  if (st === "nei") return null;
  return <section aria-label="Forslag" style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center", padding: "12px 16px", borderRadius: 8, background: "var(--surface-flat)", border: "1px solid var(--border-hairline)", minWidth: 0 }}>
    <div style={{ flex: "1 1 260px", minWidth: 0, display: "flex", flexDirection: "column", gap: 4 }}><span style={{ font: "500 14px/1.4 var(--font-sans)", color: "var(--text-primary)", textWrap: "pretty" }}>{st === "ja" ? "Uke 40 er gjort lettere." : S.text}</span><Pp.Meta>{st === "ja" ? S.effect.toUpperCase() : "FORSLAG · IKKE SPERRE · " + PD().weekPctSrc}</Pp.Meta></div>
    {!st && <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button variant="secondary" onClick={() => { setSt("ja"); Pp.toast("Uke 40 er gjort lettere", "KAN ANGRES I REDIGER"); }}>Gjør uke 40 lettere</Button><Button variant="ghost" onClick={() => { setSt("nei"); onDismiss && onDismiss(); }}>Ikke nå</Button></div>}
  </section>;
}

window.PLANS = { OktSheet, TurnSheet, CampSheet, GoogleSheet, GuideSheet, HelpSheet, AskSheet, Suggestion, CoachNote, Muted };
})();
