/* Stats — felles deler (runde 22): seksjon, «øverst i hver del», nok data, SG-strek, radar, sammenligning, filter. */
(() => {
const P_Meta = (p) => React.createElement(window.PHQ.Meta, p);
const P = () => window.PHQ, ns = () => window.PHQ.ns(), S = () => window.STATS_DATA;
const Ic = (p) => React.createElement(window.PHQ.ns().Icon, p);
const d1 = (v, d = 1) => v == null ? "—" : (v < 0 ? "−" : "") + Math.abs(v).toFixed(d).replace(".", ",");

const Sec = ({ k, meta, label, children, gap = 12 }) => <section aria-label={label || k} className="pa-card" style={{ padding: 16, gap, minWidth: 0 }}>{(k || meta) && <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>{k}</span>{meta != null && <P_Meta>{meta}</P_Meta>}</div>}{children}</section>;
const Muted = ({ children }) => <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{children}</p>;
const Row = ({ children, first, tpl = "minmax(0,1fr) auto", min = 52, label }) => <div role="listitem" aria-label={label} style={{ display: "grid", gridTemplateColumns: tpl, gap: 12, alignItems: "center", minHeight: min, borderTop: first ? "none" : "1px solid var(--border-hairline)", padding: "6px 0", minWidth: 0 }}>{children}</div>;
const Lbl = ({ children, sub }) => <span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{children}</span>{sub && <P_Meta>{sub}</P_Meta>}</span>;

/* Nok data: under 4 runder «Registrer X runder til» · 4–7 foreløpig · tee og innspill sikre fra 12, nærspill og putting fra 24. */
function need(n, area) {
  const N = S().need, safe = N.safe[area] || 12;
  if (n < N.min) return { k: "none", text: "Registrer " + (N.min - n) + " " + (N.min - n === 1 ? "runde" : "runder") + " til" };
  if (n >= safe) return { k: "safe", text: "SIKKER · " + n + " RUNDER" };
  return { k: "prelim", text: "FORELØPIG · " + n + " AV " + safe + " RUNDER" };
}
const NeedTag = ({ n, area }) => { const x = need(n, area); if (x.k === "safe") return <P_Meta>{x.text}</P_Meta>; if (x.k === "none") return <P_Meta>{x.text.toUpperCase()}</P_Meta>; return <span style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "2px 6px", borderRadius: 4, background: "var(--surface-sunken)", font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-secondary)" }}>{x.text}</span>; };
function NotEnough({ n, go, what }) {
  const { EmptyState } = ns(), x = need(n, "tee");
  return <EmptyState icon="flag" title={x.text} text={(what || "Tallene") + " regnes ut fra rundene dine. Fra 4 runder vises de merket foreløpig. Tee og innspill er sikre fra 12 runder, nærspill og putting fra 24."} action="Registrer runde" actionIcon="flag" onAction={() => go("PH-RD-01")} />;
}

/* SG-strek, symmetrisk rundt 0. Grafitt; tap og gevinst skilles med retning, ikke farge. */
function SGBar({ v, max = 1.2 }) {
  const w = v == null ? 0 : Math.min(1, Math.abs(v) / max) * 50;
  return <div aria-hidden="true" style={{ position: "relative", height: 8, background: "var(--surface-sunken)", minWidth: 48 }}><span style={{ position: "absolute", left: "50%", top: -3, bottom: -3, width: 1, background: "var(--text-muted)" }}></span>{v != null && <span style={{ position: "absolute", top: 0, bottom: 0, left: v < 0 ? (50 - w) + "%" : "50%", width: w + "%", background: v < 0 ? "var(--primary)" : "var(--graphite-400)" }}></span>}</div>;
}

/* Øverst i hver del: positiv trend (hvis den finnes), deretter flest tapte slag, synkende. */
function Top({ trend, losses, lossK = "Flest tapte slag", lossMeta, empty }) {
  const Pp = P();
  return <Sec k="Øverst nå" label="Trend og flest tapte slag" gap={8}>
    {trend && <div style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr)", gap: 12, padding: "4px 0 8px", alignItems: "start" }}>
      <span style={{ width: 28, height: 28, borderRadius: 999, display: "grid", placeItems: "center", background: "var(--surface-sunken)", color: "var(--text-primary)" }}><Ic name="trending-up" size={16} /></span>
      <div style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span style={{ font: "600 15px/1.35 var(--font-sans)", color: "var(--text-primary)", textWrap: "pretty" }}>{trend.title}</span><Pp.Meta>{trend.meta}</Pp.Meta></div>
    </div>}
    {!trend && !empty && <Pp.Meta s={{ paddingBottom: 4 }}>INGEN TYDELIG FORBEDRING SISTE 10 RUNDER MOT DE 10 FØR</Pp.Meta>}
    <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap", borderTop: "1px solid var(--border-hairline)", paddingTop: 10 }}><span style={{ flex: "1 1 auto", font: "600 13px/1.3 var(--font-sans)", color: "var(--text-secondary)" }}>{lossK}</span>{lossMeta && <Pp.Meta>{lossMeta}</Pp.Meta>}</div>
    <div role="list">{empty ? <Pp.Meta>—</Pp.Meta> : losses.map((l, i) => <Row key={l.label} first={!i} tpl="20px minmax(0,1fr) auto" label={l.label + " " + Pp.sg(l.v)}><Pp.Meta>{i + 1}</Pp.Meta><Lbl sub={l.meta}>{l.label}</Lbl><Pp.Num s={{ font: "600 15px/1 var(--font-mono)", textAlign: "right" }}>{l.valText || Pp.sg(l.v)}</Pp.Num></Row>)}</div>
  </Sec>;
}

/* Sammenligning: neste kategori (ESTIMAT) som standard, PGA Tour kan slås på. */
function Compare({ pga, setPga }) {
  const { Switch } = ns(), Pp = P(), c = S().cmp[pga ? "pga" : "c"];
  return <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap", minWidth: 0 }}>
    <div style={{ flex: "1 1 220px", minWidth: 0, display: "flex", flexDirection: "column", gap: 2 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>Mot {c.long}</span><Pp.Meta>{c.src}</Pp.Meta></div>
    <Switch label="Sammenlign med PGA Tour" checked={pga} onChange={() => setPga(!pga)} />
  </div>;
}

/* Radar for Ytelsesbilde: fem faktorer, 1–5. */
function Radar({ vals, base: r0, size = 220, label }) {
  const F = S().ybFactors, c = size / 2, r = size / 2 - 34;
  const pt = (i, v) => { const a = (-90 + i * 72) * Math.PI / 180; return [c + Math.cos(a) * r * v / 5, c + Math.sin(a) * r * v / 5]; };
  const poly = (o) => F.map(([k], i) => pt(i, o[k] || 0).map((n) => n.toFixed(1)).join(",")).join(" ");
  return <svg role="img" aria-label={label} viewBox={"0 0 " + size + " " + size} style={{ width: "100%", maxWidth: size, height: "auto", display: "block", margin: "0 auto", overflow: "visible" }}>
    {[1, 2, 3, 4, 5].map((l) => <polygon key={l} points={F.map((_, i) => pt(i, l).join(",")).join(" ")} fill="none" stroke="var(--border-hairline)" />)}
    {r0 && <polygon points={poly(r0)} fill="none" stroke="var(--text-muted)" strokeWidth="1.5" strokeDasharray="4 4" />}
    <polygon points={poly(vals)} fill="var(--text-primary)" fillOpacity=".08" stroke="var(--text-primary)" strokeWidth="2" strokeLinejoin="round" />
    {F.map(([k, l], i) => { const [x, y] = pt(i, vals[k] || 0), [lx, ly] = pt(i, 6.6); return <g key={k}><circle cx={x} cy={y} r="4" fill="var(--surface-card)" stroke="var(--text-primary)" strokeWidth="2" /><text x={lx} y={ly} textAnchor="middle" dominantBaseline="middle" fontFamily="var(--font-mono)" fontSize="10" fill="var(--text-secondary)">{l.split(" ")[0].toUpperCase()} {d1(vals[k])}</text></g>; })}
  </svg>;
}

/* Én «Filter»-knapp. Valgte filtre som brikker som bryter linje. */
function useFilters() { const [f, setF] = React.useState({ tidsrom: ["Siste 8 uker"] }); return [f, setF]; }
function FilterBar({ f, setF, empty }) {
  const { Button, Sheet, ChoicePill, IconButton } = ns(), Pp = P(), F = S().filters;
  const [open, setOpen] = React.useState(false), [draft, setDraft] = React.useState(f);
  const chips = F.flatMap(([k, , opts]) => (f[k] || []).map((v) => [k, v]));
  const tog = (k, v, single) => setDraft((d) => { const cur = d[k] || []; return { ...d, [k]: single ? [v] : cur.includes(v) ? cur.filter((x) => x !== v) : [...cur, v] }; });
  const n = chips.length;
  return <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", minWidth: 0 }}>
      <Button variant="secondary" icon="sliders-horizontal" disabled={empty} onClick={() => { setDraft(f); setOpen(true); }}>{"Filter" + (n ? " · " + n : "")}</Button>
      {chips.map(([k, v]) => <span key={k + v} style={{ display: "inline-flex", alignItems: "center", gap: 2, minHeight: 36, padding: "0 4px 0 12px", borderRadius: 999, border: "1px solid var(--border-hairline)", background: "var(--surface-card)", font: "500 13px/1 var(--font-sans)", color: "var(--text-primary)", maxWidth: "100%" }}><span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{v}</span>{k !== "tidsrom" && <IconButton icon="x" size="sm" label={"Fjern " + v} onClick={() => setF((x) => ({ ...x, [k]: x[k].filter((y) => y !== v) }))} />}</span>)}
    </div>
    {open && <Sheet open onClose={() => setOpen(false)} kicker="Stats · Trening" title="Filter" footer={<><Button fullWidth icon="check" onClick={() => { setF(draft); setOpen(false); Pp.toast("Filter brukt", F.flatMap(([k]) => draft[k] || []).join(" · ").toUpperCase()); }}>Bruk filter</Button><Button variant="ghost" fullWidth onClick={() => setDraft({ tidsrom: ["Siste 8 uker"] })}>Nullstill</Button></>}>
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>{F.map(([k, label, opts, single]) => <div key={k} role="group" aria-label={label} style={{ display: "flex", flexDirection: "column", gap: 8 }}><Pp.Meta>{label.toUpperCase()}{single ? " · ÉN" : ""}</Pp.Meta><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{opts.map((o) => <ChoicePill key={o} selected={(draft[k] || []).includes(o)} onClick={() => tog(k, o, single)}>{o}</ChoicePill>)}</div></div>)}</div>
    </Sheet>}
  </div>;
}

window.STATSP = { d1, Sec, Muted, Row, Lbl, need, NeedTag, NotEnough, SGBar, Top, Compare, Radar, useFilters, FilterBar, Ic };
})();
