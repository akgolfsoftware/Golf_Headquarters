/* Lokal egen-video (golf-Live PH-05). Kun lokal prototypevedlegg: ingen opplasting, ingen deling, ingen rå filbytes lagret. */
(() => {
const P = () => window.PHQ, NS = (() => { try { return new URLSearchParams(location.search).get("ns") || "" } catch (e) { return "" } })(), KEY = "ak-proto-ph05media-v1:" + NS, MAX = 50 * 1024 * 1024;
const read = () => { try { const v = JSON.parse(localStorage.getItem(KEY) || "[]"); return Array.isArray(v) ? v : [] } catch (e) { return [] } };
const hash = (t) => { let x = 5381; for (const ch of String(t)) x = ((x << 5) + x + ch.charCodeAt(0)) >>> 0; return x.toString(36) };
const size = (b) => b >= 1048576 ? (b / 1048576).toFixed(1).replace(".", ",") + " MB" : Math.max(1, Math.round(b / 1024)) + " kB";
const txt = { margin: 0, font: "var(--type-body)", color: "var(--text-primary)" }, lab = { font: "500 13px/1.3 var(--font-sans)", color: "var(--text-secondary)" }, btn = { minHeight: 44, minWidth: 44 };
const supportsCapture = () => !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
function Panel({ ctx, onClose }) {
  const { Button } = P().ns(), [file, setFile] = React.useState(null), [url, setUrl] = React.useState(null), [er, setEr] = React.useState(null), [rec, setRec] = React.useState(null), [vakt, setVakt] = React.useState(false), root = React.useRef(null);
  const ur = React.useRef(null), setU = (u) => { if (ur.current) URL.revokeObjectURL(ur.current); ur.current = u; setUrl(u) };
  React.useEffect(() => () => { if (ur.current) { URL.revokeObjectURL(ur.current); ur.current = null } }, []);
  React.useLayoutEffect(() => { const b = root.current && root.current.querySelector('[data-control-id="ph05-media-velg-fil"]'); b && b.focus() }, []);
  React.useLayoutEffect(() => { if (!er) return; const e = root.current && root.current.querySelector('[data-control-id="ph05-media-feil"]'); if (e) { e.setAttribute("tabindex", "-1"); e.focus() } }, [er]);
  React.useLayoutEffect(() => { if (!vakt) return; const b = root.current && root.current.querySelector('[data-control-id="ph05-media-vakt-bli"]'); b && b.focus() }, [vakt]);
  const check = (f) => { if (!f) return "Velg en fil først."; if (!/^(video|image)\//.test(f.type || "")) return "Filtypen støttes ikke (" + (f.type || "ukjent") + "). Velg en video eller et bilde."; if (!f.size) return "Filen er tom."; const lim = (window.PH_MEDIA && window.PH_MEDIA.MAX) || MAX; if (f.size > lim) return "Filen er for stor (" + size(f.size) + "). Grensen er " + size(lim) + "."; return null };
  const pick = (e) => { const f = e.target.files && e.target.files[0]; e.target.value = ""; if (!f) return; setRec(null); const m = check(f); setU(null); if (m) { setFile(null); setEr(m); return } setEr(null); setFile(f); setU(URL.createObjectURL(f)) };
  const fjern = () => { setU(null); setFile(null); setEr(null); setRec(null) };
  const lukk = () => { setU(null); onClose() };
  const avbryt = () => { if (file && !rec) setVakt(true); else lukk() };
  const bekreft = () => { const m = check(file); if (m) return setEr(m); try { const k = [ctx.drillInstanceId, ctx.sessionId || "", ctx.publicationId || "", ctx.publishedRev == null ? "" : ctx.publishedRev, ctx.performerId, file.name, file.size, file.lastModified].join("|"), all = read(), ex = all.find((r) => r.key === k); if (ex) { setRec(ex); setEr(null); return } const r = { mediaId: "media-" + hash(k), key: k, performerId: ctx.performerId, sourceOwnerId: ctx.sourceOwnerId, drillInstanceId: ctx.drillInstanceId, sessionId: ctx.sessionId || null, publicationId: ctx.publicationId || null, publishedRev: ctx.publishedRev == null ? null : ctx.publishedRev, fil: { navn: file.name, type: file.type, bytes: file.size }, returnContext: ctx.returnContext, status: "lagret lokalt – ikke lastet opp eller delt", delt: false }; all.push(r); localStorage.setItem(KEY, JSON.stringify(all)); if (!read().find((x) => x.key === k)) throw new Error("les-tilbake"); setRec(r); setEr(null) } catch (e) { setEr("Vedlegget ble ikke lagret lokalt. Valget ditt er beholdt. Prøv igjen.") } };
  const video = file && /^video\//.test(file.type);
  return <section ref={root} data-control-id="ph05-media-panel" data-drill-instance-id={ctx.drillInstanceId} data-session-id={ctx.sessionId || ""} data-publication-id={ctx.publicationId || ""} data-publication-rev={ctx.publishedRev == null ? "" : ctx.publishedRev} data-performer-id={ctx.performerId} data-source-owner-id={ctx.sourceOwnerId || ""} data-return-context={JSON.stringify(ctx.returnContext)} aria-label={"Legg til egen video · " + ctx.drillName} className="pa-card" style={{ padding: 12, gap: 8, display: "flex", flexDirection: "column" }}>
    <span style={lab}>EGEN VIDEO ELLER BILDE · {String(ctx.drillName).toUpperCase()} · LAGRES BARE LOKALT</span>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
      <Button variant="secondary" icon="upload" data-control-id="ph05-media-velg-fil" onClick={() => root.current.querySelector('[data-control-id="ph05-media-fil"]').click()} style={btn}>Velg fil</Button>
      {supportsCapture() ? <Button variant="secondary" icon="camera" data-control-id="ph05-media-opptak" onClick={() => root.current.querySelector('[data-control-id="ph05-media-fil-opptak"]').click()} style={btn}>Ta opp</Button> : <span role="status" data-control-id="ph05-media-opptak-ikke-stottet" style={txt}>Opptak støttes ikke her. Velg en fil i stedet.</span>}
      <input type="file" accept="video/*,image/*" data-control-id="ph05-media-fil" aria-label="Velg video eller bilde" onChange={pick} style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }} tabIndex={-1} />
      <input type="file" accept="video/*,image/*" capture="environment" data-control-id="ph05-media-fil-opptak" aria-label="Ta opp video eller bilde" onChange={pick} style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }} tabIndex={-1} />
    </div>
    {file && <div data-control-id="ph05-media-forhandsvisning" data-media-type={file.type} data-media-bytes={file.size} style={{ display: "flex", flexDirection: "column", gap: 4 }}>{video ? <video src={url} controls muted playsInline style={{ maxWidth: "100%", maxHeight: 200 }}></video> : <img src={url} alt={"Forhåndsvisning av " + file.name} style={{ maxWidth: "100%", maxHeight: 200, objectFit: "contain" }} />}<span style={txt}>{file.name} · {file.type} · {size(file.size)} · til {ctx.drillName}</span></div>}
    {!file && !er && !rec && <span role="status" data-control-id="ph05-media-tom" style={txt}>Ingen fil valgt ennå.</span>}
    {er && <span role="alert" data-control-id="ph05-media-feil" style={{ font: "600 14px/1.3 var(--font-sans)" }}>{er}</span>}
    {rec && <span role="status" data-control-id="ph05-media-status" data-media-id={rec.mediaId} style={txt}>Lagret lokalt – ikke lastet opp eller delt. Vedlegg {rec.mediaId}.</span>}
    {vakt && <div role="group" aria-label="Ulagret valg" data-control-id="ph05-media-vakt" style={{ display: "flex", flexDirection: "column", gap: 8 }}><span role="status" style={txt}>Filen er valgt, men ikke lagret lokalt. Hva vil du gjøre?</span><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button data-control-id="ph05-media-vakt-bli" onClick={() => setVakt(false)} style={btn}>Bli her</Button><Button variant="secondary" data-control-id="ph05-media-vakt-forkast" onClick={lukk} style={btn}>Forkast</Button></div></div>}
    <div role="group" aria-label="Handlinger" style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
      {file && !rec && <Button variant="secondary" data-control-id="ph05-media-fjern" onClick={fjern} style={btn}>Fjern valg</Button>}
      <Button variant="ghost" data-control-id="ph05-media-avbryt" onClick={avbryt} style={btn}>{rec ? "Lukk" : "Avbryt"}</Button>
      {!rec && <Button data-control-id="ph05-media-bekreft" onClick={bekreft} style={btn}>{er && file ? "Prøv igjen · " : ""}Lagre lokalt</Button>}
    </div></section>;
}
window.PH_MEDIA = { Panel, read, KEY, MAX };
})();
