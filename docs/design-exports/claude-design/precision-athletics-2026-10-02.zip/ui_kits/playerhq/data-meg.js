/* PlayerHQ PH-21–26 — oppdiktede data. Tobias Lindvik, født 2009. Dagens dato lørdag 26.09.2026. */
window.PHQ_ME = {
  thread: [
    { id: "m1", from: "coach", t: "FRE 25.09 · 21:10", text: "Bra økt i går. Hold samme rytme på 50 m i morgen, og registrer avstand på hvert slag." },
    { id: "m2", from: "me", t: "FRE 25.09 · 21:32", text: "Skal gjøre det. Kan vi se på 7-jernet mandag? Det går lenger enn før." },
    { id: "m3", from: "coach", t: "LØR 26.09 · 07:55", text: "Ja. Ta med TrackMan-tallene fra torsdag. Jeg har lagt inn 20 min på mandag.", attach: "Innspill 150–200 m · Mandag 28.09" },
  ],
  questions: [
    { id: "q1", t: "Hvor mange baller bør jeg slå før en turnering?", date: "20.09.2026", status: "Besvart", answer: "30–40 slag, halvparten wedger. Avslutt med 10 putter fra 3 fot." },
    { id: "q2", t: "Skal jeg bytte til 56° i stedet for 54°?", date: "24.09.2026", status: "Venter på svar", answer: null },
  ],
  feedback: [
    { id: "f1", session: "Innspill og nærspill · 26.09", from: "me", rating: 4, text: "Lengdekontroll satt bedre på 50 m enn 100 m.", t: "26.09 · 15:44" },
    { id: "f2", session: "Privattime · 23.09", from: "coach", text: "P6 er mye bedre. Neste steg er P7 med samme hastighet.", t: "23.09 · 18:02" },
  ],
  recentSessions: ["Innspill og nærspill · 26.09", "TrackMan · wedge-lengder · 24.09", "Privattime · Anders · 23.09", "Styrke bein og kjerne · 21.09"],
  videos: [
    { id: "v1", title: "Treffpunkt med PW", len: "4:12", date: "25.09.2026", img: "../../assets/photos/academy-04.webp", seen: false },
    { id: "v2", title: "P6–P7 · Lav hastighet", len: "6:40", date: "23.09.2026", img: "../../assets/photos/academy-33.webp", seen: true },
    { id: "v3", title: "Oppstilling bunker", len: "3:05", date: "11.09.2026", img: "../../assets/photos/academy-35.webp", seen: true },
  ],
  plans: [
    { id: "pl1", title: "Uke 40 · 28.09–04.10", sent: "26.09.2026 · 07:50", status: "Venter på spiller", hours: "17,5 t", sessions: 10 },
    { id: "pl2", title: "Uke 39 · 21.09–27.09", sent: "19.09.2026", status: "Godtatt", hours: "16,0 t", sessions: 11 },
  ],
  caddie: [
    { id: "c1", from: "me", t: "08:02", text: "Hva bør jeg trene mest på denne uka?" },
    { id: "c2", from: "caddie", t: "08:02", text: "Innspill 100–150 m koster deg mest: SG APP −0,8 per runde. Putting 3–5 fot er nummer to med 81 % i hull mot 88 % for PGA Tour-snittet.", src: "10 RUNDER · 20.09.2026 · TRACKMAN 24.09.2026",
      draft: { kind: "Øvelse til økt", title: "Innspill 100–150 m · Lengdekontroll · Automatikk", meta: "30 SLAG · 20 MIN · MANDAG 28.09 16:00" } },
    { id: "c3", from: "me", t: "08:05", text: "Finnes det en turnering jeg kan spille i oktober?" },
    { id: "c4", from: "caddie", t: "08:05", text: "Srixon Tour finale på Borregaard GK 10.10 passer planen din. Den er en utviklingsturnering og krever ikke kategori C.", src: "GOLFBOX TERMINLISTE · 25.09.2026",
      draft: { kind: "Turnering til plan", title: "Srixon Tour finale · Borregaard GK", meta: "LØR 10.10.2026 · UTVIKLINGSTURNERING · PÅMELDING INNEN 03.10" } },
  ],
  booking: {
    rate: 950, currency: "kr",
    card: { pkg: "Performance Pro", total: 4, left: 3, valid: "30.09.2026", resets: "01.10.2026", covers: "Én coachet økt trekker ett klipp" },
    services: [
      { id: "pt60", name: "Privattime", min: 60, coach: "Anders Kristiansen", clip: true },
      { id: "pt30", name: "Privattime", min: 30, coach: "Anders Kristiansen", clip: true },
      { id: "bay", name: "TrackMan-bay", min: 60, coach: null, clip: false, price: 350 },
    ],
    days: [["Man", "28.09"], ["Tir", "29.09"], ["Ons", "30.09"], ["Tor", "01.10"], ["Fre", "02.10"]],
    slots: { 0: ["15:00", "16:30"], 1: ["14:00", "17:30", "18:30"], 2: [], 3: ["15:30", "16:30"], 4: ["14:00"] },
    mine: [{ id: "b1", svc: "pt60", day: "Tir 29.09", t: "16:30", place: "Studio · Fredrikstad GK", status: "Bekreftet" }],
    past: [{ id: "g1", svc: "pt60", day: "Lør 12.09.2026", t: "14:00", ref: "BK-2026-0884", src: "Booket som gjest · flyttet inn da kontoen ble opprettet 20.09.2026" }, { id: "g2", svc: "pt30", day: "Tor 27.08.2026", t: "17:00", ref: "BK-2026-0812", src: "Booket som gjest · flyttet inn da kontoen ble opprettet 20.09.2026" }],
    cancelHours: 24,
  },
  me: {
    born: 2009, club: "Fredrikstad GK", hcp: "8,4", cat: "D", since: "2019", email: "tobias.lindvik@epost.no",
    bag: [["Driver", "10,5° · stiv"], ["3W", "15°"], ["5W", "18°"], ["4H", "22°"], ["5i", "24°"], ["6i", "27°"], ["7i", "31°"], ["8i", "35°"], ["9i", "39°"], ["PW", "44°"], ["50°", "Bounce 8°"], ["54°", "Bounce 10°"], ["58°", "Bounce 8°"], ["Putter", "Mallet · 34 tommer"]],
    health: { injuries: null, sleep: "8 t 10 min", sleepSrc: "EGEN REGISTRERING · 7 DAGER · 26.09.2026", rpe: "6 av 10", rpeSrc: "ØKTER · 7 DAGER · 26.09.2026", note: "Stiv i korsryggen etter lange økter i august. Borte nå." },
    parents: [{ name: "Hanne Lindvik", role: "Forelder", consent: "Gitt 12.01.2026", email: "hanne.lindvik@epost.no" }, { name: "Tor Lindvik", role: "Forelder", consent: null, email: "tor.lindvik@epost.no" }],
    docs: [["Samtykke foresatte 2026", "PDF · 12.01.2026"], ["Helseerklæring", "PDF · 03.02.2026"], ["Sesongplan 2026", "PDF · 01.09.2026"]],
    friends: [{ id: "u1", name: "Ida Berg", group: "Junior elite" }, { id: "u2", name: "Nora Bakke", group: "Junior elite" }, { id: "u3", name: "Maja Strand", group: "Junior elite" }, { id: "u4", name: "Oskar Nilsen", group: "Venn" }],
    groups: [{ id: "g1", name: "Junior elite", n: 6 }, { id: "g2", name: "Treningsgruppe tirsdag", n: 4 }],
  },
  sub: {
    plans: [{ id: "TALENT", price: 0, per: null, feats: ["Åpent testbatteri", "Analyse og runderegistrering med SG", "Booking av enkelttimer", "DataGolf-sammenligning"] }, { id: "FULL", price: 299, year: 2690, per: "mnd", feats: ["Alt i Gratis", "Plan og Workbench", "Live-økt og Gameplan", "Caddie", "TrackMan-import"] }],
    current: { plan: "FULL", period: "mnd", renews: "26.10.2026", ends: "25.10.2026" },
    card: { brand: "Visa", last4: "4821", exp: "08/28" },
    invoices: [["26.09.2026", "Full · september", 299, "Betalt"], ["26.08.2026", "Full · august", 299, "Betalt"], ["26.07.2026", "Full · juli", 299, "Betalt"]],
  },
  leaderboard: { src: "SNITT BRUTTO · 10 TELLENDE RUNDER · 20.09.2026", group: "Junior elite",
    rows: [{ name: "Ida Berg", born: 2008, consent: true, avg: 74.1 }, { name: "Tobias Lindvik", born: 2009, consent: true, avg: 75.2, me: true }, { name: "Jonas Lie", born: 2009, consent: false, avg: 73.6 }, { name: "Maja Strand", born: 2007, consent: false, avg: 76.4 }, { name: "Sara Holm", born: 2011, consent: false, avg: 81.0 }, { name: "Henrik Aas", born: null, consent: true, avg: 72.9 }, { name: "Nora Bakke", born: 2010, consent: true, avg: 78.8 }, { name: "Oskar Nilsen", born: 2006, consent: false, avg: 77.0 }] },
  challenges: [
    { id: "ch1", title: "Putting 3 fot · 20 putter", status: "Aktiv", win: "hi", unit: "av 20", ends: "30.09.2026", by: "Tobias Lindvik", rows: [["Tobias Lindvik", 18], ["Ida Berg", 17], ["Nora Bakke", null]] },
    { id: "ch2", title: "Chip til 1 m · 10 baller", status: "Aktiv", win: "hi", unit: "av 10", ends: "04.10.2026", by: "Ida Berg", rows: [["Ida Berg", 7], ["Tobias Lindvik", null], ["Maja Strand", 6]] },
    { id: "ch3", title: "9 hull · lavest brutto", status: "Avsluttet", win: "lo", unit: "slag", ends: "19.09.2026", by: "Oskar Nilsen", rows: [["Tobias Lindvik", 38], ["Oskar Nilsen", 39], ["Ida Berg", 41]] },
  ],
  puttlab: { src: "PUTTER REGISTRERT · 30 DAGER · 26.09.2026", bands: [["0–3 ft", 98, 99, 150], ["3–5 ft", 81, 88, 180], ["5–10 ft", 52, 56, 200], ["10–25 ft", 20, 24, 210], ["25–40 ft", 5, 7, 60], ["40+ ft", 2, 3, 40]] },
  tournaments: [
    { d: "03.10.2026", n: "Klubbmesterskap · Fredrikstad GK", type: "Treningsturnering", st: "Påmeldt" },
    { d: "10.10.2026", n: "Srixon Tour finale · Borregaard GK", type: "Utviklingsturnering", st: "Ikke påmeldt" },
    { d: "24.10.2026", n: "Østlandsmesterskap junior · Onsøy GK", type: "Prestasjonsturnering", st: "Venter på uttak" },
  ],
  digest: { week: 39, src: "PLAN, ØKTER OG RUNDER · 21.09–27.09.2026", hours: [14.5, 18], sessions: [9, 11], rounds: 1, sg: -1.1, best: "Innspill 50–100 m: 5 av 10 i test, opp fra 4.", next: "Uke 40 venter på at du godtar planen fra Anders." },
};
