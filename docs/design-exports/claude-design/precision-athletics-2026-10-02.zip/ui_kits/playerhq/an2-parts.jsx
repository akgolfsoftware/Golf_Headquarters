(() => {
/* Treningsanalyse (PH-A01–A08): felles hode, undernavigasjon og hjelpere. */
const PAGES = [["PH-A01", "Oversikt"], ["PH-A02", "Belastning"], ["PH-A03", "Øktkvalitet"], ["PH-A04", "Slagdata"], ["PH-A05", "Nærspill og putting"], ["PH-A06", "Runder"], ["PH-A07", "Tester"], ["PH-A08", "Datagrunnlag"]];
const d1 = (v) => v == null ? "—" : (v < 0 ? "−" : "") + Math.abs(v).toFixed(1).replace(".", ",");
const pct = (a, b) => a == null || !b ? null : Math.round((a / b) * 100);
const AXL = { fys: "FYS", tek: "TEK", slag: "SLAG", spill: "SPILL", turn: "TURN" };
function Sub({ id, go }) {
  const { ChoicePill } = window.PHQ.ns();
  return <nav aria-label="Stats · Trening" style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{PAGES.map(([pid, l]) => <ChoicePill key={pid} selected={pid === id} aria-current={pid === id ? "page" : undefined} onClick={() => pid !== id && go(pid)}>{l}</ChoicePill>)}</nav>;
}
function Head({ id, title, sub, go, period, setPeriod, compare, setCompare, actions }) {
  const { PageHeader, PeriodSelector } = window.PHQ.ns();
  return <>
    <PageHeader kicker={"Stats · Trening · " + window.PHQ_DATA.player.name} title={title} sub={sub} actions={actions} />
    <Sub id={id} go={go} />
    {setPeriod && <PeriodSelector value={period} onChange={setPeriod} compare={compare} onCompare={setCompare} />}
  </>;
}
const Card = ({ k, aside, children, gap = 12 }) => <section className="pa-card" style={{ padding: 16, gap, minWidth: 0 }}>{(k || aside) && <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "center" }}>{k && <h2 className="kicker" style={{ margin: 0 }}>{k}</h2>}{aside}</div>}{children}</section>;
function usePeriod() { const [p, setP] = React.useState("8 uker"), [c, setC] = React.useState("Ingen"); return { period: p, setPeriod: setP, compare: c, setCompare: setC }; }
function Frame({ id, title, sub, go, state, loading, children, per, actions, empty }) {
  const P = window.PHQ;
  return <P.Page max={1280}>
    <Head id={id} title={title} sub={sub} go={go} actions={actions} {...(per || {})} />
    <P.Gate state={state} loading={loading} error={{ title: "Analysen kunne ikke hentes", text: "Ingen data er endret. Tallene hentes på nytt når du prøver igjen.", code: "FEIL 503 · ANALYSE · " + id }}>
      {state === "tom" ? empty : children}
    </P.Gate>
  </P.Page>;
}
window.PHQT = { PAGES, d1, pct, AXL, Sub, Head, Card, usePeriod, Frame };
})();
