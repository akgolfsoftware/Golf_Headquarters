(() => {
const kr = (n) => n == null ? "—" : String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " kr";
const STEPS = ["Tjeneste", "Tid", "Bekreft"];
function PH23({ state, go }) {
  const { PageHeader, Button, StatusPill, KeyValue, EmptyState, Sheet, Dialog, Segmented, ChoicePill, Icon } = window.PHQ.ns();
  const P = window.PHQ, B = window.PHQ_ME.booking, { mob, desk } = P.useW(), empty = state === "tom";
  const price = (s) => s.price != null ? s.price : B.rate * s.min / 60;
  const card = empty ? { ...B.card, left: 0, total: 0 } : B.card;
  const [step, setStep] = React.useState(0), [svc, setSvc] = React.useState(null), [day, setDay] = React.useState(1), [slot, setSlot] = React.useState(null), [pay, setPay] = React.useState("Klipp");
  const [mine, setMine] = React.useState(empty ? [] : B.mine), [done, setDone] = React.useState(null), [mv, setMv] = React.useState(null), [mvDay, setMvDay] = React.useState(3), [mvSlot, setMvSlot] = React.useState(null), [cx, setCx] = React.useState(null);
  const S = B.services.find((x) => x.id === svc);
  const canClip = S && S.clip && card.left > 0;
  const confirm = () => { const b = { id: "b" + Date.now(), svc, day: B.days[day].join(" "), t: slot, place: S.id === "bay" ? "Bay 3 · Fredrikstad GK" : "Studio · Fredrikstad GK", status: "Bekreftet", pay: canClip && pay === "Klipp" ? "Klipp" : kr(price(S)) }; setMine((m) => [b, ...m]); setDone(b); P.toast("Timen er booket", (S.name + " · " + b.day + " " + b.t).toUpperCase()); };
  const reset = () => { setDone(null); setStep(0); setSvc(null); setSlot(null); };
  const svcName = (id) => { const x = B.services.find((y) => y.id === id); return x.name + " · " + x.min + " min"; };
  const stepper = <ol aria-label="Steg" style={{ listStyle: "none", margin: 0, padding: 0, display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 6 }}>{STEPS.map((n, i) => <li key={n} style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}><span style={{ height: 4, background: i <= step ? "var(--primary)" : "var(--surface-sunken)" }}></span><span style={{ font: (i === step ? "600" : "500") + " 13px/1.2 var(--font-sans)", color: i === step ? "var(--text-primary)" : "var(--text-secondary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{i + 1} · {n}</span></li>)}</ol>;
  let flow;
  if (done) { const x = B.services.find((y) => y.id === done.svc); flow = <div className="pa-card" style={{ padding: 20, gap: 16 }}>
    <div style={{ display: "flex", gap: 8, alignItems: "center" }}><StatusPill tone="ok">Bekreftet</StatusPill><P.Meta>SENDT TIL {window.PHQ_ME.me.email.toUpperCase()}</P.Meta></div>
    <div style={{ font: "var(--type-title-m)", color: "var(--text-primary)" }}>{x.name} · {done.day} kl. {done.t}</div>
    <KeyValue items={[["Varighet", x.min + " min"], ["Sted", done.place, { mono: false }], ["Coach", x.coach, { mono: false }], ["Betaling", done.pay, { hint: done.pay === "Klipp" ? (card.left - 1) + " AV " + card.total + " KLIPP IGJEN ETTER TIMEN" : "FAKTURERES ETTER TIMEN" }]]} />
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button variant="secondary" icon="calendar-plus" onClick={() => P.toast("Lagt i kalenderen", "ICS-FIL LASTET NED")}>Legg i kalender</Button><Button variant="ghost" onClick={reset}>Book en til</Button></div>
  </div>; }
  else if (step === 0) flow = <div role="radiogroup" aria-label="Tjeneste" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,240px),1fr))", gap: 8 }}>{B.services.map((x) => { const on = x.id === svc; return <button key={x.id} type="button" role="radio" aria-checked={on} onClick={() => setSvc(x.id)} style={{ textAlign: "left", padding: 16, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), boxShadow: on ? "inset 0 0 0 1px var(--border-ink)" : "none", background: "var(--surface-card)", display: "flex", flexDirection: "column", gap: 6, cursor: "pointer", minWidth: 0, color: "var(--text-primary)" }}>
    <span style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span style={{ font: "600 15px/1.3 var(--font-sans)", flex: 1 }}>{x.name}</span><span style={{ font: "600 15px/1 var(--font-mono)" }}>{kr(price(x))}</span></span>
    <P.Meta>{x.min} MIN{x.coach ? " · " + x.coach.toUpperCase() : " · UTEN COACH"}{x.clip ? " · 1 KLIPP" : ""}</P.Meta>
    {x.note && <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{x.note}</span>}
  </button>; })}</div>;
  else if (step === 1) { const sl = B.slots[day] || []; flow = <div className="pa-card" style={{ padding: 16, gap: 16 }}>
    <div role="group" aria-label="Dag" style={{ display: "grid", gridTemplateColumns: "repeat(5,minmax(0,1fr))", gap: 4 }}>{B.days.map(([d, dt], i) => { const on = i === day, n = (B.slots[i] || []).length; return <button key={dt} type="button" aria-pressed={on} onClick={() => { setDay(i); setSlot(null); }} style={{ height: 60, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--primary)" : "var(--surface-card)", color: on ? "var(--text-on-primary)" : "var(--text-primary)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, cursor: "pointer", minWidth: 0 }}><span style={{ font: "500 11px/1 var(--font-sans)" }}>{d}</span><span style={{ font: "600 14px/1 var(--font-mono)" }}>{dt.slice(0, 2)}</span><span style={{ font: "500 10px/1 var(--font-mono)", opacity: .75 }}>{n ? n + " LEDIG" : "—"}</span></button>; })}</div>
    {sl.length ? <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{sl.map((t) => <ChoicePill key={t} mono selected={slot === t} onClick={() => setSlot(t)}>{t}</ChoicePill>)}</div> : <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen ledige tider {B.days[day].join(" ")}. Velg en annen dag.</p>}
  </div>; }
  else flow = <div className="pa-card" style={{ padding: 16, gap: 16 }}>
    <KeyValue items={[["Tjeneste", S.name + " · " + S.min + " min", { mono: false }], ["Tid", B.days[day].join(" ") + " kl. " + slot], ["Coach", S.coach, { mono: false }], ["Pris", kr(price(S))]]} />
    {S.clip ? <div><div className="pa-field__label" style={{ marginBottom: 8 }}>Betaling</div><Segmented options={card.left > 0 ? ["Klipp", "Kort"] : ["Kort"]} value={card.left > 0 ? pay : "Kort"} onChange={setPay} /><P.Meta s={{ display: "block", marginTop: 8 }}>{card.left > 0 ? card.left + " AV " + card.total + " KLIPP IGJEN · GYLDIG TIL " + card.valid : "INGEN KLIPP IGJEN · BETALES MED KORT"}</P.Meta></div> : <P.Meta>BETALES MED KORT ETTER TIMEN · KLIPPEKORT GJELDER BARE {B.card.covers.toUpperCase()}</P.Meta>}
    <P.Meta>GRATIS AVBESTILLING FRAM TIL {B.cancelHours} TIMER FØR</P.Meta>
  </div>;
  const next = done ? null : <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "space-between" }}><Button variant="ghost" icon="arrow-left" disabled={step === 0} onClick={() => setStep(step - 1)}>Tilbake</Button>{step < 2 ? <Button iconRight="arrow-right" disabled={(step === 0 && !svc) || (step === 1 && !slot)} onClick={() => setStep(step + 1)}>Neste: {STEPS[step + 1]}</Button> : <Button icon="check" onClick={confirm}>Bekreft booking</Button>}</div>;
  const side = <P.Stack>
    <div className="pa-card" style={{ padding: 16, gap: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">{empty ? "Klipp" : "Klipp · " + card.pkg}</span><P.Meta>{empty ? "—" : "NYE KLIPP " + card.resets}</P.Meta></div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}><span style={{ font: "var(--type-metric-l)", color: "var(--text-primary)" }}>{empty ? "—" : card.left}</span><P.Num s={{ color: "var(--text-muted)" }}>{empty ? "ingen klipp" : "av " + card.total + " klipp igjen"}</P.Num></div>
      {!empty && <div style={{ display: "grid", gridTemplateColumns: "repeat(" + card.total + ",minmax(0,1fr))", gap: 3 }} aria-hidden="true">{Array.from({ length: card.total }, (_, i) => <span key={i} style={{ height: 8, background: i < card.total - card.left ? "var(--surface-sunken)" : "var(--primary)" }}></span>)}</div>}
      <P.Meta>{B.card.covers.toUpperCase()} · {empty ? "KLIPP FØLGER COACHING-PAKKENE PERFORMANCE (2 PER MÅNED) OG PERFORMANCE PRO (4 PER MÅNED)" : card.total + " PER MÅNED · BRUKT " + (card.total - card.left) + " I SEPTEMBER"}</P.Meta>
    </div>
    <div className="pa-card" style={{ padding: "12px 16px" }}><span className="kicker" style={{ paddingBottom: 4 }}>Mine timer</span>
      {mine.length ? mine.map((m, i) => <div key={m.id} style={{ display: "flex", flexDirection: "column", gap: 8, padding: "12px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}>
        <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", flex: "1 1 160px" }}>{svcName(m.svc)}</span><StatusPill tone={m.status === "Avbestilt" ? "neutral" : "ok"}>{m.status}</StatusPill></div>
        <P.Meta>{m.day.toUpperCase()} KL. {m.t} · {m.place.toUpperCase()}</P.Meta>
        {m.status !== "Avbestilt" && <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button size="sm" variant="secondary" icon="move" onClick={() => { setMv(m); setMvSlot(null); }}>Flytt time</Button><Button size="sm" variant="ghost" onClick={() => setCx(m)}>Avbestill</Button></div>}
      </div>) : <p style={{ margin: "4px 0 8px", font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen bookede timer.</p>}
    </div>
    {!empty && B.past && B.past.length > 0 && <div className="pa-card" style={{ padding: "12px 16px" }}><span className="kicker" style={{ paddingBottom: 4 }}>Tidligere bookinger</span>
      {B.past.map((m, i) => <div key={m.id} style={{ display: "flex", flexDirection: "column", gap: 4, padding: "10px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", flex: "1 1 160px" }}>{svcName(m.svc)}</span><StatusPill>Gjennomført</StatusPill></div><P.Meta>{m.day.toUpperCase()} KL. {m.t} · {m.ref}</P.Meta><P.Meta>{m.src.toUpperCase()}</P.Meta></div>)}
    </div>}
  </P.Stack>;
  return <P.Page max={1200}>
    <PageHeader kicker="Meg · Booking" title="Book time" sub="Privattime eller TrackMan-bay hos Fredrikstad GK." />
    <P.Gate state={state} loading="Henter ledige tider …" error={{ title: "Ledige tider kunne ikke hentes", text: "Ingen timer er booket eller endret. Prøv igjen.", code: "FEIL 502 · KALENDER" }}>
      <P.Cols tpl={desk ? "minmax(0,1fr) 340px" : "minmax(0,1fr)"}>
        <P.Stack>{!done && stepper}{flow}{next}</P.Stack>
        {side}
      </P.Cols>
    </P.Gate>
    <Sheet open={!!mv} onClose={() => setMv(null)} kicker="Flytt time" title={mv ? svcName(mv.svc) : ""} footer={<><Button fullWidth icon="check" disabled={!mvSlot} onClick={() => { setMine((l) => l.map((x) => x.id === mv.id ? { ...x, day: B.days[mvDay].join(" "), t: mvSlot } : x)); P.toast("Timen er flyttet", (B.days[mvDay].join(" ") + " kl. " + mvSlot).toUpperCase() + " · ANDERS FÅR BESKJED"); setMv(null); }}>Flytt til {mvSlot ? B.days[mvDay].join(" ") + " " + mvSlot : "valgt tid"}</Button><Button variant="ghost" fullWidth onClick={() => setMv(null)}>Avbryt</Button></>}>
      {mv && <><P.Meta>NÅ · {mv.day.toUpperCase()} KL. {mv.t}</P.Meta><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{B.days.map(([d, dt], i) => <ChoicePill key={dt} selected={mvDay === i} onClick={() => { setMvDay(i); setMvSlot(null); }}>{d} {dt}</ChoicePill>)}</div><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{(B.slots[mvDay] || []).length ? B.slots[mvDay].map((t) => <ChoicePill key={t} mono selected={mvSlot === t} onClick={() => setMvSlot(t)}>{t}</ChoicePill>) : <P.Meta>INGEN LEDIGE TIDER</P.Meta>}</div></>}
    </Sheet>
    <Dialog open={!!cx} title="Avbestille timen?" onClose={() => setCx(null)} footer={<><Button variant="secondary" onClick={() => setCx(null)}>Behold timen</Button><Button variant="signal" onClick={() => { setMine((l) => l.map((x) => x.id === cx.id ? { ...x, status: "Avbestilt" } : x)); P.toast("Timen er avbestilt", "INGEN KLIPP TREKKES"); setCx(null); }}>Avbestill</Button></>}>{cx ? svcName(cx.svc) + " " + cx.day + " kl. " + cx.t + ". Mer enn " + B.cancelHours + " timer til timen, så ingen klipp trekkes." : ""}</Dialog>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-23"] = { id: "PH-23", parent: "PH-24", name: "Booking", tab: "meg", route: "/portal/booking", Component: PH23 };
})();
