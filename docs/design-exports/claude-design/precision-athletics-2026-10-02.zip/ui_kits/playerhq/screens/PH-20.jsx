(() => {
const TEE = { Driver: [228, 14, 12], "3W": [201, 11, 10], "4H": [178, 9, 9], "5i": [168, 8, 8], "6i": [160, 7, 7], "7i": [150, 6, 6], "8i": [139, 6, 6], "9i": [128, 5, 5], PW: [113, 5, 5] };
const geo = (i, len) => ({
  bunkers: [{ d: 225 + (i * 7) % 30, off: 16, r: 8 }, { d: 195 + (i * 11) % 25, off: -18, r: 7 }, { d: len - 8, off: 13, r: 6 }, { d: len - 14, off: -12, r: 5 }].filter((b) => b.d < len - 2 && b.d > 120),
  water: i % 5 === 3 ? { from: len * 0.35, to: len * 0.6, off: -26 } : null,
});
function options(par, len) {
  if (par === 3) return Object.entries(TEE).filter(([c]) => c !== "Driver" && c !== "3W").sort((a, b) => Math.abs(a[1][0] - len) - Math.abs(b[1][0] - len)).slice(0, 3).map(([c]) => c);
  return ["Driver", "3W", "4H"];
}
function risk(club, g) {
  const [carry, hw, ry] = TEE[club];
  let r = 0; g.bunkers.forEach((b) => { const dl = Math.abs(b.d - carry), lat = Math.abs(b.off) - b.r; if (dl < ry + b.r && lat < hw) r = Math.max(r, (hw - lat) / (2 * hw) * (1 - dl / (ry + b.r))); });
  if (g.water && carry > g.water.from - ry && carry < g.water.to + ry && Math.abs(g.water.off) - 6 < hw) r = Math.max(r, 0.25);
  return Math.round(r * 100);
}
function Hole({ i, par, len, club, empty }) {
  const P = window.PHQ, g = geo(i, len), k = 640 / len, X = (off) => 200 + off * k, Y = (m) => 690 - m * k;
  const [carry, hw, ry] = TEE[club] || [len, 4, 4], land = Math.min(carry, len), fwFrom = par === 3 ? len - 30 : 150;
  const fw = "M" + X(-15) + " " + Y(fwFrom) + " L" + X(-15) + " " + Y(len - 22) + " Q" + X(0) + " " + Y(len - 12) + " " + X(15) + " " + Y(len - 22) + " L" + X(15) + " " + Y(fwFrom) + " Q" + X(0) + " " + Y(fwFrom - 10) + " " + X(-15) + " " + Y(fwFrom) + "Z";
  return <svg viewBox="0 0 400 720" preserveAspectRatio="xMidYMid meet" style={{ width: "100%", height: "100%", display: "block" }} role="img" aria-label={"Hull " + (i + 1) + ", par " + par + ", " + len + " meter" + (empty ? "" : ", slagvalg " + club + " " + carry + " meter")}>
    <rect x="0" y="0" width="400" height="720" fill="var(--sand-200)" />
    <path d={fw} fill="var(--sand-100)" stroke="var(--border-strong)" strokeWidth="1" />
    {g.water && <rect x={X(g.water.off - 8)} y={Y(g.water.to)} width={16 * k} height={(g.water.to - g.water.from) * k} rx={8 * k} fill="var(--surface-sunken)" stroke="var(--text-secondary)" strokeDasharray="4 3" />}
    {g.bunkers.map((b, j) => <ellipse key={j} cx={X(b.off)} cy={Y(b.d)} rx={b.r * k} ry={b.r * k * 0.75} fill="var(--sand-300)" stroke="var(--sand-400)" strokeWidth="1.5" />)}
    <circle cx={X(0)} cy={Y(len)} r={14 * k} fill="var(--surface-card)" stroke="var(--text-primary)" strokeWidth="1.5" />
    <line x1={X(0)} y1={Y(len)} x2={X(0)} y2={Y(len) - 26} stroke="var(--text-primary)" strokeWidth="1.5" /><path d={"M" + X(0) + " " + (Y(len) - 26) + " l14 5 l-14 5Z"} fill="var(--text-primary)" />
    {[100, 150, 200].filter((m) => m < len - 20).map((m) => <g key={m}><line x1="24" x2="376" y1={Y(len - m)} y2={Y(len - m)} stroke="var(--text-muted)" strokeDasharray="2 5" /><text x="28" y={Y(len - m) - 4} style={{ font: "500 12px var(--font-mono)", fill: "var(--text-secondary)" }}>{m} M</text></g>)}
    {!empty && <>
      <ellipse cx={X(0)} cy={Y(land)} rx={hw * k} ry={ry * k} fill="var(--text-primary)" fillOpacity=".1" stroke="var(--text-primary)" strokeDasharray="5 4" strokeWidth="1.5" />
      <polyline points={X(0) + "," + Y(4) + " " + X(0) + "," + Y(land) + (land < len ? " " + X(0) + "," + Y(len) : "")} fill="none" stroke="var(--text-primary)" strokeWidth="2" strokeDasharray={land < len ? "none" : "none"} />
      <circle cx={X(0)} cy={Y(land)} r="5" fill="var(--text-primary)" />
      <text x={X(hw) + 8} y={Y(land) + 4} style={{ font: "600 13px var(--font-mono)", fill: "var(--text-primary)" }}>{club} · {carry} M</text>
      {land < len && <text x={X(0) + 8} y={(Y(land) + Y(len)) / 2} style={{ font: "500 12px var(--font-mono)", fill: "var(--text-secondary)" }}>{len - land} M IGJEN</text>}
    </>}
    <rect x={X(-6)} y={Y(0) - 8} width={12 * k} height="10" rx="2" fill="var(--graphite-600)" />
    <rect x="12" y="12" width="236" height="26" rx="4" fill="var(--surface-card)" stroke="var(--border-strong)" /><text x="22" y="30" style={{ font: "600 12px var(--font-sans)", fill: "var(--text-primary)" }}>Eksempeldata — ikke ekte baneguide</text>
    <text x="376" y="708" textAnchor="end" style={{ font: "500 12px var(--font-mono)", fill: "var(--text-secondary)" }}>HULL {i + 1} · PAR {par} · {len} M</text>
  </svg>;
}
function PH20({ state, go }) {
  const { PageHeader, Button, StatusPill, EmptyState, DataTable, KeyValue, Icon } = window.PHQ.ns();
  const P = window.PHQ, A = window.PHQ_AN, D = window.PHQ_DATA, Q = window.PHQA, C = D.course, { mob, pad, desk } = P.useW(), empty = state === "tom";
  const [cid, setCid] = React.useState("fgk"), [h, setH] = React.useState(0);
  const [picks, setPicks] = React.useState({}), course = A.courses.find((c) => c.id === cid), has = cid === "fgk" && !empty;
  const par = C.par[h], len = C.len[h], g = geo(h, len), opts = options(par, len);
  const scored = opts.map((c) => { const r = risk(c, g), rem = Math.max(0, len - TEE[c][0]); return { c, r, rem, s: r * 2 + (par === 3 ? Math.abs(rem) : Math.abs(rem - (par === 5 ? 230 : 120)) / 4) }; });
  const rec = scored.reduce((a, b) => b.s < a.s ? b : a).c, club = picks[h] || rec;
  const plan = (i) => { const gg = geo(i, C.len[i]), o = options(C.par[i], C.len[i]); return o.map((c) => ({ c, s: risk(c, gg) * 2 + (C.par[i] === 3 ? Math.abs(C.len[i] - TEE[c][0]) : Math.abs(C.len[i] - TEE[c][0] - (C.par[i] === 5 ? 230 : 120)) / 4) })).reduce((a, b) => b.s < a.s ? b : a).c; };
  const holeRows = C.par.map((p, i) => ({ id: i, n: i + 1, par: p, len: C.len[i], avg: A.holes[i], plan: picks[i] || plan(i) }));
  const map = <div className="pa-card" style={{ padding: 0, overflow: "hidden", height: mob ? 460 : 600 }}><Hole i={h} par={par} len={len} club={club} empty={!has} /></div>;
  const choice = <div className="pa-card" style={{ padding: 16, gap: 12 }}>
    <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">Slagvalg fra tee · hull {h + 1}</span><Q.Src est>TRACKMAN-SPREDNING · 24.09.2026</Q.Src></div>
    <div role="radiogroup" aria-label="Kølle fra tee" style={{ display: "flex", flexDirection: "column", gap: 8 }}>{scored.map((o) => { const on = o.c === club; return <button key={o.c} type="button" role="radio" aria-checked={on} onClick={() => setPicks((x) => ({ ...x, [h]: o.c }))} style={{ textAlign: "left", display: "grid", gridTemplateColumns: "56px minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 56, padding: "8px 12px", borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), boxShadow: on ? "inset 0 0 0 1px var(--border-ink)" : "none", background: "var(--surface-card)", color: "var(--text-primary)", cursor: "pointer", minWidth: 0 }}>
      <span style={{ font: "600 15px/1 var(--font-mono)" }}>{o.c}</span>
      <span style={{ display: "flex", flexDirection: "column", gap: 3, minWidth: 0 }}><span style={{ font: "var(--type-num-s)" }}>Carry {TEE[o.c][0]} m · {o.rem ? o.rem + " m igjen" : "på green"}</span><span style={{ display: "inline-flex", gap: 4, alignItems: "center", font: "var(--type-meta)", color: o.r >= 10 ? "var(--warn)" : "var(--text-muted)" }}>{o.r >= 10 && <Icon name="triangle-alert" size={12} />}{o.r ? "BUNKER I SPREDNING · CA. " + o.r + " %" : "INGEN HINDER I SPREDNING"}</span></span>
      {o.c === rec ? <StatusPill tone="info">Anbefalt</StatusPill> : <span></span>}
    </button>; })}</div>
    <KeyValue items={[["Spredning", "± " + TEE[club][1] + " m side · ± " + TEE[club][2] + " m lengde", { hint: "2 SD · ESTIMAT" }], ["Snitt på hullet", "+" + P.dec(A.holes[h]) + " til par", { hint: "14 RUNDER · 2026" }]]} />
  </div>;
  const holes = <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(52px,1fr))", gap: 4 }} role="group" aria-label="Hull">{C.par.map((p, i) => { const on = i === h; return <button key={i} type="button" aria-pressed={on} aria-label={"Hull " + (i + 1)} onClick={() => setH(i)} style={{ height: 52, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--primary)" : "var(--surface-card)", color: on ? "var(--text-on-primary)" : "var(--text-primary)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, cursor: "pointer", minWidth: 0 }}><span style={{ font: "600 14px/1 var(--font-mono)" }}>{i + 1}</span><span style={{ font: "500 10px/1 var(--font-mono)", opacity: .75 }}>PAR {p}</span></button>; })}</div>;
  return <P.Page max={1400}>
    <PageHeader kicker="Stats · Gameplan" title="Gameplan og banekart" sub="Velg bane og hull. Slagvalget bygger på TrackMan-spredningen din og hvor hindrene ligger." actions={<Button variant="secondary" icon="download" onClick={() => P.toast("Gameplan lagret som PDF", course.name.toUpperCase() + " · 18 HULL")}>Last ned gameplan</Button>} />
    <P.Gate state={state} loading="Henter banebiblioteket …" error={{ title: "Banekartet kunne ikke lastes", text: "Banedata hentes fra GolfBox. Gameplanene dine er lagret.", code: "FEIL 502 · GOLFBOX" }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,220px),1fr))", gap: 8 }}>{A.courses.map((c) => { const on = c.id === cid; return <button key={c.id} type="button" aria-pressed={on} onClick={() => { setCid(c.id); setH(0); }} className="pa-card pa-card--interactive" style={{ padding: 14, gap: 6, textAlign: "left", font: "inherit", cursor: "pointer", minWidth: 0, borderColor: on ? "var(--border-ink)" : undefined, boxShadow: on ? "inset 0 0 0 1px var(--border-ink)" : undefined }}>
        <span style={{ font: "600 15px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{c.name}</span>
        <P.Meta>{c.tee.toUpperCase()} · PAR {c.par} · {String(c.len).replace(/\B(?=(\d{3})+(?!\d))/g, " ")} M</P.Meta>
        <span style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><P.Num s={{ font: "var(--type-num-s)" }}>{empty ? "—" : c.avg == null ? "—" : P.dec(c.avg) + " slag"}</P.Num><P.Meta>{empty ? "0 RUNDER" : c.played + " RUNDER"}</P.Meta><span style={{ flex: 1 }}></span>{!empty && <StatusPill tone={c.plan === "Gameplan klar" ? "ok" : "neutral"}>{c.plan}</StatusPill>}</span>
      </button>; })}</div>
      {!has ? <EmptyState icon="map" title={empty ? "Ingen gameplan ennå" : "Ingen gameplan for " + course.name} text={empty ? "Spill en runde eller registrer TrackMan-spredning, så foreslår vi slagvalg per hull." : "Banekart for denne banen kommer etter lansering. Du kan lage gameplan med par og lengde nå."} action="Lag gameplan" actionIcon="map" onAction={() => P.toast("Gameplan startet", course.name.toUpperCase())} />
        : <P.Cols tpl={desk ? "300px minmax(0,1fr) 360px" : pad ? "minmax(0,1fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
          {desk ? <DataTable caption={course.name + " · hull-liste"} rowKey="id" selected={h} onSelect={setH} columns={[{ key: "n", label: "Hull", mono: true }, { key: "par", label: "Par", mono: true }, { key: "len", label: "Meter", mono: true, align: "right" }, { key: "plan", label: "Tee", mono: true }]} rows={holeRows} /> : null}
          <P.Stack>{!desk && holes}{map}<Q.Src est>BANEDATA · GOLFBOX · 01.05.2026 · BUNKER OG VANN ER EKSEMPELDATA · KOMPLETT BANEGUIDE ETTER LANSERING</Q.Src></P.Stack>
          <P.Stack>{choice}{!desk && pad && <DataTable caption="Hull-liste" rowKey="id" selected={h} onSelect={setH} columns={[{ key: "n", label: "Hull", mono: true }, { key: "par", label: "Par", mono: true }, { key: "plan", label: "Tee", mono: true }]} rows={holeRows} />}</P.Stack>
        </P.Cols>}
    </P.Gate>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-20"] = { id: "PH-20", parent: "PH-16", name: "Gameplan og banekart", tab: "analyse", route: "/portal/gameplan", Component: PH20 };
})();
