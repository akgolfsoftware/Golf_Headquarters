(() => {
/* Runde-registrering for SG · PH-RD-06 til 09 */
const R = () => window.RD_DATA, P = () => window.PHQ, H = () => window.PHRD, PRD = window.PHRD;

const PMeta = window.PHQ.Meta;
/* Manuell SG-seksjon, brukt i RD-06, RD-07 og RD-09 */
function SgFields({ value, onChange, locked }) {
  const { FormField, TextInput, Segmented, InlineAlert } = P().ns(), F = R().sgFields, [adv, setAdv] = React.useState(false);
  const num = (s) => s == null || String(s).trim() === "" ? null : Number(String(s).replace("−", "-").replace(",", "."));
  const parts = ["sgOtt", "sgApp", "sgArg", "sgPutt"].map((k) => num(value[k])), all = parts.every((x) => x != null && !isNaN(x));
  const sum = all ? parts.reduce((a, b) => a + b, 0) : null, tot = num(value.sgTotal), bad = all && tot != null && Math.abs(tot - sum) > 0.05;
  const field = ([k, l]) => <FormField key={k} label={l} optional error={k === "sgTotal" && bad ? "Totalen stemmer ikke med summen " + H().sg(sum) + "." : undefined}><TextInput mono inputMode="decimal" placeholder={k === "sgTotal" && sum != null ? H().sg(sum) : "—"} value={value[k] || ""} disabled={locked} onChange={(e) => onChange({ ...value, [k]: e.target.value })} /></FormField>;
  return <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
    <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>SG er slag vunnet (+) eller tapt (−) mot en referanse. La ukjente felt stå tomme — de lagres som «—», ikke 0.</p>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,150px),1fr))", gap: 12 }}>{F.main.map(field)}</div>
    {!bad && sum != null && <InlineAlert tone="info" title={"Sum av fire kategorier: " + H().sg(sum)}>SG totalt fylles ut med summen hvis du lar feltet stå tomt.</InlineAlert>}
    <Segmented options={["Enkel", "Avansert · alle kategorier"]} value={adv ? "Avansert · alle kategorier" : "Enkel"} onChange={(v) => setAdv(v !== "Enkel")} />
    {adv && F.detail.map(([g, fs]) => <fieldset key={g} style={{ border: "1px solid var(--border-hairline)", borderRadius: "var(--radius)", padding: 12, margin: 0, display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}><legend className="kicker" style={{ padding: "0 4px" }}>{g}</legend><div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,120px),1fr))", gap: 12 }}>{fs.map(field)}</div></fieldset>)}
    {adv && <PMeta>DETALJFELT SUMMERES IKKE TIL HOVEDKATEGORIENE · DE KAN OVERLAPPE</PMeta>}
  </div>;
}

/* PH-RD-06 · Etterregistrering / rask score */
function RD06({ state, go, nav }) {
  const { PageHeader, Button, Segmented, Select, FormField, TextInput, Stepper, DataQualityBadge, SourceBadge, InlineAlert, ActionBar, EmptyState, ChoicePill } = P().ns();
  const { useW, Page, Gate, Meta, Cols } = P(), { mob, desk } = useW(), C = R().course;
  const [mode, setMode] = React.useState("Hull for hull"), [n, setN] = React.useState("18"), [det, setDet] = React.useState(false), [total, setTotal] = React.useState(""), [src, setSrc] = React.useState("Etterregistrering");
  const [sc, setSc] = React.useState(C.holes.map(([p]) => p)), [sgv, setSgv] = React.useState({}), [st, setSt] = React.useState("idle");
  const holes = C.holes.slice(0, +n), gross = mode === "Hull for hull" ? sc.slice(0, +n).reduce((a, b) => a + b, 0) : (total ? +total : null), par = holes.reduce((a, [p]) => a + p, 0);
  const hasSg = Object.values(sgv).some((x) => String(x || "").trim());
  const nineTotal = n === "9" && mode === "Kun total";
  const dirty = () => { setSt("dirty"); nav && nav.setDirty(true); };
  const save = (partial) => { if (nineTotal) return; setSt("saving"); setTimeout(() => { setSt("saved"); nav && nav.setDirty(false); P().toast(partial ? "Delvis lagret" : "Runden er lagret", partial ? "KAN FULLFØRES SENERE" : "BRUTTO " + gross + " · " + (hasSg ? "MANUELL SG" : "SCOREKORTNIVÅ")); }, 400); };
  return <Page max={1200}>
    <PageHeader kicker="Runde · Etterregistrering · Brutto score" title="Registrer runde" sub="Score per hull eller total. Manuell SG fra annen app i egen seksjon." />
    <Gate state={state} loading="Henter baner …" error={H().ERR("RD-06")}>
      {state === "tom" ? <EmptyState icon="list-ordered" title="Velg bane for å starte" text="Par og hull-lengde hentes fra banen." action="Velg bane" actionIcon="map-pin" onAction={() => go("PH-RD-02")} /> : <>
      <Cols tpl={desk ? "minmax(0,1.3fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
        <PRD.Sec k="Scorekort" aside={<DataQualityBadge level={hasSg ? "manuell" : "tynn"} />}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,160px),1fr))", gap: 12 }}><Select label="Bane" options={[C.name, "Borregaard GK"]} /><FormField label="Dato"><TextInput mono defaultValue="20.09.2026" /></FormField><Select label="Rundetype" options={["Turnering", "Trening"]} /></div>
          <PRD.Row><Segmented options={["Hull for hull", "Kun total"]} value={mode} onChange={(v) => { setMode(v); dirty(); }} /><Segmented options={["9", "18"]} value={n} onChange={(v) => { setN(v); dirty(); }} />{mode === "Hull for hull" && <ChoicePill selected={det} onClick={() => setDet(!det)}>Putter · FW · GIR</ChoicePill>}</PRD.Row>
          {nineTotal && <InlineAlert tone="warn" title="9 hull krever hull for hull">Velg Hull for hull slik at riktig antall hull lagres.</InlineAlert>}
          {mode === "Kun total" ? <Stepper label="Brutto totalscore" value={total ? +total : par} min={18} max={199} onChange={(v) => { setTotal(String(v)); dirty(); }} />
            : <div style={{ display: "grid", gridTemplateColumns: mob ? "repeat(3,minmax(0,1fr))" : "repeat(6,minmax(0,1fr))", gap: 6 }}>{holes.map(([p, l], i) => <div key={i} style={{ display: "flex", flexDirection: "column", gap: 4, padding: 8, borderRadius: "var(--radius-inner)", border: "1px solid var(--border-hairline)", minWidth: 0 }}><Meta>{"H" + (i + 1) + " · P" + p + " · " + l + " M"}</Meta><PRD.Row gap={4}><button type="button" aria-label={"Hull " + (i + 1) + " ett mindre"} onClick={() => { setSc((s) => s.map((x, j) => j === i ? Math.max(1, x - 1) : x)); dirty(); }} className="pa-iconbtn pa-iconbtn--sm" style={{ border: "1px solid var(--border-strong)" }}>−</button><span style={{ flex: 1, textAlign: "center", font: "600 17px/1 var(--font-mono)" }}>{sc[i]}</span><button type="button" aria-label={"Hull " + (i + 1) + " ett mer"} onClick={() => { setSc((s) => s.map((x, j) => j === i ? x + 1 : x)); dirty(); }} className="pa-iconbtn pa-iconbtn--sm" style={{ border: "1px solid var(--border-strong)" }}>+</button></PRD.Row>{det && <Meta>PUTT — · {p > 3 ? "FW — · " : ""}GIR —</Meta>}</div>)}</div>}
          <div style={{ display: "flex", alignItems: "baseline", gap: 10, flexWrap: "wrap" }}><span style={{ font: "600 40px/1 var(--font-mono)" }}>{gross ?? "—"}</span><Meta>{gross == null ? "OPPGI SCORE" : "BRUTTO · " + H().toPar(gross - par) + " · PAR " + par}</Meta></div>
        </PRD.Sec>
        <PRD.Sec k="Manuell SG · fra annen app" aside={<Select label="Kilde" value={src} onChange={(e) => setSrc(e.target.value)} options={["Etterregistrering", "UpGame", "Annen app", "Turnering"]} />}>
          <SgFields value={sgv} onChange={(v) => { setSgv(v); dirty(); }} />
          <SourceBadge source={hasSg ? "Manuell SG · " + src : "Scorekortnivå · ingen beregnet SG"} date="20.09.2026" kind={hasSg ? "annen_app" : "manuell"} />
          <Button variant="ghost" icon="route" onClick={() => go("PH-RD-09")}>Legg til slag-for-slag for beregnet SG</Button>
        </PRD.Sec>
      </Cols>
      <ActionBar sticky={mob} status={st} statusMeta={st === "saved" ? "16:42" : undefined} secondary={<><Button variant="ghost" onClick={() => go("PH-RD-01")}>Avbryt</Button><Button variant="secondary" onClick={() => save(true)}>Lagre delvis</Button></>} primary={<Button icon="check" disabled={nineTotal || gross == null} onClick={() => save(false)}>Lagre runde</Button>} />
      </>}
    </Gate>
  </Page>;
}
H().reg("PH-RD-06", "Etterregistrering · rask score", RD06, false, "PH-RD-01");

/* PH-RD-07 · Import fra UpGame / annen app */
function RD07({ state, go, nav }) {
  const { PageHeader, Button, Segmented, Select, DataTable, InlineAlert, StatusPill, SourceBadge, DataQualityBadge, EmptyState, ActionBar } = P().ns();
  const { useW, Page, Gate, Meta, Cols } = P(), { mob, desk } = useW(), COLS = R().importCols;
  const [how, setHow] = React.useState("Last opp CSV"), [map, setMap] = React.useState(Object.fromEntries(COLS.map(([k, , , f]) => [k, f ? k : "—"]))), [done, setDone] = React.useState(false);
  const missReq = COLS.filter(([k, , req]) => req && map[k] === "—"), missOpt = COLS.filter(([k, , req]) => !req && map[k] === "—");
  const prev = R().course.holes.slice(0, 6).map(([p, l], i) => ({ id: i, h: i + 1, p, s: [4, 6, 3, 5, 4, 5][i], fir: p > 3 ? ["Ja", "Nei", null, "Ja", "Ja", "Nei"][i] : "—", gir: ["Ja", "Nei", "Ja", "Nei", "Ja", "Nei"][i], pt: [2, 2, 1, 2, 2, 2][i], fp: [18, 32, 6, 24, 12, 40][i], pen: [0, 1, 0, 0, 0, 0][i] }));
  return <Page max={1280}>
    <PageHeader kicker="Runde · Import · UpGame eller annen app" title="Importer runde" sub="Last opp eller lim inn CSV. Kolonnene kobles til AK Golf-feltene før noe lagres." />
    <Gate state={state} loading="Leser filen …" error={{ title: "Filen kunne ikke leses", text: "Ingenting er lagret. Sjekk at filen er CSV med én rad per hull.", code: "FEIL 422 · IMPORT · CSV" }}>
      {state === "tom" ? <EmptyState icon="upload" title="Ingen fil valgt" text="Eksporter runden fra UpGame (Round → Export → CSV) og last den opp her." action="Velg fil" actionIcon="upload" /> : done ? <>
      <InlineAlert tone="info" title="Runden er importert">18 hull, brutto 76, putter 32. SG er ikke beregnet av AK Golf: filen har ikke slag-for-slag.</InlineAlert>
      <Cols tpl={desk ? "repeat(2,minmax(0,1fr))" : "minmax(0,1fr)"}>
        <PRD.Sec k="Lagret"><ul style={{ margin: 0, paddingLeft: 18, display: "flex", flexDirection: "column", gap: 4, font: "var(--type-body-s)" }}><li>Score, par, putter, FW, GIR, første putt (ft) og straff per hull</li><li>Scrambling og kjørelengde</li><li>Kilde: UpGame CSV · importert 26.09.2026</li></ul><DataQualityBadge level="manuell" /></PRD.Sec>
        <PRD.Sec k="Mangler for beregnet SG"><ul style={{ margin: 0, paddingLeft: 18, display: "flex", flexDirection: "column", gap: 4, font: "var(--type-body-s)" }}><li>Lie og avstand for hvert slag</li><li>Bunker og sand save (ikke i filen)</li></ul><Button variant="secondary" icon="plus" onClick={() => go("PH-RD-06")}>Legg inn SG fra UpGame</Button></PRD.Sec>
      </Cols></> : <>
      <Segmented options={["Last opp CSV", "Lim inn"]} value={how} onChange={setHow} />
      {how === "Lim inn" ? <textarea aria-label="Lim inn CSV" defaultValue={"Hole,Par,Score,FIR,GIR,Putts,First Putt Distance,Penalties\n1,4,4,1,1,2,18,0\n2,5,6,0,0,2,32,1"} style={{ width: "100%", boxSizing: "border-box", minHeight: 120, padding: 12, borderRadius: "var(--radius)", border: "1px solid var(--border-control)", font: "13px/1.5 var(--font-mono)", background: "var(--surface-card)", color: "var(--text-primary)" }} /> : <PRD.Row><StatusPill tone="ok">upgame-fredrikstad-20-09.csv</StatusPill><Meta>18 RADER · 12 KOLONNER · 4 KB</Meta></PRD.Row>}
      <Cols tpl={desk ? "minmax(0,1fr) minmax(0,1.3fr)" : "minmax(0,1fr)"}>
        <PRD.Sec k="Kolonner" aside={<Meta>FIL → AK GOLF</Meta>}>
          {COLS.map(([k, l, req]) => <div key={k} style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) minmax(0,1fr)", gap: 8, alignItems: "end" }}><span style={{ display: "flex", flexDirection: "column", gap: 2, paddingBottom: 10 }}><span style={{ font: "500 14px/1.3 var(--font-sans)" }}>{l}</span><Meta>{req ? "PÅKREVD" : "VALGFRITT"}</Meta></span><Select label={"Kolonne for " + l} value={map[k]} onChange={(e) => setMap((m) => ({ ...m, [k]: e.target.value }))} options={["—"].concat(COLS.map((c) => c[0]))} /></div>)}
        </PRD.Sec>
        <div style={{ display: "flex", flexDirection: "column", gap: 12, minWidth: 0 }}>
          {missReq.length > 0 && <InlineAlert tone="warn" title={"Mangler " + missReq.length + " påkrevde kolonner"}>{missReq.map((c) => c[1]).join(", ")}. Runden kan ikke importeres uten dem.</InlineAlert>}
          {missOpt.length > 0 && <InlineAlert tone="info" title="Ikke i filen">{missOpt.map((c) => c[1]).join(", ")} lagres som «—».</InlineAlert>}
          <PRD.Sec k="Forhåndsvisning · hull 1–6"><DataTable caption="Forhåndsvisning" rowKey="id" columns={[{ key: "h", label: "Hull", mono: true }, { key: "p", label: "Par", mono: true, align: "right" }, { key: "s", label: "Score", mono: true, align: "right" }, { key: "fir", label: "FW", render: (r) => r.fir ?? "—" }, { key: "gir", label: "GIR" }, { key: "pt", label: "Putter", mono: true, align: "right" }, { key: "fp", label: "1. putt", mono: true, align: "right", render: (r) => r.fp + " ft" }, { key: "pen", label: "Straff", mono: true, align: "right" }]} rows={prev} /></PRD.Sec>
          <SourceBadge source="UpGame CSV" date="26.09.2026" n={18} unit="hull" kind="annen_app" />
        </div>
      </Cols>
      <ActionBar sticky={mob} secondary={<Button variant="ghost" onClick={() => go("PH-RD-01")}>Avbryt</Button>} primary={<Button icon="upload" disabled={missReq.length > 0} onClick={() => setDone(true)}>Importer 18 hull</Button>} />
      </>}
    </Gate>
  </Page>;
}
H().reg("PH-RD-07", "Import fra annen app", (p) => window.RD_LOKAL && window.RD_LOKAL.RD07n ? <window.RD_LOKAL.RD07n {...p} /> : <RD07 {...p} />, false, "PH-RD-01");

/* PH-RD-08 · Runde ferdig / oppsummering */
function RD08({ state, go, nav }) {
  const { PageHeader, Button, KeyValue, DataQualityBadge, SourceBadge, EmptyState, InlineAlert, ActionBar, StatusPill } = P().ns();
  const { useW, Page, Gate, Meta, Cols } = P(), { mob, desk } = useW(), S = R().summary, C = R().course, [st, setSt] = React.useState("idle"), [off, setOff] = React.useState(false);
  const save = () => { setSt("saving"); setTimeout(() => { setOff(true); setSt("error"); }, 400); };
  return <Page max={1200}>
    <PageHeader kicker="Runde · Gjennomført · 20.09.2026" title={C.name} sub="Brutto score. SG er beregnet fra slag-for-slag." meta={<StatusPill tone="ok">Komplett</StatusPill>} />
    <Gate state={state} loading="Regner ut runden …" error={H().ERR("RD-08")}>
      {state === "tom" ? <EmptyState icon="flag" title="Ingen hull ført" text="Før minst ett hull før du avslutter." action="Tilbake til runden" actionIcon="arrow-left" onAction={() => go("PH-RD-03")} /> : <>
      {off && <InlineAlert tone="warn" title="Ingen nett · runden er lagret på telefonen">Den sendes når nettet er tilbake. Ingenting er tapt.</InlineAlert>}
      <Cols tpl={desk ? "minmax(0,1fr) minmax(0,1.2fr)" : "minmax(0,1fr)"}>
        <PRD.Sec k="Score" aside={<DataQualityBadge level="god" have={18} unit="hull med slag" />}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 10, flexWrap: "wrap" }}><span style={{ font: "600 56px/1 var(--font-mono)" }}>{S.gross}</span><Meta>BRUTTO · {H().toPar(S.gross - S.par)} · PAR {S.par}</Meta></div>
          <KeyValue columns={2} items={[["Putter", String(S.putts)], ["Fairway", S.fw[0] + " av " + S.fw[1]], ["GIR", S.gir[0] + " av " + S.gir[1]], ["Straff", String(S.pen)]]} />
        </PRD.Sec>
        <PRD.Sec k="Strokes Gained" aside={<SourceBadge source={S.src} kind="okt" />}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}><span style={{ font: "600 40px/1 var(--font-mono)" }}>{H().sg(S.sg.total)}</span><Meta>SG TOTALT</Meta></div>
          {S.sg.cats.map(([k, v]) => <window.PHQA.SGBar key={k} label={k} v={v} />)}
          <Meta>NULL = BASELINE KATEGORI D</Meta>
        </PRD.Sec>
      </Cols>
      <PRD.Sec k="Hull for hull"><div role="list" style={{ display: "grid", gridTemplateColumns: mob ? "repeat(6,minmax(0,1fr))" : "repeat(9,minmax(0,1fr))", gap: 4 }}>{C.holes.map(([p], i) => { const sc = window.PHQ_AN.rounds[0].card[i]; return <div role="listitem" key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2, padding: "6px 2px", borderRadius: "var(--radius-inner)", border: "1px solid var(--border-hairline)" }}><Meta>{i + 1}</Meta><span style={{ font: "600 15px/1 var(--font-mono)" }}>{sc}</span><Meta s={{ fontSize: 10 }}>{H().sg(S.holeSg[i])}</Meta></div>; })}</div><Meta>TALL = BRUTTO · UNDER = HULL-SG</Meta></PRD.Sec>
      <ActionBar sticky={mob} status={st} statusMeta={off ? "LAGRET LOKALT" : undefined} secondary={<><Button variant="ghost" icon="arrow-left" onClick={() => go("PH-RD-03")}>Tilbake og rett</Button><Button variant="secondary" onClick={() => { setSt("saved"); P().toast("Delvis lagret", "KAN FULLFØRES SENERE"); }}>Lagre delvis</Button></>} primary={<Button icon="check" onClick={save}>Lagre runde</Button>} />
      </>}
    </Gate>
  </Page>;
}
H().reg("PH-RD-08", "Runde gjennomført", RD08, false, "PH-RD-03");

/* PH-RD-09 · Runde-detalj / rediger */
function RD09({ state, go, nav }) {
  const { PageHeader, Button, DataTable, StatusPill, SourceBadge, ConfirmDialog, EmptyState, InlineAlert, ActionBar, ChoicePill } = P().ns();
  const { useW, Page, Gate, Meta, Cols } = P(), { mob, desk } = useW(), D = R(), [tab, setTab] = React.useState("SG"), [sgv, setSgv] = React.useState({ sgTotal: "−1,1", sgOtt: "+0,4", sgApp: "−0,8", sgArg: "−0,3", sgPutt: "−0,2" });
  const [ow, setOw] = React.useState(false), [st, setSt] = React.useState("idle");
  return <Page max={1200}>
    <PageHeader kicker="Runde · 20.09.2026 · Fredrikstad GK" title="Rediger runde" sub="Scorekort, SG og slag-for-slag. Manuell SG er beskyttet." meta={<StatusPill tone="info">Manuell SG beskyttet</StatusPill>} />
    <Gate state={state} loading="Henter runden …" error={H().ERR("RD-09")}>
      {state === "tom" ? <EmptyState icon="flag" title="Runden finnes ikke" text="Den kan være slettet eller flyttet." action="Til runder" actionIcon="arrow-left" onAction={() => go("PH-18")} /> : <>
      <div role="tablist" style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{["Scorekort", "SG", "Slag-for-slag", "Revisjon"].map((x) => <ChoicePill key={x} role="tab" aria-selected={tab === x} selected={tab === x} onClick={() => setTab(x)}>{x}</ChoicePill>)}</div>
      {tab === "SG" && <PRD.Sec k="SG · manuell" aside={<SourceBadge source="Manuell · Tobias Lindvik" date="21.09.2026" kind="manuell" />}>
        <InlineAlert tone="info" title="Manuell SG overskrives ikke automatisk">Runden har også slag-for-slag. Beregnet SG er −1,1 med PUTT −0,4. Du valgte å rette PUTT til −0,2.</InlineAlert>
        <SgFields value={sgv} onChange={(v) => { setSgv(v); setSt("dirty"); nav && nav.setDirty(true); }} />
        <Button variant="secondary" icon="refresh-cw" onClick={() => setOw(true)}>Bruk beregnet SG i stedet</Button>
      </PRD.Sec>}
      {tab === "Scorekort" && <PRD.Sec k="Scorekort"><DataTable caption="Scorekort" rowKey="h" columns={[{ key: "h", label: "Hull", mono: true }, { key: "p", label: "Par", mono: true, align: "right" }, { key: "l", label: "Meter", mono: true, align: "right" }, { key: "s", label: "Brutto", mono: true, align: "right" }]} rows={D.course.holes.slice(0, 9).map(([p, l], i) => ({ h: i + 1, p, l, s: window.PHQ_AN.rounds[0].card[i] }))} /></PRD.Sec>}
      {tab === "Slag-for-slag" && <PRD.Sec k="Hull 5 · 2 slag ført"><DataTable caption="Slag" rowKey="n" columns={[{ key: "n", label: "Slag", mono: true }, { key: "a", label: "Fra", render: (s) => H().lieL(s.lie) + " " + H().dist(s.lie, s.dist) }, { key: "b", label: "Til", render: (s) => H().lieL(s.res.lie) + " " + H().dist(s.res.lie, s.res.dist) }, { key: "c", label: "Kølle" }, { key: "sg", label: "SG", mono: true, align: "right", render: (s) => H().sg(s.sg) }]} rows={D.live.chain} /><Button variant="secondary" icon="plus" onClick={() => go("PH-RD-04")}>Legg til eller rett slag</Button></PRD.Sec>}
      {tab === "Revisjon" && <PRD.Sec k="Revisjon og kilde"><DataTable caption="Revisjon" rowKey="t" columns={[{ key: "t", label: "Tid", mono: true }, { key: "what", label: "Endring" }, { key: "src", label: "Av" }, { key: "sg", label: "SG", render: (r) => <StatusPill tone={r.sg === "Manuell" ? "info" : r.sg === "Låst" ? "neutral" : "ok"}>{r.sg}</StatusPill> }]} rows={D.revisions} /></PRD.Sec>}
      <ActionBar sticky={mob} status={st} statusMeta={st === "saved" ? "09:12" : undefined} secondary={<Button variant="ghost" onClick={() => go("PH-18")}>Avbryt</Button>} primary={<Button icon="check" onClick={() => { setSt("saved"); nav && nav.setDirty(false); }}>Lagre endringer</Button>} />
      </>}
    </Gate>
    <ConfirmDialog open={ow} kind="destructive" title="Erstatte manuell SG med beregnet?" confirmLabel="Bruk beregnet" consequences={["SG PUTT går fra −0,2 (manuell) til −0,4 (beregnet).", "Den manuelle verdien ligger i revisjonen og kan hentes tilbake."]} onCancel={() => setOw(false)} onConfirm={() => { setOw(false); setSgv({ ...sgv, sgPutt: "−0,4" }); nav && nav.undo("Beregnet SG er tatt i bruk", "KAN ANGRES I 8 SEKUNDER", () => setSgv({ ...sgv })); }} />
  </Page>;
}
H().reg("PH-RD-09", "Rediger runde", RD09, false, "PH-18");
})();
