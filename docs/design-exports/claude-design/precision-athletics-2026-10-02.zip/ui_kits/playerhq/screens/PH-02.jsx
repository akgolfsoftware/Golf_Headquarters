/* PH-02 Gjør nå — utgår 28.09 (runde 20). Gjentok bare dagens økter; oppgavene fra coach ligger nå i agendaen på PH-01.
   /portal/gjennomfore, /portal/tren/wb og /portal/live sender videre til /portal (I dag). Registreres som alias så gamle lenker viser I dag. */
(() => {
const PH01 = (window.PHQ_SCREENS || {})["PH-01"];
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-02"] = { id: "PH-02", name: "Gjør nå · utgår 28.09 → I dag", tab: "idag", route: "/portal/gjennomfore → /portal", utgar: true, Component: PH01 ? PH01.Component : () => null };
})();
