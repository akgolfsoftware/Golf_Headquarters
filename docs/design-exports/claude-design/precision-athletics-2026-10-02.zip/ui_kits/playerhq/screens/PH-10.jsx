/* PH-10 Plan — runde 21 (Anders 28.09). Én flate. Se-modus i zoom År · Måned · Uke · Dag (mobil åpner i Uke).
   Golf, fysisk, turneringer og samlinger i samme plan; opptatt tid og Google som eget lag. «Rediger» åpner Workbench (PH-11) på samme sted.
   PH-WB-FYS og PH-WB-TURN er lag i Plan, ikke egne sider: de åpner Plan med laget i fokus.
   Runde 35: kort «Teknisk plan» → PH-TP-01 (aktiv · utkast fra coach · ingen plan = ikke vist). Ingen egen primærknapp. */
(() => {
const ZOOM = ["År", "Måned", "Uke", "Dag"];
function PlanScreen({ state, go, focus }) {
  const { PageHeader, Segmented, Button, IconButton, ChoicePill, EmptyState } = window.PHQ.ns();
  const P = window.PHQ, D = window.PHQ_DATA, PD = window.PLAN_DATA, V = window.PLANV, S = window.PLANS, { mob, cw } = P.useW(), empty = state === "tom", ok = state === "data";
  const [zoom, setZoom] = React.useState("Uke"), [week, setWeek] = React.useState(focus === "turn" ? 40 : PD.today.week), [day, setDay] = React.useState(PD.today.day), [month, setMonth] = React.useState(8);
  const [layers, setLayers] = React.useState({ golf: true, fys: true, turn: true, samling: true, opptatt: true, google: true });
  const [gconn, setGconn] = React.useState(!empty), [gOpen, setGOpen] = React.useState(false), [guide, setGuide] = React.useState(false), [help, setHelp] = React.useState(null), [ask, setAsk] = React.useState(false);
  const [open, setOpen] = React.useState(() => { if (!ok) return null; if (focus === "fys") { const s = D.plan.sessions.find((x) => x.id === "p10"); return { kind: "okt", ...s, by: "coach", ex: PD.fysEx.p10 }; } if (focus === "turn") return { kind: "turn", ref: PD.tournaments[0] }; return null; });
  const L = { ...layers, __google: gconn };
  const dates = D.wk(week), wlabel = "Uke " + week + " · " + V.dd(dates[0]) + "–" + V.dd(dates[6]);
  const per = PD.periods.find((p) => week >= p.from && week <= p.to), perName = PD.periodTypes[per.type].name;
  const label = zoom === "År" ? "2026" : zoom === "Måned" ? D.monthNames[month][0].toUpperCase() + D.monthNames[month].slice(1) + " 2026" : zoom === "Dag" ? D.dayNames[day] + " " + V.dd(dates[day]) : wlabel;
  const step = (n) => { if (zoom === "Måned") setMonth((m) => Math.max(0, Math.min(11, m + n))); else if (zoom === "Dag") { let d2 = day + n, w2 = week; if (d2 < 0) { d2 = 6; w2--; } if (d2 > 6) { d2 = 0; w2++; } if (w2 >= 39 && w2 <= 42) { setDay(d2); setWeek(w2); } } else if (zoom === "Uke") setWeek((w) => Math.max(39, Math.min(42, w + n))); };
  const canPrev = zoom === "Måned" ? month > 0 : zoom === "Dag" ? !(week === 39 && day === 0) : zoom === "Uke" ? week > 39 : false;
  const canNext = zoom === "Måned" ? month < 11 : zoom === "Dag" ? !(week === 42 && day === 6) : zoom === "Uke" ? week < 42 : false;
  const onOpen = (x) => setOpen(x);
  const it = V.weekItems(week, L), blockers = [...it.busy, ...it.goog];
  const grid = cw >= 900 && window.innerWidth > 1024; /* Tidsrutenett bare over 1024: korte økter blir under 44 px høye. Til og med 1024 vises ukelisten. */
  const noWeek = ok && week > 40 && !it.ses.length;
  const lay = PD.layers.filter((l) => !l.fixed);
  return <P.Page max={1320}>
    <PageHeader kicker={"Plan · " + perName + " · uke " + PD.today.week} title="Plan" actions={<><Button variant="secondary" icon="message-square" onClick={() => setAsk(true)} disabled={!ok}>Be coach endre</Button><Button variant={empty ? "secondary" : "primary"} icon="pencil" onClick={() => go("PH-11")} disabled={state === "laster" || state === "feil"}>Rediger</Button></>} />
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
      <div style={{ flex: mob ? "1 1 100%" : "0 1 auto", minWidth: 0 }}><Segmented options={ZOOM} value={zoom} onChange={setZoom} fullWidth={mob} /></div>
      <div style={{ display: "flex", gap: 4, alignItems: "center", flex: "1 1 auto", minWidth: 0 }}>
        <IconButton icon="chevron-left" label="Forrige" variant="secondary" disabled={!canPrev} onClick={() => step(-1)} />
        <span style={{ font: "600 15px/1.2 var(--font-sans)", color: "var(--text-primary)", minWidth: 0, flex: "0 1 auto", padding: "0 4px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{label}</span>
        <IconButton icon="chevron-right" label="Neste" variant="secondary" disabled={!canNext} onClick={() => step(1)} />
        <span style={{ flex: 1 }}></span>
        <IconButton icon="circle-help" label={"Hjelp · " + zoom} onClick={() => setHelp(zoom)} />
      </div>
    </div>
    <div role="group" aria-label="Lag i planen" style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
      {lay.map((l) => l.id === "google" && !gconn ? null : <ChoicePill key={l.id} selected={layers[l.id]} onClick={() => setLayers((x) => ({ ...x, [l.id]: !x[l.id] }))}>{l.label}</ChoicePill>)}
      <Button variant={gconn ? "ghost" : "secondary"} size="sm" icon={gconn ? "calendar-check" : "calendar-plus"} onClick={() => setGOpen(true)}>{gconn ? "Google · koblet" : "Koble Google-kalender"}</Button>
    </div>
    {window.WB3_PUB && <window.WB3_PUB.Kort go={go} from="PH-10" />}
    <P.Gate state={state} loading="Henter planen …" error={{ title: "Planen kunne ikke hentes", text: "Kalenderen svarte ikke. Øktene dine er ikke endret.", code: "FEIL 503 · PLAN · " + D.date.now }}>
      {empty ? <EmptyState icon="route" title="Ingen årsplan ennå" text="Veilederen tar deg gjennom sesong, turneringer, perioder, treningsplan og opptatt tid. Du kan hoppe over hvert trinn." action="Lag årsplan" actionIcon="route" onAction={() => setGuide(true)} secondary="Velg treningsplan" onSecondary={() => go("PH-12")} /> : <>
        {zoom === "Uke" && week === 39 && <S.Suggestion />}
        {zoom === "År" && <window.PLANV.YearView week={PD.today.week} onPickPeriod={(p) => { const d0 = D.wk(p.from)[3]; setMonth(d0.getMonth()); setZoom("Måned"); }} />}
        {zoom === "Måned" && <window.PLANV.MonthGrid year={2026} month={month} layers={L} onPickDay={(w, di) => { if (w >= 39 && w <= 42) { setWeek(w); setDay(di); setZoom("Dag"); } else P.toast("Uke " + w, w < 39 ? "TIDLIGERE UKER VISES I STATS › TRENING" : "IKKE PLANLAGT ENNÅ · ÅPNE REDIGER"); }} />}
        {zoom === "Uke" && (noWeek && !it.allday.length ? <EmptyState icon="calendar-range" title={"Uke " + week + " er ikke planlagt"} text="Legg inn økter i Workbench, eller kopier forrige uke." action="Rediger" actionIcon="pencil" onAction={() => go("PH-11")} /> : grid ? <window.PLANV.TimeGrid week={week} days={[0, 1, 2, 3, 4, 5, 6]} layers={L} onOpen={onOpen} /> : <window.PLANV.WeekList week={week} layers={L} onOpen={onOpen} onDay={(di) => { setDay(di); setZoom("Dag"); }} />)}
        {zoom === "Dag" && <window.PLANV.TimeGrid week={week} days={[day]} layers={L} onOpen={onOpen} PX={48} />}
        {zoom !== "År" && <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>{V.AX.map((a) => <span key={a} style={{ display: "inline-flex", gap: 6, alignItems: "center" }}><span style={{ width: 4, height: 14, background: "var(--axis-" + a + ")" }}></span><P.Meta>{a.toUpperCase()}</P.Meta></span>)}<span style={{ display: "inline-flex", gap: 6, alignItems: "center" }}><span style={{ width: 14, height: 14, borderRadius: 3, background: V.hatch, border: "1px dashed var(--border-strong)" }}></span><P.Meta>OPPTATT</P.Meta></span>{gconn && <span style={{ display: "inline-flex", gap: 6, alignItems: "center" }}><span style={{ width: 14, height: 14, borderRadius: 3, background: "var(--surface-card)", border: "1px dashed var(--border-strong)" }}></span><P.Meta>GOOGLE</P.Meta></span>}</div>}
        {window.TP && window.TP_DATA.entry(state) !== "ingen" && <window.TP.PlanEntry entry={window.TP_DATA.entry(state)} onOpen={() => go("PH-TP-01")} />}
        <S.CoachNote>DU KAN ENDRE ALT SELV · ANDERS FÅR BESKJED NÅR EN TURNERING ENDRES ELLER EN ØKT HAN LA INN ENDRES</S.CoachNote>
      </>}
    </P.Gate>
    {open && open.kind === "okt" && <S.OktSheet key={open.id} s={open} week={week} blockers={blockers} onClose={() => setOpen(null)} go={go} />}
    {open && open.kind === "turn" && <S.TurnSheet key={open.ref.id} t={open.ref} onClose={() => setOpen(null)} go={go} />}
    {open && open.kind === "samling" && <S.CampSheet key={open.ref.id} c={open.ref} onClose={() => setOpen(null)} />}
    <S.GoogleSheet open={gOpen} onClose={() => setGOpen(false)} connected={gconn} setConnected={(v) => { setGconn(v); if (v) setGOpen(false); }} />
    <S.GuideSheet open={guide} onClose={() => setGuide(false)} go={go} onDone={() => { setGuide(false); P.toast("Årsplanen er laget", "UTKAST · DU KAN ENDRE ALT"); }} />
    <S.HelpSheet level={help} onClose={() => setHelp(null)} onGuide={help === "År" ? () => { setHelp(null); setGuide(true); } : null} />
    <S.AskSheet open={ask} onClose={() => setAsk(false)} />
  </P.Page>;
}
const PH10 = (p) => <PlanScreen {...p} />;
window.PHQ_PLAN = PlanScreen;
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-10"] = { id: "PH-10", name: "Plan", tab: "plan", route: "/portal/planlegge", Component: PH10 };
})();
