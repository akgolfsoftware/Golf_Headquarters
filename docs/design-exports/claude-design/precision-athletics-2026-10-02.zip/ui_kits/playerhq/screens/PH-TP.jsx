(() => {
/* PH-TP-01 · Teknisk plan (spiller). Leser planen, ingen redigering. Registrerer repetisjoner og kvalitetssjekk. Rute /portal/tren/teknisk-plan/[planId]. Lenket fra PH-10 (kort) og PH-11-MAL (rad). Runde 35: utkast-tilstand, milepæler, tekniske krav, siste registreringer, video ved registrering. */
function PHTP01({ state, go, nav }) {
  const { PageHeader, Button, EmptyState, ChoicePill, Stepper, Sheet, Select, FormField, TextInput, InlineAlert } = window.PHQ.ns();
  const P = window.PHQ, TP = window.TP, D = window.TP_DATA, { mob, cw, night } = P.useW(), entry = D.entry(state), empty = state === "tom" || entry === "ingen", draft = entry === "utkast", wide = cw >= 900;
  const [mSel, setMSel] = React.useState("t1"), [ver, setVer] = React.useState(0), [dov, setDov] = React.useState({}), [sel, setSel] = React.useState(null), [open, setOpen] = React.useState({ t1: true }), [qc, setQc] = React.useState(null);
  const [reg, setReg] = React.useState(false), [r, setR] = React.useState({ task: "t1", step: "LH50", env: "Utendørs treningsområde", n: 20, cmt: "", video: false }), [rcpt, setRcpt] = React.useState(null), [log, setLog] = React.useState(D.log);
  React.useEffect(() => { const f = (e) => { if (!e || !e.key || e.key === "ak-proto-publisert-v2") setVer((x) => x + 1); }; window.addEventListener("storage", f); window.addEventListener("focus", f); return () => { window.removeEventListener("storage", f); window.removeEventListener("focus", f); }; }, []);
  const tasks = React.useMemo(() => window.TP2.playerTasks(D.tasks).map((t) => { const o = dov[t.id]; return o ? { ...t, steps: t.steps.map(([c, d, g]) => [c, o.steps && o.steps[c] != null ? o.steps[c] : d, g]), envs: t.envs.map(([e, d, g]) => [e, o.envs && o.envs[e] != null ? o.envs[e] : d, g]), qc: o.qc || t.qc } : t; }), [ver, dov]);
  const K = empty ? [] : tasks, shown = sel ? K.filter((t) => t.pos === sel) : K;
  const tot = K.reduce((a, t) => { const s = D.sum(t); return [a[0] + s[0], a[1] + s[1]]; }, [0, 0]);
  const rt = tasks.find((t) => t.id === r.task) || tasks[0], fam = D.family(rt.area), steps = fam === "Fullsving" ? D.STEPS_FULL : fam === "Bunker" ? D.STEPS_SAND : [];
  const pickTask = (id) => { const t = tasks.find((x) => x.id === id), f = D.family(t.area); setR((o) => ({ ...o, task: id, step: f === "Fullsving" || f === "Bunker" ? (t.steps.find((s) => s[1] < s[2]) || t.steps[0])[0] : null, env: t.env })); };
  const submit = () => {
    setDov((o) => { const t = tasks.find((x) => x.id === r.task), prev = o[r.task] || { steps: {}, envs: {} }, st = { ...prev.steps }, en = { ...prev.envs }; t.steps.forEach(([c, d]) => { if (steps.length ? c === r.step : true) st[c] = (d || 0) + r.n; }); t.envs.forEach(([e, d]) => { if (e === r.env) en[e] = (d || 0) + r.n; }); return { ...o, [r.task]: { ...prev, steps: st, envs: en } }; });
    const txt = "Registrert 27.09 · " + r.n + " repetisjoner" + (r.step ? " · " + D.stepName(r.step).replace(/ \d+ %$/, "") : "");
    setRcpt({ txt, task: rt.title, env: r.env, cmt: r.cmt }); setLog((l) => [{ id: "n" + l.length, date: "27.09.2026", task: r.task, reps: r.n, step: r.step, env: r.env, src: "Manuelt", cmt: r.cmt || null, reply: null, video: r.video }, ...l]); setReg(false); nav && nav.setDirty(false); P.toast(txt, "SENDT TIL ANDERS KRISTIANSEN"); setR((o) => ({ ...o, cmt: "", video: false }));
  };
  const saveQc = (res) => { setDov((o) => ({ ...o, [qc.id]: { ...(o[qc.id] || { steps: {}, envs: {} }), qc: { ...res, date: "27.09.2026", src: qc.tm ? "TrackMan" : "Manuelt" } } })); P.toast("Kvalitetssjekken er lagret", res.hits + " AV " + res.of + " · SENDT TIL ANDERS"); setQc(null); };
  const mt = tasks.find((x) => x.id === mSel) || tasks[0], pm = window.TP2.playerMedia(mt.id, D.MEDIA[mt.id]);
  return <P.Page max={1200}>
    <PageHeader kicker="Plan · Teknisk plan" title={D.plan.name} sub={draft ? "Utkast fra Anders Kristiansen. Ikke publisert ennå. Du kan lese utkastet, men registrere først når planen er publisert." : "Fra Anders Kristiansen. Publisert " + D.plan.pub + ". Du leser planen her. Endringer gjør du sammen med coachen."} actions={<><Button variant="secondary" icon="plus" onClick={() => setReg(true)} disabled={empty || draft}>Registrer repetisjoner</Button><Button icon="play" onClick={() => { window.PHQ_SEL = { sessionId: "okt-2609", kind: "golf" }; window.PHQ_SESSION = undefined; go("PH-04"); }}>Start økt</Button></>} />
    <P.Gate state={state} loading="Henter den tekniske planen …" error={{ title: "Planen kunne ikke hentes", text: "Registreringer du har gjort er lagret på telefonen og sendes når nettet er tilbake.", code: "FEIL 503 · TEKNISK PLAN" }}>
      {empty ? <EmptyState icon="list-checks" title="Ingen teknisk plan ennå" text="Anders lager planen sammen med deg. Du får varsel når den er publisert." action="Send melding til Anders" actionIcon="message-square" onAction={() => go("PH-21")} /> : <>
      {rcpt && <InlineAlert tone="ok" title={rcpt.txt}>{rcpt.task} · {rcpt.env}.{rcpt.cmt ? " Kommentaren er sendt til Anders." : ""}</InlineAlert>}
      {draft && <InlineAlert tone="info" title="Utkast fra coach">Anders Kristiansen jobber med planen. Oppgavene kan endres før den publiseres.</InlineAlert>}
      {(() => { const pl = window.TP2.published(); return pl.length ? <InlineAlert tone="ok" title={"Publisert av coach · " + pl.length}><span style={{ display: "flex", flexDirection: "column", gap: 2 }}>{pl.map((x) => <span key={x.taskId + x.kilde} data-task-id={x.taskId} data-rev={x.rev} data-kilde={x.kilde} style={{ font: "var(--type-meta)" }}>{(x.task && x.task.title) || x.title} · {x.kilde === "workbench-okt" ? "I ØKT UKE " + (x.uke || "—") : "TEKNISK PLAN"} · PUBLISERT {x.time}</span>)}</span></InlineAlert> : null; })()}
      <TP.Summary plan={D.plan} done={tot[0]} goal={tot[1]} mob={mob} draft={draft} />
      <div className="pa-card" style={{ padding: 16, gap: 12 }}><div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">Posisjoner P1.0–P10.0</span><TP.Meta>HOVEDFOKUS {D.plan.focus.join(" · ")}</TP.Meta></div>
        <TP.PosLine tasks={K} sel={sel} onSel={setSel} focus={D.plan.focus} mob={mob} />
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>Oppgaver · {sel || "alle posisjoner"}</span><TP.Meta>{shown.length} {shown.length === 1 ? "OPPGAVE" : "OPPGAVER"}</TP.Meta></div>
        {shown.length === 0 ? <div className="pa-card" style={{ padding: 16 }}><p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen oppgaver på {sel}.</p></div> : shown.map((t) => <TP.TaskCard key={t.id} t={t} mob={mob} wide={wide} open={!!open[t.id]} onToggle={() => setOpen((o) => ({ ...o, [t.id]: !o[t.id] }))} onQC={draft ? null : () => setQc(t)} />)}
      </div>
      <div className="pa-card" style={{ padding: 16, gap: 12 }}><div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">Før og etter · {mt.pos}</span><TP.Meta>{pm.for ? "FØR " + pm.for.dato : "FØR —"} · {pm.etter ? "ETTER " + pm.etter.dato : "ETTER —"}</TP.Meta></div>
        <div role="group" aria-label="Oppgave" style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{K.map((x) => <ChoicePill key={x.id} selected={x.id === mSel} aria-pressed={x.id === mSel} onClick={() => setMSel(x.id)} style={{ minHeight: 44 }}>{x.pos + " · " + x.title}</ChoicePill>)}</div>
        <window.TP2.MediaTrack key={mSel} task={mt} media={pm} onChange={() => {}} canEdit={false} viewer="spiller" />
      </div>
      {!draft && <TP.LogList log={log} tasks={tasks} />}
      </>}
    </P.Gate>
    <Sheet open={reg} onClose={() => setReg(false)} kicker="Teknisk plan" title="Registrer repetisjoner" footer={<><Button fullWidth size={night ? "xl" : "lg"} icon="check" disabled={!r.n} onClick={submit}>Registrer {r.n} repetisjoner</Button><Button variant="ghost" fullWidth onClick={() => setReg(false)}>Avbryt</Button></>}>
      <Select label="Oppgave" value={r.task} onChange={(e) => pickTask(e.target.value)} options={tasks.map((t) => ({ value: t.id, label: t.pos + " · " + t.title }))} />
      {steps.length > 0 && <div role="group" aria-label={fam === "Bunker" ? "Sandtrinn" : "Læringssteg"} style={{ display: "flex", flexDirection: "column", gap: 8 }}><span style={{ font: "500 13px/1.3 var(--font-sans)" }}>{fam === "Bunker" ? "Sandtrinn" : "Læringssteg"}</span><div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{steps.filter(([c]) => rt.steps.some((s) => s[0] === c)).map(([c, n]) => <ChoicePill key={c} size="lg" selected={r.step === c} aria-pressed={r.step === c} onClick={() => setR((o) => ({ ...o, step: c }))}>{n}</ChoicePill>)}</div></div>}
      <div role="group" aria-label="Treningsmiljø" style={{ display: "flex", flexDirection: "column", gap: 8 }}><span style={{ font: "500 13px/1.3 var(--font-sans)" }}>Treningsmiljø</span><div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{D.ENV.map((e) => <ChoicePill key={e} size="lg" selected={r.env === e} aria-pressed={r.env === e} onClick={() => setR((o) => ({ ...o, env: e }))}>{e}</ChoicePill>)}</div></div>
      <Stepper size="xl" label="Antall repetisjoner" value={r.n} min={0} max={500} onChange={(v) => { setR((o) => ({ ...o, n: v })); nav && nav.setDirty(true); }} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 8 }}><Button variant="secondary" size={night ? "xl" : "lg"} onClick={() => setR((o) => ({ ...o, n: Math.min(500, o.n + 10) }))}>+10</Button><Button variant="secondary" size={night ? "xl" : "lg"} onClick={() => setR((o) => ({ ...o, n: Math.min(500, o.n + 25) }))}>+25</Button></div>
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><Button variant="secondary" size={night ? "xl" : "lg"} icon={r.video ? "check" : "video"} aria-pressed={r.video} onClick={() => setR((o) => ({ ...o, video: !o.video }))}>{r.video ? "Video lagt ved" : "Legg ved video fra mobil"}</Button><TP.Meta>{r.video ? "SENDES MED REGISTRERINGEN" : "VALGFRITT"}</TP.Meta></div>
      <FormField label="Kommentar til coachen" optional><TextInput value={r.cmt} onChange={(e) => setR((o) => ({ ...o, cmt: e.target.value }))} placeholder="Hva kjente du?" /></FormField>
      <TP.Meta>KILDE MANUELT · 27.09.2026 · LAGRES PÅ TELEFONEN OM NETTET ER BORTE</TP.Meta>
    </Sheet>
    <TP.QCSheet open={!!qc} task={qc} onClose={() => setQc(null)} onSave={saveQc} toast={P.toast} outdoor={night} />
  </P.Page>;
}
window.PHQ_SCREENS["PH-TP-01"] = { id: "PH-TP-01", name: "Teknisk plan", tab: "plan", parent: "PH-10", route: "/portal/tren/teknisk-plan/[planId]", Component: PHTP01 };
})();
