(() => {
const kr = (n) => n == null ? "—" : String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " kr";
const Sec = ({ t, children, meta }) => <div className="pa-card" style={{ padding: 16, gap: 12, minWidth: 0 }}><div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">{t}</span>{meta}</div>{children}</div>;
function PH25({ state, go }) {
  const { PageHeader, Button, StatusPill, KeyValue, DataTable, Switch, Segmented, Dialog, FormField, TextInput, Icon, InlineAlert } = window.PHQ.ns();
  const P = window.PHQ, S = window.PHQ_ME.sub, { mob, pad, desk } = P.useW(), empty = state === "tom";
  const full = S.plans.find((p) => p.id === "FULL"), talent = S.plans.find((p) => p.id === "TALENT");
  const [plan, setPlan] = React.useState(empty ? "TALENT" : S.current.plan), [per, setPer] = React.useState(S.current.period === "mnd" ? "Månedlig" : "Årlig"), [cancel, setCancel] = React.useState(false), [cancelled, setCancelled] = React.useState(false), [del, setDel] = React.useState(false), [delTxt, setDelTxt] = React.useState("");
  const [c, setC] = React.useState({ coach: true, data: true, bilder: false, forsk: false }), [n, setN] = React.useState({ plan: true, meld: true, turn: true, digest: true, caddie: false }), [tfa, setTfa] = React.useState(true), [fb, setFb] = React.useState(""), [fbSent, setFbSent] = React.useState(false);
  const yearSave = full.price * 12 - full.year;
  return <P.Page max={1200}>
    <PageHeader kicker="Meg · Innstillinger" title="Abonnement og innstillinger" actions={<Button variant="secondary" icon="arrow-left" onClick={() => go("PH-24")}>Meg</Button>} />
    {empty && <InlineAlert tone="info" title="Gameplan krever Full">Du kom hit fordi flaten er låst i Gratis. Åpent i Gratis: testbatteriet, analyse og runderegistrering med SG, DataGolf-sammenligning, booking av enkelttimer og konto. Velg Full for plan, Live-økt, Gameplan og Caddie.</InlineAlert>}
    <P.Gate state={state} loading="Henter abonnement og innstillinger …" error={{ title: "Abonnementet kunne ikke hentes", text: "Ingenting er endret og ingenting er trukket. Prøv igjen.", code: "FEIL 502 · BETALING" }}>
      <div style={{ display: "grid", gridTemplateColumns: desk || pad ? "repeat(2,minmax(0,1fr))" : "minmax(0,1fr)", gap: 12 }}>
        {[talent, full].map((p) => { const on = plan === p.id; return <div key={p.id} className="pa-card" style={{ padding: 16, gap: 12, borderColor: on ? "var(--border-ink)" : undefined, boxShadow: on ? "inset 0 0 0 1px var(--border-ink)" : undefined }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><span style={{ font: "600 17px/1 var(--font-mono)", color: "var(--text-primary)", letterSpacing: ".04em", flex: 1 }}>{p.id === "FULL" ? "Full" : "Gratis"}</span>{on && <StatusPill tone={cancelled ? "warn" : "ok"}>{cancelled ? "Avsluttes " + S.current.ends : "Ditt nivå"}</StatusPill>}</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 6, flexWrap: "wrap" }}><span style={{ font: "var(--type-metric)", color: "var(--text-primary)" }}>{p.price ? kr(p.price) : "Gratis"}</span>{p.per && <P.Num s={{ color: "var(--text-muted)", font: "var(--type-num-s)" }}>per {p.per} · eller {kr(p.year)} per år</P.Num>}</div>
          <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 6 }}>{p.feats.map((f) => <li key={f} style={{ display: "flex", gap: 8, alignItems: "center", font: "var(--type-body-s)", color: "var(--text-primary)" }}><Icon name="check" size={14} />{f}</li>)}</ul>
          {!on && <div><Button variant={p.id === "FULL" ? "primary" : "secondary"} onClick={() => { setPlan(p.id); setCancelled(false); P.toast(p.id === "FULL" ? "Du har Full" : "Du bytter til Gratis", p.id === "FULL" ? kr(full.price).toUpperCase() + " PER MND · FORNYES 26.10.2026" : "GJELDER FRA " + S.current.renews); }}>{p.id === "FULL" ? "Velg Full" : "Bytt til Gratis"}</Button></div>}
        </div>; })}
      </div>
      <P.Cols tpl={desk ? "repeat(2,minmax(0,1fr))" : "minmax(0,1fr)"}>
        <P.Stack>
          {plan === "FULL" && <Sec t="Betalingsperiode" meta={<P.Meta>{cancelled ? "AVSLUTTES " + S.current.ends : "FORNYES " + S.current.renews}</P.Meta>}>
            <Segmented options={["Månedlig", "Årlig"]} value={per} onChange={(v) => { setPer(v); P.toast("Betalingsperiode endret", v === "Årlig" ? kr(full.year).toUpperCase() + " PER ÅR · FRA " + S.current.renews : kr(full.price).toUpperCase() + " PER MND"); }} />
            <P.Meta>{per === "Årlig" ? kr(full.year).toUpperCase() + " PER ÅR · SPARER " + kr(yearSave).toUpperCase() : kr(full.price).toUpperCase() + " PER MND · ÅRLIG GIR " + kr(yearSave).toUpperCase() + " LAVERE PRIS"}</P.Meta>
            {cancelled ? <InlineAlert tone="warn" title={"Full avsluttes " + S.current.ends}>Du beholder alt til og med {S.current.ends}. Deretter får du Gratis. Ingen flere trekk.</InlineAlert> : <div><Button variant="ghost" onClick={() => setCancel(true)}>Avslutt abonnement</Button></div>}
            {cancelled && <div><Button variant="secondary" onClick={() => { setCancelled(false); P.toast("Abonnementet fortsetter", "FORNYES " + S.current.renews); }}>Fortsett Full</Button></div>}
          </Sec>}
          <Sec t="Betalingskort">{empty ? <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen kort registrert.</p> : <KeyValue items={[["Kort", S.card.brand + " •••• " + S.card.last4], ["Utløper", S.card.exp]]} />}<div><Button size="sm" variant="secondary" icon="external-link" onClick={() => P.toast("Åpner Stripe-kundeportalen", "BYTT KORT OG SE KVITTERINGER HOS STRIPE")}>Bytt kort og se kvitteringer</Button></div><P.Meta>ÅPNES I STRIPE-KUNDEPORTALEN</P.Meta></Sec>
          {empty ? <Sec t="Faktura"><p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen fakturaer på Gratis.</p></Sec> : <DataTable caption="Faktura" rowKey="d" columns={[{ key: "d", label: "Dato", mono: true }, { key: "t", label: "Gjelder" }, { key: "a", label: "Beløp", mono: true, align: "right", render: (r) => kr(r.a) }, { key: "s", label: "Status", render: (r) => <StatusPill tone="ok">{r.s}</StatusPill> }]} rows={S.invoices.map(([d, t, a, s]) => ({ d, t, a, s }))} />}
        </P.Stack>
        <P.Stack>
          <Sec t="Samtykke" meta={<P.Meta>UNDER 16 ÅR GIR FORELDEREN SAMTYKKET</P.Meta>}>
            <Switch checked={c.coach} onChange={(e) => setC({ ...c, coach: e.target.checked })} label="Ytelsesbilde (søvn, mat, energi)" />
            <Switch checked={c.data} onChange={(e) => setC({ ...c, data: e.target.checked })} label="Opptak i coachingøkt" />
            <P.Meta>HVEM SOM SER DATAENE STYRES I MEG › DELING</P.Meta>
          </Sec>
          <Sec t="Varsler">
            {[["plan", "Ny plan fra coach"], ["meld", "Meldinger"], ["turn", "Turneringsfrister"], ["digest", "Ukesdigest søndag kveld"], ["caddie", "Forslag fra Caddie"]].map(([k, l]) => <Switch key={k} checked={n[k]} onChange={(e) => setN({ ...n, [k]: e.target.checked })} label={l} />)}
          </Sec>
          <Sec t="Sikkerhet"><Switch checked={tfa} onChange={(e) => { setTfa(e.target.checked); P.toast(e.target.checked ? "Tofaktor er slått på" : "Tofaktor er slått av", e.target.checked ? "KODE PÅ SMS TIL +47 ••• •• 412" : "ANBEFALES PÅ"); }} label="Tofaktor-innlogging (2FA)" /><P.Meta>{tfa ? "PÅ · SMS TIL +47 ••• •• 412 · SIDEN 12.01.2026" : "AV"}</P.Meta></Sec>
          <Sec t="Hjelp">{[["Slik registrerer du en runde", "file-text"], ["Slik kobler du TrackMan", "file-text"], ["Kontakt Fredrikstad GK", "mail"]].map(([t, ic], i) => <button key={t} type="button" onClick={() => P.toast("Åpner", t.toUpperCase())} style={{ all: "unset", cursor: "pointer", display: "flex", gap: 10, alignItems: "center", minHeight: 44, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><Icon name={ic} size={16} /><span style={{ flex: 1, font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{t}</span><Icon name="arrow-up-right" size={14} /></button>)}</Sec>
          <Sec t="Slett konto"><p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Alt du har registrert slettes innen 30 dager: økter, runder, tester, helse og meldinger. Abonnementet avsluttes i Stripe. Coachene mister tilgangen straks.</p><div><Button variant="signal" size="sm" icon="trash-2" onClick={() => setDel(true)}>Slett konto</Button></div></Sec>
          <Sec t="Tilbakemelding">{fbSent ? <div style={{ display: "flex", gap: 8, alignItems: "center" }}><StatusPill tone="ok">Sendt</StatusPill><P.Meta>TAKK · VI LESER ALT</P.Meta></div> : <><FormField label="Hva kan bli bedre?" optional><TextInput value={fb} onChange={(e) => setFb(e.target.value)} placeholder="Skriv kort" /></FormField><div><Button size="sm" icon="send" disabled={!fb.trim()} onClick={() => setFbSent(true)}>Send</Button></div></>}</Sec>
        </P.Stack>
      </P.Cols>
    </P.Gate>
    <Dialog open={del} title="Slette kontoen?" onClose={() => { setDel(false); setDelTxt(""); }} footer={<><Button variant="secondary" onClick={() => { setDel(false); setDelTxt(""); }}>Behold kontoen</Button><Button variant="primary" disabled={delTxt.trim().toUpperCase() !== "SLETT"} onClick={() => { setDel(false); setDelTxt(""); P.toast("Kontoen slettes", "INNEN 30 DAGER · KVITTERING PÅ E-POST"); }}>Slett for godt</Button></>}><div style={{ display: "flex", flexDirection: "column", gap: 10 }}><p style={{ margin: 0, font: "var(--type-body)" }}>Dette kan ikke angres. Skriv SLETT for å bekrefte.</p><FormField label="Skriv SLETT"><TextInput mono value={delTxt} onChange={(e) => setDelTxt(e.target.value)} placeholder="SLETT" /></FormField></div></Dialog>
    <Dialog open={cancel} title="Avslutte Full?" onClose={() => setCancel(false)} footer={<><Button variant="secondary" onClick={() => setCancel(false)}>Behold Full</Button><Button variant="primary" onClick={() => { setCancelled(true); setCancel(false); P.toast("Abonnementet avsluttes " + S.current.ends, "DU BEHOLDER FULL TIL DA"); }}>Avslutt abonnement</Button></>}>Full gjelder til og med {S.current.ends}. Etter det får du Gratis: testbatteri, analyse og runderegistrering, booking og konto. Plan fra coach, Live-økt, Gameplan og Caddie stopper.</Dialog>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-25"] = { id: "PH-25", parent: "PH-24", name: "Abonnement og innstillinger", tab: "meg", route: "/portal/meg/abonnement", routes: ["/portal/oppgrader?fra=laast", "/portal/meg/abonnement/oppgrader/flyt"], Component: PH25 };
})();
