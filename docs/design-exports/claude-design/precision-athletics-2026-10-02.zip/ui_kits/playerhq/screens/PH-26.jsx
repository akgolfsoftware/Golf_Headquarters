(() => {
const TABS = [{ value: "fys", label: "FYS-økt" }, { value: "utf", label: "Utfordringer" }, { value: "putt", label: "Putte-lab" }, { value: "turn", label: "Turneringer" }, { value: "digest", label: "Ukesdigest" }];
const FYS = [["Oppvarming · mobilitet", "10 min", "Bevegelighet"], ["Knebøy", "4 × 6 @ 40 kg", "RIR 2"], ["Rumensk markløft", "3 × 8 @ 30 kg", "RIR 3"], ["Utfall med rotasjon", "3 × 8 per side", "RIR 3"], ["Pallof press", "3 × 10 per side", "RIR 2"]];
const rankRows = (c) => { const done = c.rows.filter((r) => r[1] != null).sort((a, b) => c.win === "hi" ? b[1] - a[1] : a[1] - b[1]); return c.rows.map((r) => ({ name: r[0], v: r[1], rank: r[1] == null ? null : done.findIndex((x) => x[0] === r[0]) + 1 })).sort((a, b) => (a.rank || 99) - (b.rank || 99)); };
function Challenge({ c, me, onEnd }) {
  const { Button, StatusPill } = window.PHQ.ns();
  const P = window.PHQ, rows = rankRows(c), mine = c.by === me && c.status === "Aktiv";
  return <div className="pa-card" style={{ padding: 16, gap: 12, minWidth: 0 }}>
    <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><span style={{ font: "600 15px/1.3 var(--font-sans)", color: "var(--text-primary)", flex: "1 1 180px" }}>{c.title}</span><StatusPill tone={c.status === "Aktiv" ? "info" : "neutral"}>{c.status}</StatusPill></div>
    <P.Meta>{c.win === "hi" ? "HØYEST SCORE VINNER" : "LAVEST SCORE VINNER"} · {c.status === "Aktiv" ? "SLUTTER " : "AVSLUTTET "}{c.ends} · LAGET AV {c.by.toUpperCase()}</P.Meta>
    <div role="list">{rows.map((r, i) => <div role="listitem" key={r.name} style={{ display: "grid", gridTemplateColumns: "32px minmax(0,1fr) auto", gap: 10, alignItems: "center", minHeight: 40, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ font: "600 14px/1 var(--font-mono)", color: "var(--text-primary)" }}>{r.rank || "—"}</span><span style={{ font: (r.name === me ? "600" : "400") + " 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{r.name}</span><P.Num s={{ font: "var(--type-num-s)" }}>{r.v == null ? "—" : r.v + " " + c.unit}</P.Num></div>)}</div>
    {mine && <div style={{ border: "1px solid var(--signal)", borderRadius: 8, padding: 12, display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}><span style={{ flex: "1 1 200px", font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Avslutter du nå, låses resultatene. Den som ikke har registrert, står uten plassering.</span><Button variant="primary" onClick={() => onEnd(c.id)}>Avslutt utfordring</Button></div>}
  </div>;
}
function PH26({ state, go }) {
  const { PageHeader, Button, KeyValue, DataTable, Checkbox, Segmented, FormField, TextInput, StatusPill, EmptyState, BarRow, Chart, Icon } = window.PHQ.ns();
  const P = window.PHQ, M = window.PHQ_ME, Q = window.PHQA, { mob, pad, desk } = P.useW(), empty = state === "tom";
  const [tab, setTab] = React.useState(window.__phq26 || "fys"); React.useEffect(() => { window.__phq26 = null; }, []);
  const [fysDone, setFysDone] = React.useState({ 0: !empty }), [chs, setChs] = React.useState(empty ? [] : M.challenges);
  const [nt, setNt] = React.useState(""), [nw, setNw] = React.useState("Høyest"), [nu, setNu] = React.useState("treff"), [picked, setPicked] = React.useState({}), [tried, setTried] = React.useState(false);
  const [stimp, setStimp] = React.useState("10"), [tours, setTours] = React.useState(M.tournaments);
  const me = window.PHQ_DATA.player.name;
  const nPicked = Object.values(picked).filter(Boolean).length;
  const create = () => { setTried(true); if (!nt.trim() || !nPicked) return; const people = M.me.friends.filter((f) => picked[f.id]).map((f) => [f.name, null]); M.me.groups.filter((g) => picked[g.id]).forEach((g) => people.push(["Gruppe · " + g.name, null])); setChs((l) => [{ id: "n" + Date.now(), title: nt.trim(), status: "Aktiv", win: nw === "Høyest" ? "hi" : "lo", unit: nu, ends: "03.10.2026", by: me, rows: [[me, null], ...people] }, ...l]); setNt(""); setPicked({}); setTried(false); P.toast("Utfordringen er opprettet", nPicked + " VALGT · VARSEL SENDT I APPEN"); };
  let body;
  if (tab === "fys") body = empty ? <EmptyState icon="dumbbell" title="Ingen FYS-økt i dag" text="Anders har ikke lagt inn fysisk trening for lørdag." action="Åpne plan" actionIcon="calendar-days" onAction={() => go("PH-10")} /> : <P.Cols tpl={desk ? "minmax(0,1.3fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
    <div className="pa-card" style={{ padding: "16px 16px 8px", gap: 4 }}>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "baseline", paddingBottom: 8 }}><span className="kicker" style={{ flex: 1 }}>Styrke bein og kjerne · 17:30</span><P.Meta>FYS · 45 MIN · STYRKEROMMET</P.Meta></div>
      {FYS.map(([n, q, r], i) => <div key={n} style={{ display: "flex", alignItems: "center", gap: 12, minHeight: 56, borderTop: i ? "1px solid var(--border-hairline)" : "none", flexWrap: "wrap" }}><div style={{ flex: "1 1 180px", minWidth: 0 }}><Checkbox checked={!!fysDone[i]} onChange={() => setFysDone((d) => ({ ...d, [i]: !d[i] }))} label={n} /></div><P.Num s={{ font: "var(--type-num-s)" }}>{q}</P.Num><P.Meta>{r}</P.Meta></div>)}
    </div>
    <div className="pa-card" style={{ padding: 16, gap: 12 }}><span className="kicker">Fremdrift</span><div style={{ display: "flex", alignItems: "baseline", gap: 8 }}><span style={{ font: "var(--type-metric-l)", color: "var(--text-primary)" }}>{Object.values(fysDone).filter(Boolean).length}</span><P.Num s={{ color: "var(--text-muted)" }}>av {FYS.length} øvelser</P.Num></div><div style={{ height: 6, background: "var(--surface-sunken)" }}><div style={{ height: "100%", width: Object.values(fysDone).filter(Boolean).length / FYS.length * 100 + "%", background: "var(--primary)" }}></div></div><Button fullWidth icon="check" onClick={() => P.toast("FYS-økt registrert", Object.values(fysDone).filter(Boolean).length + " AV " + FYS.length + " ØVELSER · 45 MIN")}>Registrer økt</Button><P.Meta>RIR = REPETISJONER I RESERVE</P.Meta></div>
  </P.Cols>;
  if (tab === "utf") body = <P.Cols tpl={desk ? "minmax(0,1fr) minmax(0,1.2fr)" : "minmax(0,1fr)"}>
    <div className="pa-card" style={{ padding: 16, gap: 16 }}><span className="kicker">Ny utfordring</span>
      <FormField label="Navn" required error={tried && !nt.trim() ? "Gi utfordringen et navn, for eksempel «Putting 5 fot · 10 putter»." : null}><TextInput value={nt} onChange={(e) => setNt(e.target.value)} placeholder="Putting 5 fot · 10 putter" /></FormField>
      <FormField label="Vinner"><Segmented options={["Høyest", "Lavest"]} value={nw} onChange={setNw} /></FormField>
      <FormField label="Enhet"><Segmented options={["treff", "slag", "ft"]} value={nu} onChange={setNu} /></FormField>
      <FormField label="Deltakere" required error={tried && !nPicked ? "Velg minst én venn eller gruppe." : null}><div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        <P.Meta>VENNER</P.Meta>{M.me.friends.map((f) => <Checkbox key={f.id} checked={!!picked[f.id]} onChange={() => setPicked((p) => ({ ...p, [f.id]: !p[f.id] }))} label={f.name} />)}
        <P.Meta s={{ marginTop: 8 }}>GRUPPER</P.Meta>{M.me.groups.map((g) => <Checkbox key={g.id} checked={!!picked[g.id]} onChange={() => setPicked((p) => ({ ...p, [g.id]: !p[g.id] }))} label={g.name + " · " + g.n + " spillere"} />)}
      </div></FormField>
      <div><Button icon="plus" onClick={create}>Opprett utfordring</Button></div>
      <P.Meta>UTFORDRINGER TELLER IKKE SOM TRENING OG VISES IKKE I PLAN ELLER STATS</P.Meta>
    </div>
    <P.Stack>{chs.length ? chs.map((c) => <Challenge key={c.id} c={c} me={me} onEnd={(id) => { setChs((l) => l.map((x) => x.id === id ? { ...x, status: "Avsluttet", ends: "26.09.2026" } : x)); P.toast("Utfordringen er avsluttet", "RESULTATENE ER LÅST"); }} />) : <EmptyState icon="trophy" title="Ingen utfordringer" text="Lag en utfordring og velg venner eller grupper som skal være med." />}</P.Stack>
  </P.Cols>;
  if (tab === "putt") body = <P.Cols tpl={desk ? "minmax(0,1.2fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
    <div className="pa-card" style={{ padding: 16 }}><Chart kicker="Putte-lab · i hull per avstand" title={empty ? "—" : "Tobias mot PGA Tour"} footer={M.puttlab.src} axis={{ min: 0, max: 100, ticks: 5, unit: "%" }}>{M.puttlab.bands.map(([b, me2, pga]) => <BarRow key={b} label={b} value={empty ? null : me2} max={100} goal={pga} display={empty ? null : me2 + " %"} goalLabel={"PGA TOUR " + pga + " %"} />)}</Chart></div>
    <DataTable caption="Putter registrert" columns={[{ key: "b", label: "Avstand", mono: true }, { key: "n", label: "Putter", mono: true, align: "right" }, { key: "m", label: "I hull", mono: true, align: "right" }]} rows={M.puttlab.bands.map(([b, m, , n]) => ({ id: b, b, n: empty ? null : n, m: empty ? null : m + " %" }))} />
  </P.Cols>;
  if (tab === "break") { const k = +stimp / 10, slopes = [1, 2, 3, 4]; body = <div className="pa-card" style={{ padding: 16, gap: 12 }}>
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "flex-end" }}><FormField label="Greenhastighet (Stimp)"><Segmented options={["8", "10", "12"]} value={stimp} onChange={setStimp} /></FormField><span style={{ flex: 1 }}></span><Q.Src est>MODELL · IKKE MÅLT</Q.Src></div>
    <DataTable caption="Break i cm ved helning" columns={[{ key: "ft", label: "Avstand", mono: true, render: (r) => r.ft + " ft" }, ...slopes.map((s2) => ({ key: "s" + s2, label: s2 + " %", mono: true, align: "right" }))]} rows={[3, 5, 10, 15, 20, 25].map((ft) => ({ id: ft, ft, ...Object.fromEntries(slopes.map((s2) => ["s" + s2, Math.round(0.55 * ft * s2 * k) + " cm"])) }))} />
    <P.Meta>SIKT OVER HØYESTE PUNKT · PUTTINGAVSTAND I FOT · 1 FT ≈ 30 CM</P.Meta>
  </div>; }
  if (tab === "turn") body = <DataTable caption="Turneringsplan høst 2026" rowKey="n" columns={[{ key: "d", label: "Dato", mono: true }, { key: "n", label: "Turnering" }, { key: "type", label: "Type" }, { key: "st", label: "Status", render: (r) => r.st === "Ikke påmeldt" ? <Button size="sm" variant="secondary" onClick={() => { setTours((l) => l.map((x) => x.n === r.n ? { ...x, st: "Påmeldt" } : x)); P.toast("Du er påmeldt", r.n.toUpperCase()); }}>Meld på</Button> : <StatusPill tone={r.st === "Påmeldt" ? "ok" : "neutral"}>{r.st}</StatusPill> }]} rows={empty ? [] : tours} emptyText="Ingen turneringer i planen. Spør Caddie om forslag." />;
  if (tab === "digest") { const G = M.digest; body = <div className="pa-card" style={{ padding: 16, gap: 16, maxWidth: 720 }}>
    <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">Ukesdigest · uke {G.week}</span><Q.Src>{G.src}</Q.Src></div>
    <KeyValue columns={mob ? 1 : 2} items={[["Treningstid", empty ? null : P.dec(G.hours[0]) + " av " + G.hours[1] + " t"], ["Økter", empty ? null : G.sessions[0] + " av " + G.sessions[1]], ["Runder", empty ? null : G.rounds], ["SG total", empty ? null : Q.sgc(G.sg)]]} />
    <p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-primary)", textWrap: "pretty" }}>{empty ? "—" : G.best}</p>
    <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{empty ? "Ingen data for uka ennå." : G.next}</p>
    {!empty && <div><Button variant="secondary" icon="arrow-right" onClick={() => go("PH-21")}>Se planen fra Anders</Button></div>}
  </div>; }
  return <P.Page max={1200}>
    <PageHeader kicker="Plan · Utenfor banen" title="Utenfor banen" sub="FYS, utfordringer, putte-lab, turneringer (break-tabellen ligger i Øvelsesbank) og ukesdigest." />
    <P.Gate state={state} loading="Henter FYS-økt, utfordringer og turneringer …" error={{ title: "Siden kunne ikke lastes", text: "Ingenting er endret. Prøv igjen.", code: "FEIL 503 · UTENFOR BANEN" }}>
      <Q.Tabs value={tab} onChange={setTab} options={TABS} />
      {body}
    </P.Gate>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-26"] = { id: "PH-26", parent: "PH-24", name: "Utenfor banen", tab: "plan", route: "/portal/utenfor-banen", Component: PH26 };
})();
