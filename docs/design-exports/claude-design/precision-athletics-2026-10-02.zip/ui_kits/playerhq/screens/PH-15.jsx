(() => {
const N = 10, LIM = 4;
const SEED = [3.2, 5.8, 2.1, 4.4, 1.6, 3.9];
function PH15({ state, go }) {
  const { Button, IconButton, StatusPill, Dialog, EmptyState } = window.PHQ.ns();
  const P = window.PHQ, { mob } = P.useW(), empty = state === "tom";
  const [res, setRes] = React.useState(empty ? [] : SEED), [m, setM] = React.useState(empty ? 4 : 3.5), [end, setEnd] = React.useState(false), [saved, setSaved] = React.useState(false);
  const done = res.length >= N, inside = res.filter((x) => x <= LIM).length, avg = res.length ? res.reduce((a, b) => a + b, 0) / res.length : null;
  const reg = () => { if (done) return; const nx = [...res, m]; setRes(nx); P.toast("Slag " + nx.length + " · " + P.dec(m) + " m", (m <= LIM ? "INNENFOR 4 M" : "UTENFOR 4 M") + " · " + nx.filter((x) => x <= LIM).length + " AV " + nx.length); };
  const st = { height: 72, flex: "1 1 0", minWidth: 0, borderRadius: 8, border: "1px solid var(--border-strong)", background: "var(--surface-card)", color: "var(--text-primary)", font: "600 21px/1 var(--font-mono)", cursor: "pointer" };
  const top = <><StatusPill tone="live">Test</StatusPill><P.Meta>INNSPILL 50–100 M · 10 SLAG</P.Meta><span style={{ flex: 1 }}></span><Button variant="ghost" onClick={() => setEnd(true)} style={{ height: 56 }}>Avslutt</Button></>;
  const action = state === "data" || state === "tom" ? (done ? (saved ? <Button size="xl" fullWidth icon="arrow-left" style={{ height: 64 }} onClick={() => go("PH-14")}>Til testene</Button> : <Button size="xl" fullWidth icon="check" style={{ height: 64 }} onClick={() => { setSaved(true); P.toast("Resultatet er lagret", inside + " AV 10 INNENFOR 4 M · SNITT " + P.dec(avg) + " M"); }}>Lagre resultat · {inside} av 10</Button>)
    : <Button size="xl" fullWidth icon="plus" style={{ height: 80, font: "600 21px/1 var(--font-sans)" }} onClick={reg}>Registrer slag {res.length + 1} · {P.dec(m)} m</Button>) : null;
  return <P.Focus top={top} action={action}>
    <P.Gate state={state} loading="Henter testprotokollen …" error={{ title: "Testen kunne ikke startes", text: "Protokollen kunne ikke lastes. Registrerte slag er lagret på telefonen.", code: "FRAKOBLET · TN3" }}>
      <div><h1 style={{ margin: 0, font: "var(--type-title-l)", color: "var(--text-primary)" }}>Innspill 50–100 m</h1><P.Meta s={{ display: "block", marginTop: 6 }}>TEAM NORWAY · 10 SLAG MOT FLAGG · INNENFOR 4 M TELLER · FORRIGE 5 AV 10</P.Meta></div>
      <div className="pa-card" style={{ padding: 16, gap: 12 }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 12 }}>
          {[["Innenfor 4 m", res.length ? inside + " av " + res.length : "—"], ["Snitt", avg == null ? "—" : P.dec(avg) + " m"], ["Slag", res.length + " / " + N]].map(([k, v]) => <div key={k} style={{ minWidth: 0 }}><P.Meta>{k.toUpperCase()}</P.Meta><div style={{ font: "600 " + (mob ? 21 : 26) + "px/1.2 var(--font-mono)", color: "var(--text-primary)", marginTop: 4 }}>{v}</div></div>)}
        </div>
      </div>
      <div className="pa-card" style={{ padding: 12, gap: 8 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", padding: "0 4px" }}><span className="kicker">Scorekort</span><P.Meta>METER FRA FLAGGET</P.Meta></div>
        <div role="list" style={{ display: "grid", gridTemplateColumns: "repeat(5,minmax(0,1fr))", gap: 6 }}>{Array.from({ length: N }, (_, i) => { const v = res[i], nx = i === res.length, ok = v != null && v <= LIM; return <div role="listitem" key={i} aria-label={"Slag " + (i + 1) + (v != null ? " " + P.dec(v) + " meter" : " ikke slått")} style={{ height: 64, borderRadius: 8, border: "1px solid " + (nx ? "var(--border-ink)" : "var(--border-hairline)"), background: ok ? "var(--surface-sunken)" : "transparent", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, minWidth: 0, position: "relative" }}>
          <span style={{ font: "500 10px/1 var(--font-mono)", color: "var(--text-muted)" }}>{i + 1}</span>
          <span style={{ font: "600 17px/1 var(--font-mono)", color: v == null ? "var(--text-faint)" : "var(--text-primary)", textDecoration: ok ? "underline" : "none", textUnderlineOffset: 4, textDecorationThickness: 2 }}>{v == null ? "—" : P.dec(v)}</span>
        </div>; })}</div>
        <P.Meta s={{ padding: "0 4px" }}>UNDERSTREKET = INNENFOR 4 M</P.Meta>
      </div>
      {empty && !res.length && <EmptyState icon="target" title="Ingen slag registrert" text="Slå første slag, mål avstanden til flagget og registrer." />}
      {!done && <div><div style={{ display: "flex", justifyContent: "space-between", gap: 8, marginBottom: 8 }}><span className="pa-field__label" style={{ color: "var(--text-secondary)" }}>Meter fra flagget · slag {res.length + 1}</span>{res.length > 0 && <button type="button" onClick={() => setRes(res.slice(0, -1))} style={{ all: "unset", cursor: "pointer", font: "var(--type-label)", color: "var(--text-secondary)", minHeight: 44, display: "flex", alignItems: "center" }}>Angre siste</button>}</div>
        <div style={{ textAlign: "center", padding: "8px 0 12px" }}><span style={{ font: "600 " + (mob ? 56 : 72) + "px/1 var(--font-mono)", color: "var(--text-primary)", fontVariantNumeric: "tabular-nums" }}>{P.dec(m)}</span><span style={{ font: "var(--type-num)", color: "var(--text-muted)" }}> m</span><div style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: m <= LIM ? "var(--text-primary)" : "var(--text-muted)", marginTop: 6 }}>{m <= LIM ? "INNENFOR 4 M" : "UTENFOR 4 M"}</div></div>
        <div style={{ display: "flex", gap: 6 }}>{[-1, -0.5, 0.5, 1].map((d) => <button key={d} type="button" aria-label={(d > 0 ? "+" : "−") + P.dec(Math.abs(d)) + " meter"} onClick={() => setM(Math.max(0, Math.round((m + d) * 10) / 10))} style={st}>{(d > 0 ? "+" : "−") + P.dec(Math.abs(d))}</button>)}</div>
      </div>}
      {done && <div className="pa-card" style={{ padding: 16, gap: 8 }}><span className="kicker">Resultat</span><div style={{ font: "600 29px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{inside} av 10 innenfor 4 m</div><P.Meta>{inside > 5 ? "+" + (inside - 5) + " SIDEN 12.09" : inside === 5 ? "LIKT SOM 12.09" : "−" + (5 - inside) + " SIDEN 12.09"} · MÅL 7 AV 10</P.Meta></div>}
    </P.Gate>
    <Dialog open={end} title="Avslutte testen?" onClose={() => setEnd(false)} footer={<><Button variant="secondary" onClick={() => setEnd(false)}>Fortsett</Button><Button onClick={() => go("PH-14")}>Avslutt uten å lagre</Button></>}>{res.length} av 10 slag er registrert. En test må ha alle 10 slag for å telle. Slagene lagres ikke.</Dialog>
  </P.Focus>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-15"] = { id: "PH-15", name: "Test: gjennomfør", tab: "plan", night: true, route: "/portal/tren/tester/[testId]/gjennomfor", Component: PH15 };
})();
