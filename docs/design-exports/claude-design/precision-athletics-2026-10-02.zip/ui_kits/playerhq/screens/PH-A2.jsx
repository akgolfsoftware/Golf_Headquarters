(() => {
const T = () => window.TR_DATA, Q = () => window.PHQT;
const reg = (id, name, C) => { window.PHQ_SCREENS[id] = { id, name, tab: "analyse", parent: "PH-16", route: "/portal/analysere/trening", Component: C }; };

/* PH-A05 · Nærspill og putting */
function A05({ state, go }) {
  const { ChartTable, BarRow, DataTable, TrendChart, InsightCard, SourceBadge, EmptyAnalysisState } = window.PHQ.ns();
  const P = window.PHQ, D = T().putt, { Frame, Card, usePeriod } = Q(), per = usePeriod(), { desk } = P.useW();
  return <Frame id="PH-A05" title="Nærspill og putting" sub="Putting per avstandssone i fot, 3-putter per runde og treffvindu for wedger." go={go} state={state} loading="Henter putter og nærspill …" per={per}
    empty={<EmptyAnalysisState title="Ingen putter registrert" have={0} need={40} unit="putter" text="Registrer putter i en økt eller runde. Soner vises fra 40 putter." action="Start putteøkt" onAction={() => go("PH-02")} />}>
    <P.Cols tpl={desk ? "minmax(0,1.3fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
      <Card k="Satt i hull per sone" aside={<SourceBadge source={D.src} date={D.date} kind="okt" />}>
        <ChartTable chart={<div style={{ display: "flex", flexDirection: "column", gap: 8 }}>{D.zones.map(([z, v, n, ref]) => <BarRow key={z} label={z} value={v} max={100} goal={ref} display={v + " %"} meta={n + " PUTTER · REF " + ref + " %"} />)}<P.Meta>STREK = REFERANSE KATEGORI D</P.Meta></div>} rowKey="z" columns={[{ key: "z", label: "Sone" }, { key: "v", label: "Satt", mono: true, align: "right", render: (r) => r.v + " %" }, { key: "n", label: "Putter", mono: true, align: "right" }, { key: "ref", label: "Referanse", mono: true, align: "right", render: (r) => r.ref + " %" }]} rows={D.zones.map(([z, v, n, ref]) => ({ z, v, n, ref }))} />
      </Card>
      <Card k="3-putter per runde"><TrendChart symmetric={false} zero={false} min={0} max={4} series={[{ label: "3-putter", values: D.threePutt }]} labels={T().weeks} format={(v) => v == null ? "—" : String(Math.round(v))} caption="U36 INGEN RUNDE" /></Card>
    </P.Cols>
    <Card k="Treffvindu wedger" aside={<SourceBadge source="Øktlogg" date="24.09.2026" kind="okt" />}>
      <DataTable caption="Treffvindu" rowKey="d" columns={[{ key: "d", label: "Avstand", mono: true }, { key: "w", label: "Vindu", mono: true }, { key: "v", label: "Innenfor", mono: true, align: "right", render: (r) => r.v == null ? "—" : r.v + " %" }, { key: "n", label: "Slag", mono: true, align: "right", render: (r) => r.n || "—" }]} rows={D.wedges.map(([d, v, n, w]) => ({ d, v, n, w }))} />
    </Card>
    <InsightCard kind="trend" title="5–10 fot er 12 prosentpoeng under referansen" cause="38 % satt av 52 putter. 3–5 fot er også under." evidence={[["5–10 ft", "38 %"], ["Referanse", "50 %"], ["Putter", 52]]} quality={{ level: "god", have: 52, unit: "putter" }} actions={[{ label: "Legg i plan", icon: "calendar-plus", primary: true, onClick: () => P.toast("Forslag sendt til Anders", "PUTTING 5–10 FT · UTKAST") }, { label: "Registrer data", onClick: () => go("PH-02") }]} />
  </Frame>;
}
reg("PH-A05", "Nærspill og putting", A05);

/* PH-A06 · Rundeanalyse */
function A06({ state, go }) {
  const { ChartTable, TrendChart, BarRow, DataTable, StatusPill, SourceBadge, InsightCard, EmptyAnalysisState } = window.PHQ.ns();
  const P = window.PHQ, AN = window.PHQ_AN, { Frame, Card, usePeriod, d1 } = Q(), per = usePeriod(), { desk } = P.useW();
  const sg = (v) => v == null ? "—" : (v > 0.04 ? "+" : v < -0.04 ? "−" : "±") + Math.abs(v).toFixed(1).replace(".", ",");
  const src = { r10: "Manuell · annen app", r9: "Manuell", r8: "Manuell" };
  return <Frame id="PH-A06" title="Rundeanalyse" sub="Brutto score og Strokes Gained per kategori. Kilde og dato på hver runde." go={go} state={state} loading="Henter runder …" per={per}
    actions={<window.PHQ.ns.Btn icon="plus" onClick={() => go("PH-09")}>Registrer runde</window.PHQ.ns.Btn>}
    empty={<EmptyAnalysisState title="For få runder" have={1} need={3} unit="runder" text="SG-trend vises fra tre runder. Du kan legge inn SG fra en annen app." action="Registrer runde" onAction={() => go("PH-09")} />}>
    <P.Cols tpl={desk ? "minmax(0,1fr) minmax(0,1.2fr)" : "minmax(0,1fr)"}>
      <Card k="SG per kategori · 10 runder" aside={<SourceBadge source="GolfBox + manuell" date="20.09.2026" n={10} unit="runder" kind="golfbox" />}>
        {AN.sg.cats.map(([k, l, v]) => <window.PHQA.SGBar key={k} label={k} sub={l} v={v} />)}
        <P.Meta>NULL = BASELINE KATEGORI D · LIK SKALA OVER OG UNDER</P.Meta>
      </Card>
      <Card k="SG totalt per runde"><ChartTable chart={<TrendChart series={[{ label: "SG totalt", values: AN.sg.trend }]} labels={["R5", "R6", "R7", "R8", "R9", "R10"]} format={sg} caption="NULLINJE = BASELINE" />} rowKey="r" columns={[{ key: "r", label: "Runde", mono: true }, { key: "v", label: "SG", mono: true, align: "right", render: (r) => sg(r.v) }]} rows={AN.sg.trend.map((v, i) => ({ r: "R" + (i + 5), v }))} /></Card>
    </P.Cols>
    <Card k="Runder">
      <DataTable caption="Runder" rowKey="id" columns={[{ key: "date", label: "Dato", mono: true }, { key: "course", label: "Bane" }, { key: "b", label: "Brutto", mono: true, align: "right", render: (r) => r.score + " (" + P.toPar(r.score - r.par) + ")" }, { key: "sg", label: "SG", mono: true, align: "right", render: (r) => sg(r.sg) }, { key: "src", label: "Kilde", render: (r) => <StatusPill tone={src[r.id] ? "info" : "neutral"}>{src[r.id] || "GolfBox"}</StatusPill> }]} rows={AN.rounds.slice(0, 6)} onSelect={() => go("PH-18")} />
    </Card>
    <InsightCard kind="trend" title="Innspill koster 0,8 slag per runde" cause="Største tap av de fire kategoriene. Tre av rundene er manuelt lagt inn fra annen app." evidence={[["APP", "−0,8"], ["Runder", 10], ["Manuelle", 3]]} quality={{ level: "manuell", have: 3, unit: "manuelle runder" }} actions={[{ label: "Legg i plan", icon: "calendar-plus", primary: true, onClick: () => P.toast("Forslag sendt til Anders", "INNSPILL · UTKAST") }, { label: "Sammenlign periode", onClick: () => per.setCompare("Forrige periode") }, { label: "Registrer data", onClick: () => go("PH-18") }]} />
  </Frame>;
}
reg("PH-A06", "Rundeanalyse", A06);

/* PH-A07 · Tester */
function A07({ state, go }) {
  const { StatusPill, Sparkline, Button, EmptyAnalysisState, SourceBadge } = window.PHQ.ns();
  const P = window.PHQ, D = T().tests, { Frame, Card, usePeriod } = Q(), per = usePeriod(), { desk, pad } = P.useW();
  const f = (v) => v == null ? "—" : String(v).replace(".", ",");
  return <Frame id="PH-A07" title="Tester" sub="Siste resultat, utvikling, om testen er gyldig og når neste test er." go={go} state={state} loading="Henter tester …" per={per}
    empty={<EmptyAnalysisState title="Ingen tester tatt" have={0} need={1} unit="test" text="Ta første test for å få et utgangspunkt." action="Velg test" onAction={() => go("PH-14")} />}>
    {(() => { const TD = window.TD, X = window.TEST_DATA, t = X.tests[0], st = t.choice === "ingen" ? ["neutral", "Ingen endring nå"] : ["info", "Anders vurderer planen"];
      return <Card k={t.name} aside={<StatusPill tone={st[0]}>{st[1]}</StatusPill>}>
        <P.Cols tpl={desk ? "minmax(0,1fr) minmax(0,1fr)" : "minmax(0,1fr)"}><TD.TestHead t={t} /><TD.TestSignal t={t} /></P.Cols>
        <TD.TestHistory t={t} />
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}><Button size="sm" variant="secondary" icon="clipboard-check" onClick={() => go("PH-15")}>Gjennomfør test på nytt</Button><P.Meta>ANDERS BESTEMMER OM NOE ENDRES I PLANEN · ØVELSER LEGGES I ØKT AV COACHEN</P.Meta></div>
      </Card>; })()}
    <div style={{ display: "grid", gridTemplateColumns: desk ? "repeat(2,minmax(0,1fr))" : pad ? "repeat(2,minmax(0,1fr))" : "minmax(0,1fr)", gap: 12 }}>{D.map((t) => <Card key={t.id} k={t.name} aside={t.valid === false ? <StatusPill tone="warn">Ikke gyldig</StatusPill> : t.valid ? <StatusPill tone="ok">Gyldig</StatusPill> : <StatusPill>Ikke tatt</StatusPill>}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-metric)", color: "var(--text-primary)" }}>{f(t.last)}</span><P.Meta>{t.unit.toUpperCase()} · {t.better === "low" ? "LAVERE ER BEDRE" : "HØYERE ER BEDRE"}</P.Meta></div>
      <Sparkline values={t.trend.length ? t.trend : [null]} height={32} label={t.name + ": " + (t.trend.length ? t.trend.map(f).join(", ") : "ingen målinger")} />
      {t.why && <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{t.why}. Tas på nytt før tallet brukes.</p>}
      <SourceBadge source="Test" date={t.date || "—"} n={t.trend.length || null} unit="målinger" kind="test" />
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}><Button size="sm" variant={t.valid === null ? "primary" : "secondary"} icon="clipboard-check" onClick={() => go("PH-15")}>{t.valid === null ? "Ta testen" : "Ta på nytt"}</Button><P.Meta>NESTE {t.next}</P.Meta></div>
    </Card>)}</div>
  </Frame>;
}
reg("PH-A07", "Tester · utvikling", A07);

/* PH-A08 · Datagrunnlag */
function A08({ state, go }) {
  const { DataQualityBadge, SourceBadge, Button, EmptyAnalysisState } = window.PHQ.ns();
  const P = window.PHQ, D = T().sources, { Frame, Card, usePeriod } = Q(), per = usePeriod(), { desk, pad } = P.useW();
  const act = { trackman: ["Importer økt", "PH-17"], golfbox: ["Oppdater nå", null], annen_app: ["Legg inn runde", "PH-18"], okt: ["Registrer økt", "PH-02"], test: ["Velg test", "PH-14"], manuell: ["Registrer dagsform", "PH-01"] };
  return <Frame id="PH-A08" title="Datagrunnlag" sub="Hvilke kilder analysen bygger på, når de sist ble oppdatert og hva som mangler." go={go} state={state} loading="Sjekker kilder …" per={per}
    empty={<EmptyAnalysisState title="Ingen kilder koblet til" text="Registrer en økt, koble TrackMan eller legg inn en runde for å starte." action="Registrer økt" onAction={() => go("PH-02")} />}>
    <div role="list" style={{ display: "grid", gridTemplateColumns: desk ? "repeat(3,minmax(0,1fr))" : pad ? "repeat(2,minmax(0,1fr))" : "minmax(0,1fr)", gap: 12 }}>{D.map((s) => { const [l, to] = act[s.kind]; return <div role="listitem" key={s.name} className="pa-card" style={{ padding: 16, gap: 10, minWidth: 0 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "center" }}><h2 style={{ margin: 0, font: "var(--type-title-s)" }}>{s.name}</h2><DataQualityBadge level={s.level} /></div>
      <SourceBadge date={"SIST " + s.last} n={s.n} unit={s.unit} kind={s.kind} />
      {s.missing ? <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Mangler: {s.missing}.</p> : <P.Meta>INGEN KJENTE HULL</P.Meta>}
      <div><Button size="sm" variant="secondary" icon={s.kind === "golfbox" ? "refresh-cw" : "plus"} onClick={() => to ? go(to) : P.toast("GolfBox oppdateres", "HENTER RUNDER")}>{l}</Button></div>
    </div>; })}</div>
    <Card k="Slik brukes kildene"><ul style={{ margin: 0, paddingLeft: 18, display: "flex", flexDirection: "column", gap: 6, font: "var(--type-body-s)", color: "var(--text-secondary)" }}><li>Målt (TrackMan, GolfBox) går foran egenregistrert når begge finnes.</li><li>Manuell data fra annen app merkes med kilde og dato i alle visninger.</li><li>Tynt grunnlag gir ingen «forbedring» — bare tallet og hva som mangler.</li><li>Manglende verdi vises som «—», aldri 0.</li></ul></Card>
  </Frame>;
}
reg("PH-A08", "Datagrunnlag", A08);
window.PHQ.ns.Btn = function Btn(p) { const { Button } = window.PHQ.ns(); return <Button {...p} />; };
})();
