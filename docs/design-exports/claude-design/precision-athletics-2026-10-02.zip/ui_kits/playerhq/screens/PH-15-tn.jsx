/* PH-15-TN Test: Team Norway-tester med poengskala fra TN-scorekortarket (Anders 28.09.2026). Natt.
   8-ball og 9 hull lengde: spilleren fører avstand, appen gir poeng. Nærspill Gate og VISA Express: poeng for hånd per slag, appen summerer. Wedge Gate: 9 slag (lav/medium/høy × 40/50/60 m ±3), Treff eller Bom, resultat X / 9 treff. */
(() => {
function PH15TN({ state, go }) {
  const { Button, StatusPill, Dialog, EmptyState, ChoicePill, TextInput } = window.PHQ.ns();
  const P = window.PHQ, T = window.TN_SCORE, empty = state === "tom";
  const [tid, setTid] = React.useState("8ball"), t = T.tests.find((x) => x.id === tid);
  const seed = { "8ball": [0.4, 1.2, 0.08, 2.5, 0.9], "9hull": [0, 1, 3, 0.8], gate: [2, 3, 1.5, 3], visa: [1, 2, 2], wedge: [1, 0, 1, 1, 1] };
  const [res, setRes] = React.useState(() => Object.fromEntries(T.tests.map((x) => [x.id, empty ? [] : (seed[x.id] || [])])));
  const [v, setV] = React.useState(1.0), [mp, setMp] = React.useState(""), [end, setEnd] = React.useState(false), [saved, setSaved] = React.useState({});
  const L = res[tid] || [], done = t.n && L.length >= t.n;
  const pts = t.mode === "auto" ? L.map(t.pts) : L, sum = pts.reduce((a, b) => a + (b || 0), 0);
  const add = (val) => { if (done) return; setRes((r) => ({ ...r, [tid]: [...L, val] })); const p = t.mode === "auto" ? t.pts(val) : val; t.mode === "hit" ? P.toast(val ? "Treff" : "Bom", (t.slots[L.length] + " · " + (sum + p) + " / " + t.n + " TREFF").toUpperCase()) : P.toast((t.mode === "auto" ? P.dec(val) + " " + t.unit + " · " : "") + T.fmt(p) + " poeng", "SUM " + T.fmt(sum + p) + (t.max ? " AV " + t.max : "")); };
  const step = t.unit === "fot" ? [-1, -0.5, 0.5, 1] : [-1, -0.1, 0.1, 1];
  const btn = { height: 64, flex: "1 1 0", minWidth: 0, borderRadius: 8, border: "1px solid var(--border-strong)", background: "var(--surface-card)", color: "var(--text-primary)", font: "600 19px/1 var(--font-mono)", cursor: "pointer" };
  const top = <><StatusPill tone="live">Test</StatusPill><P.Meta>TEAM NORWAY · {t.name.toUpperCase()}</P.Meta><span style={{ flex: 1 }}></span><Button variant="ghost" onClick={() => setEnd(true)} style={{ height: 56 }}>Avslutt</Button></>;
  const action = (state === "data" || empty) ? (done ? (saved[tid] ? <Button size="xl" fullWidth icon="arrow-left" style={{ height: 64 }} onClick={() => go("PH-14")}>Til testene</Button> : <Button size="xl" fullWidth icon="check" style={{ height: 64 }} onClick={() => { setSaved((s) => ({ ...s, [tid]: true })); P.toast("Resultatet er lagret", t.name.toUpperCase() + " · " + (t.mode === "hit" ? sum + " / " + t.n + " TREFF" : T.fmt(sum) + " POENG") + " · EGENFØRT"); }}>{t.mode === "hit" ? "Lagre · " + sum + " / " + t.n + " treff" : "Lagre · " + T.fmt(sum) + " poeng"}</Button>)
    : t.mode === "hit" ? <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><P.Meta s={{ textAlign: "center" }}>SLAG {L.length + 1} AV {t.n} · {t.slots[L.length].toUpperCase()} ±3</P.Meta><div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 8 }}><Button size="xl" icon="check" style={{ height: 72 }} onClick={() => add(1)}>Treff</Button><Button size="xl" variant="secondary" icon="x" style={{ height: 72 }} onClick={() => add(0)}>Bom</Button></div></div> : t.mode === "auto" ? <Button size="xl" fullWidth icon="plus" style={{ height: 72 }} onClick={() => add(v)}>Registrer {t.id === "8ball" ? "ball" : "hull"} {L.length + 1} · {P.dec(v)} {t.unit}</Button> : null) : null;
  return <P.Focus top={top} action={action}>
    <P.Gate state={state} loading="Henter scorekortet …" error={{ title: "Testen kunne ikke startes", text: "Scorekortet kunne ikke lastes. Registrerte slag er lagret på telefonen.", code: "FRAKOBLET · TN" }}>
      <div role="group" aria-label="Test" style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{T.tests.map((x) => <ChoicePill key={x.id} selected={tid === x.id} onClick={() => { setTid(x.id); setV(x.unit === "fot" ? 2 : 1); }}>{x.name}</ChoicePill>)}</div>
      <div><h1 style={{ margin: 0, font: "var(--type-title-l)", color: "var(--text-primary)" }}>{t.name}</h1><P.Meta s={{ display: "block", marginTop: 6 }}>{t.rule.toUpperCase()}</P.Meta></div>
      {<>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 12 }}>{[[t.mode === "hit" ? "Treff" : "Sum", t.mode === "hit" ? sum + " / " + t.n : T.fmt(sum) + (t.max ? " av " + t.max : "")], [t.id === "8ball" ? "Baller" : t.id === "9hull" ? "Hull" : "Slag", L.length + " / " + t.n]].map(([k, x]) => <div key={k}><P.Meta>{k.toUpperCase()}</P.Meta><div style={{ font: "600 26px/1.2 var(--font-mono)", color: "var(--text-primary)", marginTop: 4 }}>{x}</div></div>)}</div>
        <section aria-label="Scorekort" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">Scorekort</span><P.Meta>{t.mode === "auto" ? t.unit.toUpperCase() + " → POENG" : t.mode === "hit" ? "LAUNCH × CARRY · TREFF ELLER BOM" : "POENG PER SLAG"}</P.Meta></div>
          <div role="list" style={{ display: "grid", gridTemplateColumns: "repeat(" + (t.slots ? 3 : t.n > 8 ? 5 : 4) + ",minmax(0,1fr))", gap: 6 }}>{Array.from({ length: t.n }, (_, i) => { const x = L[i], nx = i === L.length; return <div role="listitem" key={i} aria-label={(i + 1) + ": " + (x == null ? "ikke ført" : (t.mode === "auto" ? P.dec(x) + " " + t.unit + ", " : "") + T.fmt(pts[i]) + " poeng")} style={{ minHeight: 64, borderRadius: 8, border: "1px solid " + (nx ? "var(--border-ink)" : "var(--border-hairline)"), display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 3, minWidth: 0 }}>
            <span style={{ font: "500 10px/1.2 var(--font-mono)", color: "var(--text-muted)", textAlign: "center" }}>{t.slots ? t.slots[i].toUpperCase() : t.labels ? t.labels[i] : i + 1}</span>
            <span style={{ font: "600 17px/1 var(--font-mono)", color: x == null ? "var(--text-faint)" : "var(--text-primary)" }}>{x == null ? "—" : t.mode === "hit" ? (x ? "Treff" : "Bom") : T.fmt(pts[i]) + " p"}</span>
            {t.mode === "auto" && x != null && <span style={{ font: "500 10px/1 var(--font-mono)", color: "var(--text-muted)" }}>{t.id === "9hull" && x === 0 ? "SENKET" : P.dec(x) + " " + t.unit}</span>}
          </div>; })}</div>
          {L.length > 0 && !done && <div><Button variant="ghost" size="sm" onClick={() => setRes((r) => ({ ...r, [tid]: L.slice(0, -1) }))} style={{ minHeight: 44 }}>Angre siste</Button></div>}
        </section>
        {empty && !L.length && <EmptyState icon="target" title="Ingenting ført ennå" text={t.mode === "auto" ? "Mål avstanden og registrer. Appen gir poeng etter skalaen." : t.mode === "hit" ? "Første slag: lav launch (<26°) mot 40 m ±3. Trykk Treff eller Bom." : "Før poengene for hvert slag. Appen summerer."} />}
        {!done && t.mode === "auto" && <div>
          <div style={{ textAlign: "center", padding: "8px 0 12px" }}><span style={{ font: "600 64px/1 var(--font-mono)", color: "var(--text-primary)", fontVariantNumeric: "tabular-nums" }}>{P.dec(v)}</span><span style={{ font: "var(--type-num)", color: "var(--text-muted)" }}> {t.unit}</span><div style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-primary)", marginTop: 6 }}>= {T.fmt(t.pts(v))} POENG</div></div>
          <div style={{ display: "flex", gap: 6 }}>{step.map((d) => <button key={d} type="button" aria-label={(d > 0 ? "+" : "−") + P.dec(Math.abs(d)) + " " + t.unit} onClick={() => setV(Math.max(0, Math.round((v + d) * 100) / 100))} style={btn}>{(d > 0 ? "+" : "−") + P.dec(Math.abs(d))}</button>)}</div>
          {t.holed && <div style={{ marginTop: 8 }}><Button variant="secondary" fullWidth icon="flag" onClick={() => add(0)} style={{ height: 56 }}>Senket · 6 poeng</Button></div>}
        </div>}
        {!done && t.mode === "manual" && <div role="group" aria-label={"Poeng slag " + (L.length + 1)} style={{ display: "flex", flexDirection: "column", gap: 8 }}><P.Meta>POENG · SLAG {L.length + 1} · {t.labels[L.length].toUpperCase()}</P.Meta><div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 8 }}><TextInput mono inputMode="decimal" aria-label={"Poeng slag " + (L.length + 1)} value={mp} placeholder="Poeng" onChange={(e) => setMp(e.target.value.replace(/[^\d,.]/g, "").slice(0, 5))} style={{ height: 64, fontSize: 24 }} /><Button size="xl" icon="plus" disabled={mp === ""} style={{ height: 64 }} onClick={() => { add(+mp.replace(",", ".")); setMp(""); }}>Før</Button></div></div>}
      </>}
    </P.Gate>
    <Dialog open={end} title="Avslutte testen?" onClose={() => setEnd(false)} footer={<><Button variant="secondary" onClick={() => setEnd(false)}>Fortsett</Button><Button onClick={() => go("PH-14")}>Avslutt uten å lagre</Button></>}>{L.length} av {t.n || "—"} er ført. Testen lagres ikke før alle er ført.</Dialog>
  </P.Focus>;
}
window.PHQ_SCREENS["PH-15-TN"] = { id: "PH-15-TN", parent: "PH-15", name: "Test: Team Norway med poengskala", tab: "plan", night: true, route: "/portal/tren/tester/[testId]/gjennomfor", Component: PH15TN };
})();
