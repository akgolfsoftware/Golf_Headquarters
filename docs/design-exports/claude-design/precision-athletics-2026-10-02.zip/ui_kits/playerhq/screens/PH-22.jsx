(() => {
const CHIPS = ["Hva bør jeg trene på i dag?", "Hvordan var siste runde?", "Foreslå en turnering i oktober", "Hvor mye har jeg trent denne uka?"];
const REPLY = { text: "Denne uka har du trent 14 t 30 min av 18 t planlagt. SLAG har fått mest tid, TURN har ingen timer ennå.", src: "PLAN OG ØKTER · UKE 39 · 26.09.2026" };
function Draft({ d, onAccept, onDrop, state }) {
  const { Button, StatusPill } = window.PHQ.ns();
  const P = window.PHQ;
  return <div style={{ border: "1px dashed var(--border-strong)", borderRadius: 8, padding: 12, display: "flex", flexDirection: "column", gap: 8, background: "var(--surface-flat)" }}>
    <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><StatusPill tone={state === "godtatt" ? "ok" : state === "forkastet" ? "neutral" : "info"}>{state === "godtatt" ? "Sendt til Anders" : state === "forkastet" ? "Forkastet" : "Utkast"}</StatusPill><P.Meta>{d.kind.toUpperCase()}</P.Meta></div>
    <span style={{ font: "500 14px/1.35 var(--font-sans)", color: "var(--text-primary)" }}>{d.title}</span>
    <P.Meta>{d.meta}</P.Meta>
    {!state && <><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button size="sm" icon="send" onClick={onAccept}>Godta og send til Anders</Button><Button size="sm" variant="ghost" onClick={onDrop}>Forkast</Button></div><P.Meta>CADDIE ENDRER IKKE PLANEN. ANDERS GODKJENNER FØR DET BLIR LAGT INN.</P.Meta></>}
  </div>;
}
function PH22({ state, go }) {
  const { PageHeader, Button, IconButton, TextInput, EmptyState, Icon } = window.PHQ.ns();
  const P = window.PHQ, M = window.PHQ_ME, { mob } = P.useW(), empty = state === "tom";
  const [msgs, setMsgs] = React.useState(empty ? [] : M.caddie), [txt, setTxt] = React.useState(""), [ds, setDs] = React.useState({}), [busy, setBusy] = React.useState(false);
  const ask = (q) => { const t = (q || txt).trim(); if (!t) return; setMsgs((m) => [...m, { id: "u" + Date.now(), from: "me", t: "08:14", text: t }]); setTxt(""); setBusy(true); setTimeout(() => { setMsgs((m) => [...m, { id: "c" + Date.now(), from: "caddie", t: "08:14", ...REPLY }]); setBusy(false); }, 900); };
  return <P.Page max={880}>
    <PageHeader kicker="Meg · Caddie" title="Caddie" sub="Caddie svarer ut fra dine data og viser kilden. Alt Caddie foreslår er utkast. Du eller Anders godtar før noe endres." actions={<Button variant="secondary" icon="message-square" onClick={() => go("PH-21")}>Skriv til Anders</Button>} />
    <P.Gate state={state} loading="Caddie leser dataene dine …" error={{ title: "Caddie svarer ikke", text: "Ingen forslag er sendt og ingenting er endret. Prøv igjen, eller skriv til Anders.", code: "FEIL 503 · CADDIE · 08:14" }}>
      <div className="pa-card" style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 16, minHeight: 280 }} aria-live="polite">
          {msgs.length === 0 && <EmptyState icon="sparkles" title="Spør Caddie om treningen din" text="Caddie kjenner planen, øktene, rundene og TrackMan-tallene dine. Caddie sender og endrer ingenting selv." />}
          {msgs.map((m) => m.from === "me" ? <div key={m.id} style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}><div style={{ maxWidth: "min(520px,88%)", padding: "10px 14px", borderRadius: 8, background: "var(--primary)", color: "var(--text-on-primary)", font: "var(--type-body)", overflowWrap: "anywhere" }}>{m.text}</div><P.Meta>DU · {m.t}</P.Meta></div>
            : <div key={m.id} style={{ display: "grid", gridTemplateColumns: "32px minmax(0,1fr)", gap: 10 }}>
              <span style={{ width: 32, height: 32, borderRadius: 8, background: "var(--surface-sunken)", display: "grid", placeItems: "center", color: "var(--text-primary)" }}><Icon name="sparkles" size={16} /></span>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
                <p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-primary)", textWrap: "pretty" }}>{m.text}</p>
                <span style={{ display: "inline-flex", gap: 6, alignItems: "center", font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)" }}><Icon name="database" size={12} />KILDE · {m.src}</span>
                {m.draft && <Draft d={m.draft} state={ds[m.id]} onAccept={() => { setDs((x) => ({ ...x, [m.id]: "godtatt" })); P.toast("Utkastet er sendt til Anders", "ANDERS GODKJENNER FØR DET LEGGES INN"); }} onDrop={() => setDs((x) => ({ ...x, [m.id]: "forkastet" }))} />}
                <P.Meta>CADDIE · {m.t}</P.Meta>
              </div>
            </div>)}
          {busy && <P.Meta>CADDIE LESER PLAN OG ØKTER …</P.Meta>}
        </div>
        <div style={{ padding: 12, borderTop: "1px solid var(--border-hairline)", display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{CHIPS.map((c) => <button key={c} type="button" onClick={() => ask(c)} className="pa-filter__opt" style={{ height: 44 }}><span className="pa-filter__label">{c}</span></button>)}</div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}><div style={{ flex: 1, minWidth: 0 }}><TextInput aria-label="Spørsmål til Caddie" value={txt} onChange={(e) => setTxt(e.target.value)} placeholder="Spør Caddie" onKeyDown={(e) => { if (e.key === "Enter") ask(); }} /></div><IconButton icon="arrow-up" label="Send til Caddie" variant="primary" disabled={!txt.trim() || busy} onClick={() => ask()} /></div>
        </div>
      </div>
    </P.Gate>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-22"] = { id: "PH-22", parent: "PH-01", name: "Caddie-chat", tab: "meg", route: "/portal/coach/ai", Component: PH22 };
})();
