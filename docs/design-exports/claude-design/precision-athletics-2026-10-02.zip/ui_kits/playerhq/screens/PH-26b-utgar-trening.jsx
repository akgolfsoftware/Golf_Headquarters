/* PH-26B Utgår: Treningslogg og putte-laboratoriet — nattkjøring 29.09.2026. FORSLAG, ikke vedtak.
   Ruter i koden: /portal/trening/logg (Registrer treningsøkt: dato, område, varighet, øvelse, kvalitet 1–5, notat) og /portal/trening/putte-laboratoriet
   (seks ledd fra green-lesing til aksept, make-sannsynlighet, svakeste ledd, ti putter med samme prosess). Ingen av dem har plass i IA 28.09.
   Uavklart hvor de havner: Anders velger, ingenting fjernes før valget er bekreftet. Tre alternativer per side, anbefalt merket.
   Regler: grafitt primærknapp, ingen rust (ingenting er destruktivt før valget er bekreftet), lyst tema, ingen sidelengs rulling, manglende verdi som «—».
   Ikke nattflate. */
(() => {
const LOGG = [
  ["L1", "I dag › Registrer ekstra økt", "Knapp under dagens økter. Åpner etter-økt-skjermen (PH-07) uten plan.", "Registreringen hører til dagen. Spilleren registrerer der hun ser resten av dagen.", true, "/portal/trening/logg → I dag"],
  ["L2", "Hurtigknapp › Registrer økt", "Femte handling i hurtigknappen, ved siden av Start økt.", "Alltid ett trykk unna, men hurtigknappen har fire handlinger etter 28.09. En femte endrer den beslutningen.", false, "/portal/trening/logg → Hurtigknapp › Registrer økt"],
  ["L3", "Plan › Rediger › Ekstra økt", "Ny økt uten plan i Workbench, merket «Ekstra».", "Én motor for økter. Tyngre for en rask registrering etter trening, og skjemaet med kvalitet 1–5 må inn i Workbench.", false, "/portal/trening/logg → Plan › Rediger"],
];
const PUTT = [
  ["P1", "Plan › Øvelsesbank › Putting", "Verktøykort over break-tabellen, som flyttet dit 28.09.", "Putte-laboratoriet er et øvingsverktøy, ikke statistikk. Break-tabellen ligger allerede der.", true, "/portal/trening/putte-laboratoriet → Plan › Øvelsesbank › Putting"],
  ["P2", "Stats › Trening › Nærspill og putting", "Ligger sammen med putting-tallene (i hull per avstand mot PGA Tour).", "Samlet med tallene, men simulatoren er ikke en måling, og Stats skal bare vise målinger med kilde.", false, "/portal/trening/putte-laboratoriet → Stats › Trening"],
  ["P3", "Fjernes ved lansering", "Ingen ny plassering. Adressen sender til I dag.", "Enklest for lansering. Seksleddsmodellen (green-lesing til aksept) og «svakeste ledd» finnes da ikke i appen.", false, "/portal/trening/putte-laboratoriet → I dag"],
];
const Sec = ({ k, meta, children, label }) => <section aria-label={label || k} className="pa-card" style={{ padding: 16, gap: 12, minWidth: 0 }}><div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>{k}</span>{meta != null && React.createElement(window.PHQ.Meta, null, meta)}</div>{children}</section>;
const Muted = ({ children }) => <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{children}</p>;

function Valg({ o, sel, onPick }) {
  const { StatusPill, Icon } = window.PHQ.ns();
  const [id, tittel, hva, hvorfor, anbefalt] = o;
  return <button type="button" role="radio" aria-checked={sel} onClick={() => onPick(id)} style={{ boxSizing: "border-box", cursor: "pointer", width: "100%", minWidth: 0, minHeight: 64, margin: 0, padding: 14, textAlign: "left", font: "inherit", color: "var(--text-primary)", background: sel ? "var(--surface-sunken)" : "transparent", border: "1px solid " + (sel ? "var(--primary)" : "var(--border-hairline)"), borderRadius: 8, boxShadow: sel ? "inset 0 0 0 1px var(--primary)" : "none", display: "grid", gridTemplateColumns: "20px minmax(0,1fr)", gap: 12, alignItems: "start" }}>
    <span aria-hidden="true" style={{ width: 18, height: 18, marginTop: 2, borderRadius: 2, boxSizing: "border-box", border: "1px solid " + (sel ? "var(--primary)" : "var(--border-strong)"), background: sel ? "var(--primary)" : "transparent", color: "var(--primary-foreground, #fff)", display: "inline-flex", alignItems: "center", justifyContent: "center" }}>{sel && <Icon name="check" size={12} />}</span>
    <span style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}>
      <span style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><span style={{ font: "600 15px/1.3 var(--font-sans)", overflowWrap: "anywhere" }}>{tittel}</span>{anbefalt && <StatusPill tone="info">Anbefalt</StatusPill>}</span>
      <span style={{ font: "var(--type-body-s)", color: "var(--text-primary)", overflowWrap: "anywhere", textWrap: "pretty" }}>{hva}</span>
      <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", overflowWrap: "anywhere", textWrap: "pretty" }}>{hvorfor}</span>
    </span>
  </button>;
}

function PH26B({ state, go }) {
  const { PageHeader, Button, StatusPill, KeyValue } = window.PHQ.ns();
  const P = window.PHQ;
  const [l, setL] = React.useState(null), [p, setP] = React.useState(null), [ok, setOk] = React.useState(false);
  const lv = LOGG.find((o) => o[0] === l), pv = PUTT.find((o) => o[0] === p), klar = !!(lv && pv);
  const pick = (set) => (v) => { set(v); setOk(false); };
  const bekreft = () => { setOk(true); P.toast("Plasseringen er valgt", "FORSLAG · INGENTING FJERNET ENNÅ"); };
  return <P.Page max={880}>
    <PageHeader kicker="Forslag · Utgår 28.09" title="Treningslogg og putte-laboratoriet" sub="Ingen av de to har plass i menyen etter 28.09. Velg hvor de havner. Ingenting fjernes før du har bekreftet." actions={<Button variant="secondary" icon="arrow-left" onClick={() => go("PH-26")}>Utenfor banen</Button>} />
    <P.Gate state={state} loading="Henter forslaget …" error={{ title: "Forslaget kunne ikke hentes", text: "Ingenting er endret. Prøv igjen.", code: "FEIL 503 · TRENING" }}>
      <P.Stack>
        <Sec k="Slik er det i dag" meta="TO SIDER">
          <div role="list">
            {[["Registrer treningsøkt", "/portal/trening/logg", "Dato, område (tee-slag, innspill, nærspill, putting), varighet, øvelse, kvalitet 1–5 og notat."], ["Putte-laboratoriet", "/portal/trening/putte-laboratoriet", "Seks ledd fra green-lesing til aksept, make-sannsynlighet, svakeste ledd og ti putter med samme prosess."]].map(([n, r, t], i) => <div role="listitem" key={n} style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 12, alignItems: "start", padding: "10px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}>
              <span style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span style={{ font: "600 15px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{n}</span><Muted>{t}</Muted><P.Meta s={{ overflowWrap: "anywhere" }}>{r.toUpperCase()}</P.Meta></span>
              <StatusPill tone="neutral">Ikke avgjort</StatusPill>
            </div>)}
          </div>
          <Muted>Hva registreringen teller som i Stats og Plan er ikke avklart: —</Muted>
        </Sec>

        <Sec k="Registrer treningsøkt: hvor havner den?" meta={lv ? "VALGT " + lv[0] : "IKKE VALGT"} label="Plassering av treningsregistrering">
          <div role="radiogroup" aria-label="Plassering av treningsregistrering" style={{ display: "flex", flexDirection: "column", gap: 8 }}>{LOGG.map((o) => <Valg key={o[0]} o={o} sel={l === o[0]} onPick={pick(setL)} />)}</div>
        </Sec>

        <Sec k="Putte-laboratoriet: hvor havner det?" meta={pv ? "VALGT " + pv[0] : "IKKE VALGT"} label="Plassering av putte-laboratoriet">
          <div role="radiogroup" aria-label="Plassering av putte-laboratoriet" style={{ display: "flex", flexDirection: "column", gap: 8 }}>{PUTT.map((o) => <Valg key={o[0]} o={o} sel={p === o[0]} onPick={pick(setP)} />)}</div>
        </Sec>

        <Sec k="Gamle adresser etter valget" meta={klar ? "SENDER VIDERE" : "VENTER PÅ VALG"}>
          <KeyValue columns={1} items={[["Registrering", lv ? lv[5] : null], ["Putte-laboratoriet", pv ? pv[5] : null]]} />
          <div><Button icon="check" disabled={!klar} onClick={bekreft}>Bekreft plassering</Button></div>
          {ok && <Muted>Valget er notert som forslag. Neste steg er at tegningene og menyen rettes, og at adressene sender videre. Ingenting er fjernet.</Muted>}
        </Sec>
        <P.Meta>FORSLAG FRA AGENT 29.09.2026 · GJELDER FØRST NÅR ANDERS HAR BEKREFTET</P.Meta>
      </P.Stack>
    </P.Gate>
  </P.Page>;
}

window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-26B"] = { id: "PH-26B", parent: "PH-26", name: "Utgår: Treningslogg og putte-laboratoriet", tab: "plan", route: "/portal/trening/logg · /portal/trening/putte-laboratoriet", Component: PH26B };
})();
