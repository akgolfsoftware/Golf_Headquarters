(() => {
const AX = ["fys", "tek", "slag", "spill", "turn"];
function Detail({ o, go, onClose }) {
  const { Button, AxisBadge, KeyValue, StatusPill } = window.PHQ.ns();
  const P = window.PHQ;
  const parts = o.code.split("_");
  return <div style={{ display: "flex", flexDirection: "column", gap: 16, minWidth: 0 }}>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}><AxisBadge axis={o.axis} />{o.draft ? <StatusPill tone="info">Utkast</StatusPill> : <P.Meta>{o.src === "mine" ? "LAGET AV DEG" : "FRA ANDERS"}</P.Meta>}</div>
    <div><span className="kicker">AK-formelen</span><div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 8 }}>{parts.map((p, i) => <span key={i} style={{ font: "600 12px/1 var(--font-mono)", padding: "6px 8px", borderRadius: 4, background: i === 0 ? "var(--axis-" + o.axis + "-bg)" : "var(--surface-sunken)", color: i === 0 ? "var(--axis-" + o.axis + "-fg)" : "var(--text-primary)", overflowWrap: "anywhere" }}>{p}</span>)}</div></div>
    <KeyValue items={[["Pyramide", o.axis.toUpperCase()], ["Område", o.area, { mono: false }], ["Læringssteg", o.mot, { mono: false }], ["Teknisk dimensjon", o.dim, { mono: false }], ["Treningsmiljø", o.bel, { mono: false }], ["Press", o.press, { mono: false }], ["P-posisjoner", o.p], ["Mengde", o.qty], ["Tid", o.min + " min"], ["Mål", o.goal === "—" ? null : o.goal, { mono: false }]]} />
    {o.desc && <p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-body)", textWrap: "pretty" }}>{o.desc}</p>}
    {o.why && <div style={{ padding: 12, borderRadius: 8, background: "var(--surface-sunken)" }}><P.Meta>HVORFOR CADDIE FORESLÅR DENNE</P.Meta><p style={{ margin: "6px 0 0", font: "var(--type-body-s)", color: "var(--text-primary)", textWrap: "pretty" }}>{o.why}</p></div>}
  </div>;
}
/* Break-tabell — flyttet fra PH-26 til Plan › Øvelsesbank, under putting (Anders 28.09). */
function BreakTab() {
  const { Segmented } = window.PHQ.ns(), P = window.PHQ, [stimp, setStimp] = React.useState("10"), k = +stimp / 10, slopes = [1, 2, 3, 4];
  return <section aria-label="Break-tabell" className="pa-card" style={{ padding: 16, gap: 10, minWidth: 0 }}>
    <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>Putting · Break-tabell</span><P.Meta>CM BREAK VED HELNING · ESTIMAT</P.Meta></div>
    <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><P.Meta>STIMP</P.Meta><Segmented options={["8", "10", "12"]} value={stimp} onChange={setStimp} /></div>
    <div role="table" aria-label={"Break i cm, stimp " + stimp} style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) repeat(4,minmax(0,1fr))", gap: "0 8px" }}>
      <P.Meta s={{ padding: "6px 0" }}>AVSTAND</P.Meta>{slopes.map((s) => <P.Meta key={s} s={{ padding: "6px 0", textAlign: "right" }}>{s} %</P.Meta>)}
      {[3, 5, 10, 15, 20, 25].map((ft) => <React.Fragment key={ft}><span style={{ font: "600 13px/1 var(--font-mono)", color: "var(--text-primary)", padding: "10px 0", borderTop: "1px solid var(--border-hairline)" }}>{ft} fot</span>{slopes.map((s) => <span key={s} style={{ font: "500 13px/1 var(--font-mono)", color: "var(--text-primary)", textAlign: "right", padding: "10px 0", borderTop: "1px solid var(--border-hairline)" }}>{Math.round(0.55 * ft * s * k)}</span>)}</React.Fragment>)}
    </div>
    <P.Meta>SIKT UT FRA HULLET · TOMMELFINGERREGEL, IKKE MÅLT PÅ DIN GREEN</P.Meta>
  </section>;
}
function PH13({ state, go }) {
  const { PageHeader, SearchField, SegmentedFilter, Segmented, Button, AxisBadge, StatusPill, EmptyState, Sheet, Icon } = window.PHQ.ns();
  const P = window.PHQ, D = window.PHQ_DATA, { mob, desk } = P.useW(), empty = state === "tom";
  const [q, setQ] = React.useState(""), [ax, setAx] = React.useState("alle"), [src, setSrc] = React.useState("Alle"), [sel, setSel] = React.useState(desk && !empty ? "o1" : null);
  const [drafts, setDrafts] = React.useState(empty ? [] : D.caddieBank.map((c) => ({ ...c, draft: true, src: "caddie" }))), [bank, setBank] = React.useState(empty ? [] : D.bank);
  const all = bank.filter((o) => src === "Alle" || (src === "Fra coach" ? o.src === "coach" : o.src === "mine"));
  const hits = all.filter((o) => (ax === "alle" || o.axis === ax) && (o.name + " " + o.code + " " + o.area).toLowerCase().includes(q.toLowerCase()));
  const cur = [...bank, ...drafts].find((o) => o.id === sel);
  const add = () => P.toast("Lagt til i økt", (cur.name + " · LØR 26.09 14:30").toUpperCase());
  const accept = (c) => { setDrafts((d) => d.filter((x) => x.id !== c.id)); setBank((b) => [{ ...c, draft: false, src: "mine", mot: c.mot || null, p: null, goal: "—", desc: null }, ...b]); P.toast("Lagt i øvelsesbanken", "MERKET SOM DIN · ANDERS SER DEN"); };
  const footer = cur && (cur.draft ? <><Button fullWidth icon="check" onClick={() => { accept(cur); setSel(null); }}>Legg i banken</Button><Button variant="ghost" fullWidth onClick={() => { setDrafts((d) => d.filter((x) => x.id !== cur.id)); setSel(null); P.toast("Utkastet er forkastet", "CADDIE FORESLÅR IKKE DENNE IGJEN"); }}>Forkast utkast</Button></> : <><Button fullWidth icon="plus" onClick={add}>Legg til i økt</Button><Button variant="ghost" fullWidth icon="layers" onClick={() => go("PH-11")}>Åpne Workbench</Button></>);
  const opts = [{ value: "alle", label: "Alle", count: all.length }, ...AX.map((a) => ({ value: a, label: a.toUpperCase(), count: all.filter((o) => o.axis === a).length }))];
  const row = (o, i) => { const on = o.id === sel; return <button key={o.id} type="button" onClick={() => setSel(o.id)} aria-pressed={on} style={{ all: "unset", cursor: "pointer", display: "grid", gridTemplateColumns: "4px minmax(0,1fr) auto", gap: 12, alignItems: "center", padding: "12px 16px 12px 12px", borderTop: i ? "1px solid var(--border-hairline)" : "none", background: on ? "var(--surface-flat)" : "transparent", boxShadow: on ? "inset 2px 0 0 var(--border-ink)" : "none", minHeight: 56 }}>
    <span style={{ alignSelf: "stretch", background: "var(--axis-" + o.axis + ")" }}></span>
    <span style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", textWrap: "pretty" }}>{o.name}</span><span style={{ font: "500 11px/1.3 var(--font-mono)", color: "var(--text-muted)", overflowWrap: "anywhere" }}>{o.code}</span></span>
    <span style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}><P.Num s={{ font: "var(--type-num-s)" }}>{o.min} min</P.Num><P.Meta>{o.qty.split(" · ")[0].toUpperCase()}</P.Meta></span>
  </button>; };
  return <P.Page max={1320}>
    <PageHeader kicker={"Plan · " + (empty ? "—" : bank.length) + " øvelser"} title="Øvelsesbank" sub="Alle øvelser er navngitt etter AK-formelen. Caddie-forslag er utkast til du legger dem i banken." actions={<Button variant="secondary" icon="plus" onClick={() => P.toast("Ny øvelse", "ÅPNES I ØKTBYGGER")}>Ny øvelse</Button>} />
    <P.Gate state={state} loading="Henter øvelsesbanken …" error={{ title: "Øvelsesbanken kunne ikke hentes", text: "Ingen øvelser er slettet. Prøv igjen om litt.", code: "FEIL 503 · ØVELSER" }}>
      <P.Cols tpl={desk ? "minmax(0,1fr) 380px" : "minmax(0,1fr)"}>
        <P.Stack>
          {drafts.length > 0 && <div className="pa-card" style={{ padding: 16, gap: 12 }}>
            <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><Icon name="sparkles" size={16} /><span className="kicker" style={{ flex: 1 }}>Caddie foreslår · {drafts.length} utkast</span><P.Meta>BYGGER PÅ SG OG TRACKMAN SISTE 30 DAGER</P.Meta></div>
            {drafts.map((c) => <div key={c.id} style={{ display: "grid", gridTemplateColumns: mob ? "minmax(0,1fr)" : "minmax(0,1fr) auto", gap: 12, alignItems: "center", padding: 12, borderRadius: 8, border: "1px dashed var(--border-strong)", background: "var(--surface-flat)" }}>
              <button type="button" onClick={() => setSel(c.id)} style={{ all: "unset", cursor: "pointer", display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><AxisBadge axis={c.axis} /><StatusPill tone="info">Utkast</StatusPill></span><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{c.name}</span><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{c.why}</span></button>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button size="sm" variant="secondary" icon="check" onClick={() => accept(c)}>Legg i banken</Button><Button size="sm" variant="ghost" onClick={() => setSel(c.id)}>Se detaljer</Button></div>
            </div>)}
          </div>}
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}><div style={{ flex: "1 1 240px", minWidth: 0 }}><SearchField value={q} onChange={setQ} placeholder="Søk øvelse, område eller kode" count={hits.length} /></div><Segmented options={["Alle", "Fra coach", "Mine"]} value={src} onChange={setSrc} /></div>
            <SegmentedFilter value={ax} onChange={setAx} options={opts} label="Akse" />
          </div>
          <div className="pa-card" style={{ padding: 0, overflow: "hidden" }}>
            {hits.length ? hits.map(row) : <div style={{ padding: 16 }}><EmptyState icon="search" title={empty ? "Øvelsesbanken er tom" : "Ingen øvelser passer filteret"} text={empty ? "Anders har ikke delt øvelser med deg ennå. Du kan lage din egen." : "Prøv en annen akse eller fjern søket."} action={empty ? "Ny øvelse" : "Nullstill filter"} actionIcon={empty ? "plus" : "rotate-ccw"} onAction={() => { setQ(""); setAx("alle"); setSrc("Alle"); }} /></div>}
          </div>
          {!empty && (ax === "alle" || ax === "slag") && <BreakTab />}
        </P.Stack>
        {desk && <div className="pa-card" style={{ position: "sticky", top: 24, minWidth: 0 }}>
          {cur ? <><div style={{ padding: "16px 16px 12px", borderBottom: "1px solid var(--border-hairline)" }}><span className="kicker">Øvelse</span><div style={{ font: "var(--type-title-s)", color: "var(--text-primary)", marginTop: 6, textWrap: "pretty" }}>{cur.name}</div></div><div style={{ padding: 16 }}><Detail o={cur} go={go} /></div><div style={{ padding: 16, borderTop: "1px solid var(--border-hairline)", display: "flex", flexDirection: "column", gap: 8 }}>{footer}</div></>
            : <div style={{ padding: 16, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{empty ? "—" : "Velg en øvelse for å se AK-formelen, mengde og mål."}</div>}
        </div>}
      </P.Cols>
    </P.Gate>
    {!desk && <Sheet open={!!cur} onClose={() => setSel(null)} kicker="Øvelse" title={cur ? cur.name : ""} footer={footer}>{cur && <Detail o={cur} go={go} />}</Sheet>}
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-13"] = { id: "PH-13", parent: "PH-10", name: "Øvelsesbank", tab: "plan", route: "/portal/drills", Component: PH13 };
})();
