(() => {
const T = () => window.TR_DATA, Q = () => window.PHQT;
const reg = (id, name, C) => { window.PHQ_SCREENS[id] = { id, name, tab: "analyse", parent: "PH-16", route: "/portal/analysere/trening", Component: C }; };

/* PH-A01 · Oversikt: hva utvikler seg, hva haster, neste handling */
function A01({ state, go }) {
  const { InsightCard, EvidenceDrawer, EmptyAnalysisState, SourceBadge, DataQualityBadge, Sparkline, Icon } = window.PHQ.ns();
  const P = window.PHQ, D = T(), { Frame, Card, usePeriod, d1 } = Q(), per = usePeriod(), { desk, pad } = P.useW();
  const [ev, setEv] = React.useState(null);
  const tot = (w) => w.parts ? Object.values(w.parts).reduce((a, b) => a + b, 0) : null;
  const moves = [
    ["Belastning", "ACWR " + d1(D.acwr.value), "Over 1,3 i to uker", "PH-A02", "tynn"],
    ["Øktkvalitet", "14 av 19 økter", "74 % gjennomført siste tre uker", "PH-A03", "god"],
    ["Slagdata", "7 Iron 153 m carry", "Spredning sideveis 6,1 m", "PH-A04", "god"],
    ["Putting", "5–10 ft 38 %", "Referanse kategori D 50 %", "PH-A05", "god"],
    ["Runder", "SG innspill −0,8", "10 runder · fallende", "PH-A06", "god"],
    ["Tester", "2 av 4 gyldige", "Neste: Nærspill 20 m 29.09", "PH-A07", "tynn"]
  ];
  return <Frame id="PH-A01" title="Treningsanalyse" sub="Hva utvikler seg, hva haster og hva du gjør nå. Hvert tall har kilde, dato og antall målinger." go={go} state={state} loading="Henter økter, slag, runder og tester …" per={per}
    empty={<EmptyAnalysisState title="For lite data til en analyse" have={3} need={8} unit="økter" text="Analysen trenger minst åtte registrerte økter eller to TrackMan-økter. Du har tre." action="Registrer en økt" onAction={() => go("PH-02")} secondary="Se datagrunnlaget" onSecondary={() => go("PH-A08")} />}>
    <div style={{ display: "grid", gridTemplateColumns: desk ? "repeat(3,minmax(0,1fr))" : pad ? "repeat(2,minmax(0,1fr))" : "minmax(0,1fr)", gap: 12 }}>
      <InsightCard kind="haster" title="Belastningen er over planen to uker på rad" cause="Du trente 620 min i uke 38 mot 500 planlagt. Dagsform falt fra 3,9 til 3,1." evidence={[["ACWR", d1(D.acwr.value)], ["Anbefalt", "0,8–1,3"], ["Dagsform", "3,1 / 5"]]} quality={{ level: "god", have: 31, unit: "økter" }} source={{ source: "Øktlogg", date: D.acwr.src.split(" · ")[1], n: 31, unit: "økter", kind: "okt" }} recommendation="Be Anders vurdere lettere uke 40." actions={[{ label: "Be coach vurdere", icon: "message-square", primary: true, onClick: () => P.toast("Sendt til Anders", "ANDERS VURDERER UKE 40") }, { label: "Se belastning", onClick: () => go("PH-A02") }]} onEvidence={() => setEv("load")} />
      <InsightCard kind="trend" title="Innspill taper mest slag" cause="SG innspill har vært negativ i 8 av 10 runder. Utslag er positivt." evidence={[["SG APP", "−0,8"], ["SG OTT", "+0,4"], ["Runder", 10]]} quality={{ level: "god", have: 10, unit: "runder" }} source={{ source: "GolfBox + manuell", date: "20.09.2026", n: 10, unit: "runder", kind: "golfbox" }} actions={[{ label: "Legg i plan", icon: "calendar-plus", primary: true, onClick: () => P.toast("Forslag sendt til Anders", "INNSPILL 50–100 M · UKE 40 · UTKAST") }, { label: "Sammenlign periode", onClick: () => go("PH-A06") }]} onEvidence={() => setEv("sg")} />
      <InsightCard kind="datamangel" title="Uke 36 mangler i øktloggen" cause="Seks planlagte økter uten registrering. Belastning og gjennomføring kan være feil for den uka." evidence={[["Planlagt", 6], ["Registrert", null]]} quality={{ level: "tynn", have: 7, need: 8, unit: "uker" }} actions={[{ label: "Registrer data", icon: "plus", primary: true, onClick: () => go("PH-02") }, { label: "Se datagrunnlaget", onClick: () => go("PH-A08") }]} />
    </div>
    <Card k="Utvikling · 8 uker" aside={<SourceBadge source="Alle kilder" period={per.period} date="26.09.2026" />}>
      <div role="list" style={{ display: "grid", gridTemplateColumns: desk ? "repeat(3,minmax(0,1fr))" : pad ? "repeat(2,minmax(0,1fr))" : "minmax(0,1fr)", gap: 8 }}>{moves.map(([k, v, s, to, q]) =>
        <button key={k} role="listitem" type="button" onClick={() => go(to)} style={{ all: "unset", cursor: "pointer", display: "flex", flexDirection: "column", gap: 6, padding: 12, borderRadius: 8, border: "1px solid var(--border-hairline)", minHeight: 44, minWidth: 0 }}>
          <span style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center" }}><span className="kicker">{k}</span><Icon name="arrow-right" size={14} /></span>
          <span style={{ font: "var(--type-num)", color: "var(--text-primary)" }}>{v}</span>
          <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{s}</span>
          {q !== "god" && <DataQualityBadge level={q} />}
        </button>)}</div>
    </Card>
    <Card k="Treningsvolum per uke" aside={<P.Meta>MIN · ØKTLOGG</P.Meta>}><Sparkline values={D.load.map(tot)} goal={500} height={48} label={"Volum per uke: " + D.load.map((w) => w.label + " " + (tot(w) == null ? "ikke registrert" : tot(w) + " min")).join(", ")} /><P.Meta>STREK = PLAN 500 MIN · U36 IKKE REGISTRERT</P.Meta></Card>
    <EvidenceDrawer open={ev === "load"} onClose={() => setEv(null)} title="Belastning uke 37–39" rows={[{ label: "Volum uke 38", value: "620 min", source: "Øktlogg", date: "20.09.2026", n: 6 }, { label: "Planlagt uke 38", value: "500 min", source: "Workbench", date: "13.09.2026" }, { label: "ACWR", value: d1(D.acwr.value), source: "Beregnet", date: "26.09.2026", n: 31 }, { label: "Dagsform snitt", value: "3,1", source: "Egenregistrert", date: "26.09.2026", n: 6 }]} method="Akutt belastning (7 dager, minutter × RPE) delt på kronisk (28 dager)." uncertainty="Uke 36 mangler. Kronisk belastning kan være undervurdert." missing={["Øktlogg uke 36", "RPE for 2 økter i uke 39"]} />
    <EvidenceDrawer open={ev === "sg"} onClose={() => setEv(null)} title="Strokes Gained siste 10 runder" rows={[{ label: "SG innspill", value: "−0,8", source: "GolfBox + manuell", date: "20.09.2026", n: 10 }, { label: "SG utslag", value: "+0,4", n: 10 }, { label: "SG nærspill", value: "−0,3", n: 10 }, { label: "SG putting", value: "−0,6", n: 10 }]} method="Broadie-baseline, kategori D. Tre runder er manuelt lagt inn fra annen app." uncertainty="±0,3 slag per kategori ved 10 runder." missing={["Slag for slag mangler i 4 runder"]} />
  </Frame>;
}
reg("PH-A01", "Treningsanalyse · oversikt", A01);

/* PH-A02 · Treningsbelastning */
function A02({ state, go }) {
  const { ChartTable, AxisVolumeBars, FilterChips, Metric, TrendChart, InsightCard, SourceBadge, DataTable } = window.PHQ.ns();
  const P = window.PHQ, D = T(), { Frame, Card, usePeriod, d1, AXL } = Q(), per = usePeriod(), { desk } = P.useW();
  const [ax, setAx] = React.useState([]);
  const rows = D.load.map((w) => ({ label: w.label, plan: w.plan, parts: w.parts && (ax.length ? Object.fromEntries(Object.entries(w.parts).filter(([k]) => ax.includes(k))) : w.parts) }));
  const tot = (p) => p ? Object.values(p).reduce((a, b) => a + b, 0) : null;
  return <Frame id="PH-A02" title="Treningsbelastning" sub="Volum, intensitet og fordeling på aksene. Mål mot faktisk per uke." go={go} state={state} loading="Regner ut belastning fra øktloggen …" per={per}
    empty={<window.PHQ.ns.EA go={go} />}>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,180px),1fr))", gap: 12 }}>
      <Card><Metric label="ACWR" value={d1(D.acwr.value)} meta="ANBEFALT 0,8–1,3 · 26.09" /></Card>
      <Card><Metric label="Volum uke 39" value="322" unit="min" meta="PLAN 500 · 3 AV 6 ØKTER" /></Card>
      <Card><Metric label="Snitt RPE" value="6,6" meta="6 ØKTER · EGENREGISTRERT" /></Card>
      <Card><Metric label="Dagsform" value="3,4" unit="/ 5" meta="7 DAGER · EGENREGISTRERT" /></Card>
    </div>
    <Card k="Volum per akse" aside={<SourceBadge source="Øktlogg" date="26.09.2026" n={31} unit="økter" kind="okt" />}>
      <FilterChips label="Akser" options={Object.keys(AXL).map((a) => ({ value: a, label: AXL[a], axis: a }))} value={ax} onChange={setAx} />
      <ChartTable caption="Minutter per uke" chart={<AxisVolumeBars rows={rows} />} rowKey="label" columns={[{ key: "label", label: "Uke", mono: true }, { key: "t", label: "Faktisk", mono: true, align: "right", render: (r) => tot(r.parts) == null ? "—" : tot(r.parts) + " min" }, { key: "plan", label: "Plan", mono: true, align: "right", render: (r) => r.plan + " min" }, { key: "d", label: "Avvik", mono: true, align: "right", render: (r) => tot(r.parts) == null ? "—" : (tot(r.parts) - r.plan > 0 ? "+" : tot(r.parts) - r.plan < 0 ? "−" : "±") + Math.abs(tot(r.parts) - r.plan) + " min" }]} rows={rows} />
    </Card>
    <P.Cols tpl={desk ? "minmax(0,1.3fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
      <Card k="Intensitet og dagsform"><TrendChart symmetric={false} zero={false} min={1} max={10} format={(v) => v == null ? "—" : String(v).replace(".", ",")} series={[{ label: "RPE", values: D.load.map((w) => w.rpe) }, { label: "Dagsform × 2", values: D.load.map((w) => w.form == null ? null : +(w.form * 2).toFixed(1)) }]} labels={D.weeks} caption="U36 IKKE REGISTRERT" /></Card>
      <InsightCard kind="haster" title="Uke 38 var 24 % over plan" cause="Mest ekstra tid på SLAG og SPILL. Dagsform falt samtidig." evidence={[["Faktisk", "620 min"], ["Plan", "500 min"], ["RPE", "7,2"]]} quality={{ level: "tynn", have: 7, need: 8, unit: "uker" }} actions={[{ label: "Be coach vurdere", icon: "message-square", primary: true, onClick: () => P.toast("Sendt til Anders", "UKE 40 VURDERES") }, { label: "Se økt", onClick: () => go("PH-A03") }]} />
    </P.Cols>
  </Frame>;
}
reg("PH-A02", "Treningsbelastning", A02);

/* PH-A03 · Øktkvalitet */
function A03({ state, go }) {
  const { DataTable, StatusPill, BarRow, InsightCard, SourceBadge, Metric } = window.PHQ.ns();
  const P = window.PHQ, D = T(), { Frame, Card, usePeriod, pct } = Q(), per = usePeriod(), { desk } = P.useW();
  const tone = { "Gjennomført": "ok", "Hoppet over": "warn", "Avbrutt": "warn" };
  return <Frame id="PH-A03" title="Øktkvalitet" sub="Planlagt mot gjennomført. Hva ble hoppet over, hva ble avbrutt, og hvordan økta kjentes." go={go} state={state} loading="Henter økter …" per={per} empty={<window.PHQ.ns.EA go={go} />}>
    <P.Cols tpl={desk ? "minmax(0,1fr) minmax(0,1.4fr)" : "minmax(0,1fr)"}>
      <Card k="Gjennomføring per uke" aside={<SourceBadge source="Øktlogg" date="26.09.2026" kind="okt" />}>
        {D.quality.map((w) => <BarRow key={w.label} label={w.label} value={pct(w.done, w.planned)} max={100} goal={85} display={w.done == null ? "—" : w.done + " av " + w.planned} meta={w.done == null ? "IKKE REGISTRERT" : (w.skipped ? w.skipped + " HOPPET OVER" : "") + (w.aborted ? " " + w.aborted + " AVBRUTT" : "")} />)}
        <P.Meta>STREK = MÅL 85 % GJENNOMFØRT</P.Meta>
      </Card>
      <Card k="Siste økter">
        <DataTable caption="Siste økter" rowKey="id" columns={[{ key: "date", label: "Dato", mono: true }, { key: "title", label: "Økt" }, { key: "status", label: "Status", render: (r) => <StatusPill tone={tone[r.status]}>{r.status}</StatusPill> }, { key: "t", label: "Tid", mono: true, align: "right", render: (r) => (r.actual == null ? "—" : r.actual) + " / " + r.plan + " min" }, { key: "rpe", label: "RPE", mono: true, align: "right", render: (r) => r.rpe ?? "—" }, { key: "form", label: "Dagsform", mono: true, align: "right", render: (r) => r.form ?? "—" }]} rows={D.sessions} onSelect={() => go("PH-03")} />
      </Card>
    </P.Cols>
    <InsightCard kind="trend" title="To av tre bortfall skjedde på dager med dagsform 2" cause="Styrke 25.09 ble hoppet over med vondt i korsryggen. Banespill 21.09 ble avbrutt av vær." evidence={[["Hoppet over", 1], ["Avbrutt", 1], ["Dagsform snitt", "2,5"]]} quality={{ level: "tynn", have: 5, need: 10, unit: "økter" }} recommendation="For få økter til å si at dagsform styrer bortfall. Fortsett å registrere dagsform." actions={[{ label: "Se økt", icon: "arrow-right", primary: true, onClick: () => go("PH-03") }, { label: "Be coach vurdere", onClick: () => P.toast("Sendt til Anders", "KORSRYGG · STYRKE 25.09") }]} />
  </Frame>;
}
reg("PH-A03", "Øktkvalitet", A03);

/* PH-A04 · Slagdata (TrackMan) */
function A04({ state, go }) {
  const { FilterChips, TrendChart, DistributionPlot, ChartTable, DataTable, SourceBadge, DataQualityBadge, InsightCard, InlineAlert, EmptyAnalysisState } = window.PHQ.ns();
  const P = window.PHQ, D = T().tm, W = T().weeks, { Frame, Card, usePeriod } = Q(), per = usePeriod(), { desk } = P.useW();
  const [club, setClub] = React.useState(["7 Iron"]);
  const c = D.clubs.find((x) => x.club === club[0]) || D.clubs[1];
  return <Frame id="PH-A04" title="Slagdata" sub="TrackMan-samling per kølle: carry over tid, spredning og gapping. Datagrunnlaget vises for hvert tall." go={go} state={state} loading="Henter TrackMan-slag …" per={per}
    empty={<EmptyAnalysisState title="Ingen TrackMan-økter i perioden" have={0} need={2} unit="økter" text="Koble TrackMan eller importer en økt for å se carry, spredning og gapping." action="Importer TrackMan-økt" actionIcon="upload" onAction={() => go("PH-17")} />}>
    <FilterChips label="Kølle" single allLabel={null} options={D.clubs.map((x) => x.club)} value={club} onChange={setClub} />
    <P.Cols tpl={desk ? "minmax(0,1.3fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
      <Card k={"Carry · " + c.club} aside={<SourceBadge source={D.src} date={D.date} n={c.n} unit="slag" kind="trackman" />}>
        <ChartTable chart={<TrendChart symmetric={false} zero={false} goal={c.target} series={[{ label: "Carry", values: c.carry }]} labels={W} format={(v) => v == null ? "—" : Math.round(v) + " m"} caption={"STIPLET = MÅL " + c.target + " M · HULL = IKKE MÅLT"} />} rowKey="w" columns={[{ key: "w", label: "Uke", mono: true }, { key: "v", label: "Carry", mono: true, align: "right", render: (r) => r.v == null ? "—" : r.v + " m" }]} rows={W.map((w, i) => ({ w, v: c.carry[i] }))} />
      </Card>
      <Card k={"Spredning · " + c.club} aside={<DataQualityBadge level={c.n >= 50 ? "god" : "tynn"} have={c.n} unit="slag" />}>
        <DistributionPlot points={D.disp.map(([x, y]) => ({ x, y }))} range={16} xLabel="Offline" yLabel="Carry-avvik" />
      </Card>
    </P.Cols>
    <Card k="Gapping" aside={<SourceBadge source={D.src} date={D.date} kind="trackman" />}>
      <DataTable caption="Gapping" rowKey="c" columns={[{ key: "c", label: "Club" }, { key: "v", label: "Carry", mono: true, align: "right", render: (r) => r.v + " m" }, { key: "g", label: "Gap", mono: true, align: "right", render: (r) => r.g == null ? "—" : r.g + " m" }]} rows={D.gaps.map(([c2, v], i) => ({ c: c2, v, g: i ? D.gaps[i - 1][1] - v : null }))} />
    </Card>
    <InlineAlert tone="info" title="Datakvalitet">{D.missing.join(". ")}.</InlineAlert>
    <InsightCard kind="mal" title="7 Iron er innenfor mål, men spredningen er bred" cause="Carry 153 m mot mål 150 m. Offline standardavvik 6,1 m." evidence={[["Carry", "153 m"], ["Offline SD", "6,1 m"], ["Slag", 212]]} quality={{ level: "god", have: 212, unit: "slag" }} actions={[{ label: "Legg i plan", icon: "calendar-plus", primary: true, onClick: () => P.toast("Forslag sendt til Anders", "SPREDNING 7 IRON · UTKAST") }, { label: "Sammenlign periode", onClick: () => per.setCompare("Forrige periode") }]} />
  </Frame>;
}
reg("PH-A04", "Slagdata", A04);

/* Felles tom analyse for belastning/øktkvalitet */
window.PHQ.ns.EA = function EA({ go }) { const { EmptyAnalysisState } = window.PHQ.ns(); return <EmptyAnalysisState title="For få registrerte økter" have={2} need={8} unit="økter" text="Belastning og gjennomføring beregnes når åtte økter er registrert med tid og RPE." action="Registrer en økt" onAction={() => go("PH-02")} secondary="Se datagrunnlaget" onSecondary={() => go("PH-A08")} />; };
})();
