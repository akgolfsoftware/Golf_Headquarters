/* PH-11 Workbench for spiller — runde 29. Samme Workbench som coach, uten velgere. Målsetninger bytter ut kalenderen i midtfeltet. */
(() => {
const S = window.PHQ_SCREENS, C = (p) => <window.WB3_Workbench kit={window.PHQ} {...p} />;
S["PH-11"] = { id: "PH-11", parent: "PH-10", name: "Workbench (spiller)", tab: "plan", route: "/portal/planlegge/workbench", Component: C };
S["PH-11-MAL"] = { id: "PH-11-MAL", parent: "PH-11", name: "Workbench · Målsetninger", tab: "plan", route: "/portal/planlegge/workbench?niva=malsetninger", Component: (p) => <C {...p} level0="mal" side0="mal" /> };
S["PH-11-VOL"] = { id: "PH-11-VOL", parent: "PH-11", name: "Workbench · volum og belastning", tab: "plan", route: "/portal/planlegge/workbench?niva=volum", Component: (p) => <C {...p} level0="vol" /> };
S["PH-19"] = { id: "PH-19", parent: "PH-11", name: "Målsetning → Workbench · Målsetninger", tab: "plan", route: "/portal/mal → /portal/planlegge/workbench?niva=malsetninger", Component: (p) => <C {...p} level0="mal" side0="mal" /> };
S["PH-11-AR"] = { id: "PH-11-AR", parent: "PH-11", name: "Workbench · årsplan", tab: "plan", route: "/portal/planlegge/workbench?niva=ar", Component: (p) => <C {...p} level0="ar" /> };
S["PH-11-NY"] = { id: "PH-11-NY", parent: "PH-11-AR", name: "Workbench · opprett årsplan", tab: "plan", route: "/portal/planlegge/workbench?niva=ar&ny=1", Component: (p) => <C {...p} level0="ar" wiz0 /> };
S["PH-11-PER"] = { id: "PH-11-PER", parent: "PH-11-AR", name: "Workbench · periode", tab: "plan", route: "/portal/planlegge/workbench?niva=periode", Component: (p) => <C {...p} level0="periode" /> };
S["PH-11-PERSKJEMA"] = { id: "PH-11-PERSKJEMA", parent: "PH-11-PER", name: "Workbench · periodeskjema (alias til valgt periode)", tab: "plan", route: "/portal/planlegge/workbench?niva=periode&rediger=1", Component: (p) => <C {...p} level0="periode" /> };
S["PH-11-MND"] = { id: "PH-11-MND", parent: "PH-11-AR", name: "Workbench · måned", tab: "plan", route: "/portal/planlegge/workbench?niva=maned", Component: (p) => <C {...p} level0="mnd" /> };
S["PH-11-UKE"] = { id: "PH-11-UKE", parent: "PH-11-MND", name: "Workbench · ukeplan", tab: "plan", route: "/portal/planlegge/workbench?niva=uke", Component: (p) => <C {...p} level0="uke" /> };
S["PH-11-OKT"] = { id: "PH-11-OKT", parent: "PH-11-UKE", name: "Workbench · økt", tab: "plan", route: "/portal/planlegge/workbench?niva=okt", Component: (p) => <C {...p} level0="okt" side0="bank" /> };
S["PH-11-MNDSKJEMA"] = { id: "PH-11-MNDSKJEMA", parent: "PH-11-MND", name: "Workbench · månedsskjema (alias til valgt måned)", tab: "plan", route: "/portal/planlegge/workbench?niva=maned&rediger=1", Component: (p) => <C {...p} level0="mnd" /> };
})();
