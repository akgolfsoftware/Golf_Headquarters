(() => {
/* PH-12 Velg treningsplan (runde 36, 30.09.2026). Erstatter den gamle firestegsplanbyggeren (fire maler, SMART, Caddie-forslag).
   Fem standardplaner fra guidelines/treningsplanlegging-master.md § 2.8, tilpasset kategori A–K (§ 2.7). Alder begrenser aldri plan eller mengde.
   Omfang og fordeling er ikke fastsatt i masteren og vises derfor ikke som tall. Coach bekrefter og publiserer. Ingen AI-planbygger for spilleren. */
const PLANS = ["Weekend Warrior", "Klubbspilleren", "Junior-aspirant", "Konkurransespilleren", "Practice like the pros"];
const CATS = [["A", "World Elite"], ["B", "National Elite"], ["C", "National U21"], ["D", "Regional Elite"], ["E", "Regional U18"], ["F", "Klubbspiller Senior"], ["G", "Klubbspiller Junior"], ["H", "Rekrutt Senior"], ["I", "Rekrutt Junior"], ["J", "Nybegynner Senior"], ["K", "Nybegynner Junior"]];
const catName = (k) => (CATS.find((c) => c[0] === k) || [])[1];
function PH12({ state, go }) {
  const { PageHeader, Button, StatusPill, KeyValue, EmptyState, InlineAlert, ChoicePill } = window.PHQ.ns();
  const P = window.PHQ, { desk } = P.useW(), empty = state === "tom";
  const [plan, setPlan] = React.useState(empty ? null : "Klubbspilleren"), [cat, setCat] = React.useState(empty ? null : "D"), [sent, setSent] = React.useState(false);
  const ready = plan && cat, dirty = sent && false;
  const send = () => { if (!ready) return; setSent(true); P.toast("Valget er sendt til Anders", "STATUS · VENTER PÅ COACH"); };
  const catRow = <div className="pa-card" style={{ padding: 16, gap: 12 }}>
    <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>Kategori</span><P.Meta>{empty ? "IKKE SATT" : "SATT PÅ SNITTSCORE · KATEGORI D · 10 RUNDER · 20.09.2026"}</P.Meta></div>
    <div role="radiogroup" aria-label="Kategori A–K" style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{CATS.map(([k, n]) => <ChoicePill key={k} role="radio" aria-checked={cat === k} selected={cat === k} mono disabled={sent} title={"Kategori " + k + " · " + n} aria-label={"Kategori " + k + " " + n} onClick={() => setCat(k)} style={{ minHeight: 44, minWidth: 44 }}>{k}</ChoicePill>)}</div>
    <span style={{ font: "var(--type-body-s)", color: cat ? "var(--text-primary)" : "var(--text-secondary)" }}>{cat ? "Kategori " + cat + " · " + catName(cat) : "Velg kategori. Coach justerer hvis den ikke stemmer."}</span>
  </div>;
  const list = <div className="pa-card" style={{ padding: 16, gap: 12 }}>
    <span className="kicker">Fem standardplaner</span>
    <div role="radiogroup" aria-label="Standardplan" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,220px),1fr))", gap: 8 }}>{PLANS.map((n) => { const on = plan === n; return <button key={n} type="button" role="radio" aria-checked={on} disabled={sent} onClick={() => setPlan(n)} style={{ textAlign: "left", padding: 14, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), boxShadow: on ? "inset 0 0 0 1px var(--border-ink)" : "none", background: "var(--surface-card)", color: "var(--text-primary)", display: "flex", flexDirection: "column", gap: 6, cursor: sent ? "default" : "pointer", minHeight: 88, minWidth: 0 }}><span style={{ font: "600 15px/1.3 var(--font-sans)" }}>{n}</span><P.Meta>{cat ? ("TILPASSET KATEGORI " + cat).toUpperCase() : "VELG KATEGORI FØRST"}</P.Meta></button>; })}</div>
  </div>;
  const aside = <div className="pa-card" style={{ padding: 16, gap: 12, position: desk ? "sticky" : "static", top: 24 }}>
    <span className="kicker">Valget ditt</span>
    <KeyValue items={[["Plan", plan, { mono: false }], ["Kategori", cat ? cat + " · " + catName(cat) : null, { mono: false }], ["Status", sent ? "Venter på coach" : "Ikke sendt", { mono: false }]]} />
    <P.Meta>COACH BEKREFTER OG PUBLISERER. PLANEN VISES I PLAN OG WORKBENCH NÅR DEN ER PUBLISERT.</P.Meta>
  </div>;
  return <P.Page max={1200}>
    <PageHeader kicker="Plan · Velg treningsplan" title="Velg treningsplan" sub="Fem standardplaner, tilpasset kategorien din. Coachen din bekrefter valget før planen blir aktiv." actions={<Button variant="ghost" icon="arrow-left" onClick={() => go("PH-10")} style={{ minHeight: 44 }}>Plan</Button>} />
    <P.Gate state={state} loading="Henter standardplanene …" error={{ title: "Planene kunne ikke hentes", text: "Ingenting er valgt eller sendt.", code: "FEIL 500 · STANDARDPLANER" }}>
      {empty && <InlineAlert tone="info" title="Kategorien er ikke satt ennå">Kategorien settes på snittscore fra minst fire runder. Velg kategori selv nå, så justerer coachen den senere.</InlineAlert>}
      <P.Cols tpl={desk ? "minmax(0,1fr) 320px" : "minmax(0,1fr)"}>
        <P.Stack>{catRow}{list}
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            {!sent ? <Button icon="send" disabled={!ready} onClick={send}>Send valg til coach</Button>
              : <><StatusPill tone="info">Venter på coach</StatusPill><Button variant="secondary" iconRight="arrow-right" onClick={() => go("PH-10")}>Åpne Plan</Button><Button variant="ghost" icon="undo-2" onClick={() => { setSent(false); P.toast("Valget er trukket tilbake", "INGENTING ER SENDT"); }}>Trekk tilbake</Button></>}
            {!ready && !sent && <P.Meta>VELG PLAN OG KATEGORI FOR Å SENDE</P.Meta>}
          </div>
        </P.Stack>
        {aside}
      </P.Cols>
    </P.Gate>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-12"] = { id: "PH-12", parent: "PH-10", name: "Velg treningsplan", tab: "plan", route: "/portal/planlegge/velg", Component: PH12 };
})();
