(() => {
const REASONS = ["Syk", "Skade", "Skole", "Vær", "Annet"];
function ExRow({ e, i, st, onToggle }) {
  const { AxisBadge, Checkbox } = window.PHQ.ns();
  const P = window.PHQ, done = st === "done";
  return <div style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr)", gap: 12, padding: "14px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}>
    <P.Meta s={{ font: "var(--type-num-s)", paddingTop: 2 }}>{String(i + 1).padStart(2, "0")}</P.Meta>
    <div style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}>
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><AxisBadge axis={e.axis} /><span style={{ font: "500 15px/1.3 var(--font-sans)", color: done ? "var(--text-muted)" : "var(--text-primary)", textDecoration: done ? "line-through" : "none", flex: "1 1 180px", minWidth: 0 }}>{e.n}</span></div>
      <div style={{ font: "500 12px/1.35 var(--font-mono)", color: "var(--text-secondary)", overflowWrap: "anywhere" }}>{e.code}</div>
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}><P.Meta>{e.qty} {e.unit.toUpperCase()}</P.Meta><P.Meta>{e.min} MIN</P.Meta>{e.p && <P.Meta>{e.p}</P.Meta>}<P.Meta>{e.club.toUpperCase()}</P.Meta></div>
      {st && <div><Checkbox checked={done} onChange={onToggle} label="Gjennomført" /></div>}
    </div>
  </div>;
}
function PH03({ state, go }) {
  const { PageHeader, Breadcrumb, Button, StatusPill, KeyValue, EmptyState, Sheet, ChoicePill, SortableList, InlineAlert } = window.PHQ.ns();
  const P = window.PHQ, { desk, pad, mob, nav } = P.useW(), D = window.PHQ_DATA, S = D.session, empty = state === "tom";
  const [status, setStatus] = React.useState("Planlagt");
  const [done, setDone] = React.useState({});
  const [skip, setSkip] = React.useState(false), [why, setWhy] = React.useState(null);
  const [ord, setOrd] = React.useState(null), [ro, setRo] = React.useState(false);
  const ex0 = empty ? [] : S.ex, ex = ord ? ord.map((c) => ex0.find((e) => e.code === c)) : ex0;
  const reorder = (ids) => { const before = ord; setOrd(ids); nav && nav.undo("Rekkefølgen er endret", "SENDT TIL ANDERS SOM FORSLAG", () => setOrd(before)); };
  const n = Object.values(done).filter(Boolean).length;
  const tone = status === "Pågår" ? "info" : status === "Gjennomført" ? "ok" : status === "Hoppet over" ? "warn" : "neutral";
  const actions = status === "Planlagt" ? <><Button icon="play" disabled={!ex.length} onClick={() => { setStatus("Pågår"); P.toast("Økta er startet", S.time + " · " + S.title.toUpperCase()); }}>Start økt</Button><Button variant="ghost" icon="skip-forward" onClick={() => setSkip(true)}>Hopp over</Button></>
    : status === "Pågår" ? <><Button icon="check" onClick={() => { setStatus("Gjennomført"); P.toast("Økta er gjennomført", n + " AV " + ex.length + " ØVELSER · LAGRET"); }}>Fullfør økt</Button><Button variant="secondary" icon="radio" onClick={() => go("PH-05")}>Åpne live-økt</Button></>
    : status === "Gjennomført" ? <Button variant="secondary" iconRight="arrow-right" onClick={() => go("PH-07")}>Se oppsummering</Button>
    : <Button variant="ghost" icon="undo-2" onClick={() => setStatus("Planlagt")}>Angre</Button>;
  return <P.Page>
    <PageHeader breadcrumb={<Breadcrumb items={[{ label: "Gjør nå", onClick: () => go("PH-02") }, { label: S.title }]} />} kicker={"LØR 26.09 · " + S.time + "–" + S.end + " · RANGE 3"} title={S.title} meta={<span style={{ display: "inline-flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><StatusPill tone={tone}>{status}</StatusPill>{status === "Hoppet over" && why && <span>ÅRSAK · {why.toUpperCase()}</span>}{status === "Pågår" && <span>{n} AV {ex.length} ØVELSER</span>}</span>} actions={state === "data" || state === "tom" ? actions : null} />
    <P.Gate onRetry={P.retryLoad} retryId="ph03-prov-igjen" state={state} loading="Henter øktarket …" error={{ title: "Kunne ikke åpne økta", text: "Økta finnes, men øvelsene kunne ikke lastes. Prøv igjen, eller åpne den fra Gjør nå.", code: "FEIL 500 · OKT-2609" }}>
      <P.Cols tpl={desk ? "minmax(0,1.6fr) minmax(0,1fr)" : pad ? "minmax(0,1.3fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
        <div className="pa-card" style={{ padding: "16px 16px 4px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", paddingBottom: 4 }}><span className="kicker">Øvelser · AK-formelen</span><span style={{ display: "inline-flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><P.Meta>{ex.length ? ex.length + " ØVELSER · " + S.min + " MIN" : "—"}</P.Meta>{status === "Planlagt" && ex.length > 1 && <Button size="sm" variant="ghost" icon={ro ? "check" : "arrow-up-down"} onClick={() => setRo(!ro)}>{ro ? "Ferdig" : "Endre rekkefølge"}</Button>}</span></div>
          {ro && <InlineAlert tone="info" title="Endrer ikke coachens plan">Ny rekkefølge sendes til Anders som forslag. Første øvelse er låst av coach.</InlineAlert>}
          {ro ? <SortableList label="Øvelser i økta" items={ex.map((e) => ({ ...e, id: e.code, label: e.name || e.title || e.code }))} locked={[ex0[0] && ex0[0].code]} onReorder={reorder} renderItem={(e, c) => <div style={{ display: "flex", alignItems: "center", gap: 4, minHeight: 52, borderTop: c.index ? "1px solid var(--border-hairline)" : "none" }}>{c.handle}<span style={{ flex: 1, minWidth: 0, font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{e.label}</span><P.Meta>{c.locked ? "LÅST" : String(c.index + 1).padStart(2, "0")}</P.Meta></div>} /> : ex.length ? ex.map((e, i) => <ExRow key={e.code} e={e} i={i} st={status === "Pågår" ? (done[i] ? "done" : "open") : null} onToggle={() => setDone((d) => ({ ...d, [i]: !d[i] }))} />)
            : <div style={{ padding: "12px 0 16px" }}><EmptyState icon="list-plus" title="Økta har ingen øvelser ennå" text="Anders legger inn øvelsene før start. Du får varsel når økta er klar." action="Send melding til coach" actionIcon="message-square" actionControlId="ph03-melding-coach" onAction={() => { const sel = window.PHQ_SEL || {}; window.PH21_CTX = { type: "okt", coach: "Anders Kristiansen", recipientCoachId: "coach-anders", spiller: (window.PHQ_DATA && window.PHQ_DATA.player && window.PHQ_DATA.player.name) || "Spiller", performerId: (window.TP2 && window.TP2.scope && window.TP2.scope().playerId) || "p1", sessionId: sel.sessionId || (S && S.id) || "", sessionNavn: (S && (S.title || S.name)) || "", publicationId: "", publishedRev: null, planId: "", returnTo: "PH-03", returnLabel: "Til økta", text: "" }; go("PH-21"); }} /></div>}
        </div>
        <P.Stack>
          <div className="pa-card" style={{ padding: "8px 16px" }}><KeyValue items={[["Fokus", empty ? null : S.focus, { mono: false }], ["Treningsmiljø", S.belastning, { mono: false }], ["Press", S.press, { mono: false }], ["Målsetning", empty ? null : S.goal, { mono: false }], ["Coach", D.player.coach, { mono: false }]]} /></div>
          <div className="pa-card" style={{ padding: 16, gap: 8 }}><span className="kicker">Notat fra Anders</span><p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-body)", textWrap: "pretty" }}>{empty ? "—" : S.note}</p><P.Meta>FRE 25.09 · 21:10</P.Meta></div>
        </P.Stack>
      </P.Cols>
    </P.Gate>
    <Sheet open={skip} onClose={() => setSkip(false)} kicker={"Hoppe over · " + S.time} title={S.title} footer={<><Button fullWidth disabled={!why} onClick={() => { setStatus("Hoppet over"); setSkip(false); P.toast("Økta er hoppet over", "ÅRSAK · " + why.toUpperCase() + " · ANDERS FÅR BESKJED"); }}>Hopp over økt</Button><Button variant="ghost" fullWidth onClick={() => setSkip(false)}>Avbryt</Button></>}>
      <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Velg årsak. Coachen din ser den og kan flytte økta.</p>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{REASONS.map((r) => <ChoicePill key={r} selected={why === r} onClick={() => setWhy(r)}>{r}</ChoicePill>)}</div>
    </Sheet>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-03"] = { id: "PH-03", parent: "PH-02", name: "Øktark", tab: "idag", route: "/portal/gjennomfore/[id]", Component: (p) => (window.PHQ_SEL && window.PHQ_SEL.pub && window.PHQ_SEL.view03 && window.WB3_PUB) ? <window.WB3_PUB.Ark {...p} /> : <PH03 {...p} /> };
})();
