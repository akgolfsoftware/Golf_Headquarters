/* Runde — runde 24 (Anders 28.09.2026). Natt, store treffflater. Ingen GPS eller banekart.
   PH-RD-03 live runde (slag) · PH-RD-04 putt · PH-RD-08 etter runden. Per slag påkrevd: avstand (m, fot på green), underlag og kølle.
   Putt påkrevd: lengde i fot, break, fart og hvor man misser. Straffeslag med ett trykk. «I hull» avslutter hullet. Appen går automatisk til neste slag; trykk et tall for å rette. */
(() => {
const R = () => window.LIVE_DATA.round;
const toPar = (d) => d > 0 ? "+" + d : d < 0 ? "−" + Math.abs(d) : "±0";
const sgf = (n) => (n > 0.04 ? "+" : n < -0.04 ? "−" : "±") + Math.abs(n).toFixed(1).replace(".", ",");
function Pick({ label, opts, v, set, cols }) {
  return <div role="group" aria-label={label} style={{ display: "flex", flexDirection: "column", gap: 8 }}>
    <span style={{ font: "600 14px/1.2 var(--font-sans)", color: "var(--text-secondary)" }}>{label}</span>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(" + (cols || 3) + ",minmax(0,1fr))", gap: 6 }}>{opts.map(([k, l]) => <button key={k} type="button" aria-pressed={v === k} onClick={() => set(k)} style={{ minHeight: 52, minWidth: 0, padding: "0 6px", borderRadius: 8, border: "1px solid " + (v === k ? "var(--border-ink)" : "var(--border-hairline)"), background: v === k ? "var(--primary)" : "var(--surface-card)", color: v === k ? "var(--text-on-primary)" : "var(--text-primary)", font: "600 14px/1.15 var(--font-sans)", cursor: "pointer", overflowWrap: "anywhere" }}>{l}</button>)}</div>
  </div>;
}
function Live({ state, go, mode }) {
  const { Button, IconButton, StatusPill, TextInput, EmptyState } = window.PHQ.ns();
  const P = window.PHQ, D = R(), empty = state === "tom", putt0 = mode === "putt";
  const [hole, setHole] = React.useState(empty ? 1 : D.hole), [par, setPar] = React.useState(empty ? 4 : D.par), [len, setLen] = React.useState(empty ? 342 : D.len);
  const [played, setPlayed] = React.useState(empty ? [] : D.played);
  const [shots, setShots] = React.useState(empty ? [] : putt0 ? [...D.shots, ...D.putts] : D.shots);
  const blank = (d) => ({ dist: d && d.dist != null ? String(d.dist) : "", lie: d ? d.lie : "TEE", club: d && d.lie === "GREEN" ? "Putter" : "", brk: "", res: "", fart: "", miss: "", pen: 0 });
  const [dr, setDr] = React.useState(() => empty ? blank({ dist: 342, lie: "TEE" }) : blank(putt0 ? D.nextPutt : D.next)), [edit, setEdit] = React.useState(null);
  const green = dr.lie === "GREEN", strokes = shots.reduce((a, s) => a + 1 + (s.pen || 0), 0), n = shots.length + 1;
  const tot = played.reduce((a, [p, s]) => a + s, 0), totPar = played.reduce((a, [p]) => a + p, 0);
  const okBase = dr.dist !== "" && dr.lie && dr.club;
  const okPutt = okBase && dr.brk && (dr.res === "hull" || (dr.res === "miss" && dr.fart && dr.miss));
  const ok = green ? okPutt : okBase;
  const set = (k) => (v) => setDr((x) => ({ ...x, [k]: v, ...(k === "lie" && v === "GREEN" ? { club: "Putter" } : {}), ...(k === "lie" && v !== "GREEN" && x.club === "Putter" ? { club: "" } : {}) }));
  const rec = () => ({ id: "s" + Date.now(), dist: +dr.dist, unit: green ? "fot" : "m", lie: dr.lie, club: dr.club, pen: dr.pen, ...(green ? { brk: dr.brk, fart: dr.res === "miss" ? dr.fart : null, miss: dr.res === "miss" ? dr.miss : null } : {}) });
  const endHole = (list) => { const sc = list.reduce((a, s) => a + 1 + (s.pen || 0), 0); P.toast("Hull " + hole + ": " + sc + " slag (" + toPar(sc - par) + ")", "NESTE: HULL " + (hole + 1)); const np = [...played, [par, sc]]; setPlayed(np); if (hole >= 18) { go("PH-RD-08"); return; } const H = (window.RD_DATA && window.RD_DATA.course.holes[hole]) || [4, 350]; setHole(hole + 1); setPar(H[0]); setLen(H[1]); setShots([]); setDr(blank({ dist: H[1], lie: "TEE" })); };
  const save = (holed) => {
    if (edit != null) { setShots((l) => l.map((s, i) => i === edit ? { ...s, ...rec(), id: s.id } : s)); setEdit(null); setDr(blank(null)); P.toast("Slag " + (edit + 1) + " er rettet", "—"); return; }
    const list = [...shots, rec()];
    if (holed || (green && dr.res === "hull")) { endHole(list); return; }
    setShots(list); setDr(blank({ dist: "", lie: green ? "GREEN" : "" }));
  };
  const fix = (i) => { const s = shots[i]; setEdit(i); setDr({ dist: String(s.dist), lie: s.lie, club: s.club, brk: s.brk || "", res: s.lie === "GREEN" ? (s.fart ? "miss" : "hull") : "", fart: s.fart || "", miss: s.miss || "", pen: s.pen || 0 }); };
  const lieL = (k) => (D.lies.find((l) => l[0] === k) || [k, k])[1];
  const Chip = ({ children, onClick, label }) => <button type="button" onClick={onClick} aria-label={label} style={{ minHeight: 44, minWidth: 44, padding: "0 12px", borderRadius: 8, border: "1px solid var(--border-hairline)", background: "var(--surface-card)", color: "var(--text-primary)", font: "600 14px/1 var(--font-mono)", cursor: "pointer" }}>{children}</button>;
  const top = <><StatusPill tone="live">Runde</StatusPill><span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "600 17px/1 var(--font-sans)", color: "var(--text-primary)" }}>Hull {hole} · par {par}</span><P.Meta>{len} M · {D.course.toUpperCase()}</P.Meta></span><span style={{ flex: 1 }}></span><span style={{ display: "flex", flexDirection: "column", gap: 2, alignItems: "flex-end" }}><span style={{ font: "600 17px/1 var(--font-mono)", color: "var(--text-primary)" }}>{played.length ? tot + " (" + toPar(tot - totPar) + ")" : "—"}</span><P.Meta>ETTER {played.length} HULL</P.Meta></span><IconButton icon="flag" label="Avslutt runden" variant="ghost" onClick={() => go("PH-RD-08")} style={{ width: 56, height: 56 }} /></>;
  const action = state === "data" || empty ? <Button size="xl" fullWidth icon={edit != null ? "check" : green && dr.res === "hull" ? "flag" : "arrow-right"} disabled={!ok} style={{ height: 64 }} onClick={() => save(false)}>{edit != null ? "Lagre rettelse" : green && dr.res === "hull" ? "I hull · avslutt hullet" : green ? "Lagre putt" : "Lagre slag"}</Button> : null;
  return <P.Focus top={top} action={action}>
    <P.Gate state={state} loading="Henter runden …" error={{ title: "Runden kunne ikke lagres", text: "Slagene er lagret på telefonen og sendes når nettet er tilbake.", code: "FRAKOBLET · 11:20 · 38 SLAG LOKALT" }}>
      {empty && <EmptyState icon="flag" title="Første slag på hull 1" text="Avstand, underlag og kølle for hvert slag. Appen går videre til neste slag automatisk." />}
      {shots.length > 0 && <section aria-label="Slag på hullet" style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        <div style={{ display: "flex", gap: 8, alignItems: "baseline" }}><span className="kicker" style={{ flex: 1 }}>Hull {hole} · {strokes} slag så langt</span><P.Meta>TRYKK ET TALL FOR Å RETTE</P.Meta></div>
        <div role="list">{shots.map((s, i) => <div role="listitem" key={s.id} style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap", minHeight: 56, borderTop: i ? "1px solid var(--border-hairline)" : "none", padding: "4px 0", background: edit === i ? "var(--surface-sunken)" : "transparent" }}>
          <P.Meta s={{ width: 52 }}>{s.lie === "GREEN" ? "PUTT" : "SLAG"} {i + 1}</P.Meta>
          <Chip onClick={() => fix(i)} label={"Rett avstand slag " + (i + 1)}>{s.dist} {s.unit}</Chip>
          <Chip onClick={() => fix(i)} label={"Rett underlag slag " + (i + 1)}>{lieL(s.lie)}</Chip>
          <Chip onClick={() => fix(i)} label={"Rett kølle slag " + (i + 1)}>{s.club}</Chip>
          {s.brk && <Chip onClick={() => fix(i)} label={"Rett break putt " + (i + 1)}>{s.brk.replace(" → ", "→")}</Chip>}
          {s.fart && <Chip onClick={() => fix(i)} label={"Rett miss putt " + (i + 1)}>{s.fart} · {s.miss}</Chip>}
          {s.pen > 0 && <P.Meta s={{ color: "var(--text-primary)" }}>+{s.pen} STRAFFE</P.Meta>}
        </div>)}</div>
      </section>}
      <section aria-label={edit != null ? "Rett slag " + (edit + 1) : "Slag " + n} style={{ display: "flex", flexDirection: "column", gap: 16, paddingTop: 12, borderTop: "1px solid var(--border-hairline)" }}>
        <div style={{ display: "flex", gap: 8, alignItems: "baseline" }}><h1 style={{ margin: 0, flex: 1, font: "var(--type-title-m)", color: "var(--text-primary)" }}>{edit != null ? "Rett slag " + (edit + 1) : green ? "Putt " + (shots.filter((s) => s.lie === "GREEN").length + 1) : "Slag " + n}</h1><P.Meta>ALT ER PÅKREVD</P.Meta></div>
        <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 12, alignItems: "end" }}>
          <label style={{ display: "flex", flexDirection: "column", gap: 8 }}><span style={{ font: "600 14px/1.2 var(--font-sans)", color: "var(--text-secondary)" }}>{green ? "Lengde (fot)" : "Avstand til hull (m)"}</span><TextInput mono inputMode="numeric" value={dr.dist} placeholder="—" onChange={(e) => set("dist")(e.target.value.replace(/\D/g, "").slice(0, 3))} style={{ height: 64, fontSize: 28 }} /></label>
          <Button variant={dr.pen ? "primary" : "secondary"} icon="plus" onClick={() => setDr((x) => ({ ...x, pen: (x.pen || 0) + 1 }))} style={{ height: 64 }}>{dr.pen ? dr.pen + " straffe" : "Straffeslag"}</Button>
        </div>
        <Pick label="Underlag" opts={D.lies} v={dr.lie} set={set("lie")} cols={4} />
        {green ? <>
          <Pick label="Break" opts={D.breaks.map((b) => [b, b])} v={dr.brk} set={set("brk")} cols={2} />
          <Pick label="Resultat" opts={[["hull", "I hull"], ["miss", "Bom"]]} v={dr.res} set={set("res")} cols={2} />
          {dr.res === "miss" && <><Pick label="Fart" opts={[["Kort", "Kort"], ["Lang", "Lang"]]} v={dr.fart} set={set("fart")} cols={2} /><Pick label="Hvor bommet du?" opts={[["Venstre", "Venstre"], ["Høyre", "Høyre"], ["På linja", "På linja"]]} v={dr.miss} set={set("miss")} cols={3} /></>}
        </> : <>
          <Pick label="Kølle" opts={D.bag.filter((b) => b !== "Putter").map((b) => [b, b])} v={dr.club} set={set("club")} cols={4} />
          {edit == null && <div><Button variant="ghost" icon="flag" disabled={!okBase} onClick={() => save(true)} style={{ height: 52 }}>I hull · avslutt hullet</Button></div>}
        </>}
      </section>
    </P.Gate>
  </P.Focus>;
}

function Done({ state, go }) {
  const { Button, IconButton, StatusPill, EmptyState, Icon } = window.PHQ.ns();
  const P = window.PHQ, X = window.LIVE_DATA.roundDone, D = R(), empty = state === "tom";
  const tot = X.sg.reduce((a, [, v]) => a + v, 0), t5 = X.t5.reduce((a, [, v]) => a + v, 0);
  const top = <><IconButton icon="x" label="Lukk" variant="secondary" onClick={() => go("PH-01")} style={{ width: 56, height: 56 }} /><div style={{ flex: 1, minWidth: 0 }}><div className="kicker">Runde gjennomført</div><P.Meta>{D.course.toUpperCase()} · {D.date}</P.Meta></div></>;
  const action = state === "data" || empty ? <Button size="xl" fullWidth icon="check" style={{ height: 64 }} onClick={() => go("PH-16")}>Se runden i Stats</Button> : null;
  const Sec = ({ k, meta, children }) => <section aria-label={k} style={{ display: "flex", flexDirection: "column", gap: 6, paddingTop: 12, borderTop: "1px solid var(--border-hairline)" }}><div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>{k}</span>{meta && <P.Meta>{meta}</P.Meta>}</div>{children}</section>;
  const Row = ({ a, b, i }) => <div role="listitem" style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 48, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ font: "500 15px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{a}</span><span style={{ font: "600 16px/1 var(--font-mono)", color: "var(--text-primary)" }}>{b}</span></div>;
  return <P.Focus top={top} action={action}>
    <P.Gate state={state} loading="Regner ut Strokes Gained …" error={{ title: "Runden kunne ikke lagres", text: "Alle slag er lagret på telefonen. SG regnes ut når nettet er tilbake.", code: "FRAKOBLET · 14:02 · 76 SLAG LOKALT" }}>
      {empty ? <EmptyState icon="flag" title="Ingen slag registrert" text="Runden lagres ikke før minst ett hull er ferdig." action="Tilbake til runden" actionIcon="arrow-left" onAction={() => go("PH-RD-03")} /> : <>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}><P.Meta>BRUTTO SCORE</P.Meta><div style={{ display: "flex", alignItems: "baseline", gap: 12, flexWrap: "wrap" }}><span style={{ font: "600 56px/1 var(--font-mono)", color: "var(--text-primary)" }}>{X.score}</span><span style={{ font: "600 22px/1 var(--font-mono)", color: "var(--text-secondary)" }}>{toPar(X.toPar)}</span></div><P.Meta>PAR {X.par} · {X.putts} PUTTER · FAIRWAY {X.fw.toUpperCase()} · GIR {X.gir.toUpperCase()}</P.Meta></div>
        <Sec k="Strokes Gained" meta={X.base}><div role="list">{X.sg.map(([k, v], i) => <Row key={k} i={i} a={k} b={sgf(v)} />)}<Row i={1} a="Totalt" b={sgf(tot)} /></div></Sec>
        <Sec k="Tiger 5" meta={t5 + " PÅ RUNDEN"}><div role="list">{X.t5.map(([k, v], i) => <Row key={k} i={i} a={k} b={v} />)}</div></Sec>
        <Sec k="Planen din oppdateres" meta="RUNDE-AGENTENE"><div role="list">{X.agent.map(([t, m, dn], i) => <div role="listitem" key={t} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr)", gap: 12, alignItems: "start", minHeight: 52, padding: "8px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ width: 24, height: 24, borderRadius: 999, display: "grid", placeItems: "center", border: "1px solid " + (dn ? "var(--border-ink)" : "var(--border-hairline)"), background: dn ? "var(--primary)" : "transparent", color: dn ? "var(--text-on-primary)" : "var(--text-muted)" }}>{dn ? <Icon name="check" size={14} /> : <Icon name="loader" size={14} />}</span><span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "500 15px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{t}</span><P.Meta>{m.toUpperCase()}</P.Meta></span></div>)}</div></Sec>
      </>}
    </P.Gate>
  </P.Focus>;
}
const S = window.PHQ_SCREENS;
S["PH-RD-03"] = { id: "PH-RD-03", parent: "PH-RD-02", name: "Live runde · slag", tab: "idag", night: true, route: "/portal/runde/live", Component: (p) => window.PHQ_RUND && window.WB3_RUND ? <window.WB3_RUND.RD03Pub go={p.go} /> : window.PHQ_RD && window.PHQ_RD.kind === "selvstendig" && window.RD_LOKAL ? <window.RD_LOKAL.Runde screen="PH-RD-03" go={p.go} /> : <><>{window.RD_LOKAL && <window.RD_LOKAL.Strip />}</><div data-control-id="rd-eksempel-merke" style={{ font: "600 13px/1.3 var(--font-sans)", padding: "8px 16px" }}>EKSEMPELMODUS · ikke koblet til en planlagt runde (prototypens eksempeldata)</div><Live {...p} mode="slag" /></> };
S["PH-RD-04"] = { id: "PH-RD-04", parent: "PH-RD-03", name: "Live runde · putt", tab: "idag", night: true, route: "/portal/runde/live?putt", Component: (p) => window.PHQ_RUND && window.WB3_RUND ? <window.WB3_RUND.RD03Pub go={p.go} /> : window.PHQ_RD && window.PHQ_RD.kind === "selvstendig" && window.RD_LOKAL ? <window.RD_LOKAL.Runde screen="PH-RD-04" go={p.go} /> : <><>{window.RD_LOKAL && <window.RD_LOKAL.Strip />}</><div data-control-id="rd-eksempel-merke" style={{ font: "600 13px/1.3 var(--font-sans)", padding: "8px 16px" }}>EKSEMPELMODUS · ikke koblet til en planlagt runde (prototypens eksempeldata)</div><Live {...p} mode="putt" /></> };
S["PH-RD-08"] = { id: "PH-RD-08", parent: "PH-RD-03", name: "Runde gjennomført", tab: "idag", night: true, route: "/portal/runde/[id]/ferdig", Component: (p) => window.PHQ_RUND && window.WB3_RUND ? <window.WB3_RUND.RD03Pub go={p.go} /> : window.PHQ_RD && window.PHQ_RD.kind === "selvstendig" && window.RD_LOKAL ? <window.RD_LOKAL.Runde screen="PH-RD-08" go={p.go} /> : <><>{window.RD_LOKAL && <window.RD_LOKAL.Strip />}</><div data-control-id="rd-eksempel-merke" style={{ font: "600 13px/1.3 var(--font-sans)", padding: "8px 16px" }}>EKSEMPELMODUS · ikke koblet til en planlagt runde (prototypens eksempeldata)</div><Done {...p} /></> };
})();
