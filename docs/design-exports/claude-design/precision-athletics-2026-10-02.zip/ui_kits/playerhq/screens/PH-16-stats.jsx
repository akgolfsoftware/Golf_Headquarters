/* PH-16 Stats — runde 22 (Anders 28.09). Fire deler: Snittscore · Strokes Gained · Trening · Tester.
   Øverst i hver del: positiv trend (størst forbedring siste 10 runder mot de 10 før), deretter flest tapte slag, synkende.
   Sammenligning: neste kategori (Broadie, ESTIMAT) som standard, PGA Tour kan slås på.
   PH-14, PH-17, PH-18 åpner sin del. PH-A01–A08 utgår 28.09 og er slått inn i delene. Lastes etter PH-A1/A2 og overstyrer dem. */
(() => {
const DELER = [["snitt", "Snittscore", "flag"], ["sg", "Strokes Gained", "chart-bar"], ["tren", "Trening", "activity"], ["test", "Tester", "clipboard-check"]];
function Stats({ state, go, del: d0, openId }) {
  const { PageHeader, Button, Icon } = window.PHQ.ns();
  const P = window.PHQ, D = window.PHQ_DATA, { mob, cw } = P.useW();
  const [del, setDel] = React.useState(d0 || "snitt"), [pga, setPga] = React.useState(false);
  const wide = cw >= 1000, cols = wide ? "repeat(2,minmax(0,1fr))" : "minmax(0,1fr)";
  const cur = DELER.find((x) => x[0] === del);
  const SN = window.STATS_SNITT, DL = window.STATS_DELER;
  return <P.Page max={1320}>
    <PageHeader kicker={"Stats · " + cur[1]} title="Stats" actions={<Button variant="secondary" icon="flag" onClick={() => go("PH-RD-01")}>Registrer runde</Button>} />
    <div role="tablist" aria-label="Stats" style={{ display: "grid", gridTemplateColumns: mob ? "repeat(2,minmax(0,1fr))" : "repeat(4,minmax(0,1fr))", gap: 6, minWidth: 0 }}>
      {DELER.map(([id, l, ic]) => { const on = id === del; return <button key={id} type="button" role="tab" aria-selected={on} onClick={() => setDel(id)} style={{ minHeight: 48, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--primary)" : "var(--surface-card)", color: on ? "var(--text-on-primary)" : "var(--text-primary)", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, font: "600 14px/1.2 var(--font-sans)", cursor: "pointer", padding: "0 8px", minWidth: 0 }}><Icon name={ic} size={16} /><span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{l}</span></button>; })}
    </div>
    <P.Gate state={state} loading={"Regner ut " + cur[1].toLowerCase() + " …"} error={{ title: cur[1] + " kunne ikke lastes", text: "Rundene, øktene og testene dine er lagret. Tallene hentes på nytt når du prøver igjen.", code: "FEIL 503 · STATS · " + D.date.now }}>
      <div role="tabpanel" aria-label={cur[1]} style={{ display: "flex", flexDirection: "column", gap: mob ? 16 : 24, minWidth: 0 }}>
        {del === "snitt" && <SN.Snittscore state={state} go={go} pga={pga} setPga={setPga} consent={state !== "tom"} openId={openId} cols={cols} />}
        {del === "sg" && <DL.SG state={state} go={go} pga={pga} setPga={setPga} cols={cols} />}
        {del === "tren" && <DL.Trening state={state} go={go} cols={cols} />}
        {del === "test" && <DL.Tester state={state} go={go} wide={wide} />}
      </div>
    </P.Gate>
  </P.Page>;
}
const part = (del, openId) => (p) => <Stats {...p} del={del} openId={openId} />;
const S = window.PHQ_SCREENS;
S["PH-16"] = { id: "PH-16", name: "Stats", tab: "analyse", route: "/portal/analysere", Component: part("snitt") };
S["PH-18"] = { id: "PH-18", parent: "PH-16", name: "Stats › Snittscore · runde", tab: "analyse", route: "/portal/mal/runder → /portal/analysere?del=snittscore", Component: part("snitt", "r22") };
S["PH-17"] = { id: "PH-17", parent: "PH-16", name: "Stats › Trening · TrackMan", tab: "analyse", route: "/portal/analysere/trackman → /portal/analysere?del=trening", Component: part("tren") };
S["PH-14"] = { id: "PH-14", parent: "PH-16", name: "Stats › Tester", tab: "analyse", route: "/portal/tren/tester → /portal/analysere?del=tester", Component: part("test") };
[["PH-A01", "Treningsanalyse · oversikt", "tren"], ["PH-A02", "Treningsbelastning", "tren"], ["PH-A03", "Øktkvalitet", "tren"], ["PH-A04", "Slagdata", "tren"], ["PH-A05", "Nærspill og putting", "sg"], ["PH-A06", "Rundeanalyse", "snitt"], ["PH-A07", "Tester · utvikling", "test"], ["PH-A08", "Datagrunnlag", "snitt"]].forEach(([id, n, d]) => { S[id] = { id, parent: "PH-16", name: n + " · utgår 28.09 → Stats › " + DELER.find((x) => x[0] === d)[1], tab: "analyse", utgar: true, route: "/portal/analysere/trening* → /portal/analysere", Component: part(d) }; });
})();
