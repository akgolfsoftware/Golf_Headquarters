/* PH-24 Meg — runde 23 (Anders 28.09.2026). Rekkefølge: profil · fasiliteter · bookinger · abonnement og betalingskort · foreldre · deling ·
   helse og fravær · utstyr · min coach · venner og utfordringer · hjelp · innstillinger. Talentradar vises aldri for spilleren. */
(() => {
const Sec = ({ k, meta, children, n }) => <section aria-label={k} className="pa-card" style={{ padding: 16, gap: 12, minWidth: 0 }}><div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span style={{ font: "600 11px/1 var(--font-mono)", color: "var(--text-muted)" }}>{String(n).padStart(2, "0")}</span><span className="kicker" style={{ flex: "1 1 auto" }}>{k}</span>{meta != null && React.createElement(window.PHQ.Meta, null, meta)}</div>{children}</section>;
const Muted = ({ children }) => <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{children}</p>;
const Rows = ({ rows }) => <div role="list">{rows.map(([a, b, sub], i) => <div role="listitem" key={i} style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 44, borderTop: i ? "1px solid var(--border-hairline)" : "none", padding: "6px 0" }}><span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{a}</span>{sub && React.createElement(window.PHQ.Meta, null, sub)}</span><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-secondary)", textAlign: "right" }}>{b}</span></div>)}</div>;

function PH24({ state, go }) {
  const { Avatar, Button, KeyValue, StatusPill, EmptyState, Icon, Sheet, FormField, TextInput, Segmented } = window.PHQ.ns();
  const P = window.PHQ, M = window.PHQ_MEG23, ME = window.PHQ_ME.me, tm = window.PHQ_DATA.tm || {}, { cw } = P.useW(), empty = state === "tom", U = window.FAS_UI, FA = window.FAS;
  const [fas, setFas] = React.useState(empty ? [] : FA.demo), [fEd, setFEd] = React.useState(null);
  const [par, setPar] = React.useState(empty ? [] : M.foreldre), [inv, setInv] = React.useState(false), [invMail, setInvMail] = React.useState(""), [seeP, setSeeP] = React.useState(false);
  const [abs, setAbs] = React.useState(empty ? [] : M.fravaer), [absEd, setAbsEd] = React.useState(null);
  const two = cw >= 900;
  const secs = [
    <Sec key="p" n={1} k="Profil" meta={empty ? "—" : "KATEGORI " + M.profil.cat}>
      <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}><Avatar name={M.profil.name} size={48} /><span style={{ flex: "1 1 160px", minWidth: 0, display: "flex", flexDirection: "column", gap: 2 }}><span style={{ font: "600 17px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{M.profil.name}</span><P.Meta>{M.profil.age} ÅR · {M.profil.club.toUpperCase()}</P.Meta></span></div>
      <KeyValue items={[["Født", M.profil.born], ["HCP", empty ? null : M.profil.hcp, { hint: empty ? undefined : M.profil.hcpSrc }], ["Hjemmeklubb", M.profil.club, { mono: false }], ["Golf-ID", empty ? null : M.profil.golfId], ["E-post", M.profil.email, { mono: false }], ["Telefon", M.profil.phone]]} />
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button variant="secondary" size="sm" icon="pencil">Rediger profil</Button><Button variant="ghost" size="sm" iconRight="arrow-right" onClick={() => go("PH-19")}>Målsetninger</Button></div>
    </Sec>,
    <Sec key="f" n={2} k="Fasiliteter" meta={fas.length ? fas.length + " STEDER" : "INGEN"}>
      {fas.length ? <div role="list">{fas.map((f, i) => { const c = FA.covers(f).length; return <button key={f.id} type="button" role="listitem" onClick={() => setFEd(f)} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", width: "100%", display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 52, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{f.name}</span><P.Meta>{c} OMRÅDER · ENDRET {f.updated}</P.Meta></span><Icon name="pencil" size={16} /></button>; })}</div> : <Muted>Legg inn stedene du trener. Da vet planen hva du kan trene hvor.</Muted>}
      <U.Dekning list={fas} />
      <div><Button variant="secondary" size="sm" icon="plus" onClick={() => setFEd({})}>Legg til fasilitet</Button></div>
    </Sec>,
    <Sec key="b" n={3} k="Bookinger" meta={empty ? "—" : M.klipp.left + " AV " + M.klipp.total + " KLIPP · FORNYES " + M.klipp.resets}>
      {empty ? <Muted>Ingen bookinger.</Muted> : <Rows rows={M.bookinger.map((b) => [b.what, <StatusPill tone="ok">{b.st}</StatusPill>, b.when.toUpperCase() + " · " + b.where.toUpperCase() + (b.clip ? " · 1 KLIPP" : "")])} />}
      <div><Button variant="secondary" size="sm" icon="calendar-plus" onClick={() => go("PH-23")}>Book time</Button></div>
    </Sec>,
    <Sec key="a" n={4} k="Abonnement og betalingskort" meta={empty ? "GRATIS" : (M.abo.plan === "FULL" ? "Full" : "Gratis") + " · FORNYES " + M.abo.renews}>
      <KeyValue items={[["Abonnement", empty ? "Gratis" : (M.abo.plan === "FULL" ? "Full" : "Gratis") + " · " + M.abo.price, { mono: false }], ["Betalingskort", empty ? null : M.abo.card, { hint: empty ? undefined : "UTLØPER " + M.abo.exp }]]} />
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button variant="secondary" size="sm" icon="external-link" onClick={() => P.toast("Åpner Stripe-kundeportalen", "BYTT KORT OG SE KVITTERINGER HOS STRIPE")}>Bytt kort og se kvitteringer</Button><Button variant="ghost" size="sm" iconRight="arrow-right" onClick={() => go("PH-25")}>Endre abonnement</Button></div>
    </Sec>,
    <Sec key="fo" n={5} k="Foreldre" meta={par.length ? par.length + " FORELDRE" : "INGEN"}>
      {par.length ? <Rows rows={par.map((p) => [p.name, <StatusPill tone={p.st === "Har tilgang" ? "ok" : "info"}>{p.st}</StatusPill>, p.email.toUpperCase() + " · " + p.since])} /> : <Muted>Ingen foreldre er koblet til.</Muted>}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button variant="secondary" size="sm" icon="user-plus" onClick={() => setInv(true)}>Inviter forelder</Button><Button variant="ghost" size="sm" icon="eye" onClick={() => setSeeP(true)}>Se tilgang</Button></div>
    </Sec>,
    <Sec key="d" n={6} k="Deling" meta={empty ? "INGEN" : "3 COACHER · 1 FORESPØRSEL"}>
      <Muted>{empty ? "Ingen coacher har tilgang." : "AK Golf, WANG og Team Norway har innsyn. De ser alt, også helse og meldinger."}</Muted>
      <div><Button variant="secondary" size="sm" iconRight="arrow-right" onClick={() => go("PH-27")}>Åpne deling</Button></div>
    </Sec>,
    <Sec key="h" n={7} k="Helse og fravær" meta={<span style={{ display: "inline-flex", gap: 6, alignItems: "center" }}><Icon name="lock" size={12} />FORELDRE SER IKKE DETTE</span>}>
      <KeyValue items={[["Skader nå", empty ? null : "Ingen", { mono: false }], ["Søvn snitt", empty ? null : ME.health.sleep, { hint: ME.health.sleepSrc }]]} />
      {abs.length ? <Rows rows={abs.map((a) => [a.kind + " · " + a.from.slice(0, 5) + "–" + a.to.slice(0, 5), <StatusPill tone={a.st === "Planlagt" ? "info" : "neutral"}>{a.st}</StatusPill>, a.note.toUpperCase()])} /> : <Muted>Ingen fravær registrert.</Muted>}
      <div><Button variant="secondary" size="sm" icon="plus" onClick={() => setAbsEd({ kind: "Skade", from: "", to: "", note: "" })}>Registrer fravær</Button></div>
      <P.Meta>FRAVÆR MARKERES SOM OPPTATT I PLAN · COACHENE MED TILGANG SER DET</P.Meta>
    </Sec>,
    <Sec key="u" n={8} k="Utstyr" meta={empty ? "—" : "14 KØLLER · CARRY TRACKMAN 24.09.2026"}>
      {empty ? <Muted>Bagen er ikke registrert.</Muted> : <div role="list" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,150px),1fr))", columnGap: 16 }}>{ME.bag.map(([c, spec]) => <div role="listitem" key={c} style={{ display: "grid", gridTemplateColumns: "44px minmax(0,1fr) auto", gap: 8, alignItems: "center", minHeight: 32, borderTop: "1px solid var(--border-hairline)" }}><span style={{ font: "600 13px/1 var(--font-mono)", color: "var(--text-primary)" }}>{c}</span><span style={{ font: "400 12px/1.3 var(--font-sans)", color: "var(--text-secondary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{spec}</span><P.Num s={{ font: "var(--type-num-s)" }}>{tm[c] ? P.dec(tm[c][0], 0) + " m" : "—"}</P.Num></div>)}</div>}
      <div><Button variant="ghost" size="sm" icon="pencil">Endre bag</Button></div>
    </Sec>,
    <Sec key="c" n={9} k="Min coach" meta={empty ? "—" : "SIDEN " + M.coach.since}>
      {empty ? <Muted>Ingen coach ennå. Book en privattime for å komme i gang.</Muted> : <>
        <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}><Avatar name={M.coach.name} size={40} /><span style={{ flex: "1 1 160px", minWidth: 0, display: "flex", flexDirection: "column", gap: 2 }}><span style={{ font: "600 15px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{M.coach.name}</span><P.Meta>{M.coach.role.toUpperCase()}</P.Meta></span></div>
        <KeyValue items={[["Avtale", M.coach.avtale, { mono: false }]]} />
        <P.Meta>VIDEOER FRA ANDERS</P.Meta><Rows rows={M.coach.videos.map(([t, l, d]) => [t, l, d])} />
        <P.Meta>TILBAKEMELDINGER</P.Meta><div role="list">{M.coach.feedback.map(([d, w, t], i) => <div role="listitem" key={d} style={{ display: "flex", flexDirection: "column", gap: 4, padding: "8px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><P.Meta>{d} · {w.toUpperCase()}</P.Meta><span style={{ font: "400 14px/1.4 var(--font-sans)", color: "var(--text-primary)", textWrap: "pretty" }}>{t}</span></div>)}</div>
      </>}
      <P.Meta>MELDINGER LIGGER I INNBOKSEN BAK BJELLA</P.Meta>
    </Sec>,
    <Sec key="v" n={10} k="Venner og utfordringer" meta={empty ? "—" : M.venner + " VENNER"}>
      {empty ? <Muted>Ingen venner eller utfordringer.</Muted> : <Rows rows={M.utfordringer.map(([t, s, e]) => [t, <StatusPill tone="info">{s}</StatusPill>, e.toUpperCase() + " · TELLER IKKE SOM TRENING"])} />}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button variant="secondary" size="sm" icon="trophy" onClick={() => P.toast("Ny utfordring", "VELG VENNER OG ØVELSE")}>Ny utfordring</Button><Button variant="ghost" size="sm" icon="user-plus">Legg til venn</Button></div>
    </Sec>,
    <Sec key="hj" n={11} k="Hjelp">{M.hjelp.map(([t, ic], i) => <button key={t} type="button" onClick={() => P.toast("Åpner", t.toUpperCase())} style={{ all: "unset", cursor: "pointer", display: "flex", gap: 10, alignItems: "center", minHeight: 44, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><Icon name={ic} size={16} /><span style={{ flex: 1, font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{t}</span><Icon name="arrow-up-right" size={14} /></button>)}</Sec>,
    <Sec key="i" n={12} k="Innstillinger"><Muted>Varsler, samtykker, sikkerhet og sletting av konto.</Muted><div><Button variant="secondary" size="sm" icon="settings" iconRight="arrow-right" onClick={() => go("PH-25")}>Åpne innstillinger</Button></div></Sec>,
  ];
  const half = Math.ceil(secs.length / 2);
  return <P.Page max={1280}>
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}><span className="kicker">Meg</span><h1 style={{ margin: 0, font: "600 clamp(22px,1.2vw + 16px,28px)/1.15 var(--font-sans)", color: "var(--text-primary)" }}>Meg</h1></div>
    <P.Gate state={state} loading="Henter profilen din …" error={{ title: "Profilen kunne ikke hentes", text: "Ingenting er endret. Prøv igjen.", code: "FEIL 503 · PROFIL" }}>
      {two ? <P.Cols tpl="repeat(2,minmax(0,1fr))"><P.Stack>{secs.slice(0, half)}</P.Stack><P.Stack>{secs.slice(half)}</P.Stack></P.Cols> : <P.Stack>{secs}</P.Stack>}
    </P.Gate>
    {fEd && <Sheet open onClose={() => setFEd(null)} kicker="Meg · Fasiliteter" title={fEd.name || "Ny fasilitet"}><U.FasSkjema init={fEd} onCancel={() => setFEd(null)} onSave={(f) => { setFas((l) => l.some((x) => x.id === f.id) ? l.map((x) => x.id === f.id ? f : x) : [...l, f]); setFEd(null); P.toast("Fasiliteten er lagret", (f.name + " · " + FA.covers(f).length + " OMRÅDER").toUpperCase()); }} /></Sheet>}
    {inv && <Sheet open onClose={() => setInv(false)} kicker="Meg · Foreldre" title="Inviter forelder" footer={<><Button fullWidth icon="send" disabled={!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(invMail)} onClick={() => { setPar((l) => [...l, { name: invMail.split("@")[0], email: invMail, st: "Invitert", since: "26.09.2026" }]); setInv(false); setInvMail(""); P.toast("Invitasjonen er sendt", invMail.toUpperCase()); }}>Send invitasjon</Button><Button variant="ghost" fullWidth onClick={() => setInv(false)}>Avbryt</Button></>}><FormField label="Forelderens e-post"><TextInput type="email" inputMode="email" value={invMail} onChange={(e) => setInvMail(e.target.value)} placeholder="navn@epost.no" /></FormField><Muted>Forelderen får tilgang til forelderportalen. Under 16 år gir forelderen samtykkene.</Muted></Sheet>}
    {seeP && <Sheet open onClose={() => setSeeP(false)} kicker="Meg · Foreldre" title="Hva foreldrene ser" footer={<Button variant="secondary" fullWidth onClick={() => setSeeP(false)}>Lukk</Button>}><P.Meta>SER</P.Meta><Rows rows={M.foreldreSer.map((x) => [x, "✓"])} /><P.Meta>SER IKKE</P.Meta><Rows rows={M.foreldreSerIkke.map((x) => [x, "—"])} /></Sheet>}
    {absEd && <Sheet open onClose={() => setAbsEd(null)} kicker="Meg · Helse og fravær" title="Registrer fravær" footer={<><Button fullWidth icon="check" disabled={!absEd.from} onClick={() => { setAbs((l) => [{ id: "n" + Date.now(), ...absEd, to: absEd.to || absEd.from, st: "Planlagt" }, ...l]); setAbsEd(null); P.toast("Fraværet er registrert", (absEd.kind + " · MARKERT I PLAN").toUpperCase()); }}>Lagre</Button><Button variant="ghost" fullWidth onClick={() => setAbsEd(null)}>Avbryt</Button></>}>
      <Segmented options={["Skade", "Sykdom", "Ferie"]} value={absEd.kind} onChange={(v) => setAbsEd({ ...absEd, kind: v })} fullWidth />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 12 }}><FormField label="Fra"><TextInput mono value={absEd.from} placeholder="dd.mm.åååå" onChange={(e) => setAbsEd({ ...absEd, from: e.target.value })} /></FormField><FormField label="Til"><TextInput mono value={absEd.to} placeholder="dd.mm.åååå" onChange={(e) => setAbsEd({ ...absEd, to: e.target.value })} /></FormField></div>
      <FormField label="Notat" optional><TextInput value={absEd.note} onChange={(e) => setAbsEd({ ...absEd, note: e.target.value })} placeholder="Kort hva det gjelder" /></FormField>
    </Sheet>}
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-24"] = { id: "PH-24", name: "Meg", tab: "meg", route: "/portal/meg", Component: PH24 };
})();
