(() => {
function HoleCell({ i, par, len, v, onChange, err }) {
  const P = window.PHQ;
  const b = { width: 44, height: 44, borderRadius: 8, border: "1px solid var(--border-strong)", background: "var(--surface-card)", color: "var(--text-primary)", font: "600 17px/1 var(--font-mono)", cursor: "pointer", flex: "none" };
  const d = v == null ? null : v - par;
  return <div style={{ border: "1px solid " + (err ? "var(--signal-ink)" : "var(--border-hairline)"), borderRadius: 8, background: "var(--surface-card)", padding: 8, display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}>
    <div style={{ display: "flex", justifyContent: "space-between", gap: 4 }}><P.Meta s={{ color: "var(--text-primary)", fontWeight: 600 }}>HULL {i + 1}</P.Meta><P.Meta>PAR {par} · {len} M</P.Meta></div>
    <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
      <button type="button" style={b} aria-label={"Hull " + (i + 1) + " ett slag mindre"} disabled={v == null || v <= 1} onClick={() => onChange(v - 1)}>−</button>
      <div style={{ flex: 1, textAlign: "center", minWidth: 0 }}><span style={{ font: "600 21px/1 var(--font-mono)", color: v == null ? "var(--text-faint)" : "var(--text-primary)", fontVariantNumeric: "tabular-nums" }}>{v == null ? "—" : v}</span>{d != null && <span style={{ display: "block", font: "var(--type-meta)", color: "var(--text-muted)", marginTop: 2 }}>{P.toPar(d)}</span>}</div>
      <button type="button" style={b} aria-label={"Hull " + (i + 1) + " ett slag mer"} onClick={() => onChange(v == null ? par : v + 1)}>+</button>
    </div>
  </div>;
}
function PH09({ state, go }) {
  const { PageHeader, Button, FormField, ChoicePill, Segmented, SearchField, StatusPill, InlineAlert } = window.PHQ.ns();
  const P = window.PHQ, D = window.PHQ_DATA, C = D.course, { mob, desk } = P.useW(), empty = state === "tom";
  const [day, setDay] = React.useState("I dag"), [course, setCourse] = React.useState(empty ? null : C.name), [q, setQ] = React.useState("");
  const [kind, setKind] = React.useState("Treningsrunde"), [tee, setTee] = React.useState("Gul"), [holes, setHoles] = React.useState("18 hull");
  const range = holes === "9 hull · ut" ? [0, 9] : holes === "9 hull · inn" ? [9, 18] : [0, 18], inR = (i) => i >= range[0] && i < range[1], nH = range[1] - range[0];
  const [s, setS] = React.useState(empty ? Array(18).fill(null) : C.full.map((v, i) => i === 16 ? null : v));
  const [tried, setTried] = React.useState(false), [saved, setSaved] = React.useState(false);
  const missing = s.map((v, i) => inR(i) && v == null ? i + 1 : null).filter(Boolean);
  const sum = (a, b) => s.slice(a, b).reduce((x, y, k) => x + (inR(a + k) ? y || 0 : 0), 0), par = (a, b) => C.par.slice(a, b).reduce((x, y) => x + y, 0);
  const played = s.filter((v, i) => inR(i) && v != null).length, br = sum(0, 18), parPlayed = C.par.reduce((a, p, i) => a + (inR(i) && s[i] != null ? p : 0), 0);
  const list = D.courses.filter(([n]) => n.toLowerCase().includes(q.toLowerCase()));
  const save = () => { setTried(true); if (missing.length || !course) return; setSaved(true); P.toast("Runden er lagret · " + nH + " hull", "BRUTTO " + br + " SLAG (" + P.toPar(br - parPlayed) + ") · " + course.toUpperCase()); };
  const summary = <div className="pa-card" style={{ padding: 16, gap: 12, position: desk ? "sticky" : "static", top: 24 }}>
    <span className="kicker">Brutto score</span>
    <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-metric-l)", color: "var(--text-primary)" }}>{played ? br : "—"}</span><P.Num s={{ color: "var(--text-muted)" }}>{played ? "slag (" + P.toPar(br - parPlayed) + ")" : "slag"}</P.Num></div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 8 }}>{[["UT", sum(0, 9), range[0] === 0, s.slice(0, 9)], ["INN", sum(9, 18), range[1] === 18, s.slice(9)], ["HULL", played, true, null]].map(([k, v, on, arr]) => <div key={k} style={{ background: "var(--surface-sunken)", borderRadius: 8, padding: "8px 10px" }}><P.Meta>{k}</P.Meta><div style={{ font: "600 17px/1.2 var(--font-mono)", color: "var(--text-primary)" }}>{arr ? (on && arr.some((x) => x != null) ? v : "—") : v + " / " + nH}</div></div>)}</div>
    {tried && missing.length > 0 && <InlineAlert tone="warn" title={missing.length === 1 ? "Hull " + missing[0] + " mangler score" : missing.length + " hull mangler score"}>Fyll inn alle {nH} hull, eller velg 9 hull under Antall hull.</InlineAlert>}
    {saved ? <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><StatusPill tone="ok">Lagret</StatusPill><P.Meta>15:44 · SENDT TIL ANALYSE</P.Meta></div> : <Button size="lg" fullWidth icon="check" onClick={save}>Lagre runde</Button>}
    <P.Meta>BRUTTO · TIL PAR REGNES AV PAR PÅ SPILTE HULL ({parPlayed || "—"})</P.Meta>
  </div>;
  return <P.Page>
    <PageHeader kicker="Etter runden · Brutto score" title="Registrer runde" sub="Dato, bane og antall slag per hull. Putter og slag på banen registreres live under runden." actions={<Button variant="secondary" icon="radio" onClick={() => go("PH-08")}>Registrer live</Button>} />
    <P.Gate state={state} loading="Henter baner og tidligere runder …" error={{ title: "Banelisten kunne ikke hentes", text: "Runden er ikke lagret. Prøv igjen, eller skriv inn banen når du har nett.", code: "FEIL 502 · GOLFBOX" }}>
      <P.Cols tpl={desk ? "minmax(0,1fr) 320px" : "minmax(0,1fr)"}>
        <P.Stack gap={20}>
          <div className="pa-card" style={{ padding: 16, gap: 20 }}>
            <FormField label="Dato" required><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{["I dag", "I går", "Velg dato"].map((d) => <ChoicePill key={d} selected={day === d} onClick={() => setDay(d)}>{d}</ChoicePill>)}<P.Meta s={{ alignSelf: "center" }}>{day === "I dag" ? "26.09.2026" : day === "I går" ? "25.09.2026" : "—"}</P.Meta></div></FormField>
            <FormField label="Bane" required error={tried && !course ? "Velg banen du spilte. Bruk søket hvis den ikke står i listen." : null}>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <SearchField value={q} onChange={setQ} placeholder="Søk bane" count={list.length} />
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{list.map(([n, sub]) => <ChoicePill key={n} selected={course === n} onClick={() => setCourse(n)}>{n}</ChoicePill>)}</div>
              </div>
            </FormField>
            <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
              <FormField label="Tee"><Segmented options={["Hvit", "Gul", "Blå", "Rød"]} value={tee} onChange={setTee} /></FormField>
              <FormField label="Antall hull"><Segmented options={["18 hull", "9 hull · ut", "9 hull · inn"]} value={holes} onChange={setHoles} /></FormField>
              <FormField label="Type runde"><Segmented options={["Treningsrunde", "Tellende"]} value={kind} onChange={setKind} /></FormField>
            </div>
          </div>
          {[0, 9].filter((a) => inR(a)).map((a) => <div key={a} className="pa-card" style={{ padding: 16, gap: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">{a ? "Hull 10–18 · Inn" : "Hull 1–9 · Ut"}</span><P.Meta>PAR {par(a, a + 9)}</P.Meta></div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(" + (mob ? 150 : 164) + "px,1fr))", gap: 8 }}>{C.par.slice(a, a + 9).map((p, k) => { const i = a + k; return <HoleCell key={i} i={i} par={p} len={C.len[i]} v={s[i]} err={tried && s[i] == null} onChange={(v) => setS((x) => x.map((y, j) => j === i ? v : y))} />; })}</div>
          </div>)}
        </P.Stack>
        {summary}
      </P.Cols>
    </P.Gate>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-09"] = { id: "PH-09", parent: "PH-18", name: "Registrer runde", tab: "analyse", route: "/portal/runde/logg", Component: PH09 };
})();
