/* PH-16b Skill map — Stats › Strokes Gained › Kart (runde 35, natt 29.–30.09.2026).
   Samme tall som SG-delen i PH-16 (STATS_DATA.sg), vist på en skjematisk hull-skisse: tee nederst, putting øverst.
   Ikke en egen fane i Stats: nås fra Strokes Gained («Se som kart») og har «Se som liste» tilbake. Lyst tema. Ingen rust, ingen fargekoding av SG (retning og fortegn, ikke farge).
   Puttebånd følger STATS_DATA (0–3, 3–6, 6–10, 10–20, 20–40, 40+ fot, AG-14 27.09). Hullkart og slagspor (gode/feil/spredning) er ikke tegnet: krever slagdata per slag, vises ikke før de finnes. */
(() => {
const P = () => window.PHQ, ns = () => window.PHQ.ns(), S = () => window.STATS_DATA, Q = () => window.STATSP;
/* Geometri i viewBox 360 × 548 (1 enhet = 1 px på 390). Rader: putting (2×3) · nærspill (4) · innspill (4, smalere nedover) · tee. */
const G = {
  p0: [8, 12, 112, 44], p3: [124, 12, 112, 44], p6: [240, 12, 112, 44],
  p10: [8, 62, 112, 44], p20: [124, 62, 112, 44], p40: [240, 62, 112, 44],
  chip: [8, 126, 82, 52], pitch: [98, 126, 82, 52], lob: [188, 126, 82, 52], bunker: [278, 126, 74, 52],
  i50: [30, 202, 300, 48], i100: [50, 258, 260, 48], i150: [70, 314, 220, 48], i200: [90, 370, 180, 48],
  tee: [110, 442, 140, 52],
};
const GROUP = { tee: "Tee", innspill: "Innspill", naer: "Nærspill 0–50 m", putt: "Putting" };
const short = (r) => r.g === "tee" ? "Tee" : r.g === "innspill" ? r.label.replace(" m", "") : r.label.replace(" fot", "");
const long = (r) => r.g === "tee" ? "Tee · par 4 og 5" : r.g === "innspill" ? "Innspill " + r.label : r.g === "putt" ? "Putting " + r.label : r.label;
const rowsOf = () => S().sg.flatMap((g) => g.rows.map((r) => ({ ...r, g: g.g })));
const hoursOf = (id) => { const t = S().tren.find((x) => x.id === id); return t ? t.h : null; };

function HoleMap({ rows, val, sel, onSel, minSg }) {
  const QQ = Q();
  const Pp = P();
  return <svg role="group" aria-label="Skill map: Strokes Gained per område på en skjematisk hull-skisse, tee nederst" viewBox="0 0 360 548" style={{ width: "100%", maxWidth: 420, height: "auto", display: "block", margin: "0 auto" }}>
    <rect x="0.5" y="0.5" width="359" height="547" fill="var(--surface-sunken)" stroke="var(--border-hairline)" />
    <polygon points="24,196 336,196 300,424 60,424" fill="var(--surface-page)" stroke="var(--border-hairline)" strokeDasharray="4 4" />
    <text x="12" y="120" fontFamily="var(--font-mono)" fontSize="10" fill="var(--text-muted)" letterSpacing=".04em">GREEN</text>
    <text x="348" y="196" textAnchor="end" fontFamily="var(--font-mono)" fontSize="10" fill="var(--text-muted)" letterSpacing=".04em">FAIRWAY</text>
    <text x="180" y="536" textAnchor="middle" fontFamily="var(--font-mono)" fontSize="10" fill="var(--text-muted)" letterSpacing=".04em">SKISSE · IKKE EN BANE</text>
    {rows.map((r) => {
      const [x, y, w, h] = G[r.id], v = val(r), on = sel === r.id, none = v == null;
      const weak = r.id === minSg;
      return <g key={r.id} role="button" tabIndex={0} aria-pressed={on} aria-label={long(r) + ", SG " + Pp.sg(v) + " per runde" + (weak ? ", fokusområde" : "")}
        style={{ cursor: "pointer" }} onClick={() => onSel(r.id)} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onSel(r.id); } }}>
        <rect x={x} y={y} width={w} height={h} fill={on ? "var(--surface-flat)" : "var(--surface-card)"} stroke={on ? "var(--text-primary)" : "var(--border-strong)"} strokeWidth={on ? 2 : 1} strokeDasharray={none ? "4 3" : undefined} />
        <text x={x + w / 2} y={y + h / 2 - 3} textAnchor="middle" fontFamily="var(--font-sans)" fontWeight="600" fontSize="12" fill="var(--text-primary)">{short(r)}</text>
        <text x={x + w / 2} y={y + h / 2 + 13} textAnchor="middle" fontFamily="var(--font-mono)" fontSize="12" fill="var(--text-secondary)">{Pp.sg(v)}</text>
        {weak && <rect x={x + 3} y={y + 3} width="6" height="6" fill="var(--text-primary)" />}
      </g>;
    })}
  </svg>;
}

function Detail({ r, pga, val, n }) {
  const QQ = Q();
  const Pp = P(), { d1 } = Q(), v = val(r), Sec = Q().Sec, Row = Q().Row, Lbl = Q().Lbl;
  const h = hoursOf(r.id), cmp = pga ? "PGA TOUR" : "KATEGORI C · ESTIMAT";
  return <Sec k={GROUP[r.g]} meta={long(r).toUpperCase()} label={"Detaljer for " + long(r)} gap={4}>
    <div style={{ display: "flex", gap: 12, alignItems: "baseline", flexWrap: "wrap" }}>
      <Pp.Num s={{ font: "600 26px/1 var(--font-mono)" }}>{Pp.sg(v)}</Pp.Num>
      <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>slag per runde mot {pga ? "PGA Tour" : "neste kategori"}</span>
    </div>
    <QQ.SGBar v={v} />
    <div role="list" style={{ marginTop: 4 }}>
      <Row first tpl="minmax(0,1fr) auto" label="Grunnlag"><Lbl sub={S().sgSrc}>Slag i grunnlaget</Lbl><Pp.Num>{r.n == null ? "—" : r.n}</Pp.Num></Row>
      <Row tpl="minmax(0,1fr) auto" label="Trend"><Lbl sub="SISTE 10 RUNDER MOT DE 10 FØR">Endring</Lbl><Pp.Num>{Pp.sg(r.d)}</Pp.Num></Row>
      <Row tpl="minmax(0,1fr) auto" label="Trening"><Lbl sub={S().trenSrc}>Trening siste 8 uker</Lbl><Pp.Num>{h == null ? "—" : d1(h) + " t"}</Pp.Num></Row>
      {r.prox && <Row tpl="minmax(0,1fr) auto" label="Nærhet"><Lbl sub="ESTIMAT FOR PGA TOUR">Nærhet til hull</Lbl><Pp.Num>{d1(r.prox[0]) + " m"}</Pp.Num></Row>}
      <Row tpl="minmax(0,1fr) auto" label="Datagrunnlag"><Lbl sub={cmp}>Datagrunnlag</Lbl><QQ.NeedTag n={n} area={r.g} /></Row>
    </div>
  </Sec>;
}

function SkillMap({ state, go }) {
  const QQ = Q();
  const Pp = P(), { PageHeader, Button } = ns(), { mob, cw } = Pp.useW(), Qd = Q();
  const [pga, setPga] = React.useState(false), rows = rowsOf(), n = state === "tom" ? 0 : S().n.rounds;
  const val = (r) => pga ? r.pga : r.c;
  const real = rows.filter((r) => val(r) != null), minSg = real.length ? real.reduce((a, b) => val(b) < val(a) ? b : a).id : null;
  const maxSg = real.length ? real.reduce((a, b) => val(b) > val(a) ? b : a) : null;
  const [sel, setSel] = React.useState(minSg);
  const cur = rows.find((r) => r.id === sel) || rows.find((r) => r.id === minSg);
  const wide = cw >= 1000;
  return <Pp.Page max={1200}>
    <PageHeader kicker="Stats · Strokes Gained · Kart" title="Skill map" actions={<Button variant="secondary" icon="list" onClick={() => go("PH-16")}>Se som liste</Button>} />
    <Pp.Gate state={state} loading="Regner ut Skill map …" error={{ title: "Skill map kunne ikke lastes", text: "Rundene dine er lagret. Tallene hentes på nytt når du prøver igjen.", code: "FEIL 503 · SKILL-MAP · " + window.PHQ_DATA.date.now }}>
      {state === "tom" ? <Qd.NotEnough n={0} go={go} what="Skill map" /> : <Pp.Stack gap={mob ? 16 : 24}>
        <Qd.Compare pga={pga} setPga={setPga} />
        <Pp.Cols tpl={wide ? "minmax(0,420px) minmax(0,1fr)" : "minmax(0,1fr)"} gap={wide ? 24 : 16}>
          <Pp.Stack gap={8}>
            <HoleMap rows={rows} val={val} sel={cur && cur.id} onSel={setSel} minSg={minSg} />
            <Pp.Meta>SG PER RUNDE MED FORTEGN · MARKERT FIRKANT = FOKUS · STIPLET RAMME = MANGLER TALL · {pga ? S().cmp.pga.src : S().cmp.c.src}</Pp.Meta>
          </Pp.Stack>
          <Pp.Stack>
            {cur && <Detail r={cur} pga={pga} val={val} n={n} />}
            <Qd.Sec k="Sterkest og fokus" meta={S().sgSrc} label="Sterkest og fokus" gap={4}>
              <div role="list">
                <Qd.Row first label="Sterkest"><Qd.Lbl sub="HØYEST SG">Sterkest</Qd.Lbl><Pp.Num s={{ font: "600 14px/1.3 var(--font-mono)", textAlign: "right" }}>{maxSg ? long(maxSg) + " " + Pp.sg(val(maxSg)) : "—"}</Pp.Num></Qd.Row>
                <Qd.Row label="Fokus"><Qd.Lbl sub="FLEST TAPTE SLAG">Fokus</Qd.Lbl><Pp.Num s={{ font: "600 14px/1.3 var(--font-mono)", textAlign: "right" }}>{minSg ? long(rows.find((r) => r.id === minSg)) + " " + Pp.sg(val(rows.find((r) => r.id === minSg))) : "—"}</Pp.Num></Qd.Row>
              </div>
            </Qd.Sec>
          </Pp.Stack>
        </Pp.Cols>
        <Qd.Sec k="Alle områder" meta="TABELLALTERNATIV TIL KARTET" label="Alle områder" gap={4}>
          <div role="list">{rows.map((r, i) => <div key={r.id} role="listitem" aria-label={long(r) + " " + Pp.sg(val(r))}>
            <button type="button" onClick={() => setSel(r.id)} aria-pressed={cur && cur.id === r.id} style={{ background: "none", border: 0, margin: 0, font: "inherit", color: "inherit", textAlign: "left", boxSizing: "border-box", width: "100%", cursor: "pointer", display: "grid", gridTemplateColumns: "minmax(0,1.1fr) minmax(56px,1fr) auto", gap: 12, alignItems: "center", minHeight: 52, padding: "6px 0 6px " + (cur && cur.id === r.id ? 10 : 0) + "px", borderTop: i ? "1px solid var(--border-hairline)" : "none", boxShadow: cur && cur.id === r.id ? "inset 2px 0 0 var(--text-primary)" : "none", minWidth: 0 }}>
              <Qd.Lbl sub={GROUP[r.g].toUpperCase() + " · " + (r.n == null ? "—" : r.n) + " SLAG"}>{long(r)}</Qd.Lbl><Qd.SGBar v={val(r)} /><Pp.Num s={{ font: "600 14px/1 var(--font-mono)", minWidth: 44, textAlign: "right" }}>{Pp.sg(val(r))}</Pp.Num>
            </button></div>)}</div>
        </Qd.Sec>
      </Pp.Stack>}
    </Pp.Gate>
  </Pp.Page>;
}
window.PHQ_SCREENS["PH-16b"] = { id: "PH-16b", parent: "PH-16", name: "Stats › Strokes Gained · Skill map", tab: "analyse", route: "/portal/analysere/skill-map", Component: SkillMap };
})();
