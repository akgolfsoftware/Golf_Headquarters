(() => {
const stepBtn = { width: 56, height: 56, flex: "none", borderRadius: 8, border: "1px solid var(--border-strong)", background: "var(--surface-card)", color: "var(--text-primary)", font: "600 17px/1 var(--font-mono)", cursor: "pointer" };
function Big({ value, unit, onChange, steps, label }) {
  return <div role="group" aria-label={label} style={{ display: "flex", alignItems: "center", gap: 6, minWidth: 0 }}>
    {steps.filter((s) => s < 0).map((s) => <button key={s} type="button" aria-label={label + " " + s} onClick={() => onChange(Math.max(0, value + s))} style={stepBtn}>{"−" + Math.abs(s)}</button>)}
    <div style={{ flex: 1, textAlign: "center", minWidth: 0 }}><span style={{ font: "600 40px/1 var(--font-mono)", color: "var(--text-primary)", fontVariantNumeric: "tabular-nums" }}>{value}</span><span style={{ font: "var(--type-num)", color: "var(--text-muted)" }}> {unit}</span></div>
    {steps.filter((s) => s > 0).map((s) => <button key={s} type="button" aria-label={label + " +" + s} onClick={() => onChange(value + s)} style={stepBtn}>{"+" + s}</button>)}
  </div>;
}
function PH08({ state, go }) {
  const { Button, StatusPill, Segmented, Dialog, EmptyState } = window.PHQ.ns();
  const P = window.PHQ, C = window.PHQ_DATA.course, empty = state === "tom";
  const [scores, setScores] = React.useState(empty ? [] : C.live);
  const [hole, setHole] = React.useState(empty ? 0 : C.live.length);
  const [shots, setShots] = React.useState(empty ? [] : [{ lie: "Tee", m: C.len[C.live.length] }]);
  const [mode, setMode] = React.useState("Slag"), [lie, setLie] = React.useState("Fairway"), [m, setM] = React.useState(empty ? C.len[0] : 21), [ft, setFt] = React.useState(12);
  const [end, setEnd] = React.useState(false);
  const played = scores.filter((s) => s != null).length;
  const br = scores.reduce((a, b) => a + (b || 0), 0), par = C.par.reduce((a, p, i) => a + (scores[i] != null ? p : 0), 0);
  const front = [0,1,2,3,4,5,6,7,8].every((i) => scores[i] != null), back = [9,10,11,12,13,14,15,16,17].every((i) => scores[i] != null), canSave = played === 18 || (played === 9 && (front || back));
  const reg = () => { setShots((x) => [...x, mode === "Slag" ? { lie, m } : { lie: "Putt", ft }]); if (mode === "Slag") setM((v) => Math.max(0, Math.round(v * 0.2))); };
  const finish = () => { const n = shots.length; if (!n) return; const nx = [...scores]; nx[hole] = n; setScores(nx); P.toast("Hull " + (hole + 1) + " · " + n + " slag", "BRUTTO " + nx.reduce((a, b) => a + (b || 0), 0) + " · LAGRET"); const h = Math.min(17, hole + 1); setHole(h); setShots([]); setMode("Slag"); setLie("Tee"); setM(C.len[h]); };
  const top = <><StatusPill tone="live">Runde</StatusPill><P.Meta>{C.name.toUpperCase()} · {C.tee.toUpperCase()}</P.Meta><span style={{ flex: 1 }}></span><Button variant="ghost" onClick={() => setEnd(true)} style={{ height: 56 }}>Avslutt</Button></>;
  const action = state === "data" || state === "tom" ? <>
    <Button variant="secondary" fullWidth disabled={!shots.length} onClick={finish} style={{ height: 56 }}>Fullfør hull {hole + 1} · {shots.length || "—"} slag</Button>
    <Button size="xl" fullWidth icon="plus" onClick={reg} style={{ height: 72 }}>Registrer slag</Button>
  </> : null;
  return <P.Focus top={top} action={action}>
    <P.Gate state={state} loading="Henter scorekortet …" error={{ title: "Scorekortet kunne ikke synkroniseres", text: "Slagene er lagret på telefonen. Du kan spille videre og registrere som vanlig.", code: "FRAKOBLET · HULL 7 · 26 SLAG LOKALT" }}>
      <div role="group" aria-label="Hull" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(56px,1fr))", gap: 4 }}>
        {C.par.map((p, i) => { const on = i === hole, sc = scores[i]; return <button key={i} type="button" aria-current={on ? "step" : undefined} aria-label={"Hull " + (i + 1)} onClick={() => { setHole(i); setShots([]); setLie("Tee"); setM(C.len[i]); }} style={{ height: 56, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--primary)" : "var(--surface-card)", color: on ? "var(--text-on-primary)" : "var(--text-primary)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, cursor: "pointer", minWidth: 0 }}>
          <span style={{ font: "500 10px/1 var(--font-mono)", opacity: .7 }}>{i + 1}</span><span style={{ font: "600 15px/1 var(--font-mono)" }}>{sc != null ? sc : "—"}</span></button>; })}
      </div>
      <div className="pa-card" style={{ padding: 16, gap: 6 }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-title-m)", color: "var(--text-primary)", flex: 1 }}>Hull {hole + 1}</span><P.Meta s={{ font: "var(--type-num-s)" }}>PAR {C.par[hole]} · {C.len[hole]} M</P.Meta></div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", flex: "1 1 160px" }}>Brutto score etter {played} hull</span><span style={{ font: "var(--type-metric)", color: "var(--text-primary)" }}>{played ? br : "—"}</span><P.Num s={{ color: "var(--text-muted)", font: "var(--type-num-s)" }}>{played ? "slag (" + P.toPar(br - par) + ")" : "slag"}</P.Num></div>
      </div>
      {empty && !shots.length && <EmptyState icon="flag" title="Ingen slag registrert" text="Velg leie og meter til flagget for utslaget på hull 1, og trykk Registrer slag." />}
      <Segmented size="lg" fullWidth options={["Slag", "Putt"]} value={mode} onChange={setMode} />
      {mode === "Slag" ? <>
        <div><div className="pa-field__label" style={{ marginBottom: 8, color: "var(--text-secondary)" }}>Leie</div><Segmented size="lg" fullWidth options={["Tee", "Fairway", "Rough", "Sand"]} value={lie} onChange={setLie} /></div>
        <div><div className="pa-field__label" style={{ marginBottom: 8, color: "var(--text-secondary)" }}>Meter til flagget</div><Big label="Meter" value={m} unit="m" onChange={setM} steps={[-10, -1, 1, 10]} /></div>
      </> : <div><div className="pa-field__label" style={{ marginBottom: 8, color: "var(--text-secondary)" }}>Puttavstand</div><Big label="Fot" value={ft} unit="ft" onChange={setFt} steps={[-5, -1, 1, 5]} /></div>}
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", minHeight: 24 }}>{shots.length ? shots.map((s, i) => <span key={i} className="pa-status" style={{ font: "500 12px/1 var(--font-mono)" }}>{i + 1} · {s.lie === "Putt" ? "PUTT " + s.ft + " FT" : s.lie.toUpperCase() + " " + s.m + " M"}</span>) : <P.Meta>INGEN SLAG PÅ DETTE HULLET</P.Meta>}</div>
    </P.Gate>
    <Dialog open={end} title="Avslutte runden?" onClose={() => setEnd(false)} footer={<><Button variant="secondary" onClick={() => setEnd(false)}>Fortsett</Button><Button disabled={!canSave} onClick={() => { P.toast("Runden er lagret · " + played + " hull", "BRUTTO " + br + " SLAG (" + P.toPar(br - par) + ")"); go("PH-09"); }}>{canSave ? "Lagre " + played + " hull" : "Lagre runde"}</Button></>}>{played} av 18 hull er registrert. Brutto score {played ? br + " slag (" + P.toPar(br - par) + ")" : "—"}. {canSave ? "Til par er regnet av par på de " + played + " spilte hullene." : "En runde kan lagres med 9 eller 18 hull. Spill " + (played < 9 ? 9 - played : 18 - played) + " hull til, eller fortsett senere."}</Dialog>
  </P.Focus>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-08"] = { id: "PH-08", name: "Runde live", tab: "analyse", night: true, route: "/portal/runde/live", Component: PH08 };
})();
