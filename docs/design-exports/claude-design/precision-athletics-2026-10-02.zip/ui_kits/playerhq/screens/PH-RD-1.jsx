(() => {
/* Runde-registrering for SG · PH-RD-01 til 05. Felles hjelpere i window.PHRD. */
const R = () => window.RD_DATA, P = () => window.PHQ;
const sg = (v) => v == null ? "—" : (v > 0.04 ? "+" : v < -0.04 ? "−" : "±") + Math.abs(v).toFixed(1).replace(".", ",");
const toPar = (d) => d > 0 ? "+" + d : d < 0 ? "−" + Math.abs(d) : "±0";
const ft = (m) => m == null ? "—" : Math.round(m * 3.281) + " ft";
const dist = (lie, m) => lie === "GREEN" ? ft(m) : m == null ? "—" : Math.round(m) + " m";
const lieL = (k) => (R().lies.find((l) => l[0] === k) || [k, k])[1];
const reg = (id, name, C, night, parent) => { window.PHQ_SCREENS[id] = { id, name, tab: "analyse", parent: parent || "PH-18", night: !!night, route: "/portal/runde", Component: C }; };
const Row = ({ children, gap = 8 }) => <div style={{ display: "flex", gap, flexWrap: "wrap", alignItems: "center", minWidth: 0 }}>{children}</div>;
const Sec = ({ k, aside, children }) => <section className="pa-card" style={{ padding: 16, gap: 12, minWidth: 0 }}>{(k || aside) && <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "center" }}>{k && <h2 className="kicker" style={{ margin: 0 }}>{k}</h2>}{aside}</div>}{children}</section>;
const ERR = (id) => ({ title: "Runden kunne ikke hentes", text: "Det du har ført er lagret på telefonen og sendes når nettet er tilbake.", code: "FEIL 503 · RUNDE · " + id });

/* PH-RD-01 · Start runde: velg registreringsnivå */
function RD01({ state, go }) {
  const { PageHeader, Button, DataQualityBadge, EmptyState, Icon, InlineAlert } = P().ns();
  const { useW, Page, Gate, Meta } = P(), { mob, desk } = useW(), [sel, setSel] = React.useState("slag");
  const L = R().levels;
  return <Page max={1100}>
    <PageHeader kicker="Runde · Ny" title="Registrer runde" sub="Velg hvor mye du vil registrere. Du kan alltid legge til mer etterpå." />
    <Gate state={state} loading="Henter baner og kladder …" error={ERR("RD-01")}>
      {state === "tom" ? <EmptyState icon="flag" title="Ingen bane valgt ennå" text="Velg bane og dato først. Sist spilte bane foreslås øverst." action="Velg bane" actionIcon="map-pin" onAction={() => go("PH-RD-02")} /> : <>
      <InlineAlert tone="info" title="Kladd fra 20.09.2026">Fredrikstad GK, 11 av 18 hull ført. <button type="button" data-control-id="rd01-fortsett-kladd" onClick={() => { window.RD_LOKAL && window.RD_LOKAL.fortsett(); go("PH-RD-03") }} style={{ all: "unset", cursor: "pointer", textDecoration: "underline", display: "inline-flex", alignItems: "center", minHeight: 44, minWidth: 44 }}>Fortsett kladden</button></InlineAlert>
      <div role="radiogroup" aria-label="Registreringsnivå" style={{ display: "grid", gridTemplateColumns: desk ? "repeat(3,minmax(0,1fr))" : "minmax(0,1fr)", gap: 12 }}>{L.map((l) => { const on = sel === l.id;
        return <button key={l.id} type="button" role="radio" aria-checked={on} onClick={() => setSel(l.id)} style={{ all: "unset", cursor: "pointer", boxSizing: "border-box", display: "flex", flexDirection: "column", gap: 12, padding: 16, borderRadius: "var(--radius)", background: "var(--surface-card)", border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), boxShadow: on ? "inset 0 0 0 1px var(--border-ink)" : "none", minWidth: 0 }}>
          <span style={{ display: "flex", gap: 10, alignItems: "center" }}><Icon name={l.icon} size={20} /><span style={{ font: "var(--type-title-s)", color: "var(--text-primary)", flex: 1 }}>{l.t}</span></span>
          <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{l.s}</span>
          <span className="kicker">Hva får du ut av dette?</span>
          <ul style={{ margin: 0, paddingLeft: 18, display: "flex", flexDirection: "column", gap: 4, font: "var(--type-body-s)", color: "var(--text-primary)" }}>{l.gives.map((g) => <li key={g}>{g}</li>)}{l.not && <li style={{ color: "var(--text-muted)" }}>{l.not}</li>}</ul>
          <span style={{ marginTop: "auto" }}><DataQualityBadge level={l.id === "slag" ? "god" : l.id === "import" ? "manuell" : "tynn"} /> </span><Meta>{l.q.toUpperCase()}</Meta>
        </button>; })}</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: mob ? "stretch" : "flex-end" }}><Button variant="ghost" onClick={() => go("PH-18")}>Avbryt</Button><Button size="lg" iconRight="arrow-right" fullWidth={mob} onClick={() => go(sel === "import" ? "PH-RD-07" : sel === "rask" ? "PH-RD-06" : "PH-RD-02")}>{sel === "import" ? "Til import" : sel === "rask" ? "Til scorekort" : "Til oppsett"}</Button></div>
      </>}
    </Gate>
  </Page>;
}
reg("PH-RD-01", "Registrer runde · velg nivå", (p) => window.PHQ_RUND && window.WB3_RUND ? <window.WB3_RUND.RD01Pub go={p.go} /> : <><div data-control-id="rd-eksempel-merke" style={{ font: "600 13px/1.3 var(--font-sans)", marginBottom: 8 }}>EKSEMPELMODUS · ikke koblet til en planlagt runde (prototypens eksempeldata)</div><RD01 {...p} /></>);

/* PH-RD-02 · Oppsett */
function RD02({ state, go }) {
  const { PageHeader, Button, Select, FormField, TextInput, Segmented, InlineAlert, StatusPill, EmptyState, ConfirmDialog } = P().ns();
  const { useW, Page, Gate, Meta } = P(), { mob, desk } = useW(), C = R().course;
  const [man, setMan] = React.useState(false), [holes, setHoles] = React.useState("18"), [kind, setKind] = React.useState("Turnering"), [discard, setDiscard] = React.useState(false), [draft, setDraft] = React.useState(true);
  return <Page max={900}>
    <PageHeader kicker="Runde · Oppsett · Slag-for-slag" title="Oppsett" sub="Bane, dato og antall hull. Hull-lengde og par hentes fra banen." />
    <Gate state={state} loading="Henter baner …" error={ERR("RD-02")}>
      {state === "tom" ? (man && window.RD_LOKAL ? <window.RD_LOKAL.Manuell go={go} onCancel={() => setMan(false)} /> : <EmptyState icon="map-pin-off" title="Ingen baner registrert" text="Banen legges inn av klubben eller coach. Du kan registrere med par og lengde manuelt." action="Legg inn manuelt" actionIcon="plus" actionControlId="rd02-manuell-apne" onAction={() => setMan(true)} />) : <>
      {draft && <InlineAlert tone="warn" title="Du har en kladd fra 20.09.2026">Fredrikstad GK · 11 av 18 hull. <span style={{ display: "inline-flex", gap: 8, flexWrap: "wrap", marginTop: 6 }}><Button size="sm" variant="secondary" data-control-id="rd02-gjenopprett-kladd" onClick={() => { window.RD_LOKAL && window.RD_LOKAL.fortsett(); go("PH-RD-03") }}>Gjenopprett kladd</Button><Button size="sm" variant="ghost" onClick={() => setDiscard(true)}>Forkast kladd</Button></span></InlineAlert>}
      <Sec k="Runde" aside={<StatusPill tone="ok">Lagres på telefonen</StatusPill>}>
        <div style={{ display: "grid", gridTemplateColumns: desk ? "repeat(2,minmax(0,1fr))" : "minmax(0,1fr)", gap: 12 }}>
          <Select label="Bane" options={[C.name + " · sist spilt", "Borregaard GK", "Hvaler GK", "Onsøy GK"]} /><FormField label="Dato"><TextInput mono defaultValue="26.09.2026" /></FormField>
          <Select label="Tee / lengdemal" options={[C.tee, "Rød · 4 912 m", "Hvit · 6 102 m"]} /><Select label="Start på hull" options={["1", "10"]} />
        </div>
        <Row><span style={{ flex: "1 1 200px" }}><FormField label="Rundetype"><Segmented options={["Turnering", "Trening"]} value={kind} onChange={setKind} fullWidth /></FormField></span><span style={{ flex: "1 1 200px" }}><FormField label="Antall hull"><Segmented options={["9", "18"]} value={holes} onChange={setHoles} fullWidth /></FormField></span></Row>
        <Meta>PAR {holes === "9" ? 36 : C.par} · {holes === "9" ? "2 886" : "5 804"} M · HULL-LENGDE BRUKES SOM STARTAVSTAND FOR SLAG 1</Meta>
      </Sec>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: mob ? "stretch" : "flex-end" }}><Button variant="ghost" onClick={() => go("PH-RD-01")}>Tilbake</Button><Button size="lg" icon="play" fullWidth={mob} data-control-id="rd02-start-runde" onClick={() => { window.RD_LOKAL && window.RD_LOKAL.fortsett(); go("PH-RD-03") }}>Start runde</Button></div>
      </>}
    </Gate>
    <ConfirmDialog open={discard} kind="destructive" title="Forkaste kladden?" confirmLabel="Forkast" consequences={["11 hull med score og 38 slag slettes fra telefonen.", "Kan ikke angres."]} onCancel={() => setDiscard(false)} onConfirm={() => { setDiscard(false); setDraft(false); }} />
  </Page>;
}
reg("PH-RD-02", "Registrer runde · oppsett", (p) => window.PHQ_RUND && window.WB3_RUND ? <window.WB3_RUND.RD02Pub go={p.go} /> : <><div data-control-id="rd-eksempel-merke" style={{ font: "600 13px/1.3 var(--font-sans)", marginBottom: 8 }}>EKSEMPELMODUS · ikke koblet til en planlagt runde (prototypens eksempeldata)</div><RD02 {...p} /></>, false, "PH-RD-01");

/* PH-RD-03 · Live runde ute (natt): rask stepper + inngang til slag-for-slag */
function RD03({ state, go }) {
  const { Button, IconButton, StatusPill, EmptyState, DataQualityBadge, InlineAlert } = P().ns();
  const { useW, Focus, Gate, Meta } = P(), L = R().live, C = R().course, { mob } = useW();
  const [scores, setScores] = React.useState(L.scores), [h, setH] = React.useState(L.hole - 1);
  const [par, len] = C.holes[h], v = scores[h] ?? par, played = scores.filter((x) => x != null).length;
  const tot = scores.reduce((a, x) => a + (x || 0), 0), parSoFar = scores.reduce((a, x, i) => a + (x != null ? C.holes[i][0] : 0), 0);
  const slagDone = L.slagHoles.includes(h + 1);
  const big = { width: 88, height: 88, font: "600 40px/1 var(--font-mono)" };
  const set = (x) => setScores((l) => l.map((y, i) => i === h ? Math.max(1, x) : y));
  const top = <><StatusPill tone="live">Live</StatusPill><Meta>HULL {h + 1} · PAR {par} · {len} M</Meta><span style={{ flex: 1 }}></span><Meta>{played ? tot + " (" + toPar(tot - parSoFar) + ")" : "—"}</Meta></>;
  const action = state === "data" || state === "tom" ? <>
    <Button size="xl" fullWidth icon="route" variant="secondary" onClick={() => go("PH-RD-04")}>Slag-for-slag på hull {h + 1}</Button>
    <Button size="xl" fullWidth iconRight="arrow-right" onClick={() => { if (scores[h] == null) set(par); setH(Math.min(17, h + 1)); }}>Lagre {v} og neste hull</Button>
  </> : null;
  return <Focus top={top} action={action}>
    <Gate state={state} loading="Kobler til runden …" error={ERR("RD-03")}>
      {state === "tom" ? <EmptyState icon="flag" title="Hull 1 · ingen slag ennå" text="Før score med + og −, eller åpne slag-for-slag for å få beregnet SG." /> : <>
      <Meta>{L.saved}</Meta>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 16, padding: "12px 0" }}>
        <IconButton icon="minus" label="Ett slag mindre" variant="secondary" style={big} onClick={() => set(v - 1)} />
        <div style={{ textAlign: "center", minWidth: 96 }}><div style={{ font: "600 " + (mob ? 72 : 88) + "px/1 var(--font-mono)", color: "var(--text-primary)" }}>{v}</div><Meta>{toPar(v - par)} · BRUTTO</Meta></div>
        <IconButton icon="plus" label="Ett slag mer" variant="secondary" style={big} onClick={() => set(v + 1)} />
      </div>
      {slagDone ? <DataQualityBadge level="god" have={L.slagHoles.length} need={18} unit="hull med slag" /> : <InlineAlert tone="info" title="Bare score på dette hullet">SG kan ikke beregnes for hull {h + 1} uten slag-for-slag. Du kan legge til slag etterpå.</InlineAlert>}
      <div role="list" aria-label="Hulloversikt" style={{ display: "grid", gridTemplateColumns: "repeat(9,minmax(0,1fr))", gap: 4 }}>{C.holes.map(([p], i) => <button key={i} role="listitem" type="button" onClick={() => setH(i)} aria-current={i === h ? "true" : undefined} style={{ all: "unset", cursor: "pointer", height: 56, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 2, borderRadius: "var(--radius-inner)", border: "1px solid " + (i === h ? "var(--border-ink)" : "var(--border-hairline)"), background: "var(--surface-card)" }}><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{i + 1}</span><span style={{ font: "600 15px/1 var(--font-mono)", color: "var(--text-primary)" }}>{scores[i] ?? "—"}</span>{L.slagHoles.includes(i + 1) && <span aria-label="slag ført" style={{ width: 4, height: 4, borderRadius: 999, background: "var(--text-primary)" }}></span>}</button>)}</div>
      <Button variant="ghost" icon="chart-no-axes-column" onClick={() => go("PH-RD-05")} style={{ height: 56 }}>SG hittil · {L.slagHoles.length} hull</Button>
      <Button variant="ghost" icon="check" onClick={() => go("PH-RD-08")} style={{ height: 56 }}>Avslutt runden</Button>
      </>}
    </Gate>
  </Focus>;
}
reg("PH-RD-03", "Live runde", (p) => window.PHQ_RUND && window.WB3_RUND ? <window.WB3_RUND.RD03Pub go={p.go} /> : <><>{window.RD_LOKAL && <window.RD_LOKAL.Strip />}</><div data-control-id="rd-eksempel-merke" style={{ font: "600 13px/1.3 var(--font-sans)", padding: "8px 16px" }}>EKSEMPELMODUS · ikke koblet til en planlagt runde</div><RD03 {...p} /></>, true, "PH-RD-02");

/* PH-RD-04 · Slag-for-slag-kjede (natt) */
function RD04({ state, go }) {
  const { Button, IconButton, StatusPill, EmptyState, ChoicePill, Stepper, Switch, InlineAlert, Sheet, Select, Segmented, FormField, TextInput } = P().ns();
  const { useW, Focus, Gate, Meta } = P(), D = R(), L = D.live, C = D.course, { mob } = useW(), hole = L.hole, [par, len] = C.holes[hole - 1];
  const [chain, setChain] = React.useState(L.chain), [lie, setLie] = React.useState("GREEN"), [d, setD] = React.useState(1.2), [pen, setPen] = React.useState(false), [more, setMore] = React.useState(false), [cat, setCat] = React.useState(null), [err, setErr] = React.useState(null);
  const [pb, setPb] = React.useState({ brk: null, slope: null, line: null, speed: null });
  const last = chain[chain.length - 1], start = last ? last.res : { lie: "TEE", dist: len }, n = chain.length + 1, onGreen = start.lie === "GREEN";
  const add = (holed) => { if (holed && pen) { setErr("Straffe kan ikke legges på slaget som går i hull."); return; }
    if (!holed && lie === "GREEN" && start.lie === "GREEN" && d > start.dist * 1.5) { setErr("Ny avstand er lengre enn startavstanden på green. Sjekk avstanden."); return; }
    setErr(null); setChain((l) => [...l, { n, lie: start.lie, dist: start.dist, res: holed ? { lie: "HOLE", dist: 0 } : { lie, dist: d }, pen, cat: onGreen ? null : cat, putt: onGreen ? pb : null }]); setPen(false); setCat(null); setPb({ brk: null, slope: null, line: null, speed: null }); if (holed) P().toast("Hull " + hole + " fullført", n + " SLAG · BRUTTO " + (n + chain.filter((x) => x.pen).length)); };
  const holed = last && last.res.lie === "HOLE";
  const top = <><IconButton icon="arrow-left" label="Tilbake til runden" variant="secondary" style={{ width: 56, height: 56 }} onClick={() => go("PH-RD-03")} /><div style={{ flex: 1, minWidth: 0 }}><div className="kicker">Hull {hole} · par {par} · {len} m</div><div style={{ font: "600 17px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>Slag {holed ? "—" : n}</div></div><StatusPill tone="live">Live</StatusPill></>;
  const action = state === "data" ? (holed ? <Button size="xl" fullWidth iconRight="arrow-right" onClick={() => go("PH-RD-03")}>Neste hull</Button> : <>
    <Button size="xl" fullWidth icon="flag" onClick={() => add(true)}>I hull</Button>
    <Button size="xl" fullWidth variant="secondary" iconRight="arrow-right" onClick={() => add(false)}>Lagre slag {n}</Button>
  </>) : null;
  return <Focus top={top} action={action}>
    <Gate state={state} loading="Henter slagene på hullet …" error={ERR("RD-04")}>
      {state === "tom" ? <EmptyState icon="route" title={"Slag 1 fra tee · " + len + " m"} text="Registrer hvor ballen landet og hvor langt det er igjen. Neste slag starter der." /> : <>
      <section style={{ display: "flex", flexDirection: "column", gap: 4, padding: 16, borderRadius: "var(--radius)", background: "var(--surface-card)", border: "1px solid var(--border-hairline)" }}>
        <span className="kicker">Slag {holed ? chain.length : n} starter fra</span>
        <span style={{ font: "600 28px/1.1 var(--font-mono)", color: "var(--text-primary)" }}>{lieL(start.lie)} · {dist(start.lie, start.dist)}</span>
        <Meta>AVLEDET FRA SLAG {n - 1 || "—"} · DU REGISTRERER BARE RESULTATET</Meta>
      </section>
      {err && <InlineAlert tone="warn" title="Kjeden stemmer ikke">{err}</InlineAlert>}
      {!holed && <>
        <div><span className="kicker">Hvor landet ballen?</span><div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(104px,1fr))", gap: 8, marginTop: 8 }}>{D.lies.filter((l) => l[0] !== "TEE").map(([k, l]) => <ChoicePill key={k} size="lg" selected={lie === k} onClick={() => setLie(k)} style={{ height: 56 }}>{l}</ChoicePill>)}</div></div>
        <Stepper label={lie === "GREEN" ? "Igjen til hull (fot)" : "Igjen til hull (meter)"} value={lie === "GREEN" ? Math.round(d * 3.281) : Math.round(d)} min={0} max={lie === "GREEN" ? 120 : 600} step={1} onChange={(x) => setD(lie === "GREEN" ? x / 3.281 : x)} unit={lie === "GREEN" ? "ft" : "m"} size="xl" className="pa-stepper--xl" />
        <div style={{ minHeight: 56, display: "flex", alignItems: "center" }}><Switch checked={pen} onChange={(e) => setPen(e.target.checked)} label="Straffe på dette slaget (vann eller OOB) · resultat er etter drop" /></div>
        {!onGreen && <div><span className="kicker">Slagets utfall</span><div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 8 }}>{D.endCats.map(([k, l]) => <ChoicePill key={k} selected={cat === k} onClick={() => setCat(k)} style={{ minHeight: 56 }}>{l}</ChoicePill>)}</div></div>}
        {onGreen && <section style={{ display: "flex", flexDirection: "column", gap: 10 }}><span className="kicker">Putt · {ft(start.dist)}</span>
          {[["brk", "Break", D.putt.brk], ["slope", "Helling", D.putt.slope], ["line", "Linje", D.putt.line], ["speed", "Fart", D.putt.speed]].map(([k, l, o]) => <div key={k}><Meta>{l.toUpperCase()}</Meta><div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 6 }}>{o.map((x) => <ChoicePill key={x} selected={pb[k] === x} onClick={() => setPb((p) => ({ ...p, [k]: x }))} style={{ minHeight: 56 }}>{x}</ChoicePill>)}</div></div>)}
          <Meta>LINJE ER IKKE RELEVANT NÅR PUTTEN GÅR I HULL</Meta></section>}
        <Button variant="ghost" icon="sliders-horizontal" onClick={() => setMore(true)} style={{ height: 56 }}>Mer: kølle, vind, mental, notat, sikte</Button>
      </>}
      <section aria-label="Slag på hullet" style={{ display: "flex", flexDirection: "column", gap: 0 }}><span className="kicker" style={{ paddingBottom: 6 }}>Slag på hull {hole}</span>{chain.map((s) => <div key={s.n} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 8, alignItems: "center", minHeight: 44, borderTop: "1px solid var(--border-hairline)" }}><span style={{ font: "600 13px/1 var(--font-mono)" }}>{s.n}</span><span style={{ font: "var(--type-body-s)", overflowWrap: "anywhere" }}>{lieL(s.lie)} {dist(s.lie, s.dist)} → {s.res.lie === "HOLE" ? "I hull" : lieL(s.res.lie) + " " + dist(s.res.lie, s.res.dist)}{s.pen ? " · +1 straff" : ""}</span><Meta>{s.club || ""}</Meta></div>)}
        {chain.length > 0 && <Button variant="ghost" icon="undo-2" onClick={() => setChain((l) => l.slice(0, -1))} style={{ height: 56, alignSelf: "flex-start" }}>Angre siste slag</Button>}</section>
      </>}
    </Gate>
    <Sheet open={more} onClose={() => setMore(false)} kicker={"Slag " + n + " · valgfritt"} title="Mer om slaget" footer={<Button size="xl" fullWidth onClick={() => setMore(false)}>Ferdig</Button>}>
      <Select label="Kølle" options={["—", "Driver", "3 Wood", "5 Iron", "7 Iron", "Pitching Wedge", "56°", "Putter"]} />
      <FormField label="Vind"><Segmented options={D.wind} value="Stille" onChange={() => {}} fullWidth size="lg" /></FormField>
      <Stepper label="Mental score (1–5)" value={3} min={1} max={5} onChange={() => {}} size="xl" className="pa-stepper--xl" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 12 }}><FormField label="Sikteavstand (m)" optional><TextInput mono inputMode="numeric" placeholder="—" /></FormField><FormField label="Flaggavstand (m)" optional><TextInput mono inputMode="numeric" placeholder="—" /></FormField></div>
      <FormField label="Notat" optional><TextInput placeholder="Kort" /></FormField>
      <Meta>GPS-POSISJON LAGRES AUTOMATISK NÅR TILGJENGELIG · BRUKES TIL KART, IKKE TIL SG</Meta>
    </Sheet>
  </Focus>;
}
reg("PH-RD-04", "Slag-for-slag", (p) => <>{window.RD_LOKAL && <window.RD_LOKAL.Strip />}<RD04 {...p} /></>, true, "PH-RD-03");

/* PH-RD-05 · SG hittil (natt) */
function RD05({ state, go }) {
  const { Button, IconButton, StatusPill, EmptyAnalysisState, DataQualityBadge, SourceBadge, InlineAlert } = P().ns();
  const { useW, Focus, Gate, Meta } = P(), S = R().sgSoFar;
  const top = <><IconButton icon="arrow-left" label="Tilbake til runden" variant="secondary" style={{ width: 56, height: 56 }} onClick={() => go("PH-RD-03")} /><div style={{ flex: 1 }}><div className="kicker">SG hittil</div><div style={{ font: "600 17px/1.2 var(--font-sans)" }}>Fredrikstad GK</div></div><StatusPill tone="live">Live</StatusPill></>;
  return <Focus top={top} action={state === "data" ? <Button size="xl" fullWidth icon="arrow-left" onClick={() => go("PH-RD-03")}>Tilbake til hull 5</Button> : null}>
    <Gate state={state} loading="Regner SG for fullførte hull …" error={ERR("RD-05")}>
      {state === "tom" ? <EmptyAnalysisState title="Ingen fullførte hull med slag" have={0} need={1} unit="hull" text="SG vises når første hull er ført slag for slag og ballen er i hull." action="Til slag-for-slag" actionIcon="route" onAction={() => go("PH-RD-04")} /> : <>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><DataQualityBadge level="tynn" have={S.holes} need={S.of} unit="hull" /><StatusPill>Estimat</StatusPill></div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}><span style={{ font: "600 56px/1 var(--font-mono)", color: "var(--text-primary)" }}>{sg(S.total)}</span><Meta>SG TOTALT · {S.holes} AV {S.of} HULL</Meta></div>
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>{S.cats.map(([k, l, v]) => <window.PHQA.SGBar key={k} label={k} sub={l} v={v} />)}</div>
      <Meta>NULL = BASELINE KATEGORI D · LIK SKALA OVER OG UNDER</Meta>
      <InlineAlert tone="info" title="Bare fullførte hull">Hull uten slag-for-slag telles ikke. Tallene regnes på nytt og lagres av serveren når runden lagres.</InlineAlert>
      <SourceBadge source={S.src} est />
      </>}
    </Gate>
  </Focus>;
}
reg("PH-RD-05", "SG hittil", (p) => window.PHQ_RD && window.PHQ_RD.kind === "selvstendig" && window.RD_LOKAL ? <window.RD_LOKAL.Runde screen="PH-RD-05" go={p.go} /> : <>{window.RD_LOKAL && <window.RD_LOKAL.Strip />}<RD05 {...p} /></>, true, "PH-RD-03");
window.PHRD = { sg, toPar, ft, dist, lieL, reg, Row, Sec, ERR };
})();
