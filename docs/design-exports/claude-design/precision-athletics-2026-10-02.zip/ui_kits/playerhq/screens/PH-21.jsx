(() => {
const TABS = [{ value: "msg", label: "Meldinger" }, { value: "q", label: "Spørsmål" }, { value: "fb", label: "Tilbakemelding" }, { value: "vid", label: "Videoer" }, { value: "plan", label: "Planer" }, { value: "ønske", label: "Ønsket økt" }];
function Bubble({ m }) {
  const me = m.from === "me";
  return <div style={{ display: "flex", flexDirection: "column", alignItems: me ? "flex-end" : "flex-start", gap: 4, minWidth: 0 }}>
    <div style={{ maxWidth: "min(520px, 88%)", padding: "10px 14px", borderRadius: 8, background: me ? "var(--primary)" : "var(--surface-card)", color: me ? "var(--text-on-primary)" : "var(--text-primary)", border: me ? "none" : "1px solid var(--border-hairline)", font: "var(--type-body)", textWrap: "pretty", overflowWrap: "anywhere" }}>{m.text}{m.attach && <div style={{ marginTop: 8, paddingTop: 8, borderTop: "1px solid " + (me ? "var(--graphite-600)" : "var(--border-hairline)"), font: "var(--type-meta)", letterSpacing: ".04em" }}>ØKT · {m.attach.toUpperCase()}</div>}</div>
    <window.PHQ.Meta>{me ? "DU" : "ANDERS"} · {m.t}</window.PHQ.Meta>
  </div>;
}
/* Lokal meldingskontekst (prototype): «Send» lagrer en syntetisk record lokalt med stabil idempotensnøkkel. Ingenting sendes. */
function Ctx({ P, go, txt }) {
  const { Button } = P.ns(), c = window.PH21_CTX, [vakt, setVakt] = React.useState(false), [er, setEr] = React.useState(null), [rec, setRec] = React.useState(null), [, tk] = React.useState(0);
  if (!c) return null;
  const okt = c.type === "okt", btn = { minHeight: 44, minWidth: 44 };
  const ns = (() => { try { return new URLSearchParams(location.search).get("ns") || "" } catch (e) { return "" } })(), KEY = "ak-proto-ph21-v1:" + ns;
  const h = (t) => { let x = 5381; for (const ch of t) x = ((x << 5) + x + ch.charCodeAt(0)) >>> 0; return x.toString(36) };
  const idem = () => [c.type || "tp", c.publicationId || "", c.publishedRev == null ? "" : c.publishedRev, c.sessionId || "", c.performerId || "", c.recipientCoachId || "", h(txt.trim())].join("|");
  const read = () => { try { return JSON.parse(localStorage.getItem(KEY) || "[]") } catch (e) { return [] } };
  const saved = () => read().find((r) => r.idem === idem());
  const lagre = () => { if (!txt.trim()) return { ok: false, error: "Skriv en melding først." }; try { const all = read(), k = idem(), ex = all.find((r) => r.idem === k); if (ex) return { ok: true, rec: ex }; const r = { messageId: "msg-" + h(k), idem: k, contextType: c.type, recipientCoachId: c.recipientCoachId || "", performerId: c.performerId || "", sessionId: c.sessionId || "", publicationId: c.publicationId || "", publishedRev: c.publishedRev == null ? null : c.publishedRev, planId: c.planId || "", text: txt.trim(), status: "lagret-lokalt", statusTekst: "Lagret lokalt – ikke sendt" }; all.push(r); localStorage.setItem(KEY, JSON.stringify(all)); const back = read().find((x) => x.idem === k); if (!back) throw new Error("les-tilbake"); return { ok: true, rec: back } } catch (e) { return { ok: false, error: "Meldingen ble ikke lagret lokalt. Teksten er beholdt. Prøv igjen." } } };
  const retur = () => { const lvl = c.returnLevel; window.PH21_CTX = null; if (lvl) window.WB_RET = { level: lvl }; go(c.returnTo) };
  const dirty = okt && !!txt.trim() && !saved(), tilbake = () => { if (dirty) setVakt(true); else retur() };
  const send = () => { const r = lagre(); if (!r.ok) { setEr(r.error); return false } setEr(null); setRec(r.rec); tk((x) => x + 1); return true };
  React.useLayoutEffect(() => { if (vakt) { const b = document.querySelector('[data-control-id="ph21-vakt-bli"]'); b && b.focus() } }, [vakt]);
  React.useLayoutEffect(() => { if (er) { const e = document.querySelector('[data-control-id="ph21-feil"]'); e && e.focus() } }, [er]);
  const lbl = c.returnLabel || "Tilbake til Workbench", cur = okt ? saved() || rec : null;
  return <div data-control-id="ph21-kontekst" data-context-type={c.type || "tp"} data-owner-id={c.ownerId} data-return-to={c.returnTo} data-session-id={c.sessionId || ""} data-publication-id={c.publicationId || ""} data-publication-rev={c.publishedRev == null ? "" : c.publishedRev} className="pa-card" style={{ padding: 12, gap: 8 }}>
    <span className="kicker">{okt ? "Spørsmål om valgt økt" : "Fra Workbench · be coach om teknisk plan"}</span>
    <P.Meta>TIL {String(c.coach || "").toUpperCase()} · FRA {String(c.spiller || "").toUpperCase()}{okt && c.sessionNavn ? " · ØKT " + c.sessionNavn.toUpperCase() : ""}{okt && c.publishedRev != null ? " · PUBLISERING " + c.publishedRev : ""}{okt ? "" : " · INGEN MELDING ER SENDT ENNÅ"}</P.Meta>
    {okt && cur && <span role="status" data-control-id="ph21-lokal-status" data-message-id={cur.messageId} style={{ font: "var(--type-body)" }}>{cur.statusTekst}. Meldingen er ikke sendt til coach.</span>}
    {er && <span role="alert" data-control-id="ph21-feil" tabIndex={-1} style={{ font: "600 14px/1.3 var(--font-sans)" }}>{er}</span>}
    {vakt && <div role="group" aria-label="Ulagret melding" data-control-id="ph21-vakt" style={{ display: "flex", flexDirection: "column", gap: 8 }}><span role="status" style={{ font: "var(--type-body)" }}>Meldingen er ikke lagret lokalt. Hva vil du gjøre?</span><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button data-control-id="ph21-vakt-bli" onClick={() => { const i = document.querySelector('[data-control-id="ph21-melding"] input'); i && i.focus(); setVakt(false) }} style={btn}>Bli her</Button><Button variant="secondary" data-control-id="ph21-vakt-forkast" onClick={retur} style={btn}>Forkast</Button><Button variant="secondary" data-control-id="ph21-vakt-lagre" onClick={() => { if (send()) retur() }} style={btn}>{er ? "Prøv igjen · " : ""}Lagre lokalt og gå videre</Button></div></div>}
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
      {okt && <Button icon="send" data-control-id="ph21-send-lokalt" disabled={!txt.trim()} onClick={send} style={btn}>{er ? "Prøv igjen · " : ""}Send (lagres lokalt)</Button>}
      {okt && <Button variant="ghost" data-control-id="ph21-utkast-avbryt" onClick={tilbake} style={btn}>Avbryt</Button>}
      <Button variant="secondary" data-control-id="ph21-tilbake" onClick={tilbake} style={btn}>{lbl}</Button>
    </div></div>;
}
function PH21({ state, go }) {
  const { PageHeader, Button, Avatar, EmptyState, FormField, TextInput, Select, StatusPill, ChoicePill, Segmented } = window.PHQ.ns();
  const P = window.PHQ, M = window.PHQ_ME, { mob, desk } = P.useW(), empty = state === "tom";
  const [tab, setTab] = React.useState("msg"), [thread, setThread] = React.useState(empty ? [] : M.thread), [txt, setTxt] = React.useState((window.PH21_CTX && window.PH21_CTX.text) || "");
  const [qs, setQs] = React.useState(empty ? [] : M.questions), [qt, setQt] = React.useState("");
  const [fbS, setFbS] = React.useState(M.recentSessions[0]), [fbR, setFbR] = React.useState(null), [fbT, setFbT] = React.useState(""), [fbs, setFbs] = React.useState(empty ? [] : M.feedback);
  const [plans, setPlans] = React.useState(empty ? [] : M.plans);
  const [wDay, setWDay] = React.useState("Tir 29.09"), [wArea, setWArea] = React.useState("Innspill"), [wTxt, setWTxt] = React.useState(""), [wSent, setWSent] = React.useState(false);
  const send = () => { if (window.PH21_CTX && window.PH21_CTX.type === "okt") return; if (!txt.trim()) return; setThread((t) => [...t, { id: "n" + Date.now(), from: "me", t: "LØR 26.09 · 08:14", text: txt.trim() }]); setTxt(""); P.toast("Meldingen er sendt", "ANDERS SVARER VANLIGVIS SAMME DAG"); };
  let body;
  if (tab === "msg") body = <div className="pa-card" style={{ padding: 0, overflow: "hidden" }}>
    <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 16, minHeight: 240 }}>{thread.length ? thread.map((m) => <Bubble key={m.id} m={m} />) : <EmptyState icon="message-square" title="Ingen meldinger ennå" text="Skriv til Anders om plan, økter eller turneringer. Svar kommer her." />}</div>
    <div style={{ padding: 12, borderTop: "1px solid var(--border-hairline)", display: "flex", gap: 8, alignItems: "flex-end" }}><div data-control-id="ph21-melding" style={{ flex: 1, minWidth: 0 }}><TextInput aria-label="Melding til Anders" value={txt} onChange={(e) => setTxt(e.target.value)} placeholder="Skriv til Anders" onKeyDown={(e) => { if (e.key === "Enter") send(); }} /></div><Button icon="send" disabled={!txt.trim() || !!(window.PH21_CTX && window.PH21_CTX.type === "okt")} onClick={send}>Send</Button></div>
  </div>;
  if (tab === "q") body = <P.Cols tpl={desk ? "minmax(0,1fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
    <div className="pa-card" style={{ padding: 16, gap: 12 }}><span className="kicker">Still et spørsmål</span><FormField label="Spørsmål" hint="Ett spørsmål om gangen. Anders svarer skriftlig eller i neste time."><TextInput value={qt} onChange={(e) => setQt(e.target.value)} placeholder="Hvordan varmer jeg opp før tidlig start?" /></FormField><div><Button icon="send" disabled={!qt.trim()} onClick={() => { setQs((q) => [{ id: "q" + Date.now(), t: qt.trim(), date: "26.09.2026", status: "Venter på svar", answer: null }, ...q]); setQt(""); P.toast("Spørsmålet er sendt", "STATUS · VENTER PÅ SVAR"); }}>Send spørsmål</Button></div></div>
    <div className="pa-card" style={{ padding: "12px 16px" }}><span className="kicker" style={{ paddingBottom: 4 }}>Dine spørsmål</span>{qs.length ? qs.map((q, i) => <div key={q.id} style={{ display: "flex", flexDirection: "column", gap: 6, padding: "12px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "baseline" }}><span style={{ font: "500 14px/1.35 var(--font-sans)", color: "var(--text-primary)", flex: "1 1 200px" }}>{q.t}</span><StatusPill tone={q.status === "Besvart" ? "ok" : "neutral"}>{q.status}</StatusPill></div>{q.answer && <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{q.answer}</p>}<P.Meta>{q.date}</P.Meta></div>) : <p style={{ margin: "4px 0 8px", font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen spørsmål ennå.</p>}</div>
  </P.Cols>;
  if (tab === "fb") body = <P.Cols tpl={desk ? "minmax(0,1fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
    <div className="pa-card" style={{ padding: 16, gap: 16 }}><span className="kicker">Tilbakemelding på økt</span>
      <Select label="Økt" value={fbS} onChange={(e) => setFbS(e.target.value)} options={M.recentSessions} />
      <FormField label="Hvordan gikk økta?" required><div style={{ display: "grid", gridTemplateColumns: "repeat(5,minmax(0,1fr))", gap: 6 }}>{["Tung", "Slapp", "Ok", "God", "Topp"].map((x, i) => <ChoicePill key={x} selected={fbR === i + 1} onClick={() => setFbR(i + 1)} style={{ minWidth: 0, padding: 0 }}>{i + 1}</ChoicePill>)}</div></FormField>
      <FormField label="Kommentar" optional><TextInput value={fbT} onChange={(e) => setFbT(e.target.value)} placeholder="Hva satt, hva satt ikke" /></FormField>
      <div><Button icon="send" disabled={!fbR} onClick={() => { setFbs((f) => [{ id: "f" + Date.now(), session: fbS, from: "me", rating: fbR, text: fbT || "—", t: "26.09 · 08:14" }, ...f]); setFbR(null); setFbT(""); P.toast("Tilbakemeldingen er sendt", fbS.toUpperCase()); }}>Send tilbakemelding</Button></div>
    </div>
    <div className="pa-card" style={{ padding: "12px 16px" }}><span className="kicker" style={{ paddingBottom: 4 }}>Tidligere</span>{fbs.length ? fbs.map((f, i) => <div key={f.id} style={{ display: "flex", flexDirection: "column", gap: 4, padding: "12px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{f.session}</span><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{f.text}</span><P.Meta>{f.from === "me" ? "DU · DAGSFORM " + f.rating + " / 5" : "ANDERS"} · {f.t}</P.Meta></div>) : <p style={{ margin: "4px 0 8px", font: "var(--type-body-s)", color: "var(--text-secondary)" }}>—</p>}</div>
  </P.Cols>;
  if (tab === "vid") body = empty ? <EmptyState icon="video" title="Ingen videoer fra Anders" text="Videoer fra timene dine dukker opp her." /> : <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,260px),1fr))", gap: 12 }}>{M.videos.map((v) => <button key={v.id} type="button" onClick={() => P.toast("Spiller av", v.title.toUpperCase() + " · " + v.len)} className="pa-card pa-card--interactive" style={{ padding: 0, overflow: "hidden", textAlign: "left", font: "inherit", cursor: "pointer" }}>
    <div style={{ position: "relative", aspectRatio: "16 / 9", backgroundImage: "url(" + v.img + ")", backgroundSize: "cover", backgroundPosition: "center" }}><span style={{ position: "absolute", right: 8, bottom: 8, padding: "3px 6px", borderRadius: 4, background: "var(--graphite-900)", color: "var(--sand-100)", font: "500 11px/1 var(--font-mono)" }}>{v.len}</span></div>
    <div style={{ padding: 12, display: "flex", flexDirection: "column", gap: 4 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{v.title}</span><P.Meta>ANDERS · {v.date}{v.seen ? " · SETT" : " · NY"}</P.Meta></div>
  </button>)}</div>;
  if (tab === "plan") body = plans.length ? <P.Stack>{plans.map((p) => <div key={p.id} className="pa-card" style={{ padding: 16, gap: 12 }}>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}><span style={{ font: "var(--type-title-s)", color: "var(--text-primary)", flex: "1 1 200px" }}>{p.title}</span><StatusPill tone={p.status === "Godtatt" ? "ok" : p.status === "Avvist" ? "warn" : "info"}>{p.status}</StatusPill></div>
    <P.Meta>{p.sessions} ØKTER · {p.hours.toUpperCase()} · SENDT {p.sent}</P.Meta>
    {p.status === "Venter på spiller" && <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button icon="check" onClick={() => { setPlans((l) => l.map((x) => x.id === p.id ? { ...x, status: "Godtatt" } : x)); P.toast("Planen er godtatt", p.title.toUpperCase() + " · AKTIV FRA MANDAG"); }}>Godta plan</Button><Button variant="secondary" onClick={() => go("PH-10")}>Se i Plan</Button><Button variant="ghost" onClick={() => { setPlans((l) => l.map((x) => x.id === p.id ? { ...x, status: "Avvist" } : x)); P.toast("Planen er avvist", "ANDERS FÅR BESKJED"); }}>Avvis</Button></div>}
  </div>)}</P.Stack> : <EmptyState icon="calendar-range" title="Ingen planer fra Anders" text="Når Anders sender en ukeplan, godtar eller avviser du den her." />;
  if (tab === "ønske") body = <div className="pa-card" style={{ padding: 16, gap: 16, maxWidth: 640 }}><span className="kicker">Ønsket økt</span>
    <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Be om en økt eller et tema. Anders legger den inn i planen hvis det passer.</p>
    <FormField label="Dag"><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{["Man 28.09", "Tir 29.09", "Ons 30.09", "Tor 01.10"].map((d) => <ChoicePill key={d} selected={wDay === d} onClick={() => setWDay(d)}>{d}</ChoicePill>)}</div></FormField>
    <FormField label="Område"><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{["Utslag", "Innspill", "Nærspill", "Putting", "Banespill"].map((a) => <ChoicePill key={a} selected={wArea === a} onClick={() => setWArea(a)}>{a}</ChoicePill>)}</div></FormField>
    <FormField label="Hva vil du jobbe med?" required><TextInput value={wTxt} onChange={(e) => setWTxt(e.target.value)} placeholder="Lengdekontroll 50–70 m før klubbmesterskapet" /></FormField>
    {wSent ? <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><StatusPill tone="info">Sendt</StatusPill><P.Meta>{wDay.toUpperCase()} · {wArea.toUpperCase()} · VENTER PÅ ANDERS</P.Meta></div> : <div><Button icon="send" disabled={!wTxt.trim()} onClick={() => { setWSent(true); P.toast("Ønsket er sendt til Anders", wDay.toUpperCase() + " · " + wArea.toUpperCase()); }}>Send ønske</Button></div>}
  </div>;
  return <P.Page max={1200}>
    <PageHeader kicker="Innboks · Anders Kristiansen" title="Innboks" sub="Hovedcoach · Fredrikstad GK. Meldinger, spørsmål, videoer og planer samlet." actions={<Button variant="secondary" icon="sparkles" onClick={() => go("PH-22")}>Spør Caddie</Button>} />
    <P.Gate state={state} loading="Henter samtalen med Anders …" error={{ title: "Meldingene kunne ikke hentes", text: "Det du skriver lagres og sendes når forbindelsen er tilbake.", code: "FEIL 503 · MELDINGER" }}>
      {window.PH21_CTX && <Ctx P={P} go={go} txt={txt} />}
      <window.PHQA.Tabs value={tab} onChange={setTab} options={TABS.map((t) => ({ ...t, count: t.value === "plan" && !empty ? plans.filter((p) => p.status === "Venter på spiller").length || undefined : t.value === "vid" && !empty ? M.videos.filter((v) => !v.seen).length || undefined : undefined }))} />
      {body}
    </P.Gate>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-21"] = { id: "PH-21", parent: "PH-01", name: "Innboks", tab: "meg", route: "/portal/coach", Component: PH21 };
})();
