/* PH-24D Meg › Utfordringer (liste, detalj, ny) — nattkjøring 29.09.2026.
   Regler (beslutninger.md §Utfordringer skal leve, Anders 22.09): deltakere velges fra venner og gruppa, aldri delt lenke, varsel i appen.
   Scoren har retning (høyest eller lavest vinner), låst av øvelsen når den er valgt. «Opprett utfordring» er rust. «Avslutt utfordring» er grafitt i kort med rustkant,
   bekreftknappen i dialogen er rust. Avsluttet heter «Avsluttet», ikke «Fullført». Manglende plassering vises som «—». Utfordringer teller ikke som trening.
   Oppdiktede data (Tobias Lindvik og oppdiktede venner). Ikke nattflate. */
(() => {
const ME = "Tobias Lindvik";
const OVELSER = [["Putting 3 fot · 20 putter", "hoy"], ["Chip 10 m · innenfor 1 m", "hoy"], ["Putting 9 hull · færrest putter", "lav"]];
const VENNER = ["Mats Berg", "Ida Solheim", "Jonas Dahl", "Sofie Aas", "Emil Vik", "Nora Lund"];
const GRUPPE = ["Sander Roll", "Kaja Moen", "Henrik Foss"];
const UTF = [
  { id: "u1", name: "Putting 3 fot · 20 putter", ovelse: "Putting 3 fot · 20 putter", dir: "hoy", eier: ME, start: "21.09.2026", slutt: "30.09.2026", st: "ACTIVE", mode: "eier", desc: "Tjue putter fra tre fot. Flest i hull vinner. Registrer beste økt.",
    del: [["Ida Solheim", 18, "Rolig tempo hele veien."], [ME, 16, "Bommet to på slutten."], ["Mats Berg", 14, null], ["Jonas Dahl", null, null]] },
  { id: "u2", name: "Chip 10 m · innenfor 1 m", ovelse: "Chip 10 m · innenfor 1 m", dir: "hoy", eier: "Sofie Aas", start: "24.09.2026", slutt: "04.10.2026", st: "ACTIVE", mode: "del", desc: null,
    del: [[ME, null, null], ["Sofie Aas", 7, null], ["Emil Vik", 5, null]] },
  { id: "u3", name: "Færrest putter på 9 hull", ovelse: "Putting 9 hull · færrest putter", dir: "lav", eier: "Nora Lund", start: "26.09.2026", slutt: "10.10.2026", st: "ACTIVE", mode: "inv", desc: "Spill ni hull på puttinggreenen. Lavest antall putter vinner.",
    del: [["Nora Lund", null, null], ["Kaja Moen", null, null]] },
  { id: "u4", name: "Puttingduell september", ovelse: null, dir: "hoy", eier: ME, start: "01.09.2026", slutt: "15.09.2026", st: "ENDED", mode: "eier", desc: null,
    del: [[ME, 22, null], ["Ida Solheim", 19, null], ["Emil Vik", 17, null]] },
];
const rankOf = (del, dir) => {
  const sc = del.filter((d) => d[1] != null).sort((a, b) => dir === "lav" ? a[1] - b[1] : b[1] - a[1]);
  return (nm) => { const i = sc.findIndex((d) => d[0] === nm); return i < 0 ? null : i + 1; };
};
const Sec = ({ k, meta, children, label, rust }) => <section aria-label={label || k} className="pa-card" style={{ padding: 16, gap: 12, minWidth: 0, borderLeft: rust ? "3px solid var(--signal-ink)" : undefined }}><div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>{k}</span>{meta != null && React.createElement(window.PHQ.Meta, null, meta)}</div>{children}</section>;
const Muted = ({ children }) => <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{children}</p>;
const dirTxt = (d) => d === "lav" ? "Lavest score vinner" : "Høyest score vinner";

/* ---------- Liste ---------- */
function Liste({ state, go }) {
  const { PageHeader, Button, StatusPill, EmptyState, Icon } = window.PHQ.ns();
  const P = window.PHQ, empty = state === "tom", list = empty ? [] : UTF;
  const mine = (u) => { const r = rankOf(u.del, u.dir)(ME); return r == null ? "—" : String(r); };
  const kort = (u) => <button key={u.id} type="button" onClick={() => go(u.mode === "inv" ? "PH-24D-INVITERT" : u.st === "ENDED" ? "PH-24D-AVSLUTTET" : "PH-24D-DETALJ")} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", width: "100%", display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 64, padding: "10px 0", borderTop: "1px solid var(--border-hairline)" }}>
    <span style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}>
      <span style={{ font: "600 15px/1.3 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{u.name}</span>
      <P.Meta s={{ overflowWrap: "anywhere" }}>{u.del.length} DELTAKERE · {u.st === "ENDED" ? "AVSLUTTET " : "SLUTTER "}{u.slutt.slice(0, 5)} · {u.mode === "inv" ? "DU ER INVITERT" : "DIN PLASSERING " + mine(u)}</P.Meta>
    </span>
    <span style={{ display: "flex", gap: 8, alignItems: "center" }}>{u.mode === "inv" ? <StatusPill tone="info">Invitert</StatusPill> : u.st === "ENDED" ? <StatusPill tone="neutral">Avsluttet</StatusPill> : <StatusPill tone="ok">Aktiv</StatusPill>}<Icon name="chevron-right" size={16} /></span>
  </button>;
  const grp = (k, arr) => <Sec key={k} k={k} meta={arr.length ? arr.length + (arr.length === 1 ? " UTFORDRING" : " UTFORDRINGER") : "INGEN"}>{arr.length ? <div role="list" style={{ marginTop: -12 }}>{arr.map(kort)}</div> : <Muted>Ingen.</Muted>}</Sec>;
  const inv = list.filter((u) => u.mode === "inv"), akt = list.filter((u) => u.st === "ACTIVE" && u.mode !== "inv"), avs = list.filter((u) => u.st === "ENDED");
  return <P.Page max={880}>
    <PageHeader kicker="Meg · Utfordringer" title="Utfordringer" sub="Konkurranser mot vennene og gruppa. De teller ikke som trening." actions={<><Button variant="secondary" icon="arrow-left" onClick={() => go("PH-24")}>Meg</Button><Button icon="plus" onClick={() => go("PH-24D-NY")}>Ny utfordring</Button></>} />
    <P.Gate state={state} loading="Henter utfordringene dine …" error={{ title: "Utfordringene kunne ikke hentes", text: "Ingenting er endret. Prøv igjen.", code: "FEIL 503 · UTFORDRINGER" }}>
      {empty ? <EmptyState icon="trophy" title="Ingen utfordringer" text="Lag en utfordring og velg hvem fra vennene og gruppa som skal være med." /> : <P.Stack>
        {inv.length > 0 && grp("Invitasjoner", inv)}{grp("Aktive", akt)}{grp("Avsluttede", avs)}
        <P.Meta>UTFORDRINGER TELLER IKKE SOM TRENING · REGISTRERT SCORE LEVER BARE HER</P.Meta>
      </P.Stack>}
    </P.Gate>
  </P.Page>;
}

/* ---------- Detalj ---------- */
function Detalj({ state, go, id }) {
  const { PageHeader, Button, StatusPill, Dialog, EmptyState, Icon, Avatar, FormField, TextInput } = window.PHQ.ns();
  const P = window.PHQ, empty = state === "tom", U = UTF.find((x) => x.id === id);
  const [del, setDel] = React.useState(() => empty ? U.del.map(([n]) => [n, null, null]) : U.del), [joined, setJoined] = React.useState(U.mode !== "inv");
  const [ended, setEnded] = React.useState(U.st === "ENDED"), [dlg, setDlg] = React.useState(false), [val, setVal] = React.useState(""), [note, setNote] = React.useState(""), [err, setErr] = React.useState(null);
  const eier = U.eier === ME, rk = rankOf(del, U.dir), sorted = [...del].sort((a, b) => (a[1] == null) - (b[1] == null) || (U.dir === "lav" ? a[1] - b[1] : b[1] - a[1]));
  const bliMed = () => { setDel((l) => [...l, [ME, null, null]]); setJoined(true); P.toast("Du er med", U.name.toUpperCase()); };
  const lagre = () => { const n = parseFloat(val.replace(",", ".")); if (!isFinite(n) || n < 0) { setErr("Skriv scoren som et tall, for eksempel 16."); return; } setErr(null); setDel((l) => l.map((d) => d[0] === ME ? [ME, n, note || null] : d)); setVal(""); setNote(""); P.toast("Scoren er registrert", U.name.toUpperCase() + " · " + P.dec(n, n % 1 ? 1 : 0)); };
  const min = del.find((d) => d[0] === ME);
  const head = <Sec k={U.ovelse || "Fri utfordring"} meta={U.start + " – " + U.slutt}>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>{ended ? <StatusPill tone="neutral">Avsluttet</StatusPill> : joined ? <StatusPill tone="ok">Aktiv</StatusPill> : <StatusPill tone="info">Invitert</StatusPill>}<P.Meta>{dirTxt(U.dir).toUpperCase()} · EIER {eier ? "DU" : U.eier.toUpperCase()}</P.Meta></div>
    {U.desc ? <p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-primary)", textWrap: "pretty" }}>{U.desc}</p> : <Muted>Ingen beskrivelse.</Muted>}
    <P.Meta>TELLER IKKE SOM TRENING · GÅR IKKE TIL PLAN, STATS ELLER COACH</P.Meta>
  </Sec>;
  const liste = <Sec k="Resultatliste" meta={ended ? "SLUTTRESULTAT" : del.length + " DELTAKERE"}>
    {empty || !del.some((d) => d[1] != null) ? <EmptyState icon="trophy" title="Ingen score ennå" text="Plasseringene vises når første score er registrert." /> : null}
    <div role="list">{sorted.map(([n, s, nt], i) => { const me = n === ME, r = rk(n); return <div role="listitem" key={n} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 52, borderTop: i ? "1px solid var(--border-hairline)" : "none", padding: "6px 0" }}>
      <span style={{ font: "600 15px/1 var(--font-mono)", color: r == null ? "var(--text-faint)" : "var(--text-primary)" }}>{r == null ? "—" : r}</span>
      <span style={{ display: "flex", gap: 10, alignItems: "center", minWidth: 0 }}><Avatar name={n} size={32} /><span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: (me ? "600" : "500") + " 14px/1.3 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{me ? n + " (deg)" : n}</span>{nt && <P.Meta s={{ overflowWrap: "anywhere", textTransform: "none", whiteSpace: "pre-wrap" }}>{nt}</P.Meta>}</span></span>
      <span style={{ font: "600 17px/1 var(--font-mono)", color: s == null ? "var(--text-faint)" : "var(--text-primary)" }}>{s == null ? "—" : P.dec(s, s % 1 ? 1 : 0)}</span>
    </div>; })}</div>
  </Sec>;
  const inv = <Sec k="Invitasjon" meta={"FRA " + U.eier.toUpperCase()}>
    <p style={{ margin: 0, font: "600 15px/1.4 var(--font-sans)", color: "var(--text-primary)", textWrap: "pretty" }}>{U.eier} har utfordret deg.</p>
    <Muted>Du er valgt av {U.eier}. Ingen andre kan bli med uten å bli valgt. Blir du med, ser de andre navnet og scoren din.</Muted>
    <div><Button size="lg" icon="check" onClick={bliMed}>Bli med</Button></div>
  </Sec>;
  const reg = <Sec k="Din score" meta={min && min[1] != null ? "REGISTRERT " + P.dec(min[1], min[1] % 1 ? 1 : 0) : "IKKE REGISTRERT"}>
    <FormField label="Score" hint={dirTxt(U.dir)} error={err || undefined}><TextInput mono inputMode="decimal" value={val} placeholder="—" onChange={(e) => { setVal(e.target.value); setErr(null); }} /></FormField>
    <label style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-secondary)" }}>Notat (valgfritt)</span><textarea className="pa-input" rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Hva gikk bra, hva ville du gjort annerledes?" style={{ width: "100%", boxSizing: "border-box", resize: "vertical", font: "var(--type-body)", minHeight: 80, padding: 12 }}></textarea></label>
    <div><Button icon="check" onClick={lagre}>Registrer score</Button></div>
  </Sec>;
  const avs = <Sec k="Avslutt utfordring" rust label="Avslutt utfordring">
    <Muted>Resultatlisten låses og ingen kan registrere mer. Utfordringen heter da Avsluttet.</Muted>
    <div><Button icon="flag" onClick={() => setDlg(true)}>Avslutt utfordring</Button></div>
  </Sec>;
  const two = P.useW().cw >= 900;
  const venstre = <P.Stack>{head}{joined && !ended && reg}{!joined && inv}</P.Stack>;
  const hoyre = <P.Stack>{liste}{eier && !ended && avs}</P.Stack>;
  return <P.Page max={1080}>
    <PageHeader kicker="Meg · Utfordringer" title={U.name} sub={ended ? "Avsluttet av " + (eier ? "deg" : U.eier) + " " + U.slutt : "Slutter " + U.slutt} actions={<Button variant="secondary" icon="arrow-left" onClick={() => go("PH-24D")}>Utfordringer</Button>} />
    <P.Gate state={state} loading="Henter utfordringen …" error={{ title: "Utfordringen kunne ikke hentes", text: "Ingenting er endret. Prøv igjen.", code: "FEIL 503 · UTFORDRING" }}>
      {two ? <P.Cols tpl="minmax(0,1fr) minmax(0,1.1fr)">{venstre}{hoyre}</P.Cols> : <P.Stack>{head}{!joined && inv}{liste}{joined && !ended && reg}{eier && !ended && avs}</P.Stack>}
    </P.Gate>
    <Dialog open={dlg} title="Avslutte utfordringen?" onClose={() => setDlg(false)} footer={<><Button variant="secondary" onClick={() => setDlg(false)}>Fortsett</Button><Button variant="signal" onClick={() => { setDlg(false); setEnded(true); P.toast("Utfordringen er avsluttet", U.name.toUpperCase()); }}>Avslutt utfordring</Button></>}>Resultatlisten låses, og de {del.length - 1} andre får beskjed i appen. Ingen kan registrere mer score etterpå.</Dialog>
  </P.Page>;
}

/* ---------- Ny ---------- */
function Ny({ state, go }) {
  const { PageHeader, Button, FormField, TextInput, Segmented, ChoicePill, EmptyState, Icon } = window.PHQ.ns();
  const P = window.PHQ, empty = state === "tom", venner = empty ? [] : VENNER, gruppe = empty ? [] : GRUPPE;
  const [name, setName] = React.useState(""), [desc, setDesc] = React.useState(""), [ov, setOv] = React.useState(""), [dir, setDir] = React.useState("Høyest vinner"), [fra, setFra] = React.useState(""), [til, setTil] = React.useState(""), [sel, setSel] = React.useState({}), [tried, setTried] = React.useState(false);
  const locked = OVELSER.find((o) => o[0] === ov), effDir = locked ? (locked[1] === "lav" ? "Lavest vinner" : "Høyest vinner") : dir;
  const antall = Object.values(sel).filter(Boolean).length, nameErr = tried && !name.trim() ? "Gi utfordringen et navn." : undefined;
  const tog = (n) => setSel((s) => ({ ...s, [n]: !s[n] }));
  const opprett = () => { setTried(true); if (!name.trim()) return; P.toast("Utfordringen er opprettet", antall ? antall + " VALGT FÅR VARSEL I APPEN" : "DU ER MED ALENE"); go("PH-24D-DETALJ"); };
  const liste = (k, arr) => <div key={k} role="group" aria-label={k} style={{ display: "flex", flexDirection: "column", gap: 8 }}><P.Meta>{k.toUpperCase()}</P.Meta><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{arr.map((n) => <ChoicePill key={n} selected={!!sel[n]} onClick={() => tog(n)}>{n}</ChoicePill>)}</div></div>;
  return <P.Page max={760}>
    <PageHeader kicker="Meg · Utfordringer" title="Ny utfordring" sub="Velg øvelse, hvem som er med og hvem som vinner." actions={<Button variant="secondary" icon="arrow-left" onClick={() => go("PH-24D")}>Utfordringer</Button>} />
    <P.Gate state={state} loading="Henter venner og grupper …" error={{ title: "Vennene dine kunne ikke hentes", text: "Utfordringen er ikke opprettet. Prøv igjen.", code: "FEIL 503 · VENNER" }}>
      <P.Stack>
        <Sec k="Utfordringen" meta="1 AV 3">
          <FormField label="Navn" error={nameErr}><TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="Putting 3 fot · 20 putter" /></FormField>
          <label style={{ display: "flex", flexDirection: "column", gap: 6 }}><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-secondary)" }}>Beskrivelse (valgfritt)</span><textarea className="pa-input" rows={3} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Hvordan skal øvelsen gjøres?" style={{ width: "100%", boxSizing: "border-box", resize: "vertical", font: "var(--type-body)", minHeight: 80, padding: 12 }}></textarea></label>
          <FormField label="Øvelse" optional hint="Uten øvelse er utfordringen fri"><div className="pa-control pa-select" style={{ minWidth: 0 }}><select aria-label="Øvelse" value={ov} onChange={(e) => setOv(e.target.value)}><option value="">Ingen øvelse</option>{OVELSER.map(([o]) => <option key={o} value={o}>{o}</option>)}</select></div></FormField>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><span className="pa-field__label" style={{ color: "var(--text-secondary)" }}>Hvem vinner</span>
            {locked ? <div style={{ display: "grid", gridTemplateColumns: "20px minmax(0,1fr)", gap: 8, padding: 12, borderRadius: 8, background: "var(--surface-sunken)" }}><span style={{ paddingTop: 2, color: "var(--text-secondary)" }}><Icon name="lock" size={14} /></span><span style={{ font: "var(--type-body-s)", color: "var(--text-primary)" }}>{effDir === "Lavest vinner" ? "Lavest score vinner" : "Høyest score vinner"}. Retningen er låst av øvelsen.</span></div> : <Segmented options={["Høyest vinner", "Lavest vinner"]} value={dir} onChange={setDir} fullWidth />}</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 12 }}><FormField label="Start" optional><TextInput mono value={fra} placeholder="dd.mm.åååå" onChange={(e) => setFra(e.target.value)} /></FormField><FormField label="Slutt" optional><TextInput mono value={til} placeholder="dd.mm.åååå" onChange={(e) => setTil(e.target.value)} /></FormField></div>
        </Sec>
        <Sec k="Hvem er med" meta={empty ? "INGEN Å VELGE" : antall + " VALGT"}>
          {empty ? <EmptyState icon="users" title="Ingen å velge ennå" text="Legg til venner eller bli med i en gruppe for å utfordre andre. Du kan lage utfordringen alene." /> : <>{liste("Venner", venner)}{liste("Min gruppe · AK-stigen Utvikling", gruppe)}</>}
          <P.Meta>DE VALGTE FÅR VARSEL I APPEN · INGEN DELBAR LENKE · DU ER ALLTID MED</P.Meta>
        </Sec>
        <Button variant="signal" size="xl" fullWidth icon="trophy" onClick={opprett}>Opprett utfordring{antall ? " · " + antall + " valgt" : ""}</Button>
        <P.Meta>UTFORDRINGER TELLER IKKE SOM TRENING</P.Meta>
      </P.Stack>
    </P.Gate>
  </P.Page>;
}

window.PHQ_SCREENS = window.PHQ_SCREENS || {};
const reg = (id, name, route, C) => { window.PHQ_SCREENS[id] = { id, parent: "PH-24", name, tab: "meg", route, Component: C }; };
reg("PH-24D", "Meg › Utfordringer", "/portal/utfordringer", (p) => <Liste {...p} />);
reg("PH-24D-DETALJ", "Utfordring · eier, aktiv", "/portal/utfordringer/[id]", (p) => <Detalj {...p} id="u1" />);
reg("PH-24D-INVITERT", "Utfordring · invitert", "/portal/utfordringer/[id] (ikke med ennå)", (p) => <Detalj {...p} id="u3" />);
reg("PH-24D-AVSLUTTET", "Utfordring · avsluttet", "/portal/utfordringer/[id] (avsluttet)", (p) => <Detalj {...p} id="u4" />);
reg("PH-24D-NY", "Ny utfordring", "/portal/utfordringer/ny", (p) => <Ny {...p} />);
})();
