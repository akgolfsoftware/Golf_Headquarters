/* PH-24 Meg — runde 23 (Anders 28.09.2026). Oppdiktede data. */
window.PHQ_MEG23 = {
  profil: { name: "Tobias Lindvik", born: "14.03.2009", age: 17, hcp: "8,4", hcpSrc: "GOLFBOX · 21.09.2026", club: "Fredrikstad GK", golfId: "4410982", email: "tobias.lindvik@epost.no", phone: "+47 ••• •• 412", cat: "D", catSrc: "SNITT 75,2 · 10 TELLENDE · 20.09.2026" },
  bookinger: [
    { id: "b1", when: "Tir 29.09 · 17:00–18:00", what: "Privattime · Anders Kristiansen", where: "Studio 1 · TrackMan", st: "Bekreftet", clip: true },
    { id: "b2", when: "Tor 08.10 · 16:00–17:00", what: "TrackMan-bay", where: "Bay 3", st: "Bekreftet", clip: false },
  ],
  klipp: { left: 3, total: 4, resets: "01.10.2026", pkg: "Performance Pro" },
  abo: { plan: "FULL", price: "299 kr / mnd", renews: "26.10.2026", card: "Visa •••• 4821", exp: "08/28" },
  foreldre: [
    { name: "Hanne Lindvik", email: "hanne.lindvik@epost.no", st: "Har tilgang", since: "12.01.2026" },
    { name: "Tor Lindvik", email: "tor.lindvik@epost.no", st: "Invitert", since: "20.09.2026" },
  ],
  foreldreSer: ["Plan og bookinger", "Økonomi og abonnement", "Samtykker", "Meldinger fra coach til forelder"],
  foreldreSerIkke: ["Helse og fravær", "Meldinger mellom deg og coachen", "Ytelsesbilde"],
  fravaer: [
    { id: "a1", kind: "Ferie", from: "10.10.2026", to: "12.10.2026", note: "Høstferie · hytte", st: "Planlagt" },
    { id: "a2", kind: "Skade", from: "02.09.2026", to: "09.09.2026", note: "Stiv korsrygg etter langkjøring", st: "Avsluttet" },
  ],
  coach: { name: "Anders Kristiansen", role: "Hovedcoach · AK Golf", avtale: "Performance Pro · 4 privattimer per måned · løpende", since: "04.05.2026",
    videos: [["Treffpunkt med PW", "4:12", "24.09.2026"], ["P6.0 i nedsvingen", "2:48", "17.09.2026"], ["Oppstilling bunker", "3:05", "11.09.2026"]],
    feedback: [["23.09.2026", "Privattime", "Hendene foran ballen i treff sitter i 50 %. Hold den farten til torsdag."], ["17.09.2026", "Runde · Borregaard GK", "God rutine på greenene. Tre av fire tapte slag kom fra 100–150 m."]] },
  utfordringer: [["Putting 3 fot · 20 putter", "Aktiv", "Slutter 30.09"], ["Chip 10 m · innenfor 1 m", "Aktiv", "Slutter 04.10"]],
  venner: 6,
  hjelp: [["Slik registrerer du en runde", "file-text"], ["Slik kobler du TrackMan", "file-text"], ["Slik fungerer deling", "file-text"], ["Kontakt AK Golf", "mail"]],
};
