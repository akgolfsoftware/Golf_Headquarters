# PlayerHQ skjermkatalog (/portal)

`index.html` er katalogen: verktøylinje med skjerm, bredde (390 / 768 / 1024 / 1280), tema (Lyst / Natt) og tilstand (Data / Tom / Laster / Feil). Valget lagres i `localStorage["phq-cat"]`. Skjermen vises i en iframe med ekte bredde (`screen.html`), så media queries og container queries oppfører seg som i appen.

| Fil | Innhold |
|---|---|
| `screen.html` | Vert for én skjerm. `?id=PH-01&state=data&theme=lyst`. `window.__phqShow(id, state, theme)` for revisjonen |
| `parts.jsx` | `window.PHQ`: skall (TabBar under 1024, NavRail 1024+, ingen navigasjon på nattflater), `Page`, `Focus` (nattflate med én fullbredde primærhandling), `Gate` (Laster/Feil), formatering (`dec`, `sg`, `hm`, `brutto`), toast |
| `data.js` | `window.PHQ_DATA` — oppdiktede data, lørdag 26.09.2026, Tobias Lindvik |
| `an-parts.jsx`, `data-analyse.js` | `window.PHQA` (SGBar, Src med ESTIMAT-merke, DG «Powered by Data Golf», Scatter, Tabs) og `window.PHQ_AN` for PH-16–20. Alle måletall har kilde og dato |
| `screens/PH-01.jsx` … `PH-20.jsx` | Én fil per skjermtype. Registrerer seg i `window.PHQ_SCREENS` |
| `../agencyos/planmotor-data.js`, `../agencyos/PlanParts.jsx` | Delt med AgencyOS: `window.PM` og `YearCurve` (PH-11) |
| `legacy/` | `PlanScreen`, `MoreScreens` (Data, Meg) — kildemateriale for PH-10, PH-16 og PH-24 |

Nye skjermer: lag `screens/PH-xx.jsx`, legg til i `screen.html` og i `ui_kits/katalog.js`. Hent aldri designsystemkomponenter på modulnivå — destrukturer inne i komponenten (pakken evalueres før navnerommet er fylt).
