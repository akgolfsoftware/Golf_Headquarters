/* Stats (PH-16) — runde 22, Anders 28.09.2026. Oppdiktede data for Tobias Lindvik. Dagens dato 26.09.2026.
   Sammenligning: standard neste kategori etter snittscore (Kategori C, Broadie-baseline, ESTIMAT). Alternativ: PGA Tour. */
(() => {
const PAR72 = [4, 4, 3, 5, 4, 4, 3, 4, 5, 4, 3, 4, 5, 4, 4, 3, 4, 5], PAR71 = [4, 4, 3, 5, 4, 4, 3, 4, 4, 4, 3, 4, 5, 4, 4, 3, 4, 5];
/* Deterministisk scorekort: diff per hull som summerer til over par. */
function card(seed, over) {
  const d = Array(18).fill(0), bird = seed % 3;
  for (let i = 0; i < over + bird; i++) d[(seed * 5 + i * 7) % 18] += 1;
  let b = 0; for (let i = 0; b < bird && i < 36; i++) { const p = (seed * 3 + i * 11 + 1) % 18; if (d[p] === 0) { d[p] = -1; b++; } }
  let s = d.reduce((a, x) => a + x, 0); for (let i = 0; s !== over && i < 18; i++) { if (s > over && d[i] > 0) { d[i]--; s--; } else if (s < over && d[i] === 0) { d[i]++; s++; } }
  return d;
}
const R = (id, date, course, par, score, kind, sg, t5, yb, turn) => { const pars = par === 71 ? PAR71 : PAR72; return { id, date, course, par, score, kind, sg, t5, yb, turn, pars, card: card(+id.slice(1), score - par).map((x, i) => pars[i] + x) }; };
const T5 = (p5, dbl, three, short, ud) => ({ p5, dbl, three, short, ud });
const YB = (tek, fys, men, sos, sov, energy, sleep, food) => ({ tek, fys, men, sos, sov, energy, sleep, food });
window.STATS_DATA = {
  cmp: { c: { label: "Kategori C", long: "Neste kategori · Kategori C · Broadie-baseline", src: "BROADIE-BASELINE TILPASSET KATEGORI C · ESTIMAT · 01.09.2026", est: true }, pga: { label: "PGA Tour", long: "PGA Tour-snitt", src: "DATA GOLF · PGA TOUR 2026 · 21.09.2026 · UTREGNET SG · ESTIMAT", est: true } },
  n: { rounds: 22, season: "SESONG 2026 · 22 RUNDER · 20.09.2026" },
  need: { min: 4, prelim: 8, safe: { tee: 12, innspill: 12, naer: 24, putt: 24 } },
  snitt: { avg: 75.2, prev: 76.6, cat: "D", next: "C", nextLimit: 74.0, src: "10 TELLENDE RUNDER · 13.06–20.09.2026", prevSrc: "10 RUNDER FØR · 02.05–06.06.2026", trend: [77.4, 77.0, 76.8, 76.6, 76.1, 75.8, 75.6, 75.2] },
  rounds: [
    R("r22", "20.09.2026", "Fredrikstad GK", 72, 76, "Tellende", -2.6, T5(1, 1, 2, 1, 1), YB(4, 2, 3, 3, 2, 13, 5.5, ["Spiste frokost"])),
    R("r21", "13.09.2026", "Borregaard GK", 71, 74, "Turnering", -1.7, T5(0, 0, 1, 1, 1), YB(4, 4, 4, 4, 4, null, 7.5, ["Spiste frokost", "Mat underveis", "Nok drikke"]), { name: "Srixon Tour · runde 5", place: "12. av 64", src: "AK GOLF PIPELINES · GOLFBOX · 13.09.2026" }),
    R("r20", "06.09.2026", "Onsøy GK", 72, 75, "Tellende", -2.0, T5(1, 0, 1, 1, 0), YB(4, 4, 3, 4, 3, 15, 6.5, ["Spiste frokost", "Nok drikke"])),
    R("r19", "30.08.2026", "Fredrikstad GK", 72, 73, "Turnering", -0.9, T5(0, 0, 1, 0, 1), YB(5, 4, 4, 4, 4, null, 8, ["Spiste frokost", "Mat underveis", "Nok drikke"]), { name: "Klubbmesterskap · Fredrikstad GK", place: "3. av 28", src: "AK GOLF PIPELINES · GOLFBOX · 30.08.2026" }),
    R("r18", "23.08.2026", "Fredrikstad GK", 72, 77, "Tellende", -3.1, T5(1, 1, 2, 2, 1), null),
    R("r17", "16.08.2026", "Borregaard GK", 71, 75, "Tellende", -2.3, T5(0, 1, 1, 1, 1), YB(3, 4, 3, 3, 4, 12, 7, ["Spiste frokost"])),
    R("r16", "09.08.2026", "Hvaler GK", 72, 76, "Turnering", -2.4, T5(1, 0, 2, 1, 1), YB(4, 3, 2, 3, 3, 10, 6, ["Nok drikke"]), { name: "Srixon Tour · runde 4", place: "21. av 64", src: "AK GOLF PIPELINES · GOLFBOX · 09.08.2026" }),
    R("r15", "02.08.2026", "Fredrikstad GK", 72, 74, "Tellende", -1.4, T5(0, 0, 1, 1, 0), YB(4, 4, 4, 3, 4, null, 7.5, ["Spiste frokost", "Mat underveis"])),
    R("r14", "26.07.2026", "Onsøy GK", 72, 76, "Tellende", -2.5, T5(1, 1, 1, 1, 1), null),
    R("r13", "19.07.2026", "Fredrikstad GK", 72, 76, "Tellende", -2.2, T5(0, 1, 2, 1, 1), YB(4, 3, 3, 4, 3, 14, 6.5, ["Spiste frokost", "Nok drikke"])),
  ],
  t5Labels: [["p5", "Bogey på par 5"], ["dbl", "Dobbeltbogey eller verre"], ["three", "3-putt"], ["short", "Bogey fra innenfor 130 m"], ["ud", "Bom på enkel opp-og-ned"]],
  t5Season: { p5: 11, dbl: 9, three: 26, short: 17, ud: 14, rounds: 22, src: "SESONG 2026 · 22 RUNDER · 20.09.2026" },
  ybFactors: [["tek", "Teknisk"], ["fys", "Fysisk / helse"], ["men", "Mentalt"], ["sos", "Sosialt / miljø"], ["sov", "Søvn og mat"]],
  ybSrc: "YTELSESBILDE · 8 AV 10 RUNDER FYLT UT · 20.09.2026",
  /* SG per område. c = mot Kategori C (ESTIMAT), pga = mot PGA Tour, n = slag i grunnlaget, d = endring siste 10 mot 10 før. prox = [du, PGA] m. */
  sg: [
    { g: "tee", label: "Tee", rows: [{ id: "tee", label: "Tee · par 4 og 5", c: -0.1, pga: -1.6, n: 196, d: 0.3 }] },
    { g: "innspill", label: "Innspill", rows: [
      { id: "i200", label: "200+ m", c: -0.2, pga: -0.7, n: 38, d: 0.0, prox: [24.1, 16.2] },
      { id: "i150", label: "150–200 m", c: -0.3, pga: -1.1, n: 96, d: -0.1, prox: [14.8, 10.2] },
      { id: "i100", label: "100–150 m", c: -0.4, pga: -1.0, n: 142, d: 0.1, prox: [11.6, 7.4] },
      { id: "i50", label: "50–100 m", c: -0.1, pga: -0.5, n: 88, d: 0.1, prox: [9.4, 5.8] },
    ] },
    { g: "naer", label: "Nærspill 0–50 m", rows: [
      { id: "chip", label: "Chip", c: -0.1, pga: -0.3, n: 58, d: 0.2, prox: [2.4, 1.6] },
      { id: "pitch", label: "Pitch", c: -0.2, pga: -0.4, n: 31, d: 0.0, prox: [4.1, 2.7] },
      { id: "lob", label: "Lob", c: -0.1, pga: -0.1, n: 9, d: null, prox: [3.8, 2.9] },
      { id: "bunker", label: "Bunker", c: -0.1, pga: -0.3, n: 17, d: -0.1, prox: [4.6, 3.1] },
    ] },
    { g: "putt", label: "Putting", rows: [
      { id: "p0", label: "0–3 fot", c: 0.0, pga: -0.1, n: 212, d: 0.0 },
      { id: "p3", label: "3–6 fot", c: -0.3, pga: -0.5, n: 64, d: -0.2 },
      { id: "p6", label: "6–10 fot", c: -0.1, pga: -0.3, n: 48, d: 0.0 },
      { id: "p10", label: "10–20 fot", c: -0.1, pga: -0.2, n: 71, d: 0.1 },
      { id: "p20", label: "20–40 fot", c: 0.0, pga: -0.1, n: 52, d: 0.0 },
      { id: "p40", label: "40+ fot", c: -0.1, pga: -0.1, n: 19, d: null },
    ] },
  ],
  sgSrc: "SG PER RUNDE · SNITT 10 RUNDER · 20.09.2026",
  /* Trening mot SG i samme område, siste 8 uker. */
  tren: [
    { id: "tee", label: "Tee", axis: "tek", h: 4.0, d: 0.3 },
    { id: "chip", label: "Chip", axis: "slag", h: 3.5, d: 0.2 },
    { id: "i100", label: "Innspill 100–150 m", axis: "slag", h: 1.5, d: 0.1 },
    { id: "bunker", label: "Bunker", axis: "slag", h: 0, d: -0.1 },
    { id: "p3", label: "Putting 3–6 fot", axis: "slag", h: 0.5, d: -0.2 },
  ],
  trenSrc: "ØKTLOGG OG SG · UKE 31–38 · 20.09.2026",
  pyr: { rows: [["fys", 22, 20], ["tek", 5, 20], ["slag", 45, 35], ["spill", 23, 20], ["turn", 5, 5]], hours: 96.5, src: "ØKTLOGG · UKE 31–38 · 96,5 T · 20.09.2026", planSrc: "PLAN FRA ANDERS KRISTIANSEN · PUBLISERT 21.09.2026" },
  tm: {
    clubs: ["7i", "PW", "Driver"],
    params: {
      "7i": [["Club Path", "°", 1.8, 2.4, "0 til +2°"], ["Face Angle", "°", -0.6, 2.1, null], ["Face to Path", "°", -2.4, 1.9, "−1 til +1°"], ["Attack Angle", "°", -3.2, 1.2, "−4 til −2°"], ["Dynamic Loft", "°", 22.4, 1.6, null], ["Club Speed", "mph", 80.3, 1.4, null]],
      "PW": [["Club Path", "°", 2.6, 2.8, "0 til +2°"], ["Face Angle", "°", 0.4, 2.3, null], ["Face to Path", "°", -2.2, 2.0, "−1 til +1°"], ["Attack Angle", "°", -4.6, 1.4, "−5 til −3°"], ["Dynamic Loft", "°", 31.8, 2.1, null], ["Club Speed", "mph", 72.1, 1.6, null]],
      "Driver": [["Club Path", "°", 3.4, 3.1, null], ["Face Angle", "°", 1.2, 2.6, null], ["Face to Path", "°", -2.2, 2.2, null], ["Attack Angle", "°", 1.1, 1.8, "+2 til +4°"], ["Dynamic Loft", "°", 14.6, 1.9, null], ["Club Speed", "mph", 101.2, 1.8, "105 mph"]],
    },
    n: { "7i": 64, "PW": 96, "Driver": 48 },
    src: "TRACKMAN · 3 ØKTER · 10.09–24.09.2026",
    malSrc: "MÅLSETNING FRA ANDERS KRISTIANSEN · 12.09.2026",
  },
  filters: [
    ["tidsrom", "Tidsrom", ["Siste 4 uker", "Siste 8 uker", "Sesong 2026"], true],
    ["periode", "Periode", ["Grunnperiode", "Spesialperiode", "Turneringsperiode", "Evaluering", "Ferie", "Restitusjon"]],
    ["pyramide", "Pyramide", ["FYS", "TEK", "SLAG", "SPILL", "TURN"]],
    ["omrade", "Område", ["Tee", "Innspill", "Nærspill", "Putting"]],
    ["sted", "Sted", ["Range", "Bane", "Simulator", "Hjemme", "Styrkerom"]],
    ["motorikk", "Læringssteg", ["Uten ball", "Lav hastighet", "Automatikk"]],
    ["press", "Press", ["Uten press", "Lavt press", "Middels press", "Høyt press"]],
    ["kolle", "Kølle", ["Driver", "7i", "PW", "54°", "58°", "Putter"]],
  ],
  /* Tester. norm = nivå for Kategori C (null = normen mangler). */
  tests: [
    { id: "t50", by: "Kontrollert", lvl: "D", tn: 8, name: "Innspill 50–100 m", sub: "10 slag · innenfor 4 m", axis: "slag", unit: "av 10", hist: [3, 4, 4, 5, 5], dates: ["02.05", "13.06", "11.07", "15.08", "12.09"], norm: 7, hi: true, src: "TEAM NORWAY · 12.09.2026" },
    { id: "tp3", by: "Egenregistrert", lvl: "D", tn: 19, name: "Putting 3 fot", sub: "20 putter i rad", axis: "slag", unit: "av 20", hist: [13, 14, 15, 16, 16], dates: ["02.05", "13.06", "11.07", "15.08", "12.09"], norm: 18, hi: true, src: "TEAM NORWAY · 12.09.2026" },
    { id: "tch", by: "Kontrollert", lvl: "D", tn: 8, name: "Chip 10 m", sub: "10 slag · innenfor 1 m", axis: "slag", unit: "av 10", hist: [4, 5, 6], dates: ["13.06", "15.08", "12.09"], norm: 7, hi: true, src: "TEAM NORWAY · 12.09.2026" },
    { id: "tcs", by: "Kontrollert", lvl: "D", tn: 110, name: "Driver · Club Speed", sub: "Snitt av 5 slag", axis: "fys", unit: "mph", hist: [98.4, 99.6, 100.4, 101.2], dates: ["02.05", "11.07", "15.08", "12.09"], norm: 105, hi: true, dec: 1, src: "TRACKMAN · 12.09.2026" },
    { id: "twg", by: "Egenregistrert", lvl: null, tn: null, name: "Wedge Gate", sub: "9 slag · lav/medium/høy × 40/50/60 m · X / 9 treff", axis: "slag", unit: "/ 9 treff", hist: [4, 5], dates: ["15.08", "12.09"], norm: null, hi: true, src: "TEAM NORWAY · 12.09.2026" },
    { id: "t8b", by: "Kontrollert", lvl: null, tn: null, name: "8-ball", sub: "8 baller · 0–4 poeng · TN-scorekort", axis: "slag", unit: "poeng", hist: [17, 19, 21], dates: ["13.06", "15.08", "12.09"], norm: null, hi: true, src: "TEAM NORWAY · 12.09.2026" },
    { id: "t9h", by: "Egenregistrert", lvl: null, tn: null, name: "9 hull lengde", sub: "Restavstand i fot · 0–6 poeng · TN-scorekort", axis: "slag", unit: "poeng", hist: [24, 27.5], dates: ["15.08", "12.09"], norm: null, hi: true, dec: 1, src: "TEAM NORWAY · 12.09.2026" },
    { id: "tbu", by: "Egenregistrert", lvl: null, tn: null, name: "Bunker", sub: "10 slag · innenfor 3 m", axis: "slag", unit: "av 10", hist: [3, 3, 4, 4], dates: ["02.05", "13.06", "15.08", "12.09"], norm: null, hi: true, src: "EGEN TEST · 12.09.2026" },
    { id: "tmo", by: "Kontrollert", lvl: null, tn: null, name: "Thorax-rotasjon", sub: "Sittende · beste av 3", axis: "fys", unit: "°", hist: [44, 46, 48], dates: ["02.05", "11.07", "12.09"], norm: null, hi: true, src: "FYSIOTERAPEUT · 12.09.2026" },
  ],
  isTN: true, tnClass: "G17", tnSrc: "LANDSLAGSNIVÅ G17 · ESTIMAT TIL EKTE KILDE FINNES",
  normSrc: "NORM KATEGORI C · ESTIMAT TIL EKTE KILDE FINNES",
};
})();
