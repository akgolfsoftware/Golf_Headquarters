(() => {
const { Segmented, AxisBadge, Card, DataRow, StatusPill } = window.AKGolfPrecisionAthletics_7d7c29;

const WEEK = [
  { d: "Man", n: 23, items: [{ axis: "fys", t: "Styrke underkropp", m: "45 min", s: "done" }] },
  { d: "Tir", n: 24, items: [{ axis: "slag", t: "Innspill og nærspill", m: "75 min", s: "today" }] },
  { d: "Ons", n: 25, items: [{ axis: "tek", t: "Innspill · P6–P7 · Lav hastighet", m: "45 min" }, { axis: "fys", t: "Bevegelighet", m: "20 min" }] },
  { d: "Tor", n: 26, items: [] },
  { d: "Fre", n: 27, items: [{ axis: "spill", t: "Banespill · 9 hull", m: "2 t" }] },
  { d: "Lør", n: 28, items: [{ axis: "turn", t: "Utviklingsturnering · runde 1", m: "08:40" }] },
  { d: "Søn", n: 29, items: [{ axis: "turn", t: "Utviklingsturnering · runde 2", m: "09:10" }] },
];
const SPLIT = [["fys", 22], ["tek", 18], ["slag", 30], ["spill", 16], ["turn", 14]];

function PlanScreen() {
  const [sel, setSel] = React.useState(24);
  const day = WEEK.find((w) => w.n === sel);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16, padding: "16px 16px 24px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ flex: 1 }}>
          <div className="kicker">Uke 39 · Konkurranseperiode</div>
          <h1 style={{ font: "var(--type-title-l)", color: "var(--text-primary)", marginTop: 4 }}>Plan</h1>
        </div>
        <Segmented options={["Uke", "Måned"]} value="Uke" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 4 }}>
        {WEEK.map((w) => {
          const on = w.n === sel;
          return (
            <button key={w.n} onClick={() => setSel(w.n)} style={{ height: 64, border: on ? "1px solid var(--border-ink)" : "1px solid var(--border-hairline)", borderRadius: 8, background: on ? "var(--primary)" : "var(--surface-card)", color: on ? "var(--text-on-primary)" : "var(--text-primary)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, cursor: "pointer", transition: "background-color 150ms ease" }}>
              <span style={{ font: "500 11px/1 var(--font-sans)", opacity: on ? 1 : .7 }}>{w.d}</span>
              <span style={{ font: "600 17px/1 var(--font-mono)" }}>{w.n}</span>
              <span style={{ display: "flex", gap: 2, height: 4 }}>{w.items.map((it, i) => <span key={i} style={{ width: 4, height: 4, borderRadius: 999, background: on ? "var(--text-on-primary)" : "var(--axis-" + it.axis + ")" }} />)}</span>
            </button>
          );
        })}
      </div>

      <div className="pa-card">
        {day.items.length === 0 ? (
          <div style={{ padding: 20, font: "var(--type-body-s)", color: "var(--text-muted)" }}>Hviledag. Ingen økter planlagt.</div>
        ) : day.items.map((it) => (
          <DataRow key={it.t} title={it.t} sub={it.m} trailing={it.s === "done" ? <StatusPill tone="ok">Gjennomført</StatusPill> : it.s === "today" ? <StatusPill tone="solid" dot={false}>I dag</StatusPill> : <AxisBadge axis={it.axis} />} leading={<span style={{ width: 4, alignSelf: "stretch", background: "var(--axis-" + it.axis + ")" }} />} />
        ))}
      </div>

      <Card kicker="Fordeling uke 39" title="Treningsakser" footer="PLANLAGT · 8 T 40 MIN">
        <div style={{ display: "flex", height: 12, gap: 2 }}>
          {SPLIT.map(([a, p]) => <span key={a} style={{ flex: p, background: "var(--axis-" + a + ")" }} />)}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 4 }}>
          {SPLIT.map(([a, p]) => <div key={a} style={{ display: "flex", flexDirection: "column", gap: 6 }}><AxisBadge axis={a} /><span style={{ font: "var(--type-num)", color: "var(--text-primary)" }}>{p} %</span></div>)}
        </div>
      </Card>
    </div>
  );
}
Object.assign(window, { PlanScreen });
})();
