(() => {
const { Card, Metric, DataRow, AxisBadge, Switch, Segmented, Avatar, InlineAlert } = window.AKGolfPrecisionAthletics_7d7c29;

function DataScreen() {
  const bands = [["50 m", 74], ["100 m", 64], ["150 m", 52], ["200 m", 38]];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16, padding: "16px 16px 24px" }}>
      <div><div className="kicker">Siste 30 dager</div><h1 style={{ font: "var(--type-title-l)", color: "var(--text-primary)", marginTop: 4 }}>Data</h1></div>
      <Segmented fullWidth options={["Slag", "Runder", "Fysisk"]} value="Slag" />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <Card padded><Metric label="Snitt sideavvik" value="3,8" unit="m" delta="−0,6" deltaDir="up" meta="412 SLAG" /></Card>
        <Card padded><Metric label="Launch Angle 54°" value="31,2" unit="°" meta="TRACKMAN · 22.09" /></Card>
      </div>
      <Card kicker="Innspill · innen spredningskrav" title="Treff per avstand" footer="KILDE TRACKMAN · 25.08–24.09">
        {bands.map(([b, p]) => (
          <div key={b} style={{ display: "grid", gridTemplateColumns: "48px 1fr 40px", alignItems: "center", gap: 10 }}>
            <span style={{ font: "var(--type-num-s)", color: "var(--text-secondary)" }}>{b}</span>
            <span style={{ height: 10, background: "var(--surface-sunken)" }}><span style={{ display: "block", height: "100%", width: p + "%", background: "var(--axis-slag)" }} /></span>
            <span style={{ font: "var(--type-num-s)", color: "var(--text-primary)", textAlign: "right" }}>{p} %</span>
          </div>
        ))}
      </Card>
    </div>
  );
}

function MeScreen({ night, setNight }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16, padding: "16px 16px 24px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <Avatar name="Ida Berg" size={56} />
        <div><h1 style={{ font: "var(--type-title-m)", color: "var(--text-primary)" }}>Ida Berg</h1><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>HCP 4,2 · KATEGORI C · GFGK</span></div>
      </div>
      <Card kicker="Utendørs" title="Visning">
        <Switch label="Natt-tema i Live-økt" checked={night} onChange={(e) => setNight(e.target.checked)} />
        <Switch label="Store taster ved registrering" defaultChecked />
      </Card>
      <Card kicker="Abonnement" title="FULL" action={<span style={{ font: "var(--type-num-s)", color: "var(--text-secondary)", whiteSpace: "nowrap" }}>299 kr/mnd</span>} footer="FORNYES 01.10.2026 · 2 690 KR/ÅR ER BILLIGERE"><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Full tilgang til plan, statistikk og Caddie.</span></Card>
      <Card kicker="Deling" title="Hvem ser dataene dine">
        <DataRow leading={<Avatar name="Anders Kristiansen" size={32} />} title="Anders Kristiansen" sub="Hovedcoach · alt" />
        <DataRow leading={<Avatar name="Kari Berg" size={32} />} title="Kari Berg" sub="Forelder · plan og oppmøte" />
      </Card>
      <InlineAlert tone="info">Caddie deler aldri noe uten at du eller coachen godkjenner.</InlineAlert>
    </div>
  );
}
Object.assign(window, { DataScreen, MeScreen });
})();
