# DataGolf · overlevering og felles funksjonskontrakt (prototype, 02.10.2026)

Hovedlenke: `ui_kits/datagolf-komplett/index.html` · `desktop.html` (ekte 1440) · `mobil.html` (ekte 390) · `tilstander.html` · `dekningsregister.md`.
Prototype med syntetiske data. Ingen API-nøkler, ingen produksjonsdata, ingen integrasjon i PlayerHQ. Kundevisning krever særskilt rett fra DataGolf (vilkår punkt 13); API-abonnement er ikke bevis på det.

## Navigasjon
Hovedmeny: Oversikt · Spillere · Topplister · Turneringer · Utforsk. Underinnganger: Modeller, Bane og felt, Trend og utvalg, Innspill, Historikk, Live, Kilde og dekning, Analyse til tiltak, Spesialistdata (bare synlig for AK-trener og voksen analytiker). Mobil: bunnlinje med de fem hovedvalgene; underinnganger i rullbar stripe. Filtre, valgt spiller, sammenligning og periode bevares ved navigasjon og Tilbake.

## Datakontrakt (felles for Precision, Team Norway og WANG)
- `Player { dg_id, navn, land, tour, kjonn, status (proff|amatør), fodt, alt_ids[], phq { status: koblet|konflikt|ingen, via } }` — identitet kun via kilde-ID; navnlikhet gir konflikt, aldri automatisk kobling.
- `Measure { kilde, metode (DG-målt|DG-modell|Broadie|AK|PEI), periode, enhet, n, verdi | null, status (tilgjengelig|må kobles|mangler i kilden|krever avtale|utenfor rolle) }` — null = ukjent (—), 0 = målt null, lite grunnlag under terskel.
- `Event { id, tour, bane, fra, til, st (kommende|live|ferdig), felt[], res[] }`, `Round { e, p, r, brutto, sg_total, sg_ott|app|arg|putt | null, st (ok|MC|WD), live_thru }`.
- `Live { kildeklokke, forsinkelse_min, siste_vellykkede, korrigert }` — aldri «sanntid» uten dokumentert kjede.
- `Suggestion { id, spiller, mal, økter, basisversjon, status (utkast|sendt|avvist|godtatt) }` — godta én gang (idempotent), avvis = ingen endring, utdatert basis = konflikt. TN/WANG kan bare foreslå.
- `Access { rolle, kundevisning (ikke avklart|avtalt), spesialist (av|voksen intern) }` — odds/fantasy aldri for under 18 eller i spiller-/skoleflater; ingen spillhandling.

## Komponenter
Kildelinje (kilde · periode · enhet · grunnlag · syntetisk), symmetrisk SG-stolpe med akse, statusmerke, forklaringspanel for målemetoder, filterlinje, feltvelger, tabell med lokal rulling, profilfaner, kildeklokke, dekningsmatrise, forslagsflyt med versjon.

## Videreføring
- Team Norway App delivery (`bc3e41fc`): samme kontrakt i TN-profil (Jost/Lato, mono-tall, marineblått, rød #D70232, eget skall). Ikke Precision-farger.
- WANG Golf UI prototype (`6cfa623c`): samme funksjoner under relevant hovedmeny i WANGs system. Spesialistdata ikke aktivert i skoleflater.
- Ikke sendt herfra; denne filen er kontrakten.

## Åpent
Lokal API-avstemming og kontotilgang · faktisk tour-/kjønns-/amatørdekning · utgåtte endepunkter · kundeavtale · ekte tastatur/skjermleser/mobil · PlayerHQ-integrasjon.


## Overføring til Team Norway og WANG (DG-14, oppdatert 02.10.2026)
Samme feltregister (`felt.js`: navn, kildefelt, modell, datatype, enhet, klasse, kildestatus, skjerm, kundevisning) og samme rolleregel: interne driftsfelt (params_hash, params_json, s3_key, last_error) aldri synlige for kunde; markeds-/fantasyfelt (24) og DG-17 bare for voksen intern analytiker, ikke AK-, TN- eller WANG-trener; trener- og spillerroller ser 107 av 135 felt; katalogprofil er ikke PlayerHQ-konto/IUP. Kundevisning og eksport er sperret til avtale foreligger. Team Norway og WANG tegner dette i egne visuelle systemer; prosjektene kan ikke lese filene her, så registeret må overføres som tekst.

### Rolledekning (02.10.2026)
| Rolle | DG-14 felt | Odds/fantasy (DG-17) | Sammenligning, topplister, katalog, referansegrupper, tiltak |
|---|---|---|---|
| Voksen intern analytiker | 135 | ja, uten spillhandling | ja |
| AK-trener | 107 | nei | ja |
| TN-trener / WANG-trener | 107 | nei | ja (innenfor delingssamtykke) |
| Spiller | 107 | nei | nei — sperret også via direkte lenke; egen utvikling og faglige kategori-/nivåreferanser beholdes |

## DG-16 lagring gjennom ny innlasting (02.10.2026)
- Prototypen lagrer forslag, spillerens beslutning, planversjon og anvendte tiltaksøkter i nettleserens localStorage (nøkkel `dg-tiltak-v1`, `schema: 1`, `synthetic: true`). Bare syntetiske data; ingen database.
- Ved innlasting valideres formatet. Ukjent eller ugyldig lagring forkastes og vises som «Eldre lagring kunne ikke brukes»; ingen godkjenning antas. Utilgjengelig lagring vises eksplisitt.
- Godta anvender én gang: krever status «sendt» og basisversjon = planversjon, og legger ikke inn økter for en forslags-ID som allerede er anvendt. Dobbeltklikk og godta etter reload gir ingen nye økter.
- Avvis: null nye økter, planversjon uendret. Konflikt (spilleren endret planen etter sending): godta blokkeres, null nye økter, «Lag nytt forslag» tilbys.
- Appen må gjøre det samme på serveren: idempotent anvendelse per forslags-ID, revisjonssjekk mot basisversjon og atomisk skriving. localStorage er bare prototypeoppførsel.
- Prøvd 1440 og 390 (ekte iframes, ekte reload): 2 × 45 min i 6 uker → godta (tre klikk) → 12 økter, v4 → reload → 12 økter, v4, «Gjenopprettet». 1 × 60 min → 6 økter, v4. Avvis → 0 økter, v3. Konflikt → 0 økter, v4, godta blokkert. Ugyldig eldre lagring → forkastet, 0 økter. Ingen sideoverflyt, ingen treffmål under 44 px.
