# DataGolf · dekningsregister (prototype, 02.10.2026)

Alt er syntetisk. Status gjelder prototypen: **tegnet** = skjerm finnes, **klikkbar** = handlinger virker på syntetiske data, **testet** = klikkprøve kjørt i ekte iframe 1440 og 390 (se status.md). Lokal API-status er «må kobles» til den er avstemt mot `pipelines/datagolf/client.py` og prøvd med konto. Kundevisning er ikke avklart (DataGolf-vilkår punkt 13: personlig, ikke-kommersiell bruk).

## Skjermer
| ID | Skjerm | Datakontrakt (API-familie) | Tilstander | Tegnet | Klikkbar | Testet |
|---|---|---|---|---|---|---|
| DG-01 | Analyseoversikt, dekning, lagrede utvalg | alle | laster, feil, avtale | ja | ja (lagre/åpne utvalg) | 1440, 390 |
| DG-02 | Spillerkatalog (søk, land, tour, amatør/proff, kilde-ID, sortering, feltvalg) | Spillere, Ranking | tomt søk | ja | ja | 1440, 390 |
| DG-03 | Spillerprofil (oversikt, resultater, SG, modell, innspill, historikk, rådata) | Spillere, Skill ratings, Historiske runder/resultater, Ferdighetsnedbrytning | ingen SG i kilden, lite grunnlag, identitetskonflikt | ja | ja | 1440, 390 |
| DG-04 | Topplister (11 kategorier, tour, kjønn, status, periode, min. runder, utelatte) | Skill ratings, Historiske runder | tomt, delvis | ja | ja | 1440, 390 |
| DG-05 | Sammenligning 2–4 spillere + referanse (bare trenerroller) | Historiske runder | under to valgt, lite grunnlag, sperret for spiller | ja | ja | 1440, 390 |
| DG-06 | Innspill avstand × lie | Approach skill | lite grunnlag per bøtte | ja | ja (spillervalg) | 1440, 390 |
| DG-07 | Historikk turnering → runde | Historiske runder/resultater | mangler i kilden per kategori, MC, WD | ja | ja | 1440, 390 |
| DG-08 | Turneringskalender, felt, starttider, endringer | Terminliste, Felt og starttider | — | ja | ja | 1440, 390 |
| DG-09 | Turneringsanalyse: feltstyrke, fordeling, banerunder, poeng/premie | Ranking, Historiske resultater | poeng/premie mangler i kilden | ja | lesing | 1440, 390 |
| DG-10 | Live med kildeklokke, forsinkelse, hullfordeling | Live-modell, Live turnerings-/hullstatistikk | oppdateringsfeil (siste data) | ja | ja (feil/prøv igjen) | 1440, 390 |
| DG-11 | Modellanalyse: rank, ferdighet, dekomponering, sannsynligheter | Ranking, Førturneringsmodell, Ferdighetsnedbrytning | — | ja | lesing | 1440, 390 |
| DG-12 | Bane og felt | Terminliste, Historiske runder, Ferdighetsnedbrytning | udokumentert bane | ja | lesing | 1440, 390 |
| DG-13 | Trend, referansegrupper, tabellbygger, nettside-begrensninger | Historiske runder | mangler i kilden | ja | ja | 1440, 390 |
| DG-14 | Datautforsker: datasett, feltkatalog (135 modellfelt), søk, klasse/modell-filter, kolonnevalg, 10/25/alle per side, klientendepunkter, eksport låst | alle | tomt filter, eksport krever avtale, roller | ja | ja | 1440, 390 |
| DG-15 | Kilde og dekning: tour × år, kildefeil, identitet, API-familier | alle | kildehull | ja | lesing | 1440, 390 |
| DG-16 | Analyse til tiltak → Workbench-forslag → spiller godtar/avviser | Skill ratings, Approach skill + Workbench | avvist, utdatert basis, godtatt én gang | ja | ja | 1440, 390 |
| DG-17 | Spesialistdata (odds/fantasy), kun voksen intern | Fantasy, Odds, Historiske odds/DFS | utenfor rolle (spiller), ikke aktivert (TN/WANG) | ja | lesing, ingen handlinger | 1440, 390 |

## API-familier
Se fanen Kilde og dekning (DG-15) og Datautforsker (DG-14). 18 familier + «utgåtte endepunkter» (føres fra lokalt register; ikke bekreftet her). Spesialistfamilier: krever egen avtale.

## Nettsidefunksjoner
Herreranking (API: ranking, må kobles), kvinneranking, amatørranking, pressanalyse, spørringsverktøy, egne modeller, lagkonkurranser: mangler i kilden (bare nettsted). Prestasjon/trend og karriere: avledes fra historiske runder/resultater (må kobles).

## Målinger som holdes adskilt
DataGolf målt SG · DataGolf modellestimat · Broadie-beregning · AK-nivåtall · PEI. Brutto score. Lengde i meter (kilde i yards). SG-skala symmetrisk om null. Null, ukjent (—), lite grunnlag, mangler i kilden og manglende avtale har egne tilstander.


## Feltkatalog og endepunkter (oppdatert 02.10.2026)
- Kilde: `pipelines/datagolf/schema.py` (SHA-256 2fbca8d3…677f) og `client.py` (SHA-256 22ec9970…71ef). Kildekoden er kontrollert av Codex; faktiske spillerdata, kontotilgang og feltdekning er ikke prøvd.
- `felt.js`: 135 kildefelt på 16 modeller. Klasser: metadata, målt, modell, marked, intern drift (DgSyncState, 8), beholder (RoundWithSg, 2). De 135 er ikke 135 sportslige mål og ikke en komplett API-respons.
- Aldri kundevisning: params_hash, params_json, s3_key, last_error. Bearbeidet kundevisning: last_synced_at (oppdateringstid), last_status (kildefeil uten rå melding), row_count (dekning). endpoint vises som kildenavn.
- Marked (odds/DFS: DgOutrightOdds, DgMatchupOdds, DgDfsPoints): bare voksen intern analytikerrolle, ingen spillhandling; krever egen avtale.
- Enheter: *_y og length_yards = yards (meter avledet × 0,9144). *_pct og sannsynligheter: kildeskala uavklart. skill_* og true_skill: enhet uavklart. Målt 0, manglende (—) og 0 % holdes atskilt.
- 21 implementerte klientmetoder med API-familie og lokal modell. Live-modell, live turnerings- og hullstatistikk har ingen lagringsmodell i schema.py. Fantasyprognoser og oddsverktøy: dokumentert familie uten klientmetode («ikke implementert»). Utgåtte endepunkter: ikke kartlagt i vedlagt kilde.
- Kvinne-, amatør- og juniordekning er ikke bevist (DgTour.gender og DgPlayer.amateur finnes som felt; innholdet er ikke prøvd).
- Synlig per rolle i DG-14 (prøvd 02.10.2026 i 1440-iframe): voksen intern analytiker 135 (inkl. 24 markeds-/fantasyfelt og 8 interne driftsfelt; intern rolle, ikke kunde). AK-trener, TN-trener, WANG-trener og spiller 107 hver: 4 interne driftsfelt (params_hash, params_json, s3_key, last_error) og 24 markeds-/fantasyfelt skjult. DG-17 og spesialistdatasett: bare analytiker.
- Spillerrollen: DG-05 Sammenligning, DG-04 Topplister, DG-02 Spillerkatalog, DG-13 Trend/referansegrupper og DG-16 Tiltak er sperret, også via direkte lenke (#sammen o.l.); meny, innganger, lagrede utvalg og «Sammenlign» i profil er skjult. Egen profil, innspill, historikk, turneringer, modell, bane, utforsk og kilde beholdes.
- Egen tilstand «Lite grunnlag» (?state=lite) i tilstander.html.
