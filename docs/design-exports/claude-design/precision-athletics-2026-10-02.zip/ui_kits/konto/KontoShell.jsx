(() => {
const { KitShell, G } = window.KIT;
const NAV = [
  G("profil", "Profil", "user-round", [["profil", "Spillerprofil", "user-round"], ["personvern", "Personvern", "shield-check"]]),
];
function KontoShell() {
  return <KitShell nav={NAV} bare={["innlogging"]} store="konto-page" fallback="innlogging" who={{ name: "Emma Solberg", role: "SPILLER · KATEGORI D" }} screens={{ innlogging: Innlogging, profil: SpillerProfil, personvern: PersonvernGdpr }} />;
}
window.KontoShell = KontoShell;
})();
