/* AU-04 Oppstart for spiller — runde 23 (Anders 28.09.2026). Rekkefølge:
   Om deg (alder, HCP, snittscore, turneringsnivå, SG i år og forrige sesong) · Fasiliteter · Finn deg i turneringsresultatene ·
   Teknikktest (anbefalt, bygger på Inspill Basic) · Samtykker · Velg treningsplan · Klar. Coach og forelder bruker flyten fra før. */
(() => {
const Old = (window.FO_SCREENS["AU-04"] || {}).Component;
const STEPS = ["Om deg", "Fasiliteter", "Finn deg i resultatene", "Teknikktest", "Samtykker", "Velg treningsplan", "Klar"];
const CLUBS = [["sw", "Sandwedge", 70], ["i7", "7-jern", 140], ["dr", "Driver", 220]];
const DEMO_SHOTS = { sw: [[68, 3.1], [73, 4.4], [66, 5.2], [71, 2.8], [69, 3.9]], i7: [[134, 9.2], [146, 11.8], [138, 8.1], [131, 12.4], [142, 7.6]], dr: [[214, 18.0], [226, 21.5], [208, 16.2], [219, 24.1], [223, 19.4]] };
const TM = [["Club Path", "°", 2.4], ["Face Angle", "°", 2.1], ["Face to Path", "°", 2.6], ["Attack Angle", "°", 1.2], ["Dynamic Loft", "°", 1.8], ["Club Speed", "mph", 1.6]];
const catOf = (avg) => { const C = window.AK_VOCAB.CATEGORIES; const i = C.findIndex((c) => avg < c[2]); return i < 0 ? null : C[i]; };
const d1 = (v) => v == null || isNaN(v) ? "—" : (v < 0 ? "−" : "") + Math.abs(v).toFixed(1).replace(".", ",");

function AU04S({ state, step0 }) {
  const { Button, FormField, TextInput, Select, Segmented, LoadingState, ErrorState, ChoicePill, InlineAlert, Checkbox, StatusPill } = window.AGQ.ns(), A = window.AGQ, { Box, H } = window.AUB, U = window.FAS_UI, FA = window.FAS;
  const demo = state !== "tom";
  const [role, setRole] = React.useState("Spiller"), [step, setStep] = React.useState(step0 || 0);
  const [me, setMe] = React.useState(demo ? { born: "2009", hcp: "8,4", avg: "75,2", lvl: "Region · Srixon Tour", sg: "−2,2", sgPrev: "" } : { born: "", hcp: "", avg: "", lvl: "", sg: "", sgPrev: "" });
  const [fas, setFas] = React.useState([]), [fasOpen, setFasOpen] = React.useState(false);
  const [q, setQ] = React.useState(demo ? { mode: "Navn og fødselsår", id: "", name: "Tobias Lindvik", born: "2009" } : { mode: "Navn og fødselsår", id: "", name: "", born: "" }), [hit, setHit] = React.useState(null), [linked, setLinked] = React.useState(false);
  const [tool, setTool] = React.useState("TrackMan"), [dist, setDist] = React.useState(Object.fromEntries(CLUBS.map(([k, , m]) => [k, String(m)]))), [shots, setShots] = React.useState(demo ? DEMO_SHOTS : {}), [ran, setRan] = React.useState(false);
  const [cons, setCons] = React.useState({ yb: true, rec: true }), [pmail, setPmail] = React.useState("");
  const [plan, setPlan] = React.useState(null);
  if (role !== "Spiller" && Old) return <Old state={state} role0={role} onRole={setRole} />;
  if (state === "laster") return <Box><LoadingState text="Gjør klart kontoen …" /></Box>;
  if (state === "feil") return <Box><ErrorState title="Oppsettet kunne ikke lagres" text="Svarene dine er lagret på enheten. Prøv igjen." code="FEIL 502 · ONBOARDING" onRetry={() => A.toast("Prøver igjen", "—")} /></Box>;
  const age = me.born ? 2026 - +me.born : null, u16 = age != null && age < 16;
  const avgN = parseFloat(String(me.avg).replace(",", ".")), cat = isNaN(avgN) ? null : catOf(avgN);
  const set = (k) => (e) => setMe({ ...me, [k]: e.target.value });
  const s = STEPS[step];
  const skip = <Button variant="ghost" onClick={() => setStep(step + 1)}>Hopp over</Button>;
  let body, canNext = true, optional = false;
  if (s === "Om deg") {
    canNext = !!me.born;
    body = <>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 12 }}>
        <FormField label="Fødselsår" required hint={age != null ? age + " år" : undefined}><TextInput mono inputMode="numeric" value={me.born} onChange={(e) => setMe({ ...me, born: e.target.value.replace(/\D/g, "").slice(0, 4) })} placeholder="2009" /></FormField>
        <FormField label="HCP"><TextInput mono inputMode="decimal" value={me.hcp} onChange={set("hcp")} placeholder="—" /></FormField>
        <FormField label="Snittscore" hint="Siste 10 runder, brutto"><TextInput mono inputMode="decimal" value={me.avg} onChange={set("avg")} placeholder="—" /></FormField>
        <Select label="Turneringsnivå" value={me.lvl} onChange={set("lvl")} options={["", "Ingen turneringer", "Klubb", "Region · Srixon Tour", "Nasjonalt", "Internasjonalt"].map((x) => ({ value: x, label: x || "Velg" }))} />
        <FormField label="SG i år" optional hint="Hvis du har det"><TextInput mono value={me.sg} onChange={set("sg")} placeholder="—" /></FormField>
        <FormField label="SG forrige sesong" optional hint="Hvis du har det"><TextInput mono value={me.sgPrev} onChange={set("sgPrev")} placeholder="—" /></FormField>
      </div>
      <A.Meta>{cat ? "KATEGORI " + cat[0] + " · " + cat[1].toUpperCase() + " · ESTIMAT FRA SNITTSCORE" : "KATEGORI —"}{u16 ? " · UNDER 16: FORELDER GIR SAMTYKKE" : ""}</A.Meta>
    </>;
  }
  if (s === "Fasiliteter") {
    optional = true;
    body = <>
      <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Hvor trener du? Legg inn så mange du vil. Ett spørsmål om gangen. Du kan fullføre senere i Meg.</p>
      {fas.length > 0 && <div role="list">{fas.map((f, i) => <div role="listitem" key={f.id} style={{ display: "flex", justifyContent: "space-between", gap: 8, minHeight: 44, alignItems: "center", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ font: "500 14px/1.3 var(--font-sans)" }}>{f.name}</span><A.Meta>{FA.covers(f).length} OMRÅDER</A.Meta></div>)}</div>}
      {fasOpen ? <U.FasSkjema onCancel={() => setFasOpen(false)} onSave={(f) => { setFas((l) => [...l, f]); setFasOpen(false); A.toast("Fasiliteten er lagt til", f.name.toUpperCase()); }} /> : <><U.Dekning list={fas} compact /><div><Button variant="secondary" icon="plus" onClick={() => setFasOpen(true)}>{fas.length ? "Legg til en til" : "Legg til fasilitet"}</Button></div></>}
    </>;
  }
  if (s === "Finn deg i resultatene") {
    optional = true;
    const search = () => { const byId = q.mode === "Golf-ID"; const ok = byId ? /^\d{6,8}$/.test(q.id) : q.name.trim().split(/\s+/).length >= 2 && /^\d{4}$/.test(q.born); if (!ok) { setHit([]); return; } const [fn, ...rest] = q.name.trim().split(/\s+/); const ln = rest[rest.length - 1]; setHit(byId || (/^tobias$/i.test(fn) && /^lindvik$/i.test(ln || "") && q.born === "2009") ? [{ name: "Tobias Andreas Lindvik", born: 2009, club: "Fredrikstad GK", id: "4410982", n: 14, last: "Srixon Tour · runde 5 · 13.09.2026 · 74 (+3)" }] : []); };
    body = <>
      <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Vi henter turneringsresultatene dine fra GolfBox. Søk med golf-ID, eller navn og fødselsår. Mellomnavn ignoreres.</p>
      <Segmented options={["Golf-ID", "Navn og fødselsår"]} value={q.mode} onChange={(v) => { setQ({ ...q, mode: v }); setHit(null); }} fullWidth />
      {q.mode === "Golf-ID" ? <FormField label="Golf-ID"><TextInput mono inputMode="numeric" value={q.id} onChange={(e) => setQ({ ...q, id: e.target.value.replace(/\D/g, "").slice(0, 8) })} placeholder="1234567" /></FormField>
        : <div style={{ display: "grid", gridTemplateColumns: "minmax(0,2fr) minmax(0,1fr)", gap: 12 }}><FormField label="Fornavn og etternavn"><TextInput value={q.name} onChange={(e) => setQ({ ...q, name: e.target.value })} placeholder="Tobias Lindvik" /></FormField><FormField label="Fødselsår"><TextInput mono inputMode="numeric" value={q.born} onChange={(e) => setQ({ ...q, born: e.target.value.replace(/\D/g, "").slice(0, 4) })} placeholder="2009" /></FormField></div>}
      <div><Button variant="secondary" icon="search" onClick={search}>Søk</Button></div>
      {hit && (hit.length ? hit.map((h) => <div key={h.id} style={{ display: "flex", flexDirection: "column", gap: 6, padding: "12px 0", borderTop: "1px solid var(--border-hairline)" }}><span style={{ font: "600 14px/1.3 var(--font-sans)" }}>{h.name} · {h.born}</span><A.Meta>{h.club.toUpperCase()} · GOLF-ID {h.id} · {h.n} RESULTATER</A.Meta><A.Meta>SISTE: {h.last.toUpperCase()}</A.Meta>{linked ? <StatusPill tone="ok">Koblet</StatusPill> : <div><Button icon="check" onClick={() => { setLinked(true); A.toast("Resultatene er koblet", h.n + " RESULTATER · HENTES HVER NATT"); }}>Dette er meg</Button></div>}</div>) : <A.Meta>INGEN TREFF · SJEKK STAVING ELLER BRUK GOLF-ID · DU KAN KOBLE SENERE I MEG › PROFIL</A.Meta>)}
    </>;
  }
  if (s === "Teknikktest") {
    optional = true;
    const res = CLUBS.map(([k, n]) => { const L = shots[k] || [], t = +dist[k] || 0, err = L.length ? L.reduce((a, x) => a + x[1], 0) / L.length : null; return { k, n, t, err, rel: err != null && t ? err / t : null }; });
    const worst = res.filter((r) => r.rel != null).sort((a, b) => b.rel - a.rel)[0];
    const tmWorst = TM.slice().sort((a, b) => b[2] - a[2])[0];
    const setShot = (k, i, j, v) => setShots((S) => { const L = (S[k] || Array.from({ length: 5 }, () => [null, null])).map((x) => x.slice()); L[i][j] = v === "" ? null : +v; return { ...S, [k]: L }; });
    body = <>
      <InlineAlert tone="info" title="Anbefalt, ikke påkrevd">Bygger på Inspill Basic. Fem slag med sandwedge, 7-jern og driver på din egen avstand. Resultatet viser største svakhet. Det setter ikke nivå.</InlineAlert>
      <Segmented options={["TrackMan", "TrackMan Range", "Banen"]} value={tool} onChange={setTool} fullWidth />
      {CLUBS.map(([k, n]) => <section key={k} aria-label={n} style={{ display: "flex", flexDirection: "column", gap: 8, paddingTop: 12, borderTop: "1px solid var(--border-hairline)" }}>
        <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) 112px", gap: 12, alignItems: "end" }}><span style={{ font: "600 15px/1.3 var(--font-sans)" }}>{n}</span><FormField label="Din avstand (m)"><TextInput mono inputMode="numeric" value={dist[k]} onChange={(e) => setDist({ ...dist, [k]: e.target.value.replace(/\D/g, "").slice(0, 3) })} /></FormField></div>
        <div role="table" aria-label={n + " slag"} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) minmax(0,1fr)", gap: 6, alignItems: "center" }}>
          <A.Meta>#</A.Meta><A.Meta>CARRY (M)</A.Meta><A.Meta>FRA MÅL (M)</A.Meta>
          {Array.from({ length: 5 }, (_, i) => { const x = (shots[k] || [])[i] || [null, null]; return <React.Fragment key={i}><A.Meta>{i + 1}</A.Meta><TextInput mono inputMode="decimal" aria-label={n + " slag " + (i + 1) + " carry"} value={x[0] == null ? "" : String(x[0])} onChange={(e) => setShot(k, i, 0, e.target.value.replace(/[^\d.]/g, ""))} placeholder="—" /><TextInput mono inputMode="decimal" aria-label={n + " slag " + (i + 1) + " fra mål"} value={x[1] == null ? "" : String(x[1])} onChange={(e) => setShot(k, i, 1, e.target.value.replace(/[^\d.]/g, ""))} placeholder="—" /></React.Fragment>; })}
        </div>
      </section>)}
      {tool === "TrackMan" && <section aria-label="Fra TrackMan" style={{ display: "flex", flexDirection: "column", gap: 4, paddingTop: 12, borderTop: "1px solid var(--border-hairline)" }}><A.Meta>FRA TRACKMAN · SPREDNING OG VARIASJON · 7-JERN</A.Meta>{TM.map(([p, u, sd], i) => <div key={p} style={{ display: "flex", justifyContent: "space-between", minHeight: 36, alignItems: "center", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ font: "400 14px/1.3 var(--font-sans)" }}>{p}</span><span style={{ font: "600 13px/1 var(--font-mono)" }}>{demo ? "±" + d1(sd) + " " + u : "—"}</span></div>)}</section>}
      {tool !== "TrackMan" && <A.Meta>{tool === "Banen" ? "PÅ BANEN: MÅL AVSTAND MED LASER ELLER SKRITT · CARRY ANSLÅS" : "TRACKMAN RANGE GIR CARRY OG AVSTAND FRA MÅL · IKKE KØLLEDATA"}</A.Meta>}
      <div><Button variant="secondary" icon="check" disabled={!worst} onClick={() => setRan(true)}>Vis resultat</Button></div>
      {ran && worst && <section aria-label="Resultat" style={{ display: "flex", flexDirection: "column", gap: 6, padding: 12, borderRadius: 8, background: "var(--surface-sunken)" }}><A.Meta>STØRSTE SVAKHET</A.Meta><span style={{ font: "600 15px/1.4 var(--font-sans)", textWrap: "pretty" }}>{worst.n}: {d1(worst.err)} m fra mål i snitt på {worst.t} m ({Math.round(worst.rel * 100)} % av avstanden).{tool === "TrackMan" && demo ? " Størst variasjon: " + tmWorst[0] + " ±" + d1(tmWorst[2]) + "°." : ""}</span><A.Meta>{res.map((r) => r.n.toUpperCase() + " " + d1(r.err) + " M").join(" · ")} · SETTER IKKE NIVÅ</A.Meta></section>}
    </>;
  }
  if (s === "Samtykker") {
    body = u16 ? <>
      <InlineAlert tone="info" title={"Du er " + age + " år"}>Under 16 år gir forelderen samtykket. Vi sender en lenke.</InlineAlert>
      <FormField label="Forelderens e-post" required><TextInput type="email" inputMode="email" value={pmail} onChange={(e) => setPmail(e.target.value)} placeholder="navn@epost.no" /></FormField>
      <A.Meta>YTELSESBILDE OG OPPTAK ER AV TIL FORELDEREN HAR SVART</A.Meta>
    </> : <>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <Checkbox checked={cons.yb} onChange={(e) => setCons({ ...cons, yb: e.target.checked })} label="Ytelsesbilde: søvn, mat og energi lagres og deles med coachen" />
        <Checkbox checked={cons.rec} onChange={(e) => setCons({ ...cons, rec: e.target.checked })} label="Opptak i coachingøkt: video og lyd fra timene lagres på profilen din" />
      </div>
      <A.Meta>KAN ENDRES NÅR SOM HELST I MEG › INNSTILLINGER</A.Meta>
    </>;
    if (u16) canNext = /^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(pmail);
  }
  if (s === "Velg treningsplan") {
    canNext = !!plan;
    const P5 = (window.AK_IA && window.AK_IA.treningsplaner) || ["Weekend Warrior", "Klubbspilleren", "Junior-aspirant", "Konkurransespilleren", "Practice like the pros"];
    const H5 = { "Weekend Warrior": "3–4 t per uke", "Klubbspilleren": "5–7 t per uke", "Junior-aspirant": "8–12 t per uke", "Konkurransespilleren": "12–16 t per uke", "Practice like the pros": "18–24 t per uke" };
    body = <>
      <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Alle fem planene kan velges i alle kategorier A–K. Innholdet tilpasses kategorien din{cat ? " (Kategori " + cat[0] + ")" : ""}. Du velger selv, og kan bytte senere i Plan.</p>
      <div role="radiogroup" aria-label="Treningsplan" style={{ display: "flex", flexDirection: "column" }}>{P5.map((p, i) => <button key={p} type="button" role="radio" aria-checked={plan === p} onClick={() => setPlan(p)} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", display: "grid", gridTemplateColumns: "20px minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 56, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}><span style={{ width: 18, height: 18, borderRadius: 999, border: "2px solid var(--text-primary)", boxShadow: plan === p ? "inset 0 0 0 3px var(--surface-card), inset 0 0 0 9px var(--text-primary)" : "none" }}></span><span style={{ font: "500 14px/1.3 var(--font-sans)" }}>{p}</span><A.Meta>{H5[p]}</A.Meta></button>)}</div>
    </>;
  }
  if (s === "Klar") body = <p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-secondary)" }}>PlayerHQ er klar{plan ? " med " + plan : ""}. Start med I dag.{fas.length ? "" : " Fasilitetene kan du legge inn i Meg."}</p>;
  return <Box max={s === "Teknikktest" ? 600 : 560}>
    {step === 0 && <Segmented options={["Spiller", "Coach", "Forelder"]} value={role} onChange={(v) => { setRole(v); setStep(0); }} fullWidth />}
    <A.Meta>SPILLER · STEG {step + 1} AV {STEPS.length}{optional ? " · KAN HOPPES OVER" : ""}</A.Meta>
    <div aria-hidden="true" style={{ display: "grid", gridTemplateColumns: "repeat(" + STEPS.length + ",minmax(0,1fr))", gap: 4 }}>{STEPS.map((x, i) => <span key={x} style={{ height: 4, background: i <= step ? "var(--primary)" : "var(--surface-sunken)" }}></span>)}</div>
    <H t={s} />{body}
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{step > 0 && <Button variant="ghost" onClick={() => setStep(step - 1)}>Tilbake</Button>}{step < STEPS.length - 1 ? <><Button disabled={!canNext} onClick={() => setStep(step + 1)}>Fortsett</Button>{optional && skip}</> : <Button icon="arrow-right" onClick={() => A.toast("Velkommen", "PLAYERHQ")}>Start</Button>}</div>
  </Box>;
}
window.FO_SCREENS["AU-04"] = { id: "AU-04", name: "Oppstart", route: "/onboarding", bare: true, Component: AU04S };
STEPS.forEach((n, i) => { if (!i) return; window.FO_SCREENS["AU-04-" + (i + 1)] = { id: "AU-04-" + (i + 1), parent: "AU-04", name: "Oppstart · steg " + (i + 1) + " · " + n, route: "/onboarding?steg=" + (i + 1), bare: true, Component: (p) => <AU04S {...p} step0={i} /> }; });
})();
