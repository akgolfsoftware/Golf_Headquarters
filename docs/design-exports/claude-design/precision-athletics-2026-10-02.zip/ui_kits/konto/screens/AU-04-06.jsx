(() => {
function AU04({ state, role0, onRole }) {
  const { Button, FormField, TextInput, Select, Segmented, LoadingState, ErrorState, ChoicePill, InlineAlert } = window.AGQ.ns(), A = window.AGQ, { Box, H } = window.AUB;
  const [role, setRole] = React.useState(role0 || "Spiller"), [step, setStep] = React.useState(0), [goals, setGoals] = React.useState([]);
  if (state === "laster") return <Box><LoadingState text="Gjør klart kontoen …" /></Box>;
  if (state === "feil") return <Box><ErrorState title="Oppsettet kunne ikke lagres" text="Svarene dine er lagret på enheten. Prøv igjen." code="FEIL 502 · ONBOARDING" onRetry={() => A.toast("Prøver igjen", "—")} /></Box>;
  const FLOW = { Spiller: ["Om deg", "Målsetning", "Koble coach", "Klar"], Coach: ["Om deg", "Grupper", "Koble TrackMan", "Klar"], Forelder: ["Om deg", "Koble barn", "Varsler", "Klar"] }[role];
  const s = FLOW[step];
  let body;
  if (s === "Om deg") body = <><FormField label="Fornavn"><TextInput defaultValue={role === "Forelder" ? "Hanne" : role === "Coach" ? "Anders" : "Tobias"} /></FormField>{role === "Spiller" && <FormField label="Fødselsår" hint="Spillere under 16 trenger samtykke fra forelder."><TextInput mono defaultValue="2009" /></FormField>}<Select label="Klubb" options={["Borregaard GK", "Fredrikstad GK", "Hvaler GK"]} /></>;
  if (s === "Målsetning") body = <><p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Velg opptil tre. Coachen bruker dette når planen lages.</p><div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{["Lavere snitt", "Lengre utslag", "Bedre innspill", "Bedre putting", "Spille turneringer", "Komme på WANG"].map((g) => <ChoicePill key={g} selected={goals.includes(g)} onClick={() => setGoals((l) => l.includes(g) ? l.filter((x) => x !== g) : l.length < 3 ? [...l, g] : l)}>{g}</ChoicePill>)}</div></>;
  if (s === "Koble coach" || s === "Koble barn") body = <><FormField label="Koblingskode" hint={s === "Koble barn" ? "Du får koden fra barnet eller coachen." : "Du får koden fra coachen."}><TextInput mono placeholder="AK-4F7Q" /></FormField><A.Meta>KAN GJØRES SENERE</A.Meta></>;
  if (s === "Grupper") body = <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{["Mini", "Basis", "Utvikling", "Elite", "Knøtt", "WANG Toppidrett"].map((g) => <ChoicePill key={g} selected={goals.includes(g)} onClick={() => setGoals((l) => l.includes(g) ? l.filter((x) => x !== g) : [...l, g])}>{g}</ChoicePill>)}</div>;
  if (s === "Koble TrackMan") body = <InlineAlert tone="info" title="TrackMan">Kobles i Oppsett · Integrasjoner. Du kan hoppe over dette nå.</InlineAlert>;
  if (s === "Varsler") body = <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Du får ukerapport lørdag og e-post når en booking er bekreftet. Endres under Coach og innstillinger.</p>;
  if (s === "Klar") body = <p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-secondary)" }}>{role === "Coach" ? "AgencyOS er klar. Start med Cockpit." : role === "Forelder" ? "Forelderportalen er klar. Start med I dag." : "PlayerHQ er klar. Start med I dag."}</p>;
  return <Box max={520}>
    {step === 0 && <Segmented options={["Spiller", "Coach", "Forelder"]} value={role} onChange={(v) => { setRole(v); setStep(0); setGoals([]); onRole && onRole(v); }} fullWidth />}
    <A.Meta>{role.toUpperCase()} · STEG {step + 1} AV {FLOW.length}</A.Meta>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(" + FLOW.length + ",minmax(0,1fr))", gap: 4 }}>{FLOW.map((x, i) => <span key={x} style={{ height: 4, background: i <= step ? "var(--primary)" : "var(--surface-sunken)" }}></span>)}</div>
    <H t={s} />{body}
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{step > 0 && <Button variant="ghost" onClick={() => setStep(step - 1)}>Tilbake</Button>}{step < FLOW.length - 1 ? <Button onClick={() => setStep(step + 1)}>Fortsett</Button> : <Button icon="arrow-right" onClick={() => A.toast("Velkommen", role.toUpperCase())}>Start</Button>}</div>
  </Box>;
}
function AU05({ state }) {
  const { Button, KeyValue, Checkbox, InlineAlert, LoadingState, StatusPill, Segmented } = window.AGQ.ns(), A = window.AGQ, { Box, H } = window.AUB;
  const [view, setView] = React.useState("Forelder"), [ok, setOk] = React.useState({ video: true, test: false }), [done, setDone] = React.useState(false);
  if (state === "laster") return <Box><LoadingState text="Åpner samtykket …" /></Box>;
  if (state === "feil") return <Box><H k="Samtykke" t="Lenken virker ikke" s="Lenken er brukt eller utløpt etter 7 dager. Be coachen sende en ny. Lenken gir aldri tilgang til noe annet enn selve samtykket." /></Box>;
  if (state === "tom") return <Box><H k="Samtykke" t="Ingenting å samtykke til" s="Denne forespørselen er trukket tilbake av coachen." /></Box>;
  return <Box max={520}>
    <Segmented options={["Forelder", "Spiller"]} value={view} onChange={setView} />
    {view === "Spiller" ? <><H k="Samtykke" t="Venter på forelder" s="Hanne Lindvik har fått en lenke på e-post. Du kan bruke PlayerHQ som vanlig, men video og deling av tester er av til samtykket er gitt." /><StatusPill tone={done ? "ok" : "info"}>{done ? "Samtykke gitt 26.09" : "Venter på forelder"}</StatusPill></>
      : done ? <><H k="Samtykke" t="Takk, samtykket er registrert" s="Du kan endre eller trekke samtykket når som helst i forelderportalen under Samtykke." /><KeyValue items={[["Gitt av", "Hanne Lindvik", { mono: false }], ["Tid", "26.09.2026 " + new Date().toTimeString().slice(0, 5)], ["Svingvideo", ok.video ? "Ja" : "Nei", { mono: false }], ["Deling av tester", ok.test ? "Ja" : "Nei", { mono: false }]]} /></>
      : <><H k="Samtykke for Ada Lindvik · 13 år" t="Anders Kristiansen ber om samtykke" s="Velg hva du samtykker til. Du kan trekke samtykket senere." />
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}><Checkbox checked={ok.video} onChange={(e) => setOk({ ...ok, video: e.target.checked })} label="Svingvideo på treningsområdet · deles med coach og forelder · 12 mnd" /><Checkbox checked={ok.test} onChange={(e) => setOk({ ...ok, test: e.target.checked })} label="Deling av testresultater med NGF region Øst" /></div>
        <InlineAlert tone="neutral">Denne lenken gir bare tilgang til dette samtykket. Den logger deg ikke inn og viser ingen andre data.</InlineAlert>
        <Button fullWidth size="lg" onClick={() => { setDone(true); A.toast("Samtykket er registrert", "REGISTRERT MED TID"); }}>Bekreft samtykke</Button></>}
  </Box>;
}
function AU06({ state }) {
  const { PageHeader, EmptyState, DataTable, InlineAlert, SegmentedFilter } = window.AGQ.ns(), A = window.AGQ, R = window.FO_DATA.reader, { desk } = A.useW(), empty = state === "tom";
  const vis = (p) => p.born != null && (p.born < 2008 || p.consent) && p.consent;
  const P = (empty ? [] : R.players).filter(vis), hidden = (empty ? 0 : R.players.length) - P.length;
  const [sel, setSel] = React.useState("Alle");
  const rows = P.filter((p) => sel === "Alle" || p.name === sel);
  return <A.Page max={1100}>
    <PageHeader kicker={"Innsyn · " + R.who} title="Innsyn" sub={"Samtykkede resultater for " + R.scope + ". Bare lesetilgang. Kun brutto score."} />
    <A.Gate state={state} loading="Henter samtykkede resultater …" error={{ title: "Innsyn kunne ikke hentes", text: "Tilgangen din kan være trukket. Kontakt Anders Kristiansen.", code: "FEIL 403 · INNSYN" }}>
      <InlineAlert tone="info" title="Bare samtykkede spillere">Spillere født 2008 eller senere uten samtykke vises aldri. Spillere uten fødselsår vises ikke.{hidden ? " " + hidden + " spillere er ikke med." : ""}</InlineAlert>
      {empty || !P.length ? <EmptyState icon="eye-off" title="Ingen samtykkede resultater" text="Du ser resultater når spilleren eller forelderen har gitt samtykke til deg." /> : <>
        <SegmentedFilter label="Spiller" value={sel} onChange={setSel} options={["Alle"].concat(P.map((p) => p.name))} />
        {rows.map((p) => <A.Card key={p.name} gap={10}><A.Head k={p.name + " · " + p.grp} aside={"FØDT " + p.born} />
          <DataTable caption="Runder · brutto · GOLFBOX" rowKey="0" columns={[{ key: "0", label: "Dato", mono: true }, { key: "1", label: "Bane" }, { key: "2", label: "Brutto", mono: true, align: "right" }]} rows={p.rounds.map((r) => ({ ...r }))} />
          {p.tests.length > 0 && <DataTable caption="Tester" rowKey="0" columns={[{ key: "0", label: "Test" }, { key: "1", label: "Resultat", mono: true, align: "right" }, { key: "2", label: "Dato", mono: true }]} rows={p.tests.map((r) => ({ ...r }))} />}
        </A.Card>)}
      </>}
    </A.Gate>
  </A.Page>;
}
window.FO_SCREENS = window.FO_SCREENS || {};
window.FO_SCREENS["AU-04"] = { id: "AU-04", name: "Onboarding", route: "/onboarding", bare: true, Component: AU04 };
window.FO_SCREENS["AU-05"] = { id: "AU-05", name: "Samtykke via lenke", route: "/samtykke/[token]", bare: true, Component: AU05 };
window.FO_SCREENS["AU-06"] = { id: "AU-06", name: "Innsyn (ekstern leser)", route: "/innsyn", bare: true, Component: AU06 };
})();
