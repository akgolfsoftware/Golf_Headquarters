(() => {
const { Button, Avatar, Segmented, StatusPill, IconButton } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, Grid, Mono, Kv, useW } = window.KIT;
const BAG = [
  ["Driver", "Titleist TSR2", "9,0°", "Fujikura Ventus Blue 6", "S"],
  ["3-tre", "Titleist TSR2", "15,0°", "Fujikura Ventus Blue 7", "S"],
  ["Hybrid", "Titleist TSR2", "21,0°", "Tensei AV Blue 80", "S"],
  ["4-jern", "Titleist T200", "22,0°", "KBS Tour 120", "S"],
  ["5-jern", "Titleist T100", "25,0°", "KBS Tour 120", "S"],
  ["6-jern", "Titleist T100", "28,0°", "KBS Tour 120", "S"],
  ["7-jern", "Titleist T100", "32,0°", "KBS Tour 120", "S"],
  ["8-jern", "Titleist T100", "36,0°", "KBS Tour 120", "S"],
  ["9-jern", "Titleist T100", "41,0°", "KBS Tour 120", "S"],
  ["PW", "Titleist T100", "46,0°", "KBS Tour 120", "S"],
  ["Wedge 50", "Vokey SM10 F", "50,0°", "Dynamic Gold S200", "Wedge"],
  ["Wedge 54", "Vokey SM10 S", "54,0°", "Dynamic Gold S200", "Wedge"],
  ["Wedge 58", "Vokey SM10 M", "58,0°", "Dynamic Gold S200", "Wedge"],
  ["Putter", "Scotty Cameron Phantom 7", "3,0°", "Stål · 34\"", "—"],
];
const ROLES = { Spiller: "Du ser PlayerHQ: dagens økt, plan og egne data.", Coach: "Du ser AgencyOS: stall, kalender og workbench.", Forelder: "Du ser foreldreportalen for Emma.", Admin: "Du ser økonomi, brukere og tilganger." };

function SpillerProfil({ go }) {
  const w = useW();
  const [role, setRole] = React.useState("Spiller");
  const table = w >= 900;
  return (
    <div style={pageWrap}>
      <PageHead kicker="Profil" title="Emma Solberg" actions={<Button variant="secondary" icon="pencil">Rediger</Button>} />
      <Panel kicker="Aktiv rolle" title="Se appen som" pad={20}>
        <Segmented options={Object.keys(ROLES)} value={role} onChange={setRole} size="lg" fullWidth={w < 700} />
        <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{ROLES[role]}</span>
      </Panel>
      <Grid min={320} gap={24} style={{ alignItems: "start" }}>
        <Panel kicker="Stamdata">
          <div style={{ display: "flex", gap: 16, alignItems: "center", flexWrap: "wrap" }}>
            <Avatar name="Emma Solberg" size={64} />
            <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0, flex: 1 }}>
              <span style={{ font: "var(--type-title-m)", color: "var(--text-primary)" }}>Emma Solberg</span>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                <span aria-label="Kategori D" style={{ height: 28, minWidth: 28, padding: "0 10px", boxSizing: "border-box", borderRadius: 999, background: "var(--primary)", color: "var(--text-on-primary)", display: "inline-grid", placeItems: "center", font: "600 13px/1 var(--font-sans)" }}>Kategori D</span>
                <StatusPill tone="neutral">Målsetning: B</StatusPill>
              </div>
            </div>
          </div>
          <div>
            <Kv k="Klubb" v="Gamle Fredrikstad Golfklubb" mono={false} />
            <Kv k="Hjemmebane" v="GFGK · 18 hull · par 72" mono={false} />
            <Kv k="Brutto score, snitt siste 10" v="75,2" />
            <Kv k="Beste runde 2026" v="71 · 14.08" />
            <Kv k="Født" v="14.03.2012" />
            <Kv k="Coach" v="Anders Kristiansen" mono={false} last />
          </div>
        </Panel>
        <Panel kicker="Bag-oppsett" title="14 køller" pad={table ? 0 : "var(--card-pad)"} style={table ? { gap: 0 } : null}
          action={table ? null : <IconButton icon="plus" label="Legg til kølle" />}>
          {table ? (
            <div role="table">
              <div role="row" style={{ display: "grid", gridTemplateColumns: "96px minmax(0,1fr) 64px minmax(0,1.1fr) 56px", gap: 12, padding: "12px 24px", borderTop: "1px solid var(--border-hairline)", borderBottom: "1px solid var(--border-hairline)", font: "var(--type-kicker)", letterSpacing: "var(--tracking-kicker)", textTransform: "uppercase", color: "var(--text-muted)" }}><span>Kølle</span><span>Modell</span><span style={{ textAlign: "right" }}>Loft</span><span>Skaft</span><span>Flex</span></div>
              {BAG.map((c, i) => (
                <div role="row" key={c[0]} style={{ display: "grid", gridTemplateColumns: "96px minmax(0,1fr) 64px minmax(0,1.1fr) 56px", gap: 12, padding: "0 24px", minHeight: 40, alignItems: "center", borderBottom: i < BAG.length - 1 ? "1px solid var(--border-hairline)" : "none" }}>
                  <span style={{ font: "500 14px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{c[0]}</span>
                  <span style={{ font: "var(--type-body-s)", color: "var(--text-body)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c[1]}</span>
                  <Mono s={{ textAlign: "right", color: "var(--text-primary)" }}>{c[2]}</Mono>
                  <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c[3]}</span>
                  <Mono s={{ color: "var(--text-secondary)" }}>{c[4]}</Mono>
                </div>))}
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column" }}>
              {BAG.map((c, i) => (
                <div key={c[0]} style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 4, padding: "10px 0", borderTop: i ? "1px solid var(--border-hairline)" : "none" }}>
                  <span style={{ font: "500 14px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{c[0]}</span><Mono s={{ color: "var(--text-primary)", textAlign: "right" }}>{c[2]}</Mono>
                  <span style={{ font: "400 13px/1.3 var(--font-sans)", color: "var(--text-secondary)", gridColumn: "1 / -1" }}>{c[1]} · {c[3]} · {c[4]}</span>
                </div>))}
            </div>
          )}
        </Panel>
      </Grid>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button variant="ghost" icon="shield-check" onClick={() => go("personvern")}>Personvern og data</Button><Button variant="ghost" icon="log-out" onClick={() => go("innlogging")}>Logg ut</Button></div>
    </div>
  );
}
window.SpillerProfil = SpillerProfil;
})();
