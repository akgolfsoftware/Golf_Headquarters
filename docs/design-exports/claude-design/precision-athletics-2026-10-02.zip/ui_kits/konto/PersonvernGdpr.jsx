(() => {
const { Button, Input, InlineAlert, Icon, StatusPill } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, Grid, Mono, Kv, download } = window.KIT;
const CATS = [["Profil og kontaktinfo", 1], ["Treningsøkter", 412], ["Registrerte slag", 18640], ["TrackMan-økter", 96], ["Tester og baseline", 38], ["Turneringsrunder", 27], ["Meldinger", 214], ["Samtykker og revisjon", 6]];
const INFO = [
  ["Hva vi lagrer", "Økter, slag, testresultater, TrackMan-data, runder og meldinger mellom deg, coach og foresatte."],
  ["Hvor data ligger", "På servere i EØS (Stockholm og Frankfurt). Kryptert både under lagring og overføring."],
  ["Hvem som ser dem", "Du, coachene dine og foresatte til du er 18. Ingen data selges eller deles med tredjepart."],
  ["Hvor lenge", "Så lenge du er aktiv. Etter 3 år uten aktivitet anonymiseres treningsdata automatisk."],
];

function PersonvernGdpr() {
  const [exp, setExp] = React.useState(false);
  const [del, setDel] = React.useState("idle");
  const [word, setWord] = React.useState("");
  const exportJson = () => { setExp(true); download("ak-golf-emma-solberg-" + "2026-09-25.json", JSON.stringify({ eksportert: "2026-09-25T14:32:00+02:00", spiller: { navn: "Emma Solberg", klubb: "Gamle Fredrikstad Golfklubb", kategori: "D" }, kategorier: Object.fromEntries(CATS) }, null, 2), "application/json"); };
  return (
    <div style={pageWrap}>
      <PageHead kicker="Personvern · Emma Solberg" title="Dine data og rettighetene dine" sub="Du eier treningsdataene dine. Her kan du se hva vi lagrer, laste dem ned eller slette kontoen." />
      <Grid min={260}>
        {INFO.map(([t, d]) => <Panel key={t} pad={20} style={{ gap: 8 }}><span style={{ font: "var(--type-title-s)", color: "var(--text-primary)" }}>{t}</span><span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{d}</span></Panel>)}
      </Grid>
      <Grid min={380} gap={24} style={{ alignItems: "start" }}>
        <Panel kicker="Innsyn og dataportabilitet" title="Last ned alle mine data">
          <div>{CATS.map(([k, n], i) => <Kv key={k} k={k} v={n.toLocaleString("nb-NO")} last={i === CATS.length - 1} />)}</div>
          <div><Button icon="file-down" onClick={exportJson}>Last ned alle mine data (JSON)</Button></div>
          {exp && <InlineAlert tone="ok" title="Nedlasting startet">Fila inneholder alt over i maskinlesbart format. Videofiler sendes som egen lenke på e-post innen 24 timer.</InlineAlert>}
        </Panel>
        <Panel kicker="Retten til sletting" title="Slett kontoen">
          {del === "done" ? <>
            <InlineAlert tone="warn" title="Sletting planlagt">Kontoen slettes <span style={{ fontFamily: "var(--font-mono)" }}>25.10.2026</span>. Frem til da kan du angre ved å logge inn.</InlineAlert>
            <div><Button variant="secondary" onClick={() => { setDel("idle"); setWord(""); }}>Angre sletting</Button></div>
          </> : <>
            <p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-body)", textWrap: "pretty" }}>Profil, meldinger og video slettes. Treningsdata anonymiseres: navnet fjernes, men tallene kan brukes i akademiets statistikk uten at noen kan spore dem til deg.</p>
            <ul style={{ margin: 0, paddingLeft: 18, display: "flex", flexDirection: "column", gap: 4, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>
              <li>30 dagers angrefrist</li><li>Fakturaer beholdes i 5 år etter bokføringsloven</li><li>Foresatte får beskjed hvis du er under 18</li>
            </ul>
            {del === "confirm" ? <div style={{ display: "flex", flexDirection: "column", gap: 12, paddingTop: 16, borderTop: "1px solid var(--border-hairline)" }}>
              <Input label={'Skriv SLETT for å bekrefte'} mono value={word} onChange={(e) => setWord(e.target.value.toUpperCase())} />
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button variant="signal" icon="trash-2" disabled={word !== "SLETT"} onClick={() => setDel("done")}>Slett min konto og anonymiser mine treningsdata</Button><Button variant="ghost" onClick={() => { setDel("idle"); setWord(""); }}>Avbryt</Button></div>
            </div> : <div><Button variant="secondary" icon="trash-2" onClick={() => setDel("confirm")}>Slett min konto</Button></div>}
          </>}
        </Panel>
      </Grid>
      <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>BEHANDLINGSANSVARLIG: AK GOLF AS · PERSONVERNOMBUD: PERSONVERN@AKGOLF.NO · SIST OPPDATERT 01.09.2026</span>
    </div>
  );
}
window.PersonvernGdpr = PersonvernGdpr;
})();
