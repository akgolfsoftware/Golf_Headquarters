(() => {
const { Button, Input, Icon, InlineAlert } = window.AKGolfPrecisionAthletics_7d7c29;
const { Mono } = window.KIT;

function CodeInput({ value, onChange, label }) {
  const refs = React.useRef([]);
  const set = (i, ch) => { const d = value.split(""); d[i] = ch; const v = d.join("").slice(0, 6); onChange(v); if (ch && i < 5) refs.current[i + 1]?.focus(); };
  const paste = (e) => { const t = (e.clipboardData.getData("text") || "").replace(/\D/g, "").slice(0, 6); if (t) { e.preventDefault(); onChange(t); refs.current[Math.min(5, t.length)]?.focus(); } };
  return (
    <div role="group" aria-label={label} style={{ display: "grid", gridTemplateColumns: "repeat(6,minmax(0,1fr))", gap: 8 }}>
      {Array.from({ length: 6 }, (_, i) => (
        <input key={i} ref={(el) => (refs.current[i] = el)} value={value[i] || ""} inputMode="numeric" autoComplete={i === 0 ? "one-time-code" : "off"} maxLength={1} aria-label={"Siffer " + (i + 1)} onPaste={paste}
          onChange={(e) => set(i, e.target.value.replace(/\D/g, "").slice(-1))} onKeyDown={(e) => { if (e.key === "Backspace" && !value[i] && i > 0) refs.current[i - 1]?.focus(); }}
          style={{ width: "100%", minWidth: 0, height: 56, boxSizing: "border-box", textAlign: "center", borderRadius: 8, border: "1px solid " + (value[i] ? "var(--border-ink)" : "var(--border-control)"), background: "var(--surface-card)", font: "600 22px/1 var(--font-mono)", fontVariantNumeric: "tabular-nums", color: "var(--text-primary)", outline: "none" }} />
      ))}
    </div>
  );
}

function Innlogging({ go }) {
  const [step, setStep] = React.useState("epost");
  const [mail, setMail] = React.useState("emma.solberg@example.no");
  const [code, setCode] = React.useState("");
  const [sms, setSms] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const wait = (fn) => { setBusy(true); setTimeout(() => { setBusy(false); fn(); }, 700); };
  const H = ({ k, t, s }) => <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><span className="kicker">{k}</span><h1 style={{ margin: 0, font: "600 24px/1.2 var(--font-sans)", letterSpacing: "var(--tracking-display)", color: "var(--text-primary)", textWrap: "balance" }}>{t}</h1>{s && <p style={{ margin: 0, font: "var(--type-body)", color: "var(--text-secondary)", textWrap: "pretty" }}>{s}</p>}</div>;
  return (
    <div style={{ minHeight: "100%", display: "flex", flexDirection: "column", alignItems: "center", padding: "48px var(--page-x) 24px", boxSizing: "border-box", gap: 32 }}>
      <img src="../../assets/logo-ak-golf-hq.svg" alt="AK Golf HQ" style={{ height: 22, display: "block" }} />
      <div style={{ width: "100%", maxWidth: 420, background: "var(--surface-card)", border: "1px solid var(--border-hairline)", borderRadius: 12, padding: "var(--card-pad)", boxSizing: "border-box", display: "flex", flexDirection: "column", gap: 24, boxShadow: "var(--shadow-card)" }}>
        {step === "epost" && <>
          <H k="Logg inn" t="Velkommen tilbake" s="Vi sender deg en innloggingslenke. Ingen passord å huske." />
          <Input label="E-post" type="email" autoComplete="email" size="lg" value={mail} onChange={(e) => setMail(e.target.value)} onKeyDown={(e) => e.key === "Enter" && mail && wait(() => setStep("sendt"))} />
          <Button size="lg" fullWidth icon="mail" disabled={!mail.includes("@")} loading={busy} loadingText="SENDER LENKE…" onClick={() => wait(() => setStep("sendt"))}>Send innloggingslenke</Button>
        </>}
        {step === "sendt" && <>
          <H k="Sjekk e-posten" t="Lenken er sendt" />
          <div style={{ display: "flex", gap: 12, alignItems: "center", padding: 12, borderRadius: 8, background: "var(--surface-sunken)", minWidth: 0 }}><Icon name="mail" size={18} /><Mono s={{ fontSize: 14, color: "var(--text-primary)", overflowWrap: "anywhere", minWidth: 0 }}>{mail}</Mono></div>
          <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Trykk på lenken i e-posten på denne enheten. Lenken gjelder i 15 minutter.</p>
          <div style={{ display: "flex", alignItems: "center", gap: 12, font: "var(--type-meta)", color: "var(--text-muted)" }}><span style={{ flex: 1, height: 1, background: "var(--border-hairline)" }}></span>ELLER SKRIV INN KODEN<span style={{ flex: 1, height: 1, background: "var(--border-hairline)" }}></span></div>
          <CodeInput value={code} onChange={setCode} label="Engangskode fra e-post" />
          <Button size="lg" fullWidth disabled={code.length < 6} loading={busy} loadingText="SJEKKER KODE…" onClick={() => wait(() => setStep("sms"))}>Fortsett</Button>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><Button variant="ghost" size="sm" icon="arrow-left" onClick={() => { setStep("epost"); setCode(""); }}>Annen e-post</Button><Button variant="ghost" size="sm" icon="refresh-cw">Send på nytt</Button></div>
        </>}
        {step === "sms" && <>
          <H k="Tofaktor · Steg 2 av 2" t="Bekreft med SMS" s="Vi har sendt en kode til mobilnummeret ditt." />
          <div style={{ display: "flex", gap: 12, alignItems: "center", padding: 12, borderRadius: 8, background: "var(--surface-sunken)" }}><Icon name="smartphone" size={18} /><Mono s={{ fontSize: 14, color: "var(--text-primary)" }}>+47 ••• •• 567</Mono></div>
          <CodeInput value={sms} onChange={setSms} label="Kode fra SMS" />
          <Button size="lg" fullWidth disabled={sms.length < 6} loading={busy} loadingText="LOGGER INN…" onClick={() => wait(() => go("profil"))}>Logg inn</Button>
          <InlineAlert tone="neutral">Ingen SMS etter 60 sekunder? Sjekk at nummeret stemmer, eller kontakt coach.</InlineAlert>
        </>}
      </div>
      <p style={{ margin: "auto 0 0", font: "var(--type-meta)", color: "var(--text-muted)", textAlign: "center", maxWidth: 420 }}>AK GOLF HQ · DATA LAGRES I EØS · <a href="#personvern" onClick={(e) => { e.preventDefault(); go("personvern"); }}>PERSONVERN</a></p>
    </div>
  );
}
window.Innlogging = Innlogging;
})();
