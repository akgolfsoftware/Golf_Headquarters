/* Dekningsregister X01–X18. Status er ærlig: "klikkbar" = del av kjeden i iup.html; "registrert" = bare kontrakt, ikke tegnet. Ingen spørsmålstekst dikta opp. */
window.IUP_REG = [
["X01","Veiledning","PH-IUP-01","sesongstart, minimumsopplysninger, mangler, fortsett senere","Utkast per steg","Siste steg","–","Spiller","Oppstart + Meg","–","registrert"],
["X02","Mitt team","PH-IUP-02","fagrolle, kontakt, ansvar","Lagres","Endringslogg","Kontakt ≠ appinnsyn","Spiller","Meg","–","registrert"],
["X03","Profil","PH-IUP-03","navn, fødselsår, klubb, skole, GolfBox, ansvarlige","Lagres","Endringslogg","Helsedel kun etter eget samtykke","Spiller (syntetisk)","Meg","–","registrert"],
["X04","Sesongevaluering","PH-IUP-04","3 fritekst, 10 vurderinger 1–4, faktisk/ønsket % på 5 områder, ≥3 forbedringspunkter","Utkast / fullført","Per sesong","Delt innhold etter valg","Spiller","Plan / Målsetning","Sesongtekst fra kilde vist; prosentfordeling ikke bygd","klikkbar"],
["X05","Målsetting/oppfølging","PH-IUP-05","kvartal/sesong, SG, PEI, tid, runder (Utslag, ikke Driving)","Lagres","Kvartal + sesong","Etter delt kategori","Faktisk gjennomføring","Stats","Sesong okt–sep = rapportvindu; grenser uten overlapp må låses av Codex","delvis klikkbar (tid, antall)"],
["X06","Prosessmål","PH-IUP-06","kobling til mål, handling, område, start/slutt, kriterium, ansvarlig, evaluering","Utkast / aktiv","Revisjoner","Foreslå, ikke endre","Fra X04","Målsetning","–","klikkbar"],
["X07","Årsplan","PH-IUP-07 (AG-11-AR / PH-11)","uke-fokus og prioritet per FYS/TEK/SLAG/SPILL/TURN, perioder, steder","Utkast / publisert","Revisjon","Foreslå","Plan","Plan","Nivåeksempler = valgfri mal","registrert (se Workbench-forslag)"],
["X08","Turneringsplan","PH-IUP-08","WAGR Power med år/kilde, uke, land/tour, reise, nivåbalanse","Lagres","Revisjon","Foreslå","Kilde pr. turnering","Plan","Ranking/feltstyrke ≠ Power","registrert"],
["X09","Ukeplan","PH-IUP-09","grunn/spesial/turnering, tid på døgnet, antall/tid, treukerssyklus, tester","Utkast / publisert","Revisjon","Foreslå","Plan","Plan","–","klikkbar (økt i uke)"],
["X10","Økter","PH-IUP-10","oppvarming, basisøkter, hensikt, reps/tid, utstyr, maler, progresjon","Utkast / publisert","Revisjon","Foreslå","Plan","Plan","Ett hovedfokus per økt","klikkbar (økt)"],
["X11","Utviklingssjekk","PH-IUP-11","Ung 34 · Junior 43 · Amatør 47 · Proff 38 spørsmål, 7 tema, skala 1–5","Lagre underveis / fullført","Alle versjoner bevares","Etter delt kategori","2027-kravversjon","Meg","Eksakt tekst lagret (162 spørsmål, kildemateriale/iup-2027-kilde-2026-10-01.json). Kilde-skrivefeil bevart og meldt. Ikke prøvd av bruker; sluttdekning ikke påstått.","klikkbar (utkast)"],
["X12","Tester","PH-IUP-12","felles katalog, dato, egenført/kontrollert, retest","Lagres","Per test","Etter delt kategori","Katalog","Stats","–","registrert"],
["X13","Teknikktest","PH-IUP-13","A/B, sju felt (Swing Direction … Club Speed), 24 diagram via valg","Lagres","Per måling","Etter delt kategori","Rådata","Stats","A/B-antall og formler motstridende: vis rådata, ingen score","registrert"],
["X14","Teknikkplan","PH-IUP-14","hvorfor, ballflukt nå/ønsket, GOBBS, drill, ferdiguke","Utkast / publisert","Kilde-ID + revisjon","Foreslå","AG-TP","Plan","Må ikke gjeninnføre gammel AG-10 eller mellomposisjoner","registrert"],
["X15","Fystester","PH-IUP-15","resultatserier, valgbare protokoller, 3000 m tabell","Lagres","Per test","Etter delt kategori","Protokoll","Stats","Sumformel ≠ vekttabell: ingen scoring","registrert"],
["X16","Dagbok","PH-IUP-16","etterregistrering + automatisk fra gjennomføring","Lagres","Per dag","Etter delt kategori","Faktisk tid","I dag / Stats","Ingen dobbelttelling mellom øktmodeller","klikkbar"],
["X17","Referanser","PH-IUP-17","SG/PEI etter avstand/plassering, kilde, utvalg","Lesing","Versjon","–","Kilde/dato","Stats","Ikke bland metoder i ett tall","registrert"],
["X18","Skjult Ref","(ingen skjerm)","versjonert puttreferanse m. grenseprøver","–","Versjon","–","Kilde","–","Ikke eget ark i spillerappen","registrert"]];
window.IUP_X05 = { tid:{plan:60,dagbok:0,ant:0}, sg:null };
