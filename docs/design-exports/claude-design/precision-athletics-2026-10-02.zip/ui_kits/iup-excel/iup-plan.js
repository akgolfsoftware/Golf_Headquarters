/* Plan-flaten (årsplan/periode/måned/uke/økt + turneringer). Gjenbruker Workbench-forslagets syntetiske data (WBD) og visningsdeler (WBC): ingen egen planmotor. Spilleren ser bare publiserte økter og egne planlagte økter – aldri trenerutkast. */
(() => {
const W = window.WBD, C = window.WBC, { add, dow, dm, dd, F, P, D } = W;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
const MN = ["januar", "februar", "mars", "april", "mai", "juni", "juli", "august", "september", "oktober", "november", "desember"];
const TUR = [
 { id: "t3", navn: "Høstturnering (syntetisk)", fra: "2026-10-16", til: "2026-10-18", hull: 54, land: "Norge", tour: "Nasjonal", power: 33.0, ref: "2025", kilde: "WAGR (syntetisk)", ut: "2026-10-15", hjem: "2026-10-18" },
 { id: "t1", navn: "Nyttårsturnering (syntetisk)", fra: "2026-12-29", til: "2027-01-01", hull: 72, land: "Spania", tour: "Syntetisk Tour", power: 41.5, ref: "2026", kilde: "WAGR (syntetisk)", ut: "2026-12-28", hjem: "2027-01-02" },
 { id: "t2", navn: "Vårturnering (syntetisk)", fra: "2027-03-19", til: "2027-03-21", hull: 54, land: "Norge", tour: "Nasjonal", power: null, ref: null, kilde: null, ut: "2027-03-18", hjem: "2027-03-21" }];
const days = (a, b) => Math.round((P(b) - P(a)) / D) + 1, lab = (a, b) => dm(a) + (a.slice(0, 4) !== b.slice(0, 4) ? " " + a.slice(0, 4) : "") + "–" + dm(b) + " " + b.slice(0, 4);
const wkOf = (d) => W.weeks.find((w) => w.fra <= d && d <= w.til), nm = (k) => k.slice(-2);
const band = (p) => p == null ? "ukjent" : p >= 45 ? "høy" : p >= 35 ? "middels" : "lav";
const num = (n) => String(n).replace(".", ",");
function sessions(S) {
 const l = W.sessions.filter((s) => s.st === "Publisert").map((s) => ({ ...s, own: false }));
 if (S.sess) l.push({ ...W.sessions.find((s) => s.id === "s4"), st: "Planlagt av deg", own: true, reg: S.act });
 if (S.prop && S.prop.st === "godtatt") l.push({ id: "sx", dato: "2026-10-03", ax: "tek", fra: "10:00", til: "11:00", navn: "Teknikkøkt (godtatt forslag)", st: "Planlagt av deg", own: true, reg: null, ov: [] });
 return l;
}
function cw(w, S) { const c = { ...w, reg: { ...w.reg } }; return c }
function ctx(S) { const w = wkOf(S.pl.date), p = W.periods.find((x) => x.id === w.per); return `<p class="note">Valgt: <b>${dd(S.pl.date)}</b> · uke ${nm(w.key)} · ${esc(p.navn)} · Sesong 2026/27</p>` }
function lvls(S) { const L = [["ar", "År"], ["periode", "Periode"], ["mnd", "Måned"], ["uke", "Uke"], ["okt", "Økt"], ["tur", "Turneringer"]]; return `<div class="seg wrap" role="group" aria-label="Plannivå">${L.map(([k, t]) => `<button class="${S.pl.lvl === k ? "on" : ""}" data-a="plv" data-v="${k}" aria-pressed="${S.pl.lvl === k}">${t}</button>`).join("")}</div>` }
function pmFor(S, id) { return id === "p1" && S.pm.length ? `<p class="note">Prosessmål: ${S.pm.map(esc).join(" · ")}</p>` : id === "p1" ? `<p class="note">Ingen prosessmål ennå. <button class="lnk" data-a="tab" data-v="malsetning">Gjør sesongevalueringen</button></p>` : "" }
function ar(S) {
 return `<div class="stack"><p class="note">${C.range(W.plan.fra, W.plan.til)} · over årsskiftet</p>${W.periods.map((p) => { const nw = W.weeks.filter((w) => w.per === p.id).length; return `<section class="card"><div class="wh"><div><h4>${esc(p.navn)}</h4><small>${C.range(p.fra, p.til)} · ${nw} uker${p.fra.slice(0, 4) !== p.til.slice(0, 4) ? " · går over årsskiftet" : ""}</small></div><button class="btn${p.id === S.pl.per ? " pri" : ""}" data-a="pper" data-v="${p.id}">Åpne periode</button></div><p>${esc(p.fokus)}</p><p class="note">Mål: ${esc(p.mal)}</p>${pmFor(S, p.id)}${C.perSumHtml(p.id)}</section>` }).join("")}
 <section class="card"><h4>Hendelser</h4><small>Ikke treningsperioder</small><div class="row" style="margin-top:6px">${W.events.map((e) => `<button class="btn" data-a="pdate" data-v="${e.fra}">${esc(e.navn)} · ${lab(e.fra, e.til)}</button>`).join("")}</div></section>${C.legend()}</div>`;
}
function periode(S) {
 const p = W.periods.find((x) => x.id === S.pl.per), ws = W.weeks.filter((w) => w.per === p.id);
 return `<div class="stack"><section class="card"><span class="kick">${C.range(p.fra, p.til)}</span><h3>${esc(p.navn)}</h3><p>${esc(p.fokus)}</p><p class="note">Mål: ${esc(p.mal)}</p>${pmFor(S, p.id)}${C.perSumHtml(p.id)}</section>
 ${ws.map((w) => `<button class="wkb ${w.key === S.pl.wk ? "sel" : ""}" data-a="pwk" data-v="${w.key}"><span><b>Uke ${nm(w.key)}</b> <small>${C.range(w.fra, w.til)}${w.cur ? " · pågår" : w.future ? " · kommer" : ""}</small></span>${C.weekCells(cw(w, S), null)}</button>`).join("")}${C.legend()}</div>`;
}
function mnd(S) {
 const [y, m] = S.pl.mon.split("-").map(Number), s = S.pl.mon + "-01", e = F(Date.UTC(y, m, 0)), ws = W.weeks.filter((w) => w.fra <= e && w.til >= s);
 const prev = F(Date.UTC(y, m - 2, 1)).slice(0, 7), next = F(Date.UTC(y, m, 1)).slice(0, 7), ok = (k) => k >= W.plan.fra.slice(0, 7) && k <= W.plan.til.slice(0, 7);
 return `<div class="stack"><div class="wh"><button class="btn" data-a="pmon" data-v="${prev}" ${ok(prev) ? "" : "disabled"} aria-label="Forrige måned">‹ Forrige</button><h3>${MN[m - 1]} ${y}</h3><button class="btn" data-a="pmon" data-v="${next}" ${ok(next) ? "" : "disabled"} aria-label="Neste måned">Neste ›</button></div>
 ${ws.map((w) => { const x = w.fra < s || w.til > e; return `<button class="wkb ${w.key === S.pl.wk ? "sel" : ""}" data-a="pwk" data-v="${w.key}"><span><b>Uke ${nm(w.key)}</b> <small>${C.range(w.fra, w.til)}${x ? " · går over månedsskifte, telles én gang (i uka)" : ""}</small></span>${C.weekCells(cw(w, S), null)}</button>` }).join("")}${C.legend()}</div>`;
}
function uke(S) {
 const w = wkOf(S.pl.date), p = W.periods.find((x) => x.id === w.per), ss = sessions(S), wd = Array.from({ length: 7 }, (_, i) => add(w.fra, i)), inW = ss.filter((s) => s.dato >= w.fra && s.dato <= w.til), pl = {}; W.AX.forEach((a) => { pl[a] = inW.filter((s) => s.ax === a).length });
 return `<div class="stack"><div><span class="kick">Uke ${nm(w.key)} · ${C.range(w.fra, w.til)}</span><h3>${dd(S.pl.date)}</h3><small>${esc(p.navn)}${w.cur ? " · pågår" : ""}</small></div>
 <div class="strip" role="group" aria-label="Velg dag">${wd.map((d) => `<button class="${d === S.pl.date ? "on" : ""}" data-a="pdate" data-v="${d}" aria-pressed="${d === S.pl.date}"><small>${W.DAG[dow(d)]}</small>${+d.slice(8)}</button>`).join("")}</div>
 <section class="card"><h4>Mål i uka</h4>${S.pm.length ? `<ul class="lst">${S.pm.map((m) => `<li>${esc(m)}</li>`).join("")}</ul>` : `<p class="note">Ingen prosessmål ennå. <button class="lnk" data-a="tab" data-v="malsetning">Gjør sesongevalueringen</button></p>`}</section>
 <section class="card"><h4>Økter</h4>${inW.length ? inW.sort((a, b) => (a.dato + a.fra).localeCompare(b.dato + b.fra)).map((s) => `<button class="arow2 ${s.dato === S.pl.date ? "sel" : ""}" data-a="pdate" data-v="${s.dato}"><span class="t">${dd(s.dato)} ${s.fra}–${s.til}</span><span>${esc(s.navn)}</span>${C.chip(s.ax)}<small>${s.st}${s.reg != null ? " · reg. " + s.reg + " min" : ""}</small></button>`).join("") : `<p class="note">Ingen økter.</p>`}
 <div class="row" style="margin-top:8px">${!S.sess ? `<button class="btn pri" data-a="plv" data-v="okt">Planlegg økt fre 2. okt.</button>` : `<button class="btn" data-a="plv" data-v="okt">Åpne økta</button>`}<button class="btn" data-a="tab" data-v="stats">Åpne i Stats</button></div></section>
 <section class="card"><h4>Ukens mengde</h4>${C.weekCells(cw(w, S), pl)}<small>Antall = budsjett/plassert (kun publisert og dine egne).</small></section>${C.legend()}</div>`;
}
function okt(S) {
 if (!S.pm.length) return `<div class="gate"><b>Velg et prosessmål først</b><p class="note">Fullfør evalueringen under Målsetning, så kan du planlegge økta.</p><button class="btn" data-a="tab" data-v="malsetning">Til Målsetning</button></div>`;
 return `<div class="stack"><h3>Økt · fre 2. okt.</h3>${ctx(S)}<label class="f">Koble til prosessmål<select id="mal">${S.pm.map((m, i) => `<option value="${i}" ${S.sess && S.sess.mal === i ? "selected" : ""}>${esc(m)}</option>`).join("")}</select></label>
 <button class="btn pri" data-a="plan" ${S.sess ? "disabled" : ""}>${S.sess ? "Planlagt: fre 2. okt. 09:00–10:00, 60 min" : "Planlegg økt (60 min, hovedfokus Teknisk)"}</button>
 ${S.sess ? `<section class="card"><h4>Overgang P5.0–P6.0 · Teknisk</h4><small>Planlagt 60 min · ${S.act == null ? "ikke registrert" : "registrert " + S.act + " min"} · revisjon ${S.rev}</small><ul class="lst">${W.sessions.find((s) => s.id === "s4").ov.map((o) => `<li>${esc(o)}</li>`).join("")}</ul><div class="row"><button class="btn pri" data-a="tab" data-v="stats">${S.act == null ? "Registrer i Stats" : "Se i Stats"}</button><button class="btn" data-a="endre">Flytt til 10:00 (endrer planen)</button><button class="btn" data-a="plv" data-v="uke">Tilbake til uke ${nm(wkOf(S.pl.date).key)}</button></div></section>` : ""}</div>`;
}
function tur(S) {
 const R = TUR.map((t) => { const cd = days(t.fra, t.til), tr = days(t.ut, t.hjem) - cd, a = W.wkKey(t.fra), b = W.wkKey(t.til); return { ...t, cd, tr, uk: a === b ? "U" + nm(a) : "U" + nm(a) + "–U" + nm(b) } });
 const sum = (k) => R.reduce((s, t) => s + t[k], 0), bal = { høy: 0, middels: 0, lav: 0, ukjent: 0 }; R.forEach((t) => bal[band(t.power)]++);
 return `<div class="stack"><p class="note">Power er WAGR Power med referanseår og kilde. Ranking og annen feltstyrke er ikke Power. Nivågrensene er syntetiske.</p>${R.map((t) => `<section class="card"><div class="wh"><div><h4>${esc(t.navn)}</h4><small>${lab(t.fra, t.til)} · ${t.uk} · ${t.land} · ${t.tour}</small></div><button class="btn" data-a="ptour" data-v="${t.fra}">Åpne uke</button></div>${(() => { const r = [["Hull", t.hull], ["Konkurransedager", t.cd], ["Reisedager", t.tr], ["Utreise – hjem", dm(t.ut) + " – " + dm(t.hjem)], ["Power", t.power == null ? "— (ikke fastsatt)" : num(t.power) + " · referanseår " + t.ref + " · " + t.kilde]]; return `<dl class="kv">${r.map(([k, v]) => `<dt>${k}</dt><dd${/^\d+$/.test(String(v)) ? ' class="num"' : ""}>${v}</dd>`).join("")}</dl>` })()}${t.power != null && t.ref !== "2026" ? `<p class="note">Referanseåret er eldre enn sesongen – kontroller Power.</p>` : ""}<div class="row"><button class="btn" data-a="toast" data-v="Åpner før/under/etter-konkurranse (eksisterende flyt)">Før / under / etter</button></div></section>`).join("")}
 <section class="card"><h4>Sesongsum</h4>${(() => { const r = [["Turneringer", R.length], ["Konkurransedager", sum("cd")], ["Reisedager", sum("tr")], ["Nivåbalanse (Power)", `høy ${bal.høy} · middels ${bal.middels} · lav ${bal.lav} · ukjent ${bal.ukjent}`]]; return `<dl class="kv">${r.map(([k, v]) => `<dt>${k}</dt><dd${/^\d+$/.test(String(v)) ? ' class="num"' : ""}>${v}</dd>`).join("")}</dl>` })()}<small>Dager telles én gang; hull og uker er atskilt fra dager.</small></section></div>`;
}
window.IUPPLAN = {
 init(S) { S.pl = { lvl: "uke", per: "p1", wk: "2026-U40", date: "2026-10-02", mon: "2026-10" } },
 render(S) { return `<div class="stack"><h2>Plan</h2>${lvls(S)}${S.pl.lvl !== "okt" ? ctx(S) : ""}${{ ar, periode, mnd, uke, okt, tur }[S.pl.lvl](S)}</div>` },
 sync(S) { const w = W.weeks.find((x) => x.cur); if (w) w.reg.tek = 55 + (S.act || 0) },
 actions(S) {
  const setDate = (d) => { S.pl.date = d; const w = wkOf(d); if (w) { S.pl.wk = w.key; S.pl.per = w.per; S.pl.mon = d.slice(0, 7) } };
  return {
   plv: (v) => { S.pl.lvl = v }, pdate: (v) => { setDate(v); S.pl.lvl = "uke" }, ptour: (v) => { setDate(v); S.pl.lvl = "uke" },
   pwk: (v) => { const w = W.weeks.find((x) => x.key === v); setDate(add(w.fra, dow(S.pl.date))); S.pl.lvl = "uke" },
   pper: (v) => { const p = W.periods.find((x) => x.id === v); if (!(p.fra <= S.pl.date && S.pl.date <= p.til)) { const w = W.weeks.find((x) => x.per === v); setDate(add(w.fra, dow(S.pl.date))) } else S.pl.per = v; S.pl.lvl = "periode" },
   pmon: (v) => { S.pl.mon = v }
  };
 }
};
})();
