# Utviklingssjekk — Team Norways IUP-ark 2025 (ordlyd fra kilden)

Kilde: Team Norway IUP-mal 2025, fane «9. Utviklingssjekk 5 Prosesser». Skala 1–8 per spørsmål. Stavefeil i kilden er rettet (Spörsmål, gjennomfär, AMATÖR); engelske linjer står som i kilden.

## Ung (13–15)

### Sosial
1. Jeg er fornøyd med hvordan det fungerer med vennene mine
2. Jeg har noen å snakke med om personlige saker
3. Jeg er en god venn for vennene mine
4. Jeg får støtte i golfsatsingen min

### Mentalt
1. Min mentale tilstand er
2. Mine forventninger er i balanse med min innsats
3. Andres forventninger er i balanse med mine egne
4. Min motivasjon for trening er

### Fysisk
1. Kostholdet jeg spiser er av god kvalitet
2. Mengden mat jeg spiser er
3. Min fysiske form for trening er

### Strategisk
1. Min plan for å håndtere livet er
2. Planen min for å takle skolearbeid er
3. Jeg er i fase med skolen
4. Jeg tar avgjørelser i livet som jeg vinner i det lange løp

### Teknisk
1. Jeg har et klart bilde av hvordan jeg skal stille opp for ballen.
2. Jeg har et klart bilde/film av hvordan jeg skal bevege kroppen min.
3. Jeg vet hvordan det skal føles når jeg stiller opp rett etter ballen.
4. Jeg vet hvordan det skal føles når jeg beveger kroppen på riktig måte.
5. Jeg kjenner gode spillere hvis sving jeg sammenligner meg med og ønsker å etterligne.
6. Jeg forstår hvorfor jeg må stå opp og bevege meg på en bestemt måte.
7. Jeg vet hva mønstrene mine er innen teknikk
8. Jeg har øvelser/øvelser som vil hjelpe meg med å trene riktig svingbevegelse.

### Golfutvikling
1. Jeg har klare mål for golfutviklingen min
2. Min treningsplan for golfutviklingen min er
3. Jeg implementerer innholdet i planleggingen min
4. Jeg gjennomfører mengden trening i planleggingen min
5. Jeg har treningskompiser

### Neste trinn
1. Jeg dokumenterer og evaluerer treningen/turneringen min
2. Jeg har balanse mellom golf og livet utenfor golfen
3. Energinivået mitt til å takle trening og livet generelt er
4. Jeg tar beslutninger om golf som jeg vinner i det lange løp
5. Jeg har funnet ut ting jeg trenger for å ta gode beslutninger
6. Jeg har forutsetninger for å gjennomføre treningen min (lokaler/treningsområde etc.)

## Junior (–19)

### Sosial
1. Jeg er fornøyd med hvordan det fungerer med vennene mine
2. Jeg har noen å snakke med om personlige saker
3. Jeg er en god venn for vennene mine
4. Jeg får støtte i golfsatsingen min

### Mentalt
1. Min mentale tilstand er
2. Jeg har balanse mellom golf og livet utenfor golfen
3. Mine forventninger er i balanse med min innsats
4. Andres forventninger er i balanse med mine egne
5. Min motivasjon for trening er

### Fysisk
1. Energinivået mitt til å takle trening og livet generelt er
2. Min søvnkvalitet og kvantitet er
3. Kostholdet jeg spiser er av god kvalitet
4. Mengden mat jeg spiser er
5. Min fysiske form for trening er

### Strategisk
1. Min plan for å håndtere livet er
2. Planen min for å takle skolearbeid er
3. Jeg er i fase med skolen
4. Jeg tar avgjørelser i livet som jeg vinner i det lange løp
5. Jeg tar beslutninger om golf som jeg vinner i det lange løp
6. Jeg har funnet ut ting jeg trenger for å ta gode beslutninger
7. Jeg dokumenterer og evaluerer treningen/turneringen min

### Teknisk
1. Jeg har et klart bilde av hvordan jeg skal stille opp for ballen.
2. Jeg har et klart bilde/film av hvordan jeg skal bevege kroppen min.
3. Jeg vet hvordan det skal føles når jeg stiller opp rett etter ballen.
4. Jeg vet hvordan det skal føles når jeg beveger kroppen på riktig måte.
5. Jeg kjenner gode spillere hvis sving jeg sammenligner meg med og ønsker å etterligne.
6. Jeg forstår hvorfor jeg må stå opp og bevege meg på en bestemt måte.
7. Jeg vet hva mønstrene mine er innen teknikk
8. Jeg har øvelser/øvelser som vil hjelpe meg med å trene riktig svingbevegelse.
9. Jeg har en teknisk plan for de fleste golfslagene (utslag, innspill, nærspill, putt)

### Golfutvikling
1. Jeg har klare mål for golfutviklingen min
2. Min treningsplan for golfutviklingen min er
3. Jeg implementerer innholdet i planleggingen min
4. Jeg gjennomfører mengden trening i planleggingen min
5. Jeg har forutsetninger for å gjennomføre treningen min (lokaler/treningsområde etc.)
6. Jeg har treningskompiser

### Neste trinn
1. Jeg har en god forståelse av hva collegelivet innebærer.
2. Jeg har en god forståelse av amerikansk kultur.
3. Jeg har en klar plan for hvordan mine ulike trenere (hjemme, college, Team Norway) skal samhandle.
4. Jeg forstår de akademiske kravene som vil bli stilt til meg på college.
5. Jeg forstår hvordan treningskulturen kan være annerledes i USA sammenlignet med Norge.

## Amatør (19–24)

### Sosial
1. Jeg er fornøyd med hvordan det fungerer med vennene mine på college
2. Jeg er fornøyd med hvordan det fungerer med vennene mine i Norge
3. Jeg har noen å snakke med om personlige saker
4. I have adapted well to the US culture and college life

### Mentalt
1. Min mentale tilstand er
2. Jeg har balanse mellom golf og livet utenfor golfen
3. Mine forventninger er i balanse med min innsats
4. Andres forventninger er i balanse med mine egne
5. Min motivasjon for trening er
6. Jeg utnytter den mentale coachingen som er tilgjengelig for meg

### Fysisk
1. Energinivået mitt til å takle trening og livet generelt er
2. Min søvnkvalitet og kvantitet er
3. Kostholdet jeg spiser er av god kvalitet
4. Mengden mat jeg spiser er
5. Min fysiske form for trening er
6. Jeg har tilgang til gode treningsfasiliteter

### Strategisk
1. Min plan for å håndtere livet er
2. Planen min for å takle skolearbeid er
3. Jeg er i fase med skolen
4. Jeg tar avgjørelser i livet som jeg vinner i det lange løp
5. Jeg tar beslutninger om golf som jeg vinner i det lange løp
6. Jeg har funnet ut ting jeg trenger for å ta gode beslutninger
7. Jeg dokumenterer og evaluerer treningen/turneringen min

### Teknisk
1. Jeg har et klart bilde av hvordan jeg skal stille opp for ballen.
2. Jeg har et klart bilde/film av hvordan jeg skal bevege kroppen min.
3. Jeg har god kontroll over ballbanen.
4. Jeg kan forme ballbanen når det kreves.
5. Jeg har en god forståelse av hvordan påvirkning påvirker ballbanen.
6. Jeg har et godt utvalg av øvelser i alle deler av spillet.

### Golfutvikling
1. Jeg har et godt forhold til college-trenerne.
2. Jeg opprettholder god kontakt med min hjemmetrener.
3. Jeg opprettholder god kontakt med trenerne på Team Norway.
4. Jeg har klare mål for golfutviklingen min.
5. Treningsplanen for golfutviklingen min er på plass.
6. Jeg har tilgang til gode treningsfasiliteter.

### Neste trinn
1. Jeg har en klar plan for min utvikling.
2. Jeg har tilstrekkelig økonomisk støtte for å støtte mine aktiviteter.
3. Spillet mitt er på et passende nivå for å bli profesjonell.
4. Jeg har en god forståelse av hva et proffliv innebærer.
5. Jeg har en plan B hvis profflivet ikke fungerer for meg.
6. Jeg er fornøyd med mitt støtteapparat

## Profesjonell (21–)

### Sosial
1. Jeg er fornøyd med hvordan det fungerer med vennene mine på tour
2. Jeg er fornøyd med hvordan det fungerer med vennene mine hjem i Norge
3. Jeg har noen å snakke med om personlige saker
4. I have adapted well to life on the Pro tour.

### Mentalt
1. Min mentale tilstand er
2. Jeg har balanse mellom golf og livet utenfor golfen
3. Mine forventninger er i balanse med min innsats
4. Andres forventninger er i balanse med mine egne
5. Min motivasjon for trening er
6. Jeg utnytter den mentale coachingen som er tilgjengelig for meg

### Fysisk
1. Energinivået mitt til å takle trening og livet generelt er...
2. Jeg bruker fysisk coaching som er tilgjengelig for meg.
3. Kostholdet jeg spiser er av god kvalitet.
4. Mengden mat jeg spiser er...
5. Jeg har en god årsplan for fysisk vedlikehold/utvikling.
6. Jeg har tilgang til gode treningsfasiliteter.

### Strategisk
1. Min plan for å håndtere livet er...
2. Jeg tar avgjørelser i livet som jeg vinner i det lange løp.
3. Jeg tar beslutninger om golf som jeg vinner i det lange løp.
4. Jeg har funnet ut ting jeg trenger for å ta gode beslutninger.
5. Jeg dokumenterer og evaluerer treningen/turneringen min

### Teknisk
1. Jeg har et klart bilde av hvordan jeg skal stille opp for ballen.
2. Jeg har et klart bilde/film av hvordan jeg skal bevege kroppen min.
3. Jeg har god kontroll over ballbanen.
4. Jeg kan forme ballbanen når det kreves.
5. Jeg har en god forståelse av hvordan påvirkning påvirker ballbanen.
6. Jeg har et godt utvalg av øvelser i alle deler av spillet.

### Golfutvikling
1. Jeg opprettholder god kontakt med min hjemmetrener.
2. Jeg opprettholder god kontakt med trenerne på Team Norway.
3. Jeg har klare mål for golfutviklingen min.
4. Treningsplanen for min golfutvikling er på plass.
5. Jeg har tilgang til gode treningsfasiliteter.

### Neste trinn
1. Jeg har en klar plan for min utvikling.
2. Jeg har tilstrekkelig økonomisk støtte for å støtte mine aktiviteter.
3. Spillet mitt er på et passende nivå for å bli profesjonell.
4. Jeg har en god forståelse av hva et proffliv innebærer.
5. Jeg har en plan B hvis profflivet ikke fungerer for meg.
6. Jeg er fornøyd med mitt støtteapparat.
