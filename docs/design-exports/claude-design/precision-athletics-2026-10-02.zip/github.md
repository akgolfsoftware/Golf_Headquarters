repo: akgolfsoftware/Golf_Headquarters
branch: main

## Last sync
date: 2026-09-30T06:14:42Z

### Updated in this project
- Ingen skjermer bygget om: endringene siden 27.09 er kode som implementerer våre egne overleveringer
- AG-WB-FYS, AG-WB-TURN og PH-WB stemmer med ny kontrakt (fys-turnering-kontrakt.ts: statuser, økttyper, konflikttyper)
- overlevering/teknisk-plan-progresjon-2026-09-27.md er nyere her (9242 B) enn i repoet (8244 B) — bør pushes
- Baseline for neste sync: blob tp-deler.tsx @de34688a0fee, fys-turnering-kontrakt.ts @1e30a6ece8bb, TekniskPlanPrecisionView.tsx @63da3142294f, WorkbenchUke.tsx @e947da9d0914

## Sync history
### 2026-09-27T14:36:47Z
date: 2026-09-27T14:36:47Z

Updated:
- Designpass: navigasjon, angre og dra-og-slipp i PlayerHQ og AgencyOS
- 16 nye analyse-skjermer (PH-A01–A08, AG-A01–A08) og 19 komponenter
- Teknisk plan i overlevering/teknisk-plan-playerhq-agencyos-analyse.md

## Screen map
| Skjerm | Repo-filer |
|---|---|
| PH-02 Gjør nå | src/app/portal/gjennomfore/page.tsx, src/app/portal/live/page.tsx |
| PH-04–07 Live-økt | src/app/portal/(fullscreen)/live/[sessionId]/* |
| PH-09 Registrer runde | src/app/portal/mal/runder/ny/page.tsx, src/app/portal/(fullscreen)/runde/logg/page.tsx, src/components/portal/runde-ny/* |
| PH-18 Runder og statistikk | src/app/portal/mal/runder/[id]/page.tsx, src/components/portal/runde-ny/manuell-sg-felt.tsx, src/app/portal/statistikk/[metric]/page.tsx |
| PH-20 Gameplan | src/app/portal/gameplan/**, src/components/gameplan/*, src/app/portal/baneguide/** |
| PH-25 Abonnement | src/app/portal/meg/abonnement/**, src/app/portal/oppgrader/page.tsx, src/lib/auth/requirePortalUser.ts, src/lib/auth/talent-allowlist.ts |
| AG-01 Hjem | src/app/admin/agencyos/page.tsx, src/app/meg/page.tsx |
| AG-04 Innboks | src/app/admin/kommunikasjon/page.tsx |
| AG-19 Caddie / Jarvis | src/app/admin/jarvis/page.tsx, src/app/admin/agenticos/** |
| AU-01 Logg inn | src/app/auth/login/page.tsx, src/app/auth/etter-innlogging/page.tsx, src/components/auth/LoginPrecisionView.tsx |
| SY-01 System | src/app/offline/page.tsx, src/app/not-found.tsx, src/app/error.tsx, src/app/vedlikehold/page.tsx, src/components/ui/OfflineBanner.tsx |
| PH-A01–A08 Treningsanalyse | src/app/portal/analysere/page.tsx, src/lib/portal-analyse/* |
| AG-A01–A08 Innsikt | src/app/admin/analyse/page.tsx, src/lib/admin/analyse/faner.ts |
| PH-11 / AG-11 Workbench dra | src/components/workbench/wb-drag.ts, src/components/workbench/WorkbenchUke.tsx |
| AG-WB-FYS / AG-WB-TURN / PH-WB | src/lib/workbench/fys-turnering-kontrakt.ts, src/lib/workbench/fys-turnering-actions.ts, src/lib/workbench/fys-turnering-data.ts, prisma/migrations/20260927201000_workbench_physical_tournament_plan/migration.sql |
| AG-10 / AG-TP-01 / AG-TP-02 / PH-TP-01 Teknisk plan | src/app/portal/tren/teknisk-plan/**, src/app/admin/spillere/[id]/plan/[planId]/**, src/components/portal/teknisk/TekniskPlanPrecisionView.tsx, src/components/precision/teknisk-plan/tp-deler.tsx, src/lib/teknisk-plan/* |
| Tema og tokens | src/lib/v2/tema-default.ts, src/styles/*, src/app/globals.css |
| Øvrige 60 skjermtyper | rutene i skjermliste.md, under src/app/{portal,admin,forelder,auth,innsyn,(marketing)/booking,(marketing)/stats,gfgk-junior} |
