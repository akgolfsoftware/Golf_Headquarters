/* Avledet av guidelines/treningsplanlegging-master.md. Ved avvik gjelder masteren. Delt vokabular for skjermer og agenter. */
window.AK_VOCAB = (() => {
  const AREAS = {
    fullsving: ["Utslag", "Innspill 200 m og lengre", "Innspill 150–200 m", "Innspill 100–150 m", "Innspill 50–100 m"],
    naerspill: ["Chip", "Pitch", "Lob", "Bunker"],
    putting: ["Putting 0–3 fot", "Putting 3–5 fot", "Putting 5–10 fot", "Putting 10–25 fot", "Putting 25–40 fot", "Putting 40+ fot"],
    fysisk: ["Styrke", "Kondisjon", "Bevegelighet"],
    bane: ["Banespill"],
  };
  const AREA_FAMILY = {};
  Object.entries(AREAS).forEach(([k, list]) => list.forEach((a) => { AREA_FAMILY[a] = k; }));
  const DIMENSIONS = {
    utslag: ["Sikte og oppstilling", "Startretning", "Kurve", "Treffpunkt"],
    innspill: ["Startretning", "Kurve", "Høyde", "Lengdekontroll", "Spinn"],
    innspill200: ["Startretning", "Kurve", "Høyde", "Treffpunkt"],
    innspill150: ["Startretning", "Kurve", "Høyde", "Lengdekontroll"],
    innspill100: ["Lengdekontroll", "Startretning", "Høyde"],
    innspill50: ["Lengdekontroll", "Høyde", "Spinn"],
    naerspill: ["Landingspunkt", "Utrulling", "Treffpunkt", "Køllevalg", "Bruk av bounce"],
    chip: ["Landingspunkt", "Utrulling", "Treffpunkt", "Køllevalg"],
    pitch: ["Lengdekontroll", "Landingspunkt", "Høyde", "Spinn"],
    lob: ["Høyde", "Landingspunkt", "Bruk av bounce", "Treffpunkt"],
    bunker: ["Sandinngang", "Lengdekontroll", "Høyde", "Lie-variasjon"],
    putting: ["Greenlesing", "Ballstart", "Sikte", "Lengdekontroll"],
    banespill: ["Spilleformat", "Strategioppgave"],
  };
  const dimsFor = (area) => area === "Utslag" ? DIMENSIONS.utslag : area === "Innspill 200 m og lengre" ? DIMENSIONS.innspill200 : area === "Innspill 150–200 m" ? DIMENSIONS.innspill150 : area === "Innspill 100–150 m" ? DIMENSIONS.innspill100 : area === "Innspill 50–100 m" ? DIMENSIONS.innspill50 : area === "Chip" ? DIMENSIONS.chip : area === "Pitch" ? DIMENSIONS.pitch : area === "Lob" ? DIMENSIONS.lob : area === "Bunker" ? DIMENSIONS.bunker : AREA_FAMILY[area] === "fullsving" ? DIMENSIONS.innspill : AREA_FAMILY[area] === "naerspill" ? DIMENSIONS.naerspill : AREA_FAMILY[area] === "putting" ? DIMENSIONS.putting : DIMENSIONS.banespill;
  return {
    AXES: [["fys", "FYS", "Fysisk"], ["tek", "TEK", "Teknisk"], ["slag", "SLAG", "Golfslag"], ["spill", "SPILL", "Spill"], ["turn", "TURN", "Turnering"]],
    AREAS, AREA_FAMILY, DIMENSIONS, dimsFor,
    MOTORIKK: ["Uten ball", "Lav hastighet", "Automatikk"],
    MOTOR_CODE: { "Uten ball": "UB", "Lav hastighet": "LH", "Automatikk": "AUTO" },
    // Spillerkategori på brutto snittscore (ak-kategori.ts). [bokstav, navn, øvre grense eksklusiv]. Trinn er [min, max).
    CATEGORIES: [["A", "World Elite", 68], ["B", "National Elite", 72], ["C", "National U21", 74], ["D", "Regional Elite", 76], ["E", "Regional U18", 78], ["F", "Klubbspiller Senior", 80], ["G", "Klubbspiller Junior", 85], ["H", "Rekrutt Senior", 90], ["I", "Rekrutt Junior", 95], ["J", "Nybegynner Senior", 100], ["K", "Nybegynner Junior", Infinity]],
    // P-posisjoner: P1.0–P10.0 som hovedvalg (MORAD-kjerne), .5 som eneste finjustering (P3.5).
    P_DECIMALS: [0, 5],
    // Puttebånd (fot) — samme 6 bånd i treningsområder, statistikk og banekart.
    PUTT_BANDS: ["0–3", "3–5", "5–10", "10–25", "25–40", "40+"],
    // Synlig navn: Treningsmiljø (internt felt BELASTNING). Konkurranse som miljø er flyttet til Press.
    BELASTNING: ["Innendørs golf", "Utendørs treningsområde", "Golfbane"],
    PRESS: ["Alene", "Observert", "Konkurranse", "Turnering"],
    TURN_TYPES: [["Treningsturnering", "Lav innsats. Test av plan og rutiner."], ["Utviklingsturnering", "Målsetning knyttet til periodens fokus."], ["Prestasjonsturnering", "Resultatet teller. Full konkurranseprosess."]],
    P: [["P1.0", "Adresse / Oppstilling"], ["P2.0", "Kølle parallell i baksving"], ["P3.0", "Venstre arm parallell i baksving"], ["P4.0", "Toppen av baksvingen"], ["P5.0", "Venstre arm parallell i nedsving"], ["P6.0", "Kølle parallell i nedsving"], ["P7.0", "Treffpunktet"], ["P8.0", "Kølle parallell i gjennomføring"], ["P9.0", "Høyre arm parallell i oppfølging"], ["P10.0", "Fullføring og balanse"]],
    TRACKMAN: ["Club Speed", "Ball Speed", "Smash Factor", "Attack Angle", "Club Path", "Face Angle", "Face to Path", "Dynamic Loft", "Launch Angle", "Spin Rate", "Spin Axis", "Carry", "Total", "Dispersion"],
    STATUS: {
      okt: ["Planlagt", "Pågår", "Gjennomført", "Avlyst", "Hoppet over"],
      plan: ["Utkast", "Venter på spiller", "Venter på coach", "Godtatt", "Avvist", "Aktiv", "Arkivert"],
      publisering: ["Ikke publisert", "Publiserer", "Publisert", "Trukket tilbake"],
      dagsform: ["Tung", "Slapp", "Ok", "God", "Topp"],
    },
    KATEGORIER: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"],
    TIERS: { TALENT: "Gratis", FULL: "Full · 299 kr/mnd eller 2 690 kr/år" },
    // Navigasjon og ord 28.09.2026 (Anders). «Mål» heter Målsetning. «Analyse» heter Stats i PlayerHQ.
    TERMS: { goal: "Målsetning", goals: "Målsetninger", stats: "Stats" },
    NAV: { playerhq: ["I dag", "Plan", "Stats", "Meg"], agencyos: ["Cockpit", "Innboks", "Stall", "Kalender", "Workbench", "Mer"], stats: ["Snittscore", "Strokes Gained", "Trening", "Tester"] },
    TRENINGSPLANER: ["Weekend Warrior", "Klubbspilleren", "Junior-aspirant", "Konkurransespilleren", "Practice like the pros"],
    FORBUDT: [["Drill", "Øvelse"], ["Logge / føre data", "Registrere"], ["Session / workout", "Økt"], ["Goal", "Målsetning"], ["Mål (om målsetning)", "Målsetning"], ["Stats (løpende tekst)", "Statistikk"], ["Analyse (fane)", "Stats"], ["Hjem (AgencyOS)", "Cockpit"], ["Schedule", "Plan / Kalender"], ["Subscription", "Abonnement"], ["Kortspill / rundt green", "Nærspill"], ["Ferdig (status)", "Lagret · Publisert · Gjennomført"], ["Pro / Premium / Plus", "Gratis / Full"], ["CoachHQ", "AgencyOS"], ["Motorikk (etikett)", "Læringssteg"], ["Belastning (sted)", "Treningsmiljø"], ["Spesialisering", "Spesialperiode"], ["Elev / atlet", "Spiller"]],
  };
})();
