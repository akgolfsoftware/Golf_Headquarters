# Status · 01.10.2026

Dette er teknisk status, ikke en samlet visuell godkjenning.

## Aktivt

- AK Golf Precision Athletics er eneste aktive designautoritet.
- Codex eier kode og implementering.
- Workbench har faste skjerm-ID-er for År, Periode, Måned, Uke, Økt, Volum og Målsetninger i AgencyOS og PlayerHQ.
- Knapp–skjerm-kartet skiller skjerm, panel, skjema, dialog og datahandling.
- Aktiv teknisk plan bruker bare P1.0–P10.0. P5.5, mellomposisjoner og den gamle uketypeprioriteringen er tatt ut av aktive kilder og bevart i arkivet.
- AG-16a, gammel AG-A07 og eldre Workbench-/Grok-materiale ligger i arkiv.

## Godkjenning

- Godkjent av Anders: PH-01 original, mobil 390 px, lyst tema, Data, dialogen «Endring i dagens plan» åpen.
- Øvrige skjermer: designkandidater som må gjennomgås skjerm for skjerm før visuell godkjenning.

## Kontrollstatus

- Rå, oppdaterte kilder etter Codex-oppryddingen: to kjøringer, 128 kontroller, 0 feil.
- Ny bundle fra de oppdaterte kildene: to kjøringer, 128 kontroller, 0 feil.
- Lokal bundle og Claude Design har identisk SHA-256: `c7b49e6497fe83edd7835f5a4f31caa66454a00935a5365a898d6d32de634a61`.
- Bundle-søk: 0 × `P5.5`, 0 × `MELLOM`, 0 × «må implementeres av Grok»; de seks Volum-handlingene har stabile kontroll-ID-er.
- Knapp–skjerm-kartet har 56 unike kontroll-ID-er og ingen duplikater.
- Prototype er ikke bevis på appens database, tilgang, opplasting eller produksjonsflyt.

## Bestilling mottatt 01.10.2026 · D1 Workbench kalender/årsplan/periodisering

- Mottatt fra Anders via Codex. Codex – ikke Grok – koder appen.
- Kvotegrensen (90 %) er nådd. D1-skjermer (AG-05, AG-11/-AR/-PER/-MND, PH-11) er IKKE påbegynt; ingen design er endret på grunn av bestillingen.
- Uferdig verifikasjon fra forrige oppdrag er ikke fullført i denne økten: bundle-regenerering og søk, reisetest-tp bundle-only (2 sidelaster), syntetiske AG-11-VOL-kontroller, audit-tp/AG-10-referanser. Tallene under «Kontrollstatus» er fra forrige økt og er ikke kjørt på nytt her.
- Bare PH-01 er visuelt godkjent. Ingenting er «komplett», «frosset» eller valgt for bygging.

## Kontrollstatus (kjørt 01.10.2026)

- `ui_kits/reisetest-tp.html` (reisetest-tp), 68 kontroller + dekningskontroll per runde, to runder per sidelast = 138 kontroller:
  - Bundle-only (`screen-bundle.html`, kun `_ds_bundle.js`; testen feiler hvis rå .jsx/.js lastes): to separate sidelaster, 138 kontroller, 0 feil per sidelast. Kildekontroll: 0 rå .jsx/.js lastet.
  - Rå kilder (`reisetest-tp-raa.html`, screen.html): én sidelast, 138 kontroller, 0 feil; 117 rå filer lastet (beviser modus).
  - Dekningen er økt fra 128 til 138: +4 AG-11-VOL-kontroller (syntetisk plan via wb-model, samme eier, kanonisk Volum-flate, ingen demo-/t1-/g1-/mf0-fallback: TEK delsum 2/mangler 5 av 6, FYS kjent 0, SLAG/SPILL/TURN ukjent —, minutter adskilt) og +1 kildekontroll per runde. Kravet 128/0 er ikke svekket; det er utvidet.
- `_ds_bundle.js` (kompilatoreid, ikke skrevet av meg): alle 171 kildefiler under ui_kits/ + styles.css har SHA-256-prefiks lik sourceHashes (0 foreldet). Bundle registrerer AG-TP.jsx og ikke AG-10.jsx; 0 × `P5.5`, 0 × `MELLOM`, 0 × «Grok». Bundlen har 47 sourceHashes-nøkler for `arkiv/` (hash-sporing, ingen modulregistrering funnet i komponentlisten).
- `screen-bundle.html` (AgencyOS og PlayerHQ) lastet tidligere 23–29 rå data-skript ved siden av bundlen; fjernet, bare React/Babel (CDN), styles.css, `_ds_bundle.js` og innebygd startskript gjenstår.
- `ui_kits/audit-tp.html`: 368 tilfeller (390/1280), 12 avvik. Alle 12 = PH-11-MAL «MAL-RAD» (raden «Åpne teknisk plan»/teksten «lager planen sammen med deg» vises ikke på PH-11-MAL i rå screen.html). AG-10 (= AG-TP.jsx), AG-TP-01, AG-TP-02, AG-11-OKT, AG-11-VOL og AG-23: 0 avvik. Åpent: enten produktmangel (innganger til PH-TP-01 mangler i målnivået i WB3-lokal) eller utdatert audit-forventning. Ikke rettet.
- `ui_kits/wb1-reise.html` refererer AG-10 med demo-oppgave `t1`; ikke kjørt, ikke lenket fra noen aktiv side. Ikke arkivert; erstatning for innvalg i økt er reisetest-tp.
- Testsidene bruker nå Web Worker-timer (sleep) så kjøring ikke strupes i skjult fane.
- Workbench-forslag (`ui_kits/workbench-forslag/index.html`): ikke kontrollert av meg ennå; ikke visuelt godkjent, ikke valgt for bygging.

## Excel-erstatning (IUP) · utkast 01.10.2026

- Laget: `ui_kits/iup-excel/iup.html` (kjede evaluering → prosessmål → økt → dagbok → Stats → delt trenerside → forslag → beslutning; Deling med ikke-delt / venter foresatt / aktiv / trukket; fane Dekning X01–X18), `index.html` (390/1440), `overlevering/wang-tn-trener-kontrakt.md`.
- Dekning: 18 områder registrert; bare X04, X06, X09/X10, X16 og deler av X05 har klikkbar del. Resten er kun kontrakt, ikke tegnet. X11: eksakt 2027-tekst tilført (kildemateriale/iup-2027-kilde-2026-10-01.json; 34/43/47/38 = 162 + 13 sesong, kontrollert med skript) og vist i iup.html fanen X11 (svar 1–5, lagre, fullfør, historikk). Ikke visuelt sett/prøvd av verifikator. Kilden har skrivefeil som ikke er rettet («gjennomfär», «øvelser/øvelser», ett engelsk spørsmål). Ingenting er prøvd av verifikator ennå, ikke visuelt godkjent, ikke valgt for bygging. Ikke komplett.

- Samordning (rettet 01.10.2026): tre prosjekter – Precision, Team Norway App delivery (bc3e41fc) og WANG Golf UI prototype (6cfa623c) som eneste WANG-prosjekt for X01–X18. Ingen avhengighet til WANG Toppidrett Software; tidligere ansvarsdeling trukket tilbake. Se `overlevering/wang-tn-trener-kontrakt.md`.

- Codex-kontroll 01.10.2026 (390×844, presentasjonsmodus; rapportert av Codex, ikke gjentatt av meg): eksempel → Stats viser 60 planlagt / 45 registrert / 1 økt; Meg → Del tilgang → aktiv WANG + aktiv TN → stopp WANG → WANG-trener viser Trukket / Ingen data. Ikke full tilgangsverifisering.
- Rettet etter Codex' visuelle avvik: prototypekontroller ligger nå i lukket «Prototypekontroller» nederst (rolle, eksempel, lagringsfeil, under 16, tilstand); tilbake-til-spiller-knapp ved trenerrolle; Plex Sans for brødtekst/tall-etiketter, mono bare for tall (.num) og metadata; krav-ID-er (X01 osv.) og tekniske delingsforklaringer flyttet til hjelpe-åpninger og Dekning-fanen.
- Reiselenker: ui_kits/iup-excel/index.html (15 lenker). Egen tastatur-/lagringsfeil-/vurdering-forslag-prøve, 390/1440-måling og overflyt: delegert til verifikator, resultat ikke rapportert ennå. Åpent som før: X05 SG/PEI, X07–X08, X12–X15, X17–X18 ikke tegnet; PH-11-MAL-avvik i audit-tp, wb1-reise (t1), Workbench-forslag-verifikasjon.

- Plan (X07–X08) koblet inn i iup.html under Plan: År · Periode · Måned · Uke · Økt · Turneringer. Bruker workbench-forslag/data.js og visningsdeler (ingen egen planmotor, ingen planetkopi); spiller ser bare publiserte økter + egne planlagte. Dato fre 2. okt. bevares mellom nivåene. Evaluering → prosessmål → «Planlegg i Plan» → Økt → Stats («Tilbake til Plan · uke 40») er klikkbar. Turneringer: Power med referanseår/kilde (syntetisk), konkurranse- og reisedager atskilt, nivåbalanse, årsskifte (29.12–01.01, U53). Desktop: innhold begrenset til 720 px med sidefelt «Sesongen» ≥1100 px. IKKE målt/sett av meg ennå (verifikator), ikke full tastaturprøve, ikke koblet til ekte Workbench-kode, tre Workbench-kandidater uendret og ingen valgt.

- Avslutningskontroll Plan (01.10.2026, min egen måling i iframe med faktisk bredde; vw bekreftet = 390 og 1440, ikke nettleserens override): ui_kits/iup-excel/maal.html. Resultat for På 390 og 1440: scrollWidth = vw (ingen sideoverflyt), main 370/720 px, ingen knapper/felt under 44 px på År, Periode, Økt, Stats, Turneringer. Valgt dato fre 2. okt. bevart År→Periode→Uke→Økt→Stats→tilbake og etter Måned→Uke. Måned: des. 2026 og jan. 2027 viser uke 53 og uke 01, merket «går over månedsskifte». Kjent 0 mot ukjent: uke 46 Fysisk antall 0 / Plan 0 t; uke 36 alle «—». Uke 40: Teknisk plan 2 t, registrert 1,7 t (55+45 min); økt 60 min planlagt / 45 min registrert i Stats. Turneringer: Nyttårsturnering U53, Power ukjent vist som «— (ikke fastsatt)». Stopp WANG (trukket): ingen plan-/tidsdata i DOM (søkt på Overgang, Uke 40, 60/120/45 min, Grunnperiode); TN aktiv viser 60/45. Alle klikkmål er native button/input (ingen tabindex>0, ingen navnløse knapper).
- Rettet: aksehoder i uketabellen var avkortet («FYSI TEKN GOLF SPIL»); nå Fys/Tek/Slag/Spill/Turn med full tittel.
- IKKE kontrollert: faktisk Tab-rekkefølge og fokusring med tastatur (kun at kontrollene er native); visuelt øyesyn av skjermbilder 390/1440 (ikke tatt av meg, kun DOM-måling); ekte tilgangskontroll (prototype).

## Workbench — fire nye retninger (01.10.2026, utforsking, ingen valgt, ikke visuelt godkjent)

- Sammenligning: ui_kits/workbench-retninger/index.html. Kandidater: kandidat.html?k=a (Sesongkart), ?k=b (Ukeverksted), ?k=c (Trenerbord), ?k=d (Analyse til tiltak). Felles case i core.js (syntetisk). iup-excel-planutkastet er ikke godtatt; beholdt kun som funksjonsreferanse. Tidligere tre Workbench-forslag uendret.
- Kontrollert av meg: (1) DOM-måling i ekte iframebredder 1440 og 390 (maal.html): ingen sideoverflyt; etter retting ingen knapper under 44 px utenom avkrysningsbokser (24 px i 44 px label). (2) Interaksjoner: A zoom Sesong→Periode→Uke, periode-bytte og tilbake beholder fre 2. okt., økt 60 planlagt / 45 registrert, turnering med 3 konkurransedager + 2 reisedager, Power 33,0 kildeår 2025; B flytt til lørdag + Angre, mal plassert torsdag 17:00, publiser trenerutkast; C bulk-dialog lister «gjelder / gjelder ikke» (Ola: ingen tilgang, deaktivert), Ola-sidefelt uten data, Jonas begrenset (tid ikke delt); D plassering av 2 tiltak gir Golfslag +1:30 t (8 t → 9:30 t), Bruk i 6 uker og Angre. (3) Skjermbilder sett av meg: desktop via skalert simulering (?vw=1440 i 910 px forhåndsvisning – ikke ekte 1440-skjerm) og mobil ?vw=390 (ekte 390 px bredde).
- Ikke kontrollert: Tab-rekkefølge/fokus med ekte tastatur, dra-og-slipp med mus/berøring, faste elementer (FAB/ark) i ekte mobil, ytelse. Sesonggrense 31.08.2026–29.08.2027 må kontrolleres mot uke 43-vedtaket.

## Workbench · samlet trenerverktøy (02.10.2026 · prototype · kombinasjonen A–D er valgt retning; visuell appgodkjenning gjenstår)

- Hovedlenke: ui_kits/workbench-samlet/index.html · tilstander.html · overlevering.md. A–D i workbench-retninger/ urørt.
- Faktisk kjørt (DOM-skript i forhåndsvisning, syntetiske data): bytte mellom alle fire visninger beholdt spiller og dato (tir. 29. sep. fulgte B→A→C→D→B); periode p2 valgt i Sesongkart, redigering avviste overlapp mot Ferie og lagret ny til-dato, budsjett Teknisk 300 min og prioritet; Måned viste okt./nov. og dagklikk ga Uke med 11. nov.; ny økt fra bibliotek (utkast) → flyttet tor. 07:00 → forhåndsvisning/publisering → live 30 av 45 min + notat → dagbok; s5 live 45 av 60 → uke 40 Teknisk 120/100 min, dagbok registreringsgrad 83 % (5 av 6); gruppeøkt for 3 med tilpasning for Tobias, Ola deaktivert, mottakere/utelatte vist; spillerforslag godkjent flyttet økta og ble logget; TN-filter og trukket TN-deling viste «Tilbaketrukket» uten data og uten gruppetall; Ola ingen tilgang i alle visninger; analyse alternativ B → 12 utkast i uke 41–46 → Angre fjernet alle; sammenligning sommer/høst.
- Målt i ekte iframes 1440 og 390 for alle fire visninger, Spiller360 og live: scrollWidth = bredde, 0 knapper under 44 px. Kalenderens klikkflater (slots) er musehjelp; tastaturalternativ er «Legg på valgt dag».
- Skjermbilder sett: desktop via skalert simulering (?vw=1440 i 924 px), mobil ?vw=390. Overlegg (Spiller360) er ikke skalert i simuleringen.
- Runde 2 (02.10.2026), kjørt som DOM-klikk i ekte iframes (desktop.html 1440 × 900, mobil.html 390 × 844):
  - Uke 41 valgt i Ukeverksted → Sesongkart → Trenerbord → Analyse → Ukeverksted tre ganger: dato 9. okt. og hash uendret; Analyse viser uke 41 (feilen med uke 42 er rettet). Direkte åpning ?view=analyse&date=2026-10-09 viser uke 41.
  - Uke 41 i Sesongkart: «registrert kommer» (aria). Trenerbord fremtidig uke: «reg. kommer». Mengdeakse 0–30 t (maks 26 t 45 min) i både uke- og sesongzoom.
  - Økt 60/45: «Fullføringsgrad 45 av 60 min = 75 %». Dagbok/Oversikt viser separat «5 av 6 økter har registrert tid (83 %)».
  - X09: celle endret, syklus Grunn/Turnering med konkurranse/Grunn fra uke 43, forhåndsvisning med datoer/økter/fem akser og 2 overlapp, 19 utkast lagt inn (synlige i Ukeverksted uke 43), Angre fjernet alle.
  - X05 nytt og endret resultatmål med kvartal/kilde/enhet/prosessmål og historikk. X14 endret og 2 øvelser lagt i økt fre 2. okt. X15 råresultat ført (ingen score) og program plassert som utkast (synlig i Ukeverksted og Historikk). X17/X18 bytte av referanseversjon endrer sammenligning; 40 fot → 40+.
  - Tastatur (syntetiske tastehendelser): Tab fra siste → første og Shift+Tab fra første → siste i Spiller360; Escape lukker overlegg og gir fokus tilbake til knappen som åpnet det.
  - Mobil 390: 0 knapper under 44 px og ingen sideoverflyt i alle fire visninger, Spiller360 (alle faner) og X09.
- Runde 3 (02.10.2026), klikk i desktop.html (ekte 1440) og mobil.html (ekte 390):
  - X08: ny turnering 24.–25. okt. (3 × 9 hull, utreise 23. okt.) forhåndsviste 2 konkurransedager, 1 reisedag, uke 43 Turnering 0 → 6 t 45 min; lagret og synlig som Reise/Turnering i Ukeverksted uke 43; endret til 2 × 18 + Power 28,5 (2026) → 9 t; Angre tilbake til 3 × 9; ugyldig datorekkefølge avvist.
  - Dagbok uke 40: Spill planlagt 2 t 30 min / registrert «kommer», Turnering 0 / 0, Golfslag 1 t 30 min +—; «4 av 5 økter som skulle vært ferdige per fre 2. okt. kl. 14:20». Uke 41: alt «kommer», registreringsgrad —. Dag, måned og sesong viser samme regler.
  - X12: Wedge Gate 9 forsøk Treff/Bom → 6 av 9, utkast bevart ved fanebytte, lagret i historikk med «9 ført»; Innspill Basic 20 forsøk → snitt 7,0 m live.
  - X10: 11 felt på øvelse 1 + oppvarming lagret og bevart etter bytte Ukeverksted → Trenerbord → Ukeverksted. Endring av akse slettet ingen andre felt.
  - Sesongzoom: august 2026 (1 dag) vises uten tekst med full dato som tilgjengelig navn; ingen månedsetikett klippes eller overlapper.
  - Mobil 390: 0 små treffmål og ingen overflyt i Spiller360 Tester/Dagbok og i øktark med åpen øvelse.
- Ikke kjørt: ekte tastatur (native Tab-rekkefølge, Enter), dra/slipp med mus/berøring, ekte mobilenhet, skjermleser. Skjermbilder av iframe-rammene kan ikke tas med verktøyet; desktop er sett skalert.

## DataGolf-analyse (02.10.2026 · prototype, syntetiske data · første designetappe i Precision)

- Filer: ui_kits/datagolf-komplett/ index.html, desktop.html, mobil.html, tilstander.html, dekningsregister.md, overlevering.md. DG-01–DG-17 tegnet; se registeret for klikkbar/testet per ID.
- Kjørt som DOM-klikk i ekte iframe 1440: Topplister SG innspill 2026 → profil → sammenlign (3 spillere) → Tilbake ×2 beholdt kategori og periode; min. runder 40 viste 16 spillere og listet utelatte; tomt søk → «Ingen treff» → nullstill; historikk → runde 1 med datadekning; turnering → felt (10) og feltstyrke → live med kildeklokke og forsinkelse, simulert feil viste siste vellykkede data, prøv igjen; datautforsker 19 datasett, filter «sg» 6 felt, eksport låst; rolle Spiller → spesialist «Ingen tilgang», TN → «Ikke aktivert», analytiker → register uten handlinger; tiltak: forslag avvist (0 økter), nytt forslag → spilleren endret plan → godta låst (utdatert) → oppdatert → godtatt = 12 økter, ny godta ga fortsatt 12.
- Mobil 390 (ekte iframe): alle 17 visninger uten sideoverflyt og uten treffmål under 44 px.
- Ikke kjørt: ekte tastatur/skjermleser, ekte mobil. Ikke gjort: TN- og WANG-versjoner (egne prosjekter), API-avstemming.

## IUP og trenerreiser R02–R16 (02.10.2026 · prototype, syntetiske data)

- Filer: ui_kits/iup-komplett/ index.html, desktop.html, mobil.html, tilstander.html, dekningsmatrise.md, overforing-wang-tn.md. R06–R08 og R15 dekkes av workbench-samlet og datagolf-komplett (uendret).
- Kjørt (DOM-handlinger i ekte iframe 1440): utviklingssjekk junior 43/43 → levert → ny runde → sammenligning 7 kategorier; lagringsfeil → kø → prøv igjen; sesongevaluering 13 + 100/100 % + 3 tiltak → levert; 37 måltall, mål endret; TN-innsyn (Emma bare tester, Sara trukket, Kari ingen), WANG annen skole; testdag 2 skoler + TN-gruppe → 5 deltakere uten dobbel tildeling, publiser igjen uten nye varsler, 8-ball 24 forsøk med halve poeng → levert i live og hos spiller, retting rev. 2; PEI 5,5 %, Nærspill Gate 12,5; forslag konflikt → oppdatert → godtatt én gang, avvist uten endring; samling 2 invitasjoner, godta én gang, ny versjon krever ny beslutning, avlysning; kildekorreksjon uten duplikat, samme navn uten autokobling.
- Mobil 390: 16 visninger uten sideoverflyt og uten treffmål under 44 px (trener-bunnlinje med «Mer»).
- Ikke gjort: WANG- og TN-versjoner (egne prosjekter; kontrakt levert), R01/R17 (kode), meldinger/kompetansemål/administrasjon, nettbrudd og samtidighet, ekte tastatur/skjermleser.

## Testbatteri 38 + 5 (02.10.2026 · prototype, syntetiske spillere A/B/C)
- Filer: ui_kits/testbatteri-komplett/ (se dekningsmatrise.md). Koblet fra iup-komplett Stats › Tester og Trener › Tester. 8-ball-grenser etter Anders' korrigering. Kildefilene ikke kontrollert.
- Kjørt i ekte iframe 1440: spiller A 8-ball variation 24 × 1 m → 48 av 96, PEI per type → Gjennomført → retting uten begrunnelse avvist → rettet rev. 2; Putt Speed: Lagrer → Lagret, Uten nett → Venter på nett → Lagret, Kunne ikke lagres → Prøv igjen → Lagret, konflikt med annen enhet → valg uten stille overskriving; bilde: feil (tall beholdt) → prøv igjen → miniatyr → åpne/Escape → avbrutt → fjern; natt-tema; Putt Gate ren men lang = ikke godkjent; FYS fullføring sperret; tilgang WANG Oslo (A ja, B annen skole, C ikke WANG-elev), TN (A, B testdeling uten medlemskap, C), B trukket/utløpt → nei; testdag 3 deltakere (A én tildeling via skole + gruppe), åpnet, innsjekk/fravær, trener førte Driver Gate 3 av 6 for C (Kontrollert), spiller A førte egen stasjon, live med foreløpig/endelig og bekreftet tid, frakobling, arrangør/stasjonstrener avgrenset, avsluttet. Kontrollfanen: 11 av 11 OK.
- Mobil 390: 16 visninger (katalog, oppsett, 7 scorekortmønstre, oppsummering, historikk, testdag spiller/trener, spillere, matrise, kontroll) uten overflyt og uten treffmål under 44 px.
- Ikke gjort: ekte tastatur/skjermleser, ekte kamera på mobil, backend.

- Testbatteri kontrollrunde (02.10.2026): målserier/etiketter/antall fra Codex' uttrekk av NGF v3 lagret i ui_kits/testbatteri-komplett/kilde/ngf-v3-uttrekk.js og brukt i katalogen. Rettet: 18 hull (mål per slag, ikke score), standard-sving (oppdiktet 150 m fjernet → egen medianlengde), innspill-basis (oppdiktet 120 m fjernet), «Må avklares» fjernet for 10 varianter med mål i uttrekket, egenvalgt mål per forsøk, fot-visning, språk etter master. Kontroll 15/15 OK inkl. 8,64/270 = 3,2 %. Mobil 390: 8 nye visninger uten overflyt/små treffmål. Åpent: 9-hull enhet, Impact Location, fysiske protokoller, livepublikum. Kildefilene er ikke selvstendig kontrollert.
- Innspill Basis rettet (02.10.2026): ingen frie mål i standardoppsett; valg gutter (5 × 145 + 5 × 160 m) eller jenter (5 × 125 + 5 × 145 m) fra de fire inspill-variantene i uttrekket, delresultat per femslagserie med kilde-ID, test-ID innspill-basis bevart, eget mål per serie vises som avvik ved siden av standard. Prøvd begge valg i 1440 og 390; kontroll 18/18 OK.
- Innspill Basis tilpasset målavstand (02.10.2026): faktisk valgt mål er nevner i PEI; standardmål vises som referanse; serie og hovedresultat merket «Tilpasset målavstand», ikke sammenlignbar med standardserien. 145→150, carry 144, side 0 = 4 % (prøvd 1440 og 390; kontroll 18/18).

## Åpent

- Avgjørelse mangler for perioder, budsjetter og mål utenfor en forkortet årsplan.


## Språkregel (02.10.2026)
guidelines/treningsplanlegging-master.md er master for synlig språk (se CLAUDE.md). Avledede kilder (ordmaster.md, ak-vocabulary.js, eldre filer) gir etter ved avvik. Eksisterende skjermer er ikke gjennomgått mot masteren ennå.

## Språkspørsmål
- (ingen registrert ennå)

## Testbatteri (pågår, ikke levert)
- ui_kits/testbatteri-komplett/katalog.js (38 + 5 + Innspill Basis) og calc.js er påbegynt; ingen skjerm ennå. 8-ball bruker nedre intervallgrenser (0,099/0,1/1/2/3 m → 4/3/2/1/0; 24 × 1 m = 48 av 96).

## Workbench R06.2 (mottatt, ikke tegnet)
- Ukevalg per akse (prioritet, fokus, øktbudsjett) og oppholdssted i Ukeverksted.


## DataGolf DG-14 og IUP-skala (02.10.2026)
- Rettet: DG-14 kolonneoverskrift «undefined» (kolonnenøkkel «enhet» manglet i kolonnelisten). Feltkatalogen bruker nå hele modellregisteret: 135 felt / 16 modeller (`ui_kits/datagolf-komplett/felt.js`), søk, klasse-/modellfilter, kolonnevalg, 10/25/alle per side. «Alle» viser alle tillatte felt (prøvd: 135 analytiker, 107 AK/TN/WANG/spiller — tidligere tall 131 for AK var feil og er rettet).
- 21 klientendepunkter med status. Fantasyprognoser og oddsverktøy: ikke implementert. Utgåtte: ikke kartlagt.
- Odds/DFS i DG-14 innsnevret til analytikerrollen (var også AK-trener).
- Prøvd på 390 (iframe): alle 16 DG-visninger uten sideoverflyt, ingen treffmål under 44 px; tilstandene laster, feil, tom, delvis, avtale og tilgang; filtre beholdt topp → spiller → sammenligning → tilbake. DG-14 sett på desktop. Fikset: lang SHA-tekst ga 500 px sidebredde på 390.
- Ikke prøvd: tastatur hele veien gjennom alle DG-visninger (bare fokusrekkefølge og synlig fokus i DG-14), 1440 for andre visninger enn DG-14 i denne runden, egen «lite grunnlag»-tilstand (vises via minimumsfilter i topplister).
- IUP-kildekorreksjon: utviklingssjekk 2025 er 1–5 (ikke 1–8), 34/41/41/38; 2027 er 1–5, 34/43/47/38; sesongevaluering 1–4 begge. Rettet i iup-komplett (v1.js, dekningsmatrise.md, overforing-wang-tn.md) og workbench-samlet (p360.js, overlevering.md).
- Gjenstår: eldre `ui_kits/_shared/data-iup.js` og `playerhq/screens/PH-27.jsx` bruker fortsatt 2025-mal med skala 8 (styrer svarknappene). Ikke endret i denne avgrensede rettingen.

## DataGolf: spillerrolle og rolledekning (02.10.2026)
- Spiller: DG-05, DG-04, DG-02, DG-13 og DG-16 sperret, også direkte lenke; meny/innganger/lagrede utvalg/«Sammenlign» skjult; cmpadd og usel avviser spillerrollen. Prøvd 1440 og 390.
- AK-trener ser ikke odds/fantasy: 107 felt, ingen DG-17-meny, DG-17 viser «Ikke aktivert for rollen». Bare analytiker ser 135.
- Ny tilstand «Lite grunnlag». DG-14 prøvd i ekte iframes 1440 og 390: ingen sideoverflyt, ingen treffmål under 44 px, alle kontroller tabbare med navn, synlig :focus-visible. Fokus beholdes nå etter Neste/Forrige, filtervalg og kolonnevalg (før gikk fokus tapt ved rerender). Filtre beholdt spiller → sammenligning → tilbake.
- Restavvik: tastatur er prøvd med fokus/klikk i DG-14, ikke med fysisk Tab-gjennomgang av alle 17 visninger. Spillerrollen ser fortsatt andre spillere i turneringsresultater, modellrangering og feltstyrke (offentlige resultater/modell, ikke snittscore-sammenligning) — trenger produktavklaring om dette også skal skjules. Analytiker ser interne driftsfelt (intern rolle, ikke kunde).

## Navngitt trenerdeling (02.10.2026)
- Ny modul `ui_kits/iup-komplett/deling-navngitt/` (index, desktop, mobil, reiser, dn.js, dn.css, overlevering.md). Inngang fra Meg › Deling i iup-komplett (v1.js). Utkast, ikke visuelt godkjent.
- Prøvd 1440/390 i ekte iframes: se overlevering.md. Workbench, testbatteri og DataGolf ikke rørt.

## DataGolf DG-16 lagring (02.10.2026)
- Forslag/beslutning/planversjon/anvendte økter overlever reload (localStorage, syntetisk, validert). 12/6 økter, avvis 0, konflikt 0, ugyldig lagring forkastet ærlig. Prøvd 1440/390. Se datagolf-komplett/overlevering.md.
