# AK Golf HQ — ord og språk (speil)

Avledet av guidelines/treningsplanlegging-master.md. Ved avvik gjelder masteren. Maskinlesbar kopi: `assets/ak-vocabulary.js` (`window.AK_VOCAB`), også avledet.

## Navn og roller (master 2.2)
AK Golf HQ (plattform) · PlayerHQ (spiller) · AgencyOS (coach, aldri «CoachHQ») · AgenticOS (AI-arbeid i AgencyOS) · Caddie (AI-assistenten). Spiller, ikke elev eller atlet. Coach / hovedcoach, ikke «trener» alene. Forelder.
Appnivå: **Gratis** og **Full**. Performance og Performance Pro er coaching-pakker, ikke appnivåer.

## Navigasjon (master 2.6)
- PlayerHQ: I dag · Plan · Stats · Meg. Stats: Snittscore · Strokes Gained · Trening · Tester.
- AgencyOS: Cockpit · Innboks · Stall · Kalender · Workbench · Mer. Cockpit er startskjerm.

## Ord (master 2.2 og 3)
| Aldri | Bruk |
|---|---|
| Drill | Øvelse |
| Logge / føre data | Registrere |
| Session / workout | Økt |
| Goal, «mål» om det spilleren sikter mot | Målsetning («mål» beholdes om måltall) |
| Stats i løpende tekst | Statistikk (fanen heter Stats) |
| Analyse som fane | Stats |
| Hjem (AgencyOS) | Cockpit |
| Schedule | Plan / Kalender |
| Subscription | Abonnement |
| Kortspill / rundt green | Nærspill |
| Ferdig som status | Lagret · Publisert · Gjennomført |
| Pro / Premium / Plus | Gratis / Full |
| Motorikk som etikett | Læringssteg |
| Belastning om stedet | Treningsmiljø |
| Spesialisering | Spesialperiode |

## Struktur (master 6, 10–16)
- Pyramide: FYS Fysisk · TEK Teknisk · SLAG Golfslag · SPILL Spill · TURN Turnering.
- Områder (19): Utslag · Innspill 200 m og lengre · 150–200 m · 100–150 m · 50–100 m · Chip · Pitch · Lob · Bunker · Putting 0–3 · 3–5 · 5–10 · 10–25 · 25–40 · 40+ fot · Styrke · Kondisjon · Bevegelighet · Banespill.
- Læringssteg: Uten ball · Lav hastighet (25, 50 eller 75 % av Club Speed) · Automatikk (100 %).
- Treningsmiljø: Innendørs golf · Utendørs treningsområde · Golfbane (flere valg: master kap. 12). Konkurranse som miljø uttrykkes som Press.
- Press: Alene · Observert · Konkurranse · Turnering.
- Teknisk fokus (maks ett per øvelse): lister per område i master 14.3.
- Perioder: Grunnperiode · Spesialperiode · Turneringsperiode · Evaluering · Ferie · Restitusjon.
- Mengde: slag · putter · hull/tid · «4 × 6 @ 90 kg · RIR 2» · pulssone S1–S5 · tid.

## Statuser (master 4.3)
- Plan: Utkast · Venter på spiller · Venter på coach · Godtatt · Avvist · Aktiv · Arkivert
- Økt: Planlagt · Pågår · Gjennomført · Avlyst · Hoppet over
- Publisering: Ikke publisert · Publiserer · Publisert · Trukket tilbake
- Lagring: Ikke lagret · Lagrer · Lagret · Kunne ikke lagres
- Målsetning: Ikke startet · På vei · Nådd
- Dagsform: 1 Tung · 2 Slapp · 3 Ok · 4 God · 5 Topp

## Tall (master 2.4)
Komma som desimalskille (72,4) · mellomrom som tusenskille (1 247) · mellomrom før % (73 %) · SG med fortegn (+1,2 / −0,4) · putting i fot, andre avstander i meter · brutto score, aldri netto · manglende verdi «—».

## TrackMan, kategorier og posisjoner
TrackMan-parametere beholder engelsk navn med stor forbokstav (master 2.3). Kategorier A–K på brutto snittscore (2.7). Posisjonene P1.0–P10.0 har faste navn (14.4).
