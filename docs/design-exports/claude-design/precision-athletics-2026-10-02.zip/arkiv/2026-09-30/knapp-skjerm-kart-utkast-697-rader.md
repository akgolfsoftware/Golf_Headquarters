# Knapp- og skjermkart · utkast 30.09.2026 (runde 37)

Generert fra kildekoden i `ui_kits/playerhq/screens/` og `ui_kits/agencyos/screens/`. **Status: utkast fra kode. Ingen rad er bekreftet av Anders.** «Bekreftet i test» gjelder bare radene i tabellen «Testet reise» under (reisetest.html, reisetest-tp.html). Skjerm-ID er den første registrerte ID-en i filen; filer med flere skjermer krever manuell fordeling. Ikke dekket av regexen: kontroller som bygges av `.map()`, komponenter i delte filer (`parts.jsx`, `tp-parts.jsx`, `tp-v2.jsx`, `WB3*.jsx`), tastatur og ikonknapper uten tekst utenfor `aria-label`. Manglende felt (objekt-ID-er, betingelser, tilbakevei, avbryt/feil, ulagrede endringer) er ikke utledet automatisk og må fylles ut per rad før eksport.

697 kontroller funnet, 165 med skjermmål (`go(...)`).

## Testet reise (bekreftet med kjørt test)

| Kontroll | Fra | Mål | Objekt | Test |
|---|---|---|---|---|
| PH-01 Start (golfkort) | PH-01 | PH-04 | sessionId okt-2609, kind golf | reisetest-tp: Start golf |
| PH-01 Start (fysisk kort) | PH-01 | PH-06 | sessionId fys-2609, kind fys | reisetest-tp: Start fysisk |
| PH-04 Start økt → PH-05 → Avslutt og gå til oppsummering | PH-04/05 | PH-07 | sessionId beholdes i PHQ_SESSION | reisetest-tp |
| PH-06 Fullfør økt / Avslutt | PH-06 | PH-07-FYS | serier og tid fra samme økt | reisetest-tp |
| PH-TP-01 Start økt | PH-TP-01 | PH-04 | sessionId okt-2609 | kode (ikke egen test) |

## Alle kontroller (utkast)

| Kontroll-ID | Fil | Linje | Rolle | Tekst/ikon | Mål/handling | Status |
|---|---|---|---|---|---|---|
| PH-01.K01 | playerhq/screens/PH-01.jsx | 26 | Button | Se økta | → PH-03 | utkast |
| PH-01.K02 | playerhq/screens/PH-01.jsx | 27 | Button | Start | handling | utkast |
| PH-01.K03 | playerhq/screens/PH-01.jsx | 36 | button | — | toast | utkast |
| PH-01.K04 | playerhq/screens/PH-01.jsx | 68 | Button | Registrer sett | → PH-WB-FYS | utkast |
| PH-01.K05 | playerhq/screens/PH-01.jsx | 75 | Button | Legg til turnering | → PH-WB-TURN | utkast |
| PH-01.K06 | playerhq/screens/PH-01.jsx | 80 | Button | Se forberedelser | → PH-WB-TURN | utkast |
| PH-01.K07 | playerhq/screens/PH-01.jsx | 87 | Button | Velg treningsplan | → PH-12 | utkast |
| PH-01.K08 | playerhq/screens/PH-01.jsx | 139 | Button | Ignorer | toast | utkast |
| PH-01.K09 | playerhq/screens/PH-01.jsx | 139 | Button | Les | → PH-21 | utkast |
| PH-03.K01 | playerhq/screens/PH-03.jsx | 27 | Button | Start økt | toast | utkast |
| PH-03.K02 | playerhq/screens/PH-03.jsx | 27 | Button | Hopp over | lokal tilstand | utkast |
| PH-03.K03 | playerhq/screens/PH-03.jsx | 28 | Button | Fullfør økt | toast | utkast |
| PH-03.K04 | playerhq/screens/PH-03.jsx | 28 | Button | Åpne live-økt | → PH-05 | utkast |
| PH-03.K05 | playerhq/screens/PH-03.jsx | 29 | Button | Se oppsummering | → PH-07 | utkast |
| PH-03.K06 | playerhq/screens/PH-03.jsx | 30 | Button | Angre | lokal tilstand | utkast |
| PH-03.K07 | playerhq/screens/PH-03.jsx | 36 | Button | ro ? "Ferdig" : "Endre rekkefølge" | lokal tilstand | utkast |
| PH-03.K08 | playerhq/screens/PH-03.jsx | 47 | Button | Hopp over økt | toast | utkast |
| PH-03.K09 | playerhq/screens/PH-03.jsx | 47 | Button | Avbryt | lokal tilstand | utkast |
| PH-03.K10 | playerhq/screens/PH-03.jsx | 49 | ChoicePill | r | lokal tilstand | utkast |
| PH-04.K01 | playerhq/screens/PH-04.jsx | 5 | IconButton | ikon:x | → PH-03 | utkast |
| PH-04.K02 | playerhq/screens/PH-04.jsx | 6 | Button | Start økt | → PH-05 | utkast |
| PH-04.K03 | playerhq/screens/PH-04.jsx | 7 | Button | Tilbake til øktarket | → PH-03 | utkast |
| PH-05.K01 | playerhq/screens/PH-05.jsx | 18 | Button | pause ? "Fortsett" : "Pause" | lokal tilstand | utkast |
| PH-05.K02 | playerhq/screens/PH-05.jsx | 18 | Button | Avslutt | lokal tilstand | utkast |
| PH-05.K03 | playerhq/screens/PH-05.jsx | 19 | Button | last ? "Fullfør økt" : "Neste øvelse" | → PH-07 | utkast |
| PH-05.K04 | playerhq/screens/PH-05.jsx | 27 | button | — | lokal tilstand | utkast |
| PH-05.K05 | playerhq/screens/PH-05.jsx | 41 | IconButton | ikon:undo-2 | handling | utkast |
| PH-05.K06 | playerhq/screens/PH-05.jsx | 42 | Button | +5 | handling | utkast |
| PH-05.K07 | playerhq/screens/PH-05.jsx | 43 | Button | +1 | handling | utkast |
| PH-05.K08 | playerhq/screens/PH-05.jsx | 45 | button | Åpne slagtelleren med kølle og TrackMan | → PH-06 | utkast |
| PH-05.K09 | playerhq/screens/PH-05.jsx | 47 | Button | Fortsett | lokal tilstand | utkast |
| PH-05.K10 | playerhq/screens/PH-05.jsx | 47 | Button | Avslutt og lagre | → PH-07 | utkast |
| PH-06.K01 | playerhq/screens/PH-06.jsx | 10 | Button | Avslutt | lokal tilstand | utkast |
| PH-06.K02 | playerhq/screens/PH-06.jsx | 13 | IconButton | ikon:undo-2 | handling | utkast |
| PH-06.K03 | playerhq/screens/PH-06.jsx | 14 | Button | +5 slag | handling | utkast |
| PH-06.K04 | playerhq/screens/PH-06.jsx | 16 | Button | +1 slag | handling | utkast |
| PH-06.K05 | playerhq/screens/PH-06.jsx | 28 | button | c | lokal tilstand | utkast |
| PH-06.K06 | playerhq/screens/PH-06.jsx | 45 | Button | Fortsett | lokal tilstand | utkast |
| PH-06.K07 | playerhq/screens/PH-06.jsx | 45 | Button | Avslutt og lagre | → PH-07 | utkast |
| PH-07.K01 | playerhq/screens/PH-07.jsx | 6 | IconButton | ikon:x | → PH-01 | utkast |
| PH-07.K02 | playerhq/screens/PH-07.jsx | 7 | Button | Til I dag | → PH-01 | utkast |
| PH-07.K03 | playerhq/screens/PH-07.jsx | 8 | Button | Lagre økt | toast | utkast |
| PH-07.K04 | playerhq/screens/PH-07.jsx | 9 | Button | Tilbake til økta | → PH-05 | utkast |
| PH-08.K01 | playerhq/screens/PH-08.jsx | 5 | button | "−" + Math.abs(s) | handling | utkast |
| PH-08.K02 | playerhq/screens/PH-08.jsx | 7 | button | "+" + s | handling | utkast |
| PH-08.K03 | playerhq/screens/PH-08.jsx | 23 | Button | Avslutt | lokal tilstand | utkast |
| PH-08.K04 | playerhq/screens/PH-08.jsx | 25 | Button | Fullfør hull hole + 1 · shots.length // "—" slag | handling | utkast |
| PH-08.K05 | playerhq/screens/PH-08.jsx | 26 | Button | Registrer slag | handling | utkast |
| PH-08.K06 | playerhq/screens/PH-08.jsx | 31 | button | — | lokal tilstand | utkast |
| PH-08.K07 | playerhq/screens/PH-08.jsx | 46 | Button | Fortsett | lokal tilstand | utkast |
| PH-08.K08 | playerhq/screens/PH-08.jsx | 46 | Button | canSave ? "Lagre " + played + " hull" : "Lagre r | → PH-09 | utkast |
| PH-09.K01 | playerhq/screens/PH-09.jsx | 9 | button | − | handling | utkast |
| PH-09.K02 | playerhq/screens/PH-09.jsx | 11 | button | + | handling | utkast |
| PH-09.K03 | playerhq/screens/PH-09.jsx | 33 | Button | Lagre runde | handling | utkast |
| PH-09.K04 | playerhq/screens/PH-09.jsx | 37 | Button | Registrer live | → PH-08 | utkast |
| PH-09.K05 | playerhq/screens/PH-09.jsx | 42 | ChoicePill | d | lokal tilstand | utkast |
| PH-09.K06 | playerhq/screens/PH-09.jsx | 46 | ChoicePill | n | lokal tilstand | utkast |
| PH-10.K01 | playerhq/screens/PH-10.jsx | 27 | Button | Be coach endre | lokal tilstand | utkast |
| PH-10.K02 | playerhq/screens/PH-10.jsx | 27 | Button | Rediger | → PH-11 | utkast |
| PH-10.K03 | playerhq/screens/PH-10.jsx | 31 | IconButton | ikon:chevron-left | handling | utkast |
| PH-10.K04 | playerhq/screens/PH-10.jsx | 33 | IconButton | ikon:chevron-right | handling | utkast |
| PH-10.K05 | playerhq/screens/PH-10.jsx | 35 | IconButton | ikon:circle-help | lokal tilstand | utkast |
| PH-10.K06 | playerhq/screens/PH-10.jsx | 39 | ChoicePill | l.label | lokal tilstand | utkast |
| PH-10.K07 | playerhq/screens/PH-10.jsx | 40 | Button | gconn ? "Google · koblet" : "Koble Google-kalend | lokal tilstand | utkast |
| PH-11.K01 | playerhq/screens/PH-11-rediger.jsx | 38 | IconButton | ikon:trash-2 | handling | utkast |
| PH-11.K02 | playerhq/screens/PH-11-rediger.jsx | 45 | button | — | lokal tilstand | utkast |
| PH-11.K03 | playerhq/screens/PH-11-rediger.jsx | 50 | button | — | lokal tilstand | utkast |
| PH-11.K04 | playerhq/screens/PH-11-rediger.jsx | 63 | IconButton | ikon:plus | handling | utkast |
| PH-11.K05 | playerhq/screens/PH-11-rediger.jsx | 66 | Button | Hele øvelsesbanken | → PH-13 | utkast |
| PH-11.K06 | playerhq/screens/PH-11-rediger.jsx | 70 | IconButton | ikon:circle-help | lokal tilstand | utkast |
| PH-11.K07 | playerhq/screens/PH-11-rediger.jsx | 70 | Button | Ferdig | → PH-10 | utkast |
| PH-11.K08 | playerhq/screens/PH-11-rediger.jsx | 73 | IconButton | ikon:chevron-left | lokal tilstand | utkast |
| PH-11.K09 | playerhq/screens/PH-11-rediger.jsx | 79 | ChoicePill | AXL[a] | lokal tilstand | utkast |
| PH-11.K01 | playerhq/screens/PH-11.jsx | 10 | button | — | handling | utkast |
| PH-11.K02 | playerhq/screens/PH-11.jsx | 76 | button | — | lokal tilstand | utkast |
| PH-11.K03 | playerhq/screens/PH-11.jsx | 81 | button | — | → «org.from.to» | utkast |
| PH-11.K04 | playerhq/screens/PH-11.jsx | 83 | button | + Økt | handling | utkast |
| PH-11.K05 | playerhq/screens/PH-11.jsx | 95 | button | — | → «d.from.to» | utkast |
| PH-11.K06 | playerhq/screens/PH-11.jsx | 96 | IconButton | ikon:minus | handling | utkast |
| PH-11.K07 | playerhq/screens/PH-11.jsx | 98 | IconButton | ikon:plus | handling | utkast |
| PH-11.K08 | playerhq/screens/PH-11.jsx | 102 | Button | Flytt … | lokal tilstand | utkast |
| PH-11.K09 | playerhq/screens/PH-11.jsx | 102 | Button | Dupliser | handling | utkast |
| PH-11.K10 | playerhq/screens/PH-11.jsx | 103 | Button | Legg til øvelse | → AG-14, PH-13 | utkast |
| PH-11.K11 | playerhq/screens/PH-11.jsx | 104 | Button | Fjern økt | toast | utkast |
| PH-11.K12 | playerhq/screens/PH-11.jsx | 109 | Button | coach.group ? "Publiser uke " + wk + " til " + c | lokal tilstand | utkast |
| PH-11.K13 | playerhq/screens/PH-11.jsx | 109 | Button | Planbygger | → PH-12 | utkast |
| PH-11.K14 | playerhq/screens/PH-11.jsx | 109 | Button | Send uke wk til coach | toast | utkast |
| PH-11.K15 | playerhq/screens/PH-11.jsx | 124 | IconButton | ikon:chevron-left | lokal tilstand | utkast |
| PH-11.K16 | playerhq/screens/PH-11.jsx | 125 | button | — | lokal tilstand | utkast |
| PH-11.K17 | playerhq/screens/PH-11.jsx | 138 | Button | Opprett uke wk | handling | utkast |
| PH-12.K01 | playerhq/screens/PH-12.jsx | 16 | ChoicePill | k | lokal tilstand | utkast |
| PH-12.K02 | playerhq/screens/PH-12.jsx | 21 | button | — | lokal tilstand | utkast |
| PH-12.K03 | playerhq/screens/PH-12.jsx | 35 | Button | Send valg til coach | handling | utkast |
| PH-12.K04 | playerhq/screens/PH-12.jsx | 36 | Button | Åpne Plan | → PH-10 | utkast |
| PH-12.K05 | playerhq/screens/PH-12.jsx | 36 | Button | Trekk tilbake | toast | utkast |
| PH-13.K01 | playerhq/screens/PH-13.jsx | 38 | Button | Legg i banken | lokal tilstand | utkast |
| PH-13.K02 | playerhq/screens/PH-13.jsx | 38 | Button | Forkast utkast | toast | utkast |
| PH-13.K03 | playerhq/screens/PH-13.jsx | 38 | Button | Legg til i økt | handling | utkast |
| PH-13.K04 | playerhq/screens/PH-13.jsx | 38 | Button | Åpne Workbench | → PH-11 | utkast |
| PH-13.K05 | playerhq/screens/PH-13.jsx | 40 | button | — | lokal tilstand | utkast |
| PH-13.K06 | playerhq/screens/PH-13.jsx | 46 | Button | Ny øvelse | toast | utkast |
| PH-13.K07 | playerhq/screens/PH-13.jsx | 53 | button | — | lokal tilstand | utkast |
| PH-13.K08 | playerhq/screens/PH-13.jsx | 54 | Button | Legg i banken | handling | utkast |
| PH-13.K09 | playerhq/screens/PH-13.jsx | 54 | Button | Se detaljer | lokal tilstand | utkast |
| PH-14.K01 | playerhq/screens/PH-14.jsx | 14 | Button | Gjennomfør test | → PH-15 | utkast |
| PH-14.K02 | playerhq/screens/PH-14.jsx | 14 | Button | Registrer resultat | handling | utkast |
| PH-14.K03 | playerhq/screens/PH-14.jsx | 32 | button | — | lokal tilstand | utkast |
| PH-14.K04 | playerhq/screens/PH-14.jsx | 40 | Button | Lag egen test | lokal tilstand | utkast |
| PH-14.K05 | playerhq/screens/PH-14.jsx | 40 | Button | Gjennomfør test | → PH-15 | utkast |
| PH-14.K06 | playerhq/screens/PH-14.jsx | 48 | Button | Lagre resultat | handling | utkast |
| PH-14.K07 | playerhq/screens/PH-14.jsx | 48 | Button | Avbryt | lokal tilstand | utkast |
| PH-14.K08 | playerhq/screens/PH-14.jsx | 51 | Button | Opprett test | handling | utkast |
| PH-14.K09 | playerhq/screens/PH-14.jsx | 51 | Button | Avbryt | lokal tilstand | utkast |
| PH-15-TN.K01 | playerhq/screens/PH-15-tn.jsx | 16 | Button | Avslutt | lokal tilstand | utkast |
| PH-15-TN.K02 | playerhq/screens/PH-15-tn.jsx | 17 | Button | Til testene | → PH-14 | utkast |
| PH-15-TN.K03 | playerhq/screens/PH-15-tn.jsx | 17 | Button | t.mode === "hit" ? "Lagre · " + sum + " / " + t. | lokal tilstand | utkast |
| PH-15-TN.K04 | playerhq/screens/PH-15-tn.jsx | 18 | Button | Treff | handling | utkast |
| PH-15-TN.K05 | playerhq/screens/PH-15-tn.jsx | 18 | Button | Bom | handling | utkast |
| PH-15-TN.K06 | playerhq/screens/PH-15-tn.jsx | 18 | Button | Registrer t.id === "8ball" ? "ball" : "hull" L.l | handling | utkast |
| PH-15-TN.K07 | playerhq/screens/PH-15-tn.jsx | 21 | ChoicePill | x.name | lokal tilstand | utkast |
| PH-15-TN.K08 | playerhq/screens/PH-15-tn.jsx | 32 | Button | Angre siste | lokal tilstand | utkast |
| PH-15-TN.K09 | playerhq/screens/PH-15-tn.jsx | 38 | Button | Senket · 6 poeng | handling | utkast |
| PH-15-TN.K10 | playerhq/screens/PH-15-tn.jsx | 40 | Button | Før | lokal tilstand | utkast |
| PH-15-TN.K11 | playerhq/screens/PH-15-tn.jsx | 43 | Button | Fortsett | lokal tilstand | utkast |
| PH-15-TN.K12 | playerhq/screens/PH-15-tn.jsx | 43 | Button | Avslutt uten å lagre | → PH-14 | utkast |
| PH-15.K01 | playerhq/screens/PH-15.jsx | 11 | Button | Avslutt | lokal tilstand | utkast |
| PH-15.K02 | playerhq/screens/PH-15.jsx | 12 | Button | Til testene | → PH-14 | utkast |
| PH-15.K03 | playerhq/screens/PH-15.jsx | 12 | Button | Lagre resultat · inside av 10 | toast | utkast |
| PH-15.K04 | playerhq/screens/PH-15.jsx | 13 | Button | Registrer slag res.length + 1 · P.dec(m) m | handling | utkast |
| PH-15.K05 | playerhq/screens/PH-15.jsx | 31 | button | Angre siste | lokal tilstand | utkast |
| PH-15.K06 | playerhq/screens/PH-15.jsx | 37 | Button | Fortsett | lokal tilstand | utkast |
| PH-15.K07 | playerhq/screens/PH-15.jsx | 37 | Button | Avslutt uten å lagre | → PH-14 | utkast |
| PH-16.K01 | playerhq/screens/PH-16-stats.jsx | 15 | Button | Registrer runde | → PH-RD-01 | utkast |
| PH-16.K02 | playerhq/screens/PH-16-stats.jsx | 17 | button | — | lokal tilstand | utkast |
| PH-16.K01 | playerhq/screens/PH-16.jsx | 16 | Button | Registrer runde | → PH-09 | utkast |
| PH-16.K02 | playerhq/screens/PH-16.jsx | 29 | button | — | → «id» | utkast |
| PH-16b.K01 | playerhq/screens/PH-16b-skill-map.jsx | 75 | Button | Se som liste | → PH-16 | utkast |
| PH-16b.K02 | playerhq/screens/PH-16b-skill-map.jsx | 96 | button | — | lokal tilstand | utkast |
| PH-17.K01 | playerhq/screens/PH-17.jsx | 16 | button | — | handling | utkast |
| PH-17.K02 | playerhq/screens/PH-17.jsx | 22 | ChoicePill | c | lokal tilstand | utkast |
| PH-17.K03 | playerhq/screens/PH-17.jsx | 64 | Button | Start stasjon · 10 slag | toast | utkast |
| PH-17.K04 | playerhq/screens/PH-17.jsx | 67 | Button | Stats | → PH-16 | utkast |
| PH-18.K01 | playerhq/screens/PH-18.jsx | 44 | Button | Del runde | lokal tilstand | utkast |
| PH-18.K02 | playerhq/screens/PH-18.jsx | 53 | Button | v.done ? "Endre gjennomgang" : "Fullfør gjennomg | lokal tilstand | utkast |
| PH-18.K03 | playerhq/screens/PH-18.jsx | 53 | Button | Hull for hull | → PH-09 | utkast |
| PH-18.K04 | playerhq/screens/PH-18.jsx | 79 | Button | Se hullet i gameplan | → PH-20 | utkast |
| PH-18.K05 | playerhq/screens/PH-18.jsx | 88 | Button | Registrer runde | → PH-09 | utkast |
| PH-18.K06 | playerhq/screens/PH-18.jsx | 93 | Button | Kopier lenke | toast | utkast |
| PH-18.K07 | playerhq/screens/PH-18.jsx | 93 | Button | Avbryt | lokal tilstand | utkast |
| PH-18.K08 | playerhq/screens/PH-18.jsx | 96 | Button | Lagre gjennomgang | toast | utkast |
| PH-18.K09 | playerhq/screens/PH-18.jsx | 96 | Button | Lagre delvis | toast | utkast |
| PH-19.K01 | playerhq/screens/PH-19.jsx | 8 | Button | Meg | → PH-24 | utkast |
| PH-20.K01 | playerhq/screens/PH-20.jsx | 54 | button | — | lokal tilstand | utkast |
| PH-20.K02 | playerhq/screens/PH-20.jsx | 61 | button | — | lokal tilstand | utkast |
| PH-20.K03 | playerhq/screens/PH-20.jsx | 63 | Button | Last ned gameplan | toast | utkast |
| PH-20.K04 | playerhq/screens/PH-20.jsx | 65 | button | — | lokal tilstand | utkast |
| PH-21.K01 | playerhq/screens/PH-21.jsx | 22 | Button | Send | handling | utkast |
| PH-21.K02 | playerhq/screens/PH-21.jsx | 25 | Button | Send spørsmål | lokal tilstand | utkast |
| PH-21.K03 | playerhq/screens/PH-21.jsx | 31 | ChoicePill | i + 1 | lokal tilstand | utkast |
| PH-21.K04 | playerhq/screens/PH-21.jsx | 33 | Button | Send tilbakemelding | lokal tilstand | utkast |
| PH-21.K05 | playerhq/screens/PH-21.jsx | 37 | button | — | toast | utkast |
| PH-21.K06 | playerhq/screens/PH-21.jsx | 44 | Button | Godta plan | lokal tilstand | utkast |
| PH-21.K07 | playerhq/screens/PH-21.jsx | 44 | Button | Se i Plan | → PH-10 | utkast |
| PH-21.K08 | playerhq/screens/PH-21.jsx | 44 | Button | Avvis | lokal tilstand | utkast |
| PH-21.K09 | playerhq/screens/PH-21.jsx | 48 | ChoicePill | d | lokal tilstand | utkast |
| PH-21.K10 | playerhq/screens/PH-21.jsx | 49 | ChoicePill | a | lokal tilstand | utkast |
| PH-21.K11 | playerhq/screens/PH-21.jsx | 51 | Button | Send ønske | toast | utkast |
| PH-21.K12 | playerhq/screens/PH-21.jsx | 54 | Button | Spør Caddie | → PH-22 | utkast |
| PH-22.K01 | playerhq/screens/PH-22.jsx | 11 | Button | Godta og send til Anders | handling | utkast |
| PH-22.K02 | playerhq/screens/PH-22.jsx | 11 | Button | Forkast | handling | utkast |
| PH-22.K03 | playerhq/screens/PH-22.jsx | 20 | Button | Skriv til Anders | → PH-21 | utkast |
| PH-22.K04 | playerhq/screens/PH-22.jsx | 38 | button | — | handling | utkast |
| PH-22.K05 | playerhq/screens/PH-22.jsx | 39 | IconButton | ikon:arrow-up | handling | utkast |
| PH-23.K01 | playerhq/screens/PH-23.jsx | 22 | Button | Legg i kalender | toast | utkast |
| PH-23.K02 | playerhq/screens/PH-23.jsx | 22 | Button | Book en til | handling | utkast |
| PH-23.K03 | playerhq/screens/PH-23.jsx | 24 | button | — | lokal tilstand | utkast |
| PH-23.K04 | playerhq/screens/PH-23.jsx | 30 | button | — | lokal tilstand | utkast |
| PH-23.K05 | playerhq/screens/PH-23.jsx | 31 | ChoicePill | t | lokal tilstand | utkast |
| PH-23.K06 | playerhq/screens/PH-23.jsx | 38 | Button | Tilbake | lokal tilstand | utkast |
| PH-23.K07 | playerhq/screens/PH-23.jsx | 38 | Button | Neste: STEPS[step + 1] | lokal tilstand | utkast |
| PH-23.K08 | playerhq/screens/PH-23.jsx | 38 | Button | Bekreft booking | handling | utkast |
| PH-23.K09 | playerhq/screens/PH-23.jsx | 50 | Button | Flytt time | lokal tilstand | utkast |
| PH-23.K10 | playerhq/screens/PH-23.jsx | 50 | Button | Avbestill | lokal tilstand | utkast |
| PH-23.K11 | playerhq/screens/PH-23.jsx | 65 | Button | Flytt til mvSlot ? B.days[mvDay].join(" ") + " " | lokal tilstand | utkast |
| PH-23.K12 | playerhq/screens/PH-23.jsx | 65 | Button | Avbryt | lokal tilstand | utkast |
| PH-23.K13 | playerhq/screens/PH-23.jsx | 66 | ChoicePill | d dt | lokal tilstand | utkast |
| PH-23.K14 | playerhq/screens/PH-23.jsx | 66 | ChoicePill | t | lokal tilstand | utkast |
| PH-23.K15 | playerhq/screens/PH-23.jsx | 68 | Button | Behold timen | lokal tilstand | utkast |
| PH-23.K16 | playerhq/screens/PH-23.jsx | 68 | Button | Avbestill | lokal tilstand | utkast |
| PH-24.K01 | playerhq/screens/PH-24.jsx | 19 | Button | Målsetninger | → PH-19 | utkast |
| PH-24.K02 | playerhq/screens/PH-24.jsx | 22 | button | — | lokal tilstand | utkast |
| PH-24.K03 | playerhq/screens/PH-24.jsx | 24 | Button | Legg til fasilitet | lokal tilstand | utkast |
| PH-24.K04 | playerhq/screens/PH-24.jsx | 28 | Button | Book time | → PH-23 | utkast |
| PH-24.K05 | playerhq/screens/PH-24.jsx | 32 | Button | Bytt kort og se kvitteringer | toast | utkast |
| PH-24.K06 | playerhq/screens/PH-24.jsx | 32 | Button | Endre abonnement | → PH-25 | utkast |
| PH-24.K07 | playerhq/screens/PH-24.jsx | 36 | Button | Inviter forelder | lokal tilstand | utkast |
| PH-24.K08 | playerhq/screens/PH-24.jsx | 36 | Button | Se tilgang | lokal tilstand | utkast |
| PH-24.K09 | playerhq/screens/PH-24.jsx | 40 | Button | Åpne deling | → PH-27 | utkast |
| PH-24.K10 | playerhq/screens/PH-24.jsx | 45 | Button | Registrer fravær | lokal tilstand | utkast |
| PH-24.K11 | playerhq/screens/PH-24.jsx | 63 | Button | Ny utfordring | toast | utkast |
| PH-24.K12 | playerhq/screens/PH-24.jsx | 65 | button | — | toast | utkast |
| PH-24.K13 | playerhq/screens/PH-24.jsx | 66 | Button | Åpne innstillinger | → PH-25 | utkast |
| PH-24.K14 | playerhq/screens/PH-24.jsx | 75 | Button | Send invitasjon | lokal tilstand | utkast |
| PH-24.K15 | playerhq/screens/PH-24.jsx | 75 | Button | Avbryt | lokal tilstand | utkast |
| PH-24.K16 | playerhq/screens/PH-24.jsx | 76 | Button | Lukk | lokal tilstand | utkast |
| PH-24.K17 | playerhq/screens/PH-24.jsx | 77 | Button | Lagre | lokal tilstand | utkast |
| PH-24.K18 | playerhq/screens/PH-24.jsx | 77 | Button | Avbryt | lokal tilstand | utkast |
| PH-24d-utfordringer.K01 | playerhq/screens/PH-24d-utfordringer.jsx | 34 | button | — | → «u.mode === "inv" ? "PH-24D-INVITERT" : u.st === "ENDED" ? | utkast |
| PH-24d-utfordringer.K02 | playerhq/screens/PH-24d-utfordringer.jsx | 44 | Button | Meg | → PH-24 | utkast |
| PH-24d-utfordringer.K03 | playerhq/screens/PH-24d-utfordringer.jsx | 44 | Button | Ny utfordring | → PH-24D-NY | utkast |
| PH-24d-utfordringer.K04 | playerhq/screens/PH-24d-utfordringer.jsx | 80 | Button | Bli med | handling | utkast |
| PH-24d-utfordringer.K05 | playerhq/screens/PH-24d-utfordringer.jsx | 85 | Button | Registrer score | handling | utkast |
| PH-24d-utfordringer.K06 | playerhq/screens/PH-24d-utfordringer.jsx | 89 | Button | Avslutt utfordring | lokal tilstand | utkast |
| PH-24d-utfordringer.K07 | playerhq/screens/PH-24d-utfordringer.jsx | 95 | Button | Utfordringer | → PH-24D | utkast |
| PH-24d-utfordringer.K08 | playerhq/screens/PH-24d-utfordringer.jsx | 99 | Button | Fortsett | lokal tilstand | utkast |
| PH-24d-utfordringer.K09 | playerhq/screens/PH-24d-utfordringer.jsx | 99 | Button | Avslutt utfordring | toast | utkast |
| PH-24d-utfordringer.K10 | playerhq/screens/PH-24d-utfordringer.jsx | 112 | ChoicePill | n | handling | utkast |
| PH-24d-utfordringer.K11 | playerhq/screens/PH-24d-utfordringer.jsx | 114 | Button | Utfordringer | → PH-24D | utkast |
| PH-24d-utfordringer.K12 | playerhq/screens/PH-24d-utfordringer.jsx | 129 | Button | Opprett utfordringantall ? " · " + antall + " va | handling | utkast |
| PH-25.K01 | playerhq/screens/PH-25.jsx | 12 | Button | Meg | → PH-24 | utkast |
| PH-25.K02 | playerhq/screens/PH-25.jsx | 20 | Button | p.id === "FULL" ? "Velg Full" : "Bytt til Gratis | toast | utkast |
| PH-25.K03 | playerhq/screens/PH-25.jsx | 28 | Button | Avslutt abonnement | lokal tilstand | utkast |
| PH-25.K04 | playerhq/screens/PH-25.jsx | 29 | Button | Fortsett Full | toast | utkast |
| PH-25.K05 | playerhq/screens/PH-25.jsx | 31 | Button | Bytt kort og se kvitteringer | toast | utkast |
| PH-25.K06 | playerhq/screens/PH-25.jsx | 44 | button | — | toast | utkast |
| PH-25.K07 | playerhq/screens/PH-25.jsx | 45 | Button | Slett konto | lokal tilstand | utkast |
| PH-25.K08 | playerhq/screens/PH-25.jsx | 46 | Button | Send | lokal tilstand | utkast |
| PH-25.K09 | playerhq/screens/PH-25.jsx | 50 | Button | Behold kontoen | lokal tilstand | utkast |
| PH-25.K10 | playerhq/screens/PH-25.jsx | 50 | Button | Slett for godt | toast | utkast |
| PH-25.K11 | playerhq/screens/PH-25.jsx | 51 | Button | Behold Full | lokal tilstand | utkast |
| PH-25.K12 | playerhq/screens/PH-25.jsx | 51 | Button | Avslutt abonnement | toast | utkast |
| PH-26.K01 | playerhq/screens/PH-26.jsx | 12 | Button | Avslutt utfordring | handling | utkast |
| PH-26.K02 | playerhq/screens/PH-26.jsx | 31 | Button | Registrer økt | toast | utkast |
| PH-26.K03 | playerhq/screens/PH-26.jsx | 42 | Button | Opprett utfordring | handling | utkast |
| PH-26.K04 | playerhq/screens/PH-26.jsx | 56 | Button | Meld på | lokal tilstand | utkast |
| PH-26.K05 | playerhq/screens/PH-26.jsx | 62 | Button | Se planen fra Anders | → PH-21 | utkast |
| PH-26B.K01 | playerhq/screens/PH-26b-utgar-trening.jsx | 24 | button | — | handling | utkast |
| PH-26B.K02 | playerhq/screens/PH-26b-utgar-trening.jsx | 42 | Button | Utenfor banen | → PH-26 | utkast |
| PH-26B.K03 | playerhq/screens/PH-26b-utgar-trening.jsx | 65 | Button | Bekreft plassering | handling | utkast |
| PH-27.K01 | playerhq/screens/PH-27.jsx | 34 | button | — | lokal tilstand | utkast |
| PH-27.K02 | playerhq/screens/PH-27.jsx | 41 | Button | a.st === "ok" ? "Trekk tilgang" : "Trekk tilbake | handling | utkast |
| PH-27.K03 | playerhq/screens/PH-27.jsx | 53 | Button | Godta | handling | utkast |
| PH-27.K04 | playerhq/screens/PH-27.jsx | 53 | Button | Avslå | handling | utkast |
| PH-27.K05 | playerhq/screens/PH-27.jsx | 58 | Button | Send lenke | handling | utkast |
| PH-27.K06 | playerhq/screens/PH-27.jsx | 63 | Button | Meg | → PH-24 | utkast |
| PH-27.K07 | playerhq/screens/PH-27.jsx | 84 | Button | Start sjekken | lokal tilstand | utkast |
| PH-27.K08 | playerhq/screens/PH-27.jsx | 85 | Button | Send til Anders | handling | utkast |
| PH-27.K09 | playerhq/screens/PH-27.jsx | 85 | Button | Fortsett senere | lokal tilstand | utkast |
| PH-27.K10 | playerhq/screens/PH-27.jsx | 88 | ChoicePill | o | lokal tilstand | utkast |
| PH-27.K11 | playerhq/screens/PH-27.jsx | 93 | Button | Se målsetningene i Plan | → PH-19 | utkast |
| PH-27.K12 | playerhq/screens/PH-27.jsx | 99 | button | — | lokal tilstand | utkast |
| PH-27.K13 | playerhq/screens/PH-27.jsx | 100 | button | n | lokal tilstand | utkast |
| PH-27.K14 | playerhq/screens/PH-27.jsx | 100 | Button | Neste område | lokal tilstand | utkast |
| PH-A1.K01 | playerhq/screens/PH-A1.jsx | 28 | button | — | → «to» | utkast |
| PH-A2.K01 | playerhq/screens/PH-A2.jsx | 60 | Button | Gjennomfør test på nytt | → PH-15 | utkast |
| PH-A2.K02 | playerhq/screens/PH-A2.jsx | 67 | Button | t.valid === null ? "Ta testen" : "Ta på nytt" | → PH-15 | utkast |
| PH-A2.K03 | playerhq/screens/PH-A2.jsx | 84 | Button | l | → «to» | utkast |
| PH-RD-1.K01 | playerhq/screens/PH-RD-1.jsx | 23 | button | Fortsett kladden | → PH-RD-03 | utkast |
| PH-RD-1.K02 | playerhq/screens/PH-RD-1.jsx | 25 | button | — | lokal tilstand | utkast |
| PH-RD-1.K03 | playerhq/screens/PH-RD-1.jsx | 32 | Button | Avbryt | → PH-18 | utkast |
| PH-RD-1.K04 | playerhq/screens/PH-RD-1.jsx | 32 | Button | sel === "import" ? "Til import" : sel === "rask" | → «sel === "import" ? "PH-RD-07" : sel === "rask" ? "PH-RD-0 | utkast |
| PH-RD-1.K05 | playerhq/screens/PH-RD-1.jsx | 48 | Button | Gjenopprett kladd | → PH-RD-03 | utkast |
| PH-RD-1.K06 | playerhq/screens/PH-RD-1.jsx | 48 | Button | Forkast kladd | lokal tilstand | utkast |
| PH-RD-1.K07 | playerhq/screens/PH-RD-1.jsx | 57 | Button | Tilbake | → PH-RD-01 | utkast |
| PH-RD-1.K08 | playerhq/screens/PH-RD-1.jsx | 57 | Button | Start runde | → PH-RD-03 | utkast |
| PH-RD-1.K09 | playerhq/screens/PH-RD-1.jsx | 77 | Button | Slag-for-slag på hull h + 1 | → PH-RD-04 | utkast |
| PH-RD-1.K10 | playerhq/screens/PH-RD-1.jsx | 78 | Button | Lagre v og neste hull | lokal tilstand | utkast |
| PH-RD-1.K11 | playerhq/screens/PH-RD-1.jsx | 85 | IconButton | ikon:minus | handling | utkast |
| PH-RD-1.K12 | playerhq/screens/PH-RD-1.jsx | 87 | IconButton | ikon:plus | handling | utkast |
| PH-RD-1.K13 | playerhq/screens/PH-RD-1.jsx | 90 | button | — | lokal tilstand | utkast |
| PH-RD-1.K14 | playerhq/screens/PH-RD-1.jsx | 91 | Button | SG hittil · L.slagHoles.length hull | → PH-RD-05 | utkast |
| PH-RD-1.K15 | playerhq/screens/PH-RD-1.jsx | 92 | Button | Avslutt runden | → PH-RD-08 | utkast |
| PH-RD-1.K16 | playerhq/screens/PH-RD-1.jsx | 110 | IconButton | ikon:arrow-left | → PH-RD-03 | utkast |
| PH-RD-1.K17 | playerhq/screens/PH-RD-1.jsx | 111 | Button | Neste hull | → PH-RD-03 | utkast |
| PH-RD-1.K18 | playerhq/screens/PH-RD-1.jsx | 112 | Button | I hull | handling | utkast |
| PH-RD-1.K19 | playerhq/screens/PH-RD-1.jsx | 113 | Button | Lagre slag n | handling | utkast |
| PH-RD-1.K20 | playerhq/screens/PH-RD-1.jsx | 125 | ChoicePill | l | lokal tilstand | utkast |
| PH-RD-1.K21 | playerhq/screens/PH-RD-1.jsx | 128 | ChoicePill | l | lokal tilstand | utkast |
| PH-RD-1.K22 | playerhq/screens/PH-RD-1.jsx | 130 | ChoicePill | x | lokal tilstand | utkast |
| PH-RD-1.K23 | playerhq/screens/PH-RD-1.jsx | 132 | Button | Mer: kølle, vind, mental, notat, sikte | lokal tilstand | utkast |
| PH-RD-1.K24 | playerhq/screens/PH-RD-1.jsx | 135 | Button | Angre siste slag | lokal tilstand | utkast |
| PH-RD-1.K25 | playerhq/screens/PH-RD-1.jsx | 138 | Button | Ferdig | lokal tilstand | utkast |
| PH-RD-1.K26 | playerhq/screens/PH-RD-1.jsx | 154 | IconButton | ikon:arrow-left | → PH-RD-03 | utkast |
| PH-RD-1.K27 | playerhq/screens/PH-RD-1.jsx | 155 | Button | Tilbake til hull 5 | → PH-RD-03 | utkast |
| PH-RD-2.K01 | playerhq/screens/PH-RD-2.jsx | 41 | ChoicePill | Putter · FW · GIR | lokal tilstand | utkast |
| PH-RD-2.K02 | playerhq/screens/PH-RD-2.jsx | 44 | button | − | lokal tilstand | utkast |
| PH-RD-2.K03 | playerhq/screens/PH-RD-2.jsx | 44 | button | + | lokal tilstand | utkast |
| PH-RD-2.K04 | playerhq/screens/PH-RD-2.jsx | 50 | Button | Legg til slag-for-slag for beregnet SG | → PH-RD-09 | utkast |
| PH-RD-2.K05 | playerhq/screens/PH-RD-2.jsx | 53 | Button | Avbryt | → PH-RD-01 | utkast |
| PH-RD-2.K06 | playerhq/screens/PH-RD-2.jsx | 53 | Button | Lagre delvis | handling | utkast |
| PH-RD-2.K07 | playerhq/screens/PH-RD-2.jsx | 53 | Button | Lagre runde | handling | utkast |
| PH-RD-2.K08 | playerhq/screens/PH-RD-2.jsx | 74 | Button | Legg inn SG fra UpGame | → PH-RD-06 | utkast |
| PH-RD-2.K09 | playerhq/screens/PH-RD-2.jsx | 89 | Button | Avbryt | → PH-RD-01 | utkast |
| PH-RD-2.K10 | playerhq/screens/PH-RD-2.jsx | 118 | Button | Tilbake og rett | → PH-RD-03 | utkast |
| PH-RD-2.K11 | playerhq/screens/PH-RD-2.jsx | 118 | Button | Lagre delvis | toast | utkast |
| PH-RD-2.K12 | playerhq/screens/PH-RD-2.jsx | 118 | Button | Lagre runde | handling | utkast |
| PH-RD-2.K13 | playerhq/screens/PH-RD-2.jsx | 134 | ChoicePill | x | lokal tilstand | utkast |
| PH-RD-2.K14 | playerhq/screens/PH-RD-2.jsx | 138 | Button | Bruk beregnet SG i stedet | lokal tilstand | utkast |
| PH-RD-2.K15 | playerhq/screens/PH-RD-2.jsx | 141 | Button | Legg til eller rett slag | → PH-RD-04 | utkast |
| PH-RD-2.K16 | playerhq/screens/PH-RD-2.jsx | 143 | Button | Avbryt | → PH-18 | utkast |
| PH-RD-2.K17 | playerhq/screens/PH-RD-2.jsx | 143 | Button | Lagre endringer | lokal tilstand | utkast |
| PH-RD-03.K01 | playerhq/screens/PH-RD-live.jsx | 11 | button | l | handling | utkast |
| PH-RD-03.K02 | playerhq/screens/PH-RD-live.jsx | 38 | button | children | handling | utkast |
| PH-RD-03.K03 | playerhq/screens/PH-RD-live.jsx | 39 | IconButton | ikon:flag | → PH-RD-08 | utkast |
| PH-RD-03.K04 | playerhq/screens/PH-RD-live.jsx | 40 | Button | edit != null ? "Lagre rettelse" : green && dr.re | handling | utkast |
| PH-RD-03.K05 | playerhq/screens/PH-RD-live.jsx | 60 | Button | dr.pen ? dr.pen + " straffe" : "Straffeslag" | lokal tilstand | utkast |
| PH-RD-03.K06 | playerhq/screens/PH-RD-live.jsx | 69 | Button | I hull · avslutt hullet | handling | utkast |
| PH-RD-03.K07 | playerhq/screens/PH-RD-live.jsx | 80 | IconButton | ikon:x | → PH-01 | utkast |
| PH-RD-03.K08 | playerhq/screens/PH-RD-live.jsx | 81 | Button | Se runden i Stats | → PH-16 | utkast |
| PH-TP-01.K01 | playerhq/screens/PH-TP.jsx | 20 | Button | Registrer repetisjoner | lokal tilstand | utkast |
| PH-TP-01.K02 | playerhq/screens/PH-TP.jsx | 20 | Button | Start økt | handling | utkast |
| PH-TP-01.K03 | playerhq/screens/PH-TP.jsx | 37 | ChoicePill | x.pos + " · " + x.title | lokal tilstand | utkast |
| PH-TP-01.K04 | playerhq/screens/PH-TP.jsx | 43 | Button | Registrer r.n repetisjoner | handling | utkast |
| PH-TP-01.K05 | playerhq/screens/PH-TP.jsx | 43 | Button | Avbryt | lokal tilstand | utkast |
| PH-TP-01.K06 | playerhq/screens/PH-TP.jsx | 45 | ChoicePill | n | lokal tilstand | utkast |
| PH-TP-01.K07 | playerhq/screens/PH-TP.jsx | 46 | ChoicePill | e | lokal tilstand | utkast |
| PH-TP-01.K08 | playerhq/screens/PH-TP.jsx | 48 | Button | +10 | lokal tilstand | utkast |
| PH-TP-01.K09 | playerhq/screens/PH-TP.jsx | 48 | Button | +25 | lokal tilstand | utkast |
| PH-TP-01.K10 | playerhq/screens/PH-TP.jsx | 49 | Button | r.video ? "Video lagt ved" : "Legg ved video fra | lokal tilstand | utkast |
| PH-04.K01 | playerhq/screens/PH-live.jsx | 17 | IconButton | ikon:x | → PH-01 | utkast |
| PH-04.K02 | playerhq/screens/PH-live.jsx | 18 | Button | Start økt | → PH-05 | utkast |
| PH-04.K03 | playerhq/screens/PH-live.jsx | 18 | Button | Tilbake til I dag | → PH-01 | utkast |
| PH-04.K04 | playerhq/screens/PH-live.jsx | 42 | Button | −1 | handling | utkast |
| PH-04.K05 | playerhq/screens/PH-live.jsx | 43 | Button | +5 | handling | utkast |
| PH-04.K06 | playerhq/screens/PH-live.jsx | 44 | Button | +1 | handling | utkast |
| PH-04.K07 | playerhq/screens/PH-live.jsx | 61 | IconButton | — | lokal tilstand | utkast |
| PH-04.K08 | playerhq/screens/PH-live.jsx | 61 | Button | Avslutt | lokal tilstand | utkast |
| PH-04.K09 | playerhq/screens/PH-live.jsx | 62 | Button | Ferdig med øvelsen | handling | utkast |
| PH-04.K10 | playerhq/screens/PH-live.jsx | 67 | button | dn ? | lokal tilstand | utkast |
| PH-04.K11 | playerhq/screens/PH-live.jsx | 68 | IconButton | ikon:list-ordered | lokal tilstand | utkast |
| PH-04.K12 | playerhq/screens/PH-live.jsx | 75 | button | — | lokal tilstand | utkast |
| PH-04.K13 | playerhq/screens/PH-live.jsx | 82 | Button | Se video · T.video | toast | utkast |
| PH-04.K14 | playerhq/screens/PH-live.jsx | 82 | Button | Legg til egen video | toast | utkast |
| PH-04.K15 | playerhq/screens/PH-live.jsx | 88 | Button | Lukk | lokal tilstand | utkast |
| PH-04.K16 | playerhq/screens/PH-live.jsx | 91 | IconButton | ikon:arrow-up | handling | utkast |
| PH-04.K17 | playerhq/screens/PH-live.jsx | 91 | IconButton | ikon:arrow-down | handling | utkast |
| PH-04.K18 | playerhq/screens/PH-live.jsx | 91 | IconButton | ikon:skip-forward | handling | utkast |
| PH-04.K19 | playerhq/screens/PH-live.jsx | 94 | Button | Fortsett | lokal tilstand | utkast |
| PH-04.K20 | playerhq/screens/PH-live.jsx | 94 | Button | Avslutt og gå til oppsummering | → PH-07 | utkast |
| PH-04.K21 | playerhq/screens/PH-live.jsx | 109 | Button | Avslutt | → PH-07-FYS | utkast |
| PH-04.K22 | playerhq/screens/PH-live.jsx | 110 | Button | Fullfør økt | → PH-07-FYS | utkast |
| PH-04.K23 | playerhq/screens/PH-live.jsx | 122 | IconButton | ikon:minus | handling | utkast |
| PH-04.K24 | playerhq/screens/PH-live.jsx | 122 | IconButton | ikon:plus | handling | utkast |
| PH-04.K25 | playerhq/screens/PH-live.jsx | 124 | button | — | handling | utkast |
| PH-04.K26 | playerhq/screens/PH-live.jsx | 127 | Button | Legg til serie | handling | utkast |
| PH-04.K27 | playerhq/screens/PH-live.jsx | 127 | Button | Fjern serie | handling | utkast |
| PH-04.K28 | playerhq/screens/PH-live.jsx | 143 | button | k | handling | utkast |
| PH-04.K29 | playerhq/screens/PH-live.jsx | 144 | IconButton | ikon:x | → PH-01 | utkast |
| PH-04.K30 | playerhq/screens/PH-live.jsx | 145 | Button | Til I dag | → PH-01 | utkast |
| PH-04.K31 | playerhq/screens/PH-live.jsx | 145 | Button | Lagre økta | toast | utkast |
| AG-01.K01 | agencyos/screens/AG-01.jsx | 15 | Button | Åpne i Kø | → AG-02 | utkast |
| AG-01.K02 | agencyos/screens/AG-01.jsx | 15 | Button | Senere | toast | utkast |
| AG-01.K03 | agencyos/screens/AG-01.jsx | 21 | button | — | → «c.to» (arg c.tab) | utkast |
| AG-01.K04 | agencyos/screens/AG-01.jsx | 48 | Button | Godkjenn | handling | utkast |
| AG-01.K05 | agencyos/screens/AG-01.jsx | 48 | Button | Rediger | → AG-02 | utkast |
| AG-01.K06 | agencyos/screens/AG-01.jsx | 48 | Button | Avvis | handling | utkast |
| AG-02.K01 | agencyos/screens/AG-02.jsx | 30 | button | — | lokal tilstand | utkast |
| AG-02.K02 | agencyos/screens/AG-02.jsx | 40 | Button | cur.kind === "Samtykke" ? "Registrer samtykke" : | handling | utkast |
| AG-02.K03 | agencyos/screens/AG-02.jsx | 40 | Button | Send tilbake | handling | utkast |
| AG-02.K04 | agencyos/screens/AG-02.jsx | 45 | Button | Godkjenn og send | handling | utkast |
| AG-02.K05 | agencyos/screens/AG-02.jsx | 45 | Button | Rediger utkast | toast | utkast |
| AG-02.K06 | agencyos/screens/AG-02.jsx | 45 | Button | Avvis | handling | utkast |
| AG-02.K07 | agencyos/screens/AG-02.jsx | 48 | Button | Attester resultat | handling | utkast |
| AG-02.K08 | agencyos/screens/AG-02.jsx | 48 | Button | Be om ny test | handling | utkast |
| AG-02.K09 | agencyos/screens/AG-02.jsx | 48 | Button | Påminn spilleren | toast | utkast |
| AG-02.K10 | agencyos/screens/AG-02.jsx | 51 | button | v | lokal tilstand | utkast |
| AG-02.K11 | agencyos/screens/AG-02.jsx | 53 | Button | Slå sammen | handling | utkast |
| AG-02.K12 | agencyos/screens/AG-02.jsx | 53 | Button | Ikke dublett | handling | utkast |
| AG-02.K13 | agencyos/screens/AG-02.jsx | 55 | Button | Behold innlegget | handling | utkast |
| AG-02.K14 | agencyos/screens/AG-02.jsx | 55 | Button | Fjern innlegget | lokal tilstand | utkast |
| AG-02.K15 | agencyos/screens/AG-02.jsx | 59 | Button | Send | handling | utkast |
| AG-02.K16 | agencyos/screens/AG-02.jsx | 59 | Button | Forkast | handling | utkast |
| AG-02.K17 | agencyos/screens/AG-02.jsx | 63 | Button | prio ? "Ferdig med prioritet" : "Sorter priorite | lokal tilstand | utkast |
| AG-02.K18 | agencyos/screens/AG-02.jsx | 70 | Button | Avbryt | lokal tilstand | utkast |
| AG-02.K19 | agencyos/screens/AG-02.jsx | 70 | Button | Fjern | lokal tilstand | utkast |
| AG-03.K01 | agencyos/screens/AG-03.jsx | 11 | button | c.who | → AG-08 | utkast |
| AG-03.K02 | agencyos/screens/AG-03.jsx | 15 | Button | Åpne igjen | lokal tilstand | utkast |
| AG-03.K03 | agencyos/screens/AG-03.jsx | 16 | Button | Løst | lokal tilstand | utkast |
| AG-03.K04 | agencyos/screens/AG-03.jsx | 16 | Button | l | lokal tilstand | utkast |
| AG-04.K01 | agencyos/screens/AG-04.jsx | 13 | Button | Tilbake | handling | utkast |
| AG-04.K02 | agencyos/screens/AG-04.jsx | 15 | button | — | handling | utkast |
| AG-04.K03 | agencyos/screens/AG-04.jsx | 25 | Button | Send | handling | utkast |
| AG-04.K04 | agencyos/screens/AG-04.jsx | 25 | Button | Nytt utkast | toast | utkast |
| AG-04.K05 | agencyos/screens/AG-04.jsx | 35 | Button | Send | toast | utkast |
| AG-04.K06 | agencyos/screens/AG-04.jsx | 35 | Button | Forkast | toast | utkast |
| AG-04.K07 | agencyos/screens/AG-04.jsx | 41 | Button | Tilbake | lokal tilstand | utkast |
| AG-04.K08 | agencyos/screens/AG-04.jsx | 46 | button | "" + k + "" | lokal tilstand | utkast |
| AG-04.K09 | agencyos/screens/AG-04.jsx | 48 | Button | Lagre mal | lokal tilstand | utkast |
| AG-04.K10 | agencyos/screens/AG-04.jsx | 48 | Button | Avbryt | lokal tilstand | utkast |
| AG-04.K11 | agencyos/screens/AG-04.jsx | 48 | Button | Slett mal | lokal tilstand | utkast |
| AG-04.K12 | agencyos/screens/AG-04.jsx | 55 | Button | Ny melding | toast | utkast |
| AG-04.K13 | agencyos/screens/AG-04.jsx | 61 | Button | Avbryt | lokal tilstand | utkast |
| AG-04.K14 | agencyos/screens/AG-04.jsx | 61 | Button | Slett | toast | utkast |
| AG-05.K01 | agencyos/screens/AG-05.jsx | 39 | button | — | lokal tilstand | utkast |
| AG-05.K02 | agencyos/screens/AG-05.jsx | 44 | Button | d dt | lokal tilstand | utkast |
| AG-05.K03 | agencyos/screens/AG-05.jsx | 50 | Button | Lagre tilgjengelighet | toast | utkast |
| AG-05.K04 | agencyos/screens/AG-05.jsx | 51 | Button | Legg til unntak | toast | utkast |
| AG-05.K05 | agencyos/screens/AG-05.jsx | 54 | Button | Ny hendelse | lokal tilstand | utkast |
| AG-05.K06 | agencyos/screens/AG-05.jsx | 61 | Button | Løs i fysisk plan | → AG-WB-FYS | utkast |
| AG-05.K07 | agencyos/screens/AG-05.jsx | 66 | Button | Book denne tiden | → AG-06 | utkast |
| AG-05.K08 | agencyos/screens/AG-05.jsx | 66 | Button | Flytt | lokal tilstand | utkast |
| AG-05.K09 | agencyos/screens/AG-05.jsx | 66 | Button | Endre hendelse | lokal tilstand | utkast |
| AG-05.K10 | agencyos/screens/AG-05.jsx | 66 | Button | Lukk | lokal tilstand | utkast |
| AG-05.K11 | agencyos/screens/AG-05.jsx | 71 | Button | Lagre | toast | utkast |
| AG-05.K12 | agencyos/screens/AG-05.jsx | 71 | Button | Avbryt | lokal tilstand | utkast |
| AG-06.K01 | agencyos/screens/AG-06.jsx | 16 | button | — | lokal tilstand | utkast |
| AG-06.K02 | agencyos/screens/AG-06.jsx | 22 | Button | Bekreft booking | handling | utkast |
| AG-06.K03 | agencyos/screens/AG-06.jsx | 22 | Button | Avvis | lokal tilstand | utkast |
| AG-06.K04 | agencyos/screens/AG-06.jsx | 22 | Button | Flytt | toast | utkast |
| AG-06.K05 | agencyos/screens/AG-06.jsx | 22 | Button | Avlys med begrunnelse | lokal tilstand | utkast |
| AG-06.K06 | agencyos/screens/AG-06.jsx | 22 | Button | Lukk | lokal tilstand | utkast |
| AG-06.K07 | agencyos/screens/AG-06.jsx | 36 | Button | Opprett booking | lokal tilstand | utkast |
| AG-06.K08 | agencyos/screens/AG-06.jsx | 43 | Button | Ny booking | lokal tilstand | utkast |
| AG-06.K09 | agencyos/screens/AG-06.jsx | 48 | Button | Avbryt | lokal tilstand | utkast |
| AG-06.K10 | agencyos/screens/AG-06.jsx | 48 | Button | rej && rej.st === "Bekreftet" ? "Avlys og lag ut | handling | utkast |
| AG-06.K11 | agencyos/screens/AG-06.jsx | 52 | Button | Lagre tjeneste | toast | utkast |
| AG-06.K12 | agencyos/screens/AG-06.jsx | 52 | Button | Avbryt | lokal tilstand | utkast |
| AG-07-NY.K01 | agencyos/screens/AG-07-NY.jsx | 27 | Button | Avbryt | → AG-07 | utkast |
| AG-07-NY.K02 | agencyos/screens/AG-07-NY.jsx | 27 | Button | Opprett spiller | lokal tilstand | utkast |
| AG-07-NY.K03 | agencyos/screens/AG-07-NY.jsx | 62 | Button | Avbryt | → AG-07 | utkast |
| AG-07-NY.K04 | agencyos/screens/AG-07-NY.jsx | 62 | Button | f.inv ? "Opprett og send invitasjon" : "Opprett  | lokal tilstand | utkast |
| AG-07.K01 | agencyos/screens/AG-07.jsx | 26 | Button | pick ? "Avbryt valg" : "Velg flere" | lokal tilstand | utkast |
| AG-07.K02 | agencyos/screens/AG-07.jsx | 26 | Button | Ny spiller | lokal tilstand | utkast |
| AG-07.K03 | agencyos/screens/AG-07.jsx | 35 | Button | Fjern valg | lokal tilstand | utkast |
| AG-07.K04 | agencyos/screens/AG-07.jsx | 35 | Button | Send melding | → AG-04 | utkast |
| AG-07.K05 | agencyos/screens/AG-07.jsx | 35 | Button | Legg i gruppe | lokal tilstand | utkast |
| AG-07.K06 | agencyos/screens/AG-07.jsx | 35 | Button | Tildel plan · pick.length | lokal tilstand | utkast |
| AG-07.K07 | agencyos/screens/AG-07.jsx | 37 | Button | bulk === "plan" ? "Tildel som utkast" : "Legg i  | lokal tilstand | utkast |
| AG-07.K08 | agencyos/screens/AG-07.jsx | 37 | Button | Avbryt | lokal tilstand | utkast |
| AG-07.K09 | agencyos/screens/AG-07.jsx | 42 | Button | Legg til spiller | handling | utkast |
| AG-07.K10 | agencyos/screens/AG-07.jsx | 42 | Button | Avbryt | lokal tilstand | utkast |
| AG-08-IUP.K01 | agencyos/screens/AG-08-IUP.jsx | 28 | Button | Last ned IUP-ark | toast | utkast |
| AG-08.K01 | agencyos/screens/AG-08.jsx | 13 | Button | Rediger profil | lokal tilstand | utkast |
| AG-08.K02 | agencyos/screens/AG-08.jsx | 13 | Button | p.golfbox ? "Endre turneringskobling" : "Koble t | lokal tilstand | utkast |
| AG-08.K03 | agencyos/screens/AG-08.jsx | 17 | Button | Spilleranalyse | → AG-09 | utkast |
| AG-08.K04 | agencyos/screens/AG-08.jsx | 17 | Button | Teknisk plan | → AG-10 | utkast |
| AG-08.K05 | agencyos/screens/AG-08.jsx | 17 | Button | Workbench | → AG-11 | utkast |
| AG-08.K06 | agencyos/screens/AG-08.jsx | 24 | Button | Stall | → AG-07 | utkast |
| AG-08.K07 | agencyos/screens/AG-08.jsx | 33 | Button | Lagre | handling | utkast |
| AG-08.K08 | agencyos/screens/AG-08.jsx | 33 | Button | Avbryt | lokal tilstand | utkast |
| AG-08.K09 | agencyos/screens/AG-08.jsx | 36 | Button | Koble | handling | utkast |
| AG-08.K10 | agencyos/screens/AG-08.jsx | 36 | Button | Avbryt | lokal tilstand | utkast |
| AG-09.K01 | agencyos/screens/AG-09.jsx | 41 | Button | Spiller 360 | → AG-08 | utkast |
| AG-10.K01 | agencyos/screens/AG-10.jsx | 18 | button | — | handling | utkast |
| AG-10.K02 | agencyos/screens/AG-10.jsx | 23 | Button | Spiller 360 | → AG-08 | utkast |
| AG-10.K03 | agencyos/screens/AG-10.jsx | 23 | Button | Før og etter | → AG-TP-02 | utkast |
| AG-10.K04 | agencyos/screens/AG-10.jsx | 23 | Button | Ny oppgave | → AG-TP-01 | utkast |
| AG-10.K05 | agencyos/screens/AG-10.jsx | 29 | Button | Legg til | handling | utkast |
| AG-10.K06 | agencyos/screens/AG-10.jsx | 29 | Button | m[0] (tom) | handling | utkast |
| AG-10.K07 | agencyos/screens/AG-10.jsx | 37 | Button | Legg til oppgave på sel | → AG-TP-01 | utkast |
| AG-10.K08 | agencyos/screens/AG-10.jsx | 38 | Button | Legg i økt | toast | utkast |
| AG-10.K09 | agencyos/screens/AG-10.jsx | 38 | Button | Rediger | → AG-TP-01 | utkast |
| AG-10.K10 | agencyos/screens/AG-10.jsx | 38 | Button | Før og etter | → AG-TP-02 | utkast |
| AG-11.K01 | agencyos/screens/AG-11.jsx | 13 | button | — | → «id» | utkast |
| AG-12.K01 | agencyos/screens/AG-12.jsx | 13 | Button | Teknisk plan | → AG-10 | utkast |
| AG-12.K02 | agencyos/screens/AG-12.jsx | 13 | Button | Spiller 360 | → AG-08 | utkast |
| AG-12.K03 | agencyos/screens/AG-12.jsx | 28 | Button | Lagre notat | handling | utkast |
| AG-12.K04 | agencyos/screens/AG-12.jsx | 28 | Button | Avbryt | lokal tilstand | utkast |
| AG-12.K05 | agencyos/screens/AG-12.jsx | 31 | Button | Rediger notat | lokal tilstand | utkast |
| AG-12.K06 | agencyos/screens/AG-12.jsx | 34 | Button | Kalender | → AG-05 | utkast |
| AG-13.K01 | agencyos/screens/AG-13.jsx | 23 | Button | Gi beskjed | toast | utkast |
| AG-13.K02 | agencyos/screens/AG-13.jsx | 23 | Button | Øktark | → AG-12 | utkast |
| AG-14.K01 | agencyos/screens/AG-14.jsx | 20 | Button | Bruk i Workbench | → AG-11 | utkast |
| AG-14.K02 | agencyos/screens/AG-14.jsx | 28 | ChoicePill | k === "axis" ? o.toUpperCase() : o | handling | utkast |
| AG-14.K03 | agencyos/screens/AG-14.jsx | 30 | Button | Ny øvelse | lokal tilstand | utkast |
| AG-14.K04 | agencyos/screens/AG-14.jsx | 35 | Button | ed && ed.id ? "Lagre øvelse" : "Opprett øvelse" | handling | utkast |
| AG-14.K05 | agencyos/screens/AG-14.jsx | 35 | Button | Avbryt | lokal tilstand | utkast |
| AG-15-NORMER.K01 | agencyos/screens/AG-15-NORMER.jsx | 33 | button | — | lokal tilstand | utkast |
| AG-15.K01 | agencyos/screens/AG-15.jsx | 14 | Button | Synk til talentprofil | handling | utkast |
| AG-15.K02 | agencyos/screens/AG-15.jsx | 16 | button | — | lokal tilstand | utkast |
| AG-15.K03 | agencyos/screens/AG-15.jsx | 25 | ChoicePill | x.name | lokal tilstand | utkast |
| AG-15.K04 | agencyos/screens/AG-15.jsx | 29 | ChoicePill | l | handling | utkast |
| AG-15.K05 | agencyos/screens/AG-15.jsx | 35 | Button | Opprett øvelse | → AG-14 | utkast |
| AG-15.K06 | agencyos/screens/AG-15.jsx | 39 | Button | Åpne økten | → AG-11 | utkast |
| AG-15.K07 | agencyos/screens/AG-15.jsx | 39 | Button | Legg i økt | lokal tilstand | utkast |
| AG-15.K08 | agencyos/screens/AG-15.jsx | 44 | Button | Tildel test | lokal tilstand | utkast |
| AG-15.K09 | agencyos/screens/AG-15.jsx | 51 | Button | Legg i Workbench | toast | utkast |
| AG-15.K10 | agencyos/screens/AG-15.jsx | 51 | Button | Avbryt | lokal tilstand | utkast |
| AG-15.K11 | agencyos/screens/AG-15.jsx | 57 | Button | Legg i økt som utkast | lokal tilstand | utkast |
| AG-15.K12 | agencyos/screens/AG-15.jsx | 57 | Button | Avbryt | lokal tilstand | utkast |
| AG-15.K13 | agencyos/screens/AG-15.jsx | 58 | button | — | lokal tilstand | utkast |
| AG-16.K01 | agencyos/screens/AG-16.jsx | 7 | button | — | lokal tilstand | utkast |
| AG-16.K02 | agencyos/screens/AG-16.jsx | 18 | Button | Åpne i Kalender | → AG-05 | utkast |
| AG-16.K03 | agencyos/screens/AG-16.jsx | 19 | Button | Åpne i Workbench · gruppemodus | → AG-11 | utkast |
| AG-16.K04 | agencyos/screens/AG-16.jsx | 28 | Button | Ny gruppe | toast | utkast |
| AG-16a.K01 | agencyos/screens/AG-16a.jsx | 14 | Button | Dupliser | lokal tilstand | utkast |
| AG-16a.K02 | agencyos/screens/AG-16a.jsx | 19 | Button | Ny gruppetrening | lokal tilstand | utkast |
| AG-16a.K03 | agencyos/screens/AG-16a.jsx | 24 | Button | Opprett | toast | utkast |
| AG-16a.K04 | agencyos/screens/AG-16a.jsx | 24 | Button | Avbryt | lokal tilstand | utkast |
| AG-16a.K05 | agencyos/screens/AG-16a.jsx | 28 | Button | Dupliser | toast | utkast |
| AG-16a.K06 | agencyos/screens/AG-16a.jsx | 28 | Button | Avbryt | lokal tilstand | utkast |
| AG-16b.K01 | agencyos/screens/AG-16b.jsx | 20 | ChoicePill | t // "Alle trinn" | lokal tilstand | utkast |
| AG-16b.K02 | agencyos/screens/AG-16b.jsx | 42 | Button | Importer | lokal tilstand | utkast |
| AG-16b.K03 | agencyos/screens/AG-16b.jsx | 57 | button | f | lokal tilstand | utkast |
| AG-17.K01 | agencyos/screens/AG-17.jsx | 14 | Button | Lukk | lokal tilstand | utkast |
| AG-17.K02 | agencyos/screens/AG-17.jsx | 23 | button | — | lokal tilstand | utkast |
| AG-17.K03 | agencyos/screens/AG-17.jsx | 32 | Button | Slå sammen | toast | utkast |
| AG-17.K04 | agencyos/screens/AG-17.jsx | 32 | Button | Ikke dublett | toast | utkast |
| AG-17.K05 | agencyos/screens/AG-17.jsx | 40 | Button | [...l,  id: "u" + Date.now(), name: f.name, date | handling | utkast |
| AG-17.K06 | agencyos/screens/AG-17.jsx | 43 | Button | Ny turnering | lokal tilstand | utkast |
| AG-18.K01 | agencyos/screens/AG-18.jsx | 10 | button | — | lokal tilstand | utkast |
| AG-18.K02 | agencyos/screens/AG-18.jsx | 14 | Button | Tegn på video | toast | utkast |
| AG-18.K03 | agencyos/screens/AG-18.jsx | 14 | Button | Del med spiller | toast | utkast |
| AG-18.K04 | agencyos/screens/AG-18.jsx | 30 | Button | rec ? "Stopp og lagre" : "Start opptak" | toast | utkast |
| AG-19.K01 | agencyos/screens/AG-19.jsx | 13 | button | — | lokal tilstand | utkast |
| AG-19.K02 | agencyos/screens/AG-19.jsx | 20 | Button | Godkjenn og send | handling | utkast |
| AG-19.K03 | agencyos/screens/AG-19.jsx | 20 | Button | Rediger i Kø | → AG-02 | utkast |
| AG-19.K04 | agencyos/screens/AG-19.jsx | 20 | Button | Forkast | toast | utkast |
| AG-19.K05 | agencyos/screens/AG-19.jsx | 21 | Button | Kjør for de 15 som har plan | toast | utkast |
| AG-19.K06 | agencyos/screens/AG-19.jsx | 24 | Button | Åpne i Oppgaver | → AG-21 | utkast |
| AG-19.K07 | agencyos/screens/AG-19.jsx | 28 | Button | Lagre som utkast | toast | utkast |
| AG-19.K08 | agencyos/screens/AG-19.jsx | 30 | Button | Spør Caddie | handling | utkast |
| AG-20.K01 | agencyos/screens/AG-20.jsx | 24 | Button | Lagre forklaring | toast | utkast |
| AG-20.K02 | agencyos/screens/AG-20.jsx | 28 | Button | Last ned rapport | toast | utkast |
| AG-21.K01 | agencyos/screens/AG-21.jsx | 13 | Button | Marker gjort | lokal tilstand | utkast |
| AG-21.K02 | agencyos/screens/AG-21.jsx | 14 | Button | Åpne i Notion | toast | utkast |
| AG-21.K03 | agencyos/screens/AG-21.jsx | 14 | Button | Synk nå | toast | utkast |
| AG-21.K04 | agencyos/screens/AG-21.jsx | 17 | Button | Ny oppgave | lokal tilstand | utkast |
| AG-21.K05 | agencyos/screens/AG-21.jsx | 22 | Button | Legg til | handling | utkast |
| AG-21.K06 | agencyos/screens/AG-21.jsx | 22 | Button | Avbryt | lokal tilstand | utkast |
| AG-22.K01 | agencyos/screens/AG-22.jsx | 30 | Button | Importer fil | toast | utkast |
| AG-08.K01 | agencyos/screens/AG-360.jsx | 15 | Button | Åpne hele planen i Workbench | → AG-11 | utkast |
| AG-08.K02 | agencyos/screens/AG-360.jsx | 24 | ChoicePill | l | lokal tilstand | utkast |
| AG-08.K03 | agencyos/screens/AG-360.jsx | 43 | Button | Åpne teknisk plan | → AG-10 | utkast |
| AG-08.K04 | agencyos/screens/AG-360.jsx | 44 | Button | Bruk som startverdi | toast | utkast |
| AG-08.K05 | agencyos/screens/AG-360.jsx | 53 | IconButton | ikon:arrow-right | toast | utkast |
| AG-08.K06 | agencyos/screens/AG-360.jsx | 54 | IconButton | ikon:trash-2 | toast | utkast |
| AG-08.K07 | agencyos/screens/AG-360.jsx | 77 | Button | Send melding | toast | utkast |
| AG-08.K08 | agencyos/screens/AG-360.jsx | 77 | Button | Åpne Workbench | → AG-11 | utkast |
| AG-08.K09 | agencyos/screens/AG-360.jsx | 77 | Button | Start live | → AG-13 | utkast |
| AG-08.K10 | agencyos/screens/AG-360.jsx | 77 | Button | IUP-samtale | toast | utkast |
| AG-08.K11 | agencyos/screens/AG-360.jsx | 79 | button | — | → «to» | utkast |
| AG-08.K12 | agencyos/screens/AG-360.jsx | 85 | button | l | lokal tilstand | utkast |
| AG-A1.K01 | agencyos/screens/AG-A1.jsx | 12 | ChoicePill | l | → «pid» | utkast |
| AG-A1.K02 | agencyos/screens/AG-A1.jsx | 31 | Button | Lag tiltak | → AG-A06 | utkast |
| AG-A1.K03 | agencyos/screens/AG-A1.jsx | 51 | ChoicePill | x | lokal tilstand | utkast |
| AG-A1.K04 | agencyos/screens/AG-A1.jsx | 75 | Button | Lag gruppetiltak | → AG-A06 | utkast |
| AG-A1.K05 | agencyos/screens/AG-A1.jsx | 75 | Button | Lag rapport | → AG-A07 | utkast |
| AG-A1.K06 | agencyos/screens/AG-A1.jsx | 96 | Button | Fysisk plan | → AG-WB-FYS | utkast |
| AG-A1.K07 | agencyos/screens/AG-A1.jsx | 96 | Button | Turneringer | → AG-WB-TURN | utkast |
| AG-A2.K01 | agencyos/screens/AG-A2.jsx | 12 | Button | Prøv igjen | toast | utkast |
| AG-A2.K02 | agencyos/screens/AG-A2.jsx | 13 | Button | Godkjenn | handling | utkast |
| AG-A2.K03 | agencyos/screens/AG-A2.jsx | 14 | Button | Slå sammen | handling | utkast |
| AG-A2.K04 | agencyos/screens/AG-A2.jsx | 40 | Button | r.target === "AG-WB-TURN" ? "Turneringsplan" : " | → «r.target» | utkast |
| AG-A2.K05 | agencyos/screens/AG-A2.jsx | 40 | Button | Rediger | handling | utkast |
| AG-A2.K06 | agencyos/screens/AG-A2.jsx | 40 | Button | Trekk tilbake | lokal tilstand | utkast |
| AG-A2.K07 | agencyos/screens/AG-A2.jsx | 41 | Button | Avbryt | handling | utkast |
| AG-A2.K08 | agencyos/screens/AG-A2.jsx | 41 | Button | Lagre utkast | toast | utkast |
| AG-A2.K09 | agencyos/screens/AG-A2.jsx | 41 | Button | Lagre og publiser | lokal tilstand | utkast |
| AG-A2.K10 | agencyos/screens/AG-A2.jsx | 63 | Button | Eksporter PDF | toast | utkast |
| AG-A2.K11 | agencyos/screens/AG-A2.jsx | 63 | Button | Send som utkast | toast | utkast |
| AG-A2.K12 | agencyos/screens/AG-A2.jsx | 104 | Button | Godkjenn | lokal tilstand | utkast |
| AG-A2.K13 | agencyos/screens/AG-A2.jsx | 104 | Button | Rediger | → AG-A06 | utkast |
| AG-A2.K14 | agencyos/screens/AG-A2.jsx | 104 | Button | Avvis | lokal tilstand | utkast |
| AG-RD-01.K01 | agencyos/screens/AG-RD.jsx | 14 | Button | Manglende data · D.gaps.length | → AG-RD-02 | utkast |
| AG-RD-01.K02 | agencyos/screens/AG-RD.jsx | 47 | Button | Be om slagdata | handling | utkast |
| AG-RD-01.K03 | agencyos/screens/AG-RD.jsx | 47 | Button | Importer SG | handling | utkast |
| AG-RD-01.K04 | agencyos/screens/AG-RD.jsx | 47 | Button | Godta scorekort | handling | utkast |
| AG-RD-01.K05 | agencyos/screens/AG-RD.jsx | 47 | Button | Ignorer | lokal tilstand | utkast |
| AG-TP-01.K01 | agencyos/screens/AG-TP.jsx | 32 | ChoicePill | label | handling | utkast |
| AG-TP-01.K02 | agencyos/screens/AG-TP.jsx | 46 | Button | Angre områdebytte | handling | utkast |
| AG-TP-01.K03 | agencyos/screens/AG-TP.jsx | 57 | Button | Fjern | handling | utkast |
| AG-TP-01.K04 | agencyos/screens/AG-TP.jsx | 61 | Button | Legg til parameter | handling | utkast |
| AG-TP-01.K05 | agencyos/screens/AG-TP.jsx | 72 | Button | Lagre oppgave | handling | utkast |
| AG-TP-01.K06 | agencyos/screens/AG-TP.jsx | 72 | Button | Publiser til spiller | toast | utkast |
| AG-TP-01.K07 | agencyos/screens/AG-TP.jsx | 81 | Button | Åpne skjemaet | lokal tilstand | utkast |
| AG-TP-01.K08 | agencyos/screens/AG-TP.jsx | 84 | Button | Teknisk plan | → AG-10 | utkast |
| AG-TP-01.K09 | agencyos/screens/AG-TP.jsx | 100 | Button | Teknisk plan | → AG-10 | utkast |
| AG-TP-01.K10 | agencyos/screens/AG-TP.jsx | 103 | ChoicePill | x.pos + " · " + x.title | lokal tilstand | utkast |
| AG-WB-FYS.K01 | agencyos/screens/AG-WB-FYS.jsx | 35 | button | — | lokal tilstand | utkast |
| AG-WB-FYS.K02 | agencyos/screens/AG-WB-FYS.jsx | 39 | IconButton | ikon:move | lokal tilstand | utkast |
| AG-WB-FYS.K03 | agencyos/screens/AG-WB-FYS.jsx | 54 | Button | Legg til øvelse | lokal tilstand | utkast |
| AG-WB-FYS.K04 | agencyos/screens/AG-WB-FYS.jsx | 54 | Button | Juster progresjon | handling | utkast |
| AG-WB-FYS.K05 | agencyos/screens/AG-WB-FYS.jsx | 54 | Button | Kopier uke | handling | utkast |
| AG-WB-FYS.K06 | agencyos/screens/AG-WB-FYS.jsx | 54 | Button | Flytt økt | lokal tilstand | utkast |
| AG-WB-FYS.K07 | agencyos/screens/AG-WB-FYS.jsx | 65 | Button | Legg til fysisk blokk | lokal tilstand | utkast |
| AG-WB-FYS.K08 | agencyos/screens/AG-WB-FYS.jsx | 65 | Button | Trekk tilbake | lokal tilstand | utkast |
| AG-WB-FYS.K09 | agencyos/screens/AG-WB-FYS.jsx | 65 | Button | Publiser til spiller | lokal tilstand | utkast |
| AG-WB-FYS.K10 | agencyos/screens/AG-WB-FYS.jsx | 68 | ChoicePill | b.name + " · uke " + b.weeks[0] + "–" + b.weeks[ | lokal tilstand | utkast |
| AG-WB-FYS.K11 | agencyos/screens/AG-WB-FYS.jsx | 73 | Button | Legg til uke | handling | utkast |
| AG-WB-FYS.K12 | agencyos/screens/AG-WB-FYS.jsx | 73 | Button | Legg til økt | lokal tilstand | utkast |
| AG-WB-FYS.K13 | agencyos/screens/AG-WB-FYS.jsx | 95 | Button | Avbryt | → AG-11 | utkast |
| AG-WB-FYS.K14 | agencyos/screens/AG-WB-FYS.jsx | 95 | Button | Lagre delvis | handling | utkast |
| AG-WB-FYS.K15 | agencyos/screens/AG-WB-FYS.jsx | 95 | Button | Lagre | handling | utkast |
| AG-WB-FYS.K16 | agencyos/screens/AG-WB-FYS.jsx | 100 | Button | Legg til | lokal tilstand | utkast |
| AG-WB-FYS.K17 | agencyos/screens/AG-WB-FYS.jsx | 100 | Button | Avbryt | lokal tilstand | utkast |
| AG-WB-FYS.K18 | agencyos/screens/AG-WB-FYS.jsx | 104 | Button | Legg til som utkast | toast | utkast |
| AG-WB-FYS.K19 | agencyos/screens/AG-WB-FYS.jsx | 104 | Button | Avbryt | lokal tilstand | utkast |
| AG-WB-FYS.K20 | agencyos/screens/AG-WB-FYS.jsx | 110 | Button | setSes(before)); >Legg til økt | lokal tilstand | utkast |
| AG-WB-FYS.K21 | agencyos/screens/AG-WB-FYS.jsx | 110 | Button | Avbryt | lokal tilstand | utkast |
| AG-WB-TURN.K01 | agencyos/screens/AG-WB-TURN.jsx | 28 | button | — | lokal tilstand | utkast |
| AG-WB-TURN.K02 | agencyos/screens/AG-WB-TURN.jsx | 32 | IconButton | ikon:move | lokal tilstand | utkast |
| AG-WB-TURN.K03 | agencyos/screens/AG-WB-TURN.jsx | 47 | IconButton | ikon:move | lokal tilstand | utkast |
| AG-WB-TURN.K04 | agencyos/screens/AG-WB-TURN.jsx | 51 | Button | Legg inn forberedelse | lokal tilstand | utkast |
| AG-WB-TURN.K05 | agencyos/screens/AG-WB-TURN.jsx | 51 | Button | Se i ukeplanen | → AG-11 | utkast |
| AG-WB-TURN.K06 | agencyos/screens/AG-WB-TURN.jsx | 51 | Button | Juster fysisk plan | → AG-WB-FYS | utkast |
| AG-WB-TURN.K07 | agencyos/screens/AG-WB-TURN.jsx | 58 | Button | Åpne gameplan | toast | utkast |
| AG-WB-TURN.K08 | agencyos/screens/AG-WB-TURN.jsx | 65 | Button | Legg inn runde | toast | utkast |
| AG-WB-TURN.K09 | agencyos/screens/AG-WB-TURN.jsx | 65 | Button | Lag tiltak fra evalueringen | → AG-A06 | utkast |
| AG-WB-TURN.K10 | agencyos/screens/AG-WB-TURN.jsx | 69 | Button | Legg til turnering | lokal tilstand | utkast |
| AG-WB-TURN.K11 | agencyos/screens/AG-WB-TURN.jsx | 69 | Button | Trekk tilbake | lokal tilstand | utkast |
| AG-WB-TURN.K12 | agencyos/screens/AG-WB-TURN.jsx | 69 | Button | Publiser plan | lokal tilstand | utkast |
| AG-WB-TURN.K13 | agencyos/screens/AG-WB-TURN.jsx | 73 | ChoicePill | x | lokal tilstand | utkast |
| AG-WB-TURN.K14 | agencyos/screens/AG-WB-TURN.jsx | 76 | Button | Avbryt | → AG-11 | utkast |
| AG-WB-TURN.K15 | agencyos/screens/AG-WB-TURN.jsx | 76 | Button | Lagre delvis | handling | utkast |
| AG-WB-TURN.K16 | agencyos/screens/AG-WB-TURN.jsx | 76 | Button | Lagre | handling | utkast |
| AG-WB-TURN.K17 | agencyos/screens/AG-WB-TURN.jsx | 82 | Button | setList(before)); >Legg til som utkast | lokal tilstand | utkast |
| AG-WB-TURN.K18 | agencyos/screens/AG-WB-TURN.jsx | 82 | Button | Avbryt | lokal tilstand | utkast |
| AG-WB-TURN.K19 | agencyos/screens/AG-WB-TURN.jsx | 88 | Button | setPrep(before)); >Legg til | lokal tilstand | utkast |
| AG-WB-TURN.K20 | agencyos/screens/AG-WB-TURN.jsx | 88 | Button | Avbryt | lokal tilstand | utkast |
| AG-01.K01 | agencyos/screens/AG-cockpit.jsx | 21 | Button | Start live | → AG-13 | utkast |
| AG-01.K02 | agencyos/screens/AG-cockpit.jsx | 33 | IconButton | ikon:send | handling | utkast |
| AG-01.K03 | agencyos/screens/AG-cockpit.jsx | 34 | Button | Hele samtalen i Innboks | → AG-04 | utkast |
| AG-01.K04 | agencyos/screens/AG-cockpit.jsx | 56 | button | — | → AG-08-PLAN | utkast |
| AG-01.K05 | agencyos/screens/AG-cockpit.jsx | 62 | button | — | → «to» | utkast |
| AG-01.K06 | agencyos/screens/AG-cockpit.jsx | 90 | IconButton | ikon:play | toast | utkast |
| AG-01.K07 | agencyos/screens/AG-cockpit.jsx | 93 | Button | l | handling | utkast |
| AG-01.K08 | agencyos/screens/AG-cockpit.jsx | 97 | Button | rec ? "Stopp opptak" : "Start opptak" | toast | utkast |
| AG-01.K09 | agencyos/screens/AG-cockpit.jsx | 103 | Button | Legg i planen | lokal tilstand | utkast |
| AG-01.K10 | agencyos/screens/AG-cockpit.jsx | 106 | Button | Avslutt økta | → AG-12 | utkast |
| AG-01.K11 | agencyos/screens/AG-cockpit.jsx | 122 | Button | Godkjenn og send | toast | utkast |
| AG-01.K12 | agencyos/screens/AG-cockpit.jsx | 122 | Button | Tilbakestill | lokal tilstand | utkast |
| AG-01.K13 | agencyos/screens/AG-cockpit.jsx | 127 | Button | Bruk som startverdi | toast | utkast |
| AG-01.K14 | agencyos/screens/AG-cockpit.jsx | 133 | Button | Cockpit | → AG-01 | utkast |
| AG-04.K01 | agencyos/screens/AG-innboks.jsx | 13 | button | — | handling | utkast |
| AG-04.K02 | agencyos/screens/AG-innboks.jsx | 25 | Button | Se video · x.video | toast | utkast |
| AG-04.K03 | agencyos/screens/AG-innboks.jsx | 30 | Button | Send | toast | utkast |
| AG-04.K04 | agencyos/screens/AG-innboks.jsx | 30 | Button | ed ? "Ferdig redigert" : "Rediger" | lokal tilstand | utkast |
| AG-04.K05 | agencyos/screens/AG-innboks.jsx | 30 | Button | Forkast | toast | utkast |
| AG-04.K06 | agencyos/screens/AG-innboks.jsx | 35 | Button | Send | toast | utkast |
| AG-04.K07 | agencyos/screens/AG-innboks.jsx | 35 | Button | Lag utkast | lokal tilstand | utkast |
| AG-04.K08 | agencyos/screens/AG-innboks.jsx | 35 | Button | Avbryt | lokal tilstand | utkast |
| AG-04.K09 | agencyos/screens/AG-innboks.jsx | 38 | Button | a | → AG-08, AG-11, AG-05-UKE | utkast |
| AG-04.K10 | agencyos/screens/AG-innboks.jsx | 39 | Button | Svar | lokal tilstand | utkast |
| AG-04.K11 | agencyos/screens/AG-innboks.jsx | 40 | Button | Ferdig | handling | utkast |
| AG-04.K12 | agencyos/screens/AG-innboks.jsx | 53 | Button | Jarvis | → AG-19 | utkast |
| AG-04.K13 | agencyos/screens/AG-innboks.jsx | 55 | ChoicePill | k + (cnt(k) ? " · " + cnt(k) : "") | lokal tilstand | utkast |
| AG-04.K14 | agencyos/screens/AG-innboks.jsx | 56 | ChoicePill | k + " · " + items.filter((x) => x.o === k).lengt | lokal tilstand | utkast |
| AG-05.K01 | agencyos/screens/AG-kalender.jsx | 15 | button | — | handling | utkast |
| AG-05.K02 | agencyos/screens/AG-kalender.jsx | 23 | button | — | handling | utkast |
| AG-05.K03 | agencyos/screens/AG-kalender.jsx | 96 | Button | Koble Google-kalender | toast | utkast |
| AG-05.K04 | agencyos/screens/AG-kalender.jsx | 97 | IconButton | ikon:chevron-left | lokal tilstand | utkast |
| AG-05.K05 | agencyos/screens/AG-kalender.jsx | 97 | IconButton | ikon:chevron-right | lokal tilstand | utkast |
| AG-05.K06 | agencyos/screens/AG-kalender.jsx | 98 | IconButton | ikon:chevron-left | lokal tilstand | utkast |
| AG-05.K07 | agencyos/screens/AG-kalender.jsx | 98 | IconButton | ikon:chevron-right | lokal tilstand | utkast |
| AG-05.K08 | agencyos/screens/AG-kalender.jsx | 101 | Button | Ny booking | → AG-06 | utkast |
| AG-05.K09 | agencyos/screens/AG-kalender.jsx | 105 | ChoicePill | Alle coacher | handling | utkast |
| AG-05.K10 | agencyos/screens/AG-kalender.jsx | 105 | ChoicePill | c.ini + " · " + c.name.split(" ")[0] | handling | utkast |
| AG-05.K11 | agencyos/screens/AG-kalender.jsx | 107 | button | — | lokal tilstand | utkast |
| AG-05.K12 | agencyos/screens/AG-kalender.jsx | 117 | Button | Lukk | lokal tilstand | utkast |
| AG-05.K13 | agencyos/screens/AG-kalender.jsx | 117 | Button | Flytt økt | lokal tilstand | utkast |
| AG-05.K14 | agencyos/screens/AG-kalender.jsx | 117 | Button | Lukk | lokal tilstand | utkast |
| AG-05.K15 | agencyos/screens/AG-kalender.jsx | 122 | Button | Avbryt | lokal tilstand | utkast |
| AG-05.K16 | agencyos/screens/AG-kalender.jsx | 123 | button | — | handling | utkast |
| AG-05.K17 | agencyos/screens/AG-kalender.jsx | 126 | Button | Godkjenn og legg ut til booking | lokal tilstand | utkast |
| AG-05.K18 | agencyos/screens/AG-kalender.jsx | 126 | Button | Avvis | toast | utkast |
| AG-05.K19 | agencyos/screens/AG-kalender.jsx | 129 | Button | Åpne i Innboks | → AG-04 | utkast |
| AG-06.K01 | agencyos/screens/AG-mer.jsx | 20 | button | — | lokal tilstand | utkast |
| AG-06.K02 | agencyos/screens/AG-mer.jsx | 21 | button | — | lokal tilstand | utkast |
| AG-06.K03 | agencyos/screens/AG-mer.jsx | 22 | ChoicePill | x[0] + " · " + x[1] | lokal tilstand | utkast |
| AG-06.K04 | agencyos/screens/AG-mer.jsx | 24 | Button | Avlys | lokal tilstand | utkast |
| AG-06.K05 | agencyos/screens/AG-mer.jsx | 25 | Button | Endre i Oppsett | → AG-23 | utkast |
| AG-06.K06 | agencyos/screens/AG-mer.jsx | 27 | Button | Ny booking | lokal tilstand | utkast |
| AG-06.K07 | agencyos/screens/AG-mer.jsx | 31 | Button | st === 3 ? "Bekreft booking" : "Neste" | lokal tilstand | utkast |
| AG-06.K08 | agencyos/screens/AG-mer.jsx | 31 | Button | st ? "Tilbake" : "Avbryt" | lokal tilstand | utkast |
| AG-06.K09 | agencyos/screens/AG-mer.jsx | 35 | Button | Avlys booking | toast | utkast |
| AG-06.K10 | agencyos/screens/AG-mer.jsx | 35 | Button | Behold | lokal tilstand | utkast |
| AG-06.K11 | agencyos/screens/AG-mer.jsx | 45 | button | n | → AG-08 | utkast |
| AG-06.K12 | agencyos/screens/AG-mer.jsx | 45 | Button | Legg til spillere | lokal tilstand | utkast |
| AG-06.K13 | agencyos/screens/AG-mer.jsx | 45 | Button | Tildel test eller TrackMan-økt | lokal tilstand | utkast |
| AG-06.K14 | agencyos/screens/AG-mer.jsx | 46 | Button | Åpne gruppeplanen i Workbench | → AG-11-GRUPPE | utkast |
| AG-06.K15 | agencyos/screens/AG-mer.jsx | 51 | ChoicePill | x.name + " · " + (empty ? 0 : x.n) | lokal tilstand | utkast |
| AG-06.K16 | agencyos/screens/AG-mer.jsx | 54 | Button | Lagre | toast | utkast |
| AG-06.K17 | agencyos/screens/AG-mer.jsx | 54 | Button | Avbryt | lokal tilstand | utkast |
| AG-06.K18 | agencyos/screens/AG-mer.jsx | 56 | button | — | lokal tilstand | utkast |
| AG-06.K19 | agencyos/screens/AG-mer.jsx | 59 | Button | Lukk | lokal tilstand | utkast |
| AG-06.K20 | agencyos/screens/AG-mer.jsx | 60 | Button | Tildel | toast | utkast |
| AG-06.K21 | agencyos/screens/AG-mer.jsx | 85 | Button | Endre budsjett | lokal tilstand | utkast |
| AG-06.K22 | agencyos/screens/AG-mer.jsx | 89 | Button | Last opp eksport for september | lokal tilstand | utkast |
| AG-06.K23 | agencyos/screens/AG-mer.jsx | 102 | Button | Lagre | toast | utkast |
| AG-06.K24 | agencyos/screens/AG-mer.jsx | 102 | Button | Avbryt | handling | utkast |
| AG-06.K25 | agencyos/screens/AG-mer.jsx | 108 | Button | Velg fil | toast | utkast |
| AG-06.K26 | agencyos/screens/AG-mer.jsx | 108 | Button | Avbryt | handling | utkast |
| AG-06.K27 | agencyos/screens/AG-mer.jsx | 120 | Button | Inviter coach | lokal tilstand | utkast |
| AG-06.K28 | agencyos/screens/AG-mer.jsx | 129 | ChoicePill | l | lokal tilstand | utkast |
| AG-06.K29 | agencyos/screens/AG-mer.jsx | 132 | Button | Send invitasjon | toast | utkast |
| AG-06.K30 | agencyos/screens/AG-mer.jsx | 132 | Button | Avbryt | lokal tilstand | utkast |
| AG-06.K31 | agencyos/screens/AG-mer.jsx | 134 | ChoicePill | r | lokal tilstand | utkast |
| AG-07.K01 | agencyos/screens/AG-stall.jsx | 15 | Button | Send varsel | toast | utkast |
| AG-07.K02 | agencyos/screens/AG-stall.jsx | 15 | Button | Avbryt | handling | utkast |
| AG-07.K03 | agencyos/screens/AG-stall.jsx | 17 | ChoicePill | m | lokal tilstand | utkast |
| AG-07.K04 | agencyos/screens/AG-stall.jsx | 25 | Button | Lukk | handling | utkast |
| AG-07.K05 | agencyos/screens/AG-stall.jsx | 34 | button | — | → AG-08 | utkast |
| AG-07.K06 | agencyos/screens/AG-stall.jsx | 45 | button | — | → AG-08 | utkast |
| AG-07.K07 | agencyos/screens/AG-stall.jsx | 49 | Button | Send melding | lokal tilstand | utkast |
| AG-07.K08 | agencyos/screens/AG-stall.jsx | 49 | Button | Følg repetisjonene | lokal tilstand | utkast |
| AG-07.K09 | agencyos/screens/AG-stall.jsx | 52 | ChoicePill | l + " · " + (k === "alle" ? P.length : P.filter( | lokal tilstand | utkast |
