/* GENERERT fra components/plan 29.09.2026. IKKE lenger lastet av screen.html for PlayerHQ og AgencyOS (30.09.2026): bundelen har nå samme komponenter. Beholdt fordi screen-ag04-mal.html, AG-07-NY-forhaand.html og screen-ag16b.html (andre chats) fortsatt laster den. Kilden er components/plan; ikke rediger her. */
(() => {
const NS = window.AKGolfPrecisionAthletics_7d7c29;
{
const PH = [["Baksving", "P1–P4", 1, 4], ["Nedsving", "P5–P7", 5, 7], ["Gjennomsving", "P8–P10", 8, 10]];
const major = (c) => parseInt(String(c).slice(1), 10);
/** P1.0–P10.0 som klikkbare noder. Valgt = grafitt fyll. Ruller aldri sidelengs: under minWidth blir linjen et rutenett med fem kolonner (2 × 5). */
function SwingTimeline({ positions = [], value = null, onChange, phases = PH, minWidth = 640, showCounts = true, countLabel = ["oppgave", "oppgaver"], ariaLabel = "Svingtidslinje P1.0–P10.0" }) {
  const ref = React.useRef(null), [w, setW] = React.useState(null);
  React.useLayoutEffect(() => { const el = ref.current; if (!el) return; const f = () => setW(el.clientWidth); f(); if (!window.ResizeObserver) return; const ro = new ResizeObserver(f); ro.observe(el); return () => ro.disconnect(); }, []);
  const grid = w != null && w < minWidth, n = positions.length || 1, at = (i) => (5 + (90 * (n === 1 ? 0.5 : i / (n - 1)))) + "%";
  const idx = positions.findIndex((p) => p.code === value);
  const aria = (p) => p.code + " " + (p.label || p.name) + (showCounts ? " · " + (p.count || 0) + " " + (p.count === 1 ? countLabel[0] : countLabel[1]) : "") + (p.focus ? " · hovedfokus" : "");
  const tag = <span style={{ font: "600 9px/1 var(--font-mono)", letterSpacing: ".04em", color: "var(--text-inverse)", background: "var(--surface-ink)", borderRadius: 999, padding: "2px 5px" }}>FOKUS</span>;
  const cnt = (p) => showCounts && <span style={{ font: "500 12px/1 var(--font-mono)", color: p.count ? "var(--text-primary)" : "var(--text-muted)" }}>{p.count ? p.count : "—"}</span>;
  if (grid) return <div ref={ref} style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <div role="group" aria-label={ariaLabel} style={{ display: "grid", gridTemplateColumns: "repeat(5,minmax(0,1fr))", gap: 6 }}>
      {positions.map((p) => { const on = p.code === value;
        return <button key={p.code} type="button" aria-pressed={on} aria-label={aria(p)} title={p.label || p.name} onClick={() => onChange && onChange(on ? null : p.code)} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", minWidth: 0, minHeight: 64, padding: "8px 6px", display: "flex", flexDirection: "column", gap: 6, justifyContent: "space-between", background: on ? "var(--surface-ink)" : "var(--surface-card)", color: on ? "var(--text-inverse)" : "var(--text-primary)", borderRadius: "var(--radius)", border: "1px solid " + (on ? "var(--surface-ink)" : "var(--border-hairline)"), transition: "background-color 200ms var(--ease-out), color 200ms var(--ease-out)" }}>
          <span style={{ font: "600 13px/1 var(--font-mono)" }}>{p.code}</span>
          <span style={{ display: "flex", gap: 4, alignItems: "center", flexWrap: "wrap", minWidth: 0 }}>{showCounts && <span style={{ font: "500 12px/1 var(--font-mono)", opacity: p.count ? 1 : 0.7 }}>{p.count ? p.count : "—"}</span>}{p.focus && (on ? <span style={{ font: "600 9px/1 var(--font-mono)", letterSpacing: ".04em", color: "var(--text-primary)", background: "var(--surface-card)", borderRadius: 999, padding: "2px 5px" }}>FOKUS</span> : tag)}</span>
        </button>; })}
    </div>
    {phases && <span style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)" }}>{phases.map(([nm, r]) => nm.toUpperCase() + " " + r).join(" · ")}</span>}
  </div>;
  return <div ref={ref} style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
    <div role="group" aria-label={ariaLabel} style={{ position: "relative", height: 132, background: "var(--surface-flat)", border: "1px solid var(--border-hairline)", borderBottom: 0, boxSizing: "border-box" }}>
      <span aria-hidden="true" style={{ position: "absolute", left: "5%", right: "5%", top: 41, height: 2, background: "var(--border-ink)" }}></span>
      {positions.map((p, i) => { const on = p.code === value, d = on ? 20 : 14;
        return <button key={p.code} type="button" aria-pressed={on} aria-label={aria(p)} title={p.label || p.name} onClick={() => onChange && onChange(on ? null : p.code)}
          style={{ all: "unset", boxSizing: "border-box", position: "absolute", top: 8, left: at(i), transform: "translateX(-50%)", width: "calc(" + (90 / Math.max(1, n - 1)) + "% - 4px)", maxWidth: 96, minWidth: 48, minHeight: 112, display: "flex", flexDirection: "column", alignItems: "center", cursor: "pointer", color: "var(--text-primary)" }}>
          <span style={{ height: 16, font: "600 13px/16px var(--font-mono)" }}>{p.code}</span>
          <span style={{ height: 36, display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ width: d, height: d, boxSizing: "border-box", borderRadius: 999, border: "2px " + (p.count || on ? "solid " : "dashed ") + "var(--border-ink)", background: on ? "var(--surface-ink)" : "var(--surface-card)", boxShadow: on ? "0 0 0 3px var(--surface-flat), 0 0 0 4px var(--border-ink)" : "none", transition: "background-color 200ms var(--ease-out), width 200ms var(--ease-out), height 200ms var(--ease-out)" }}></span></span>
          <span style={{ font: (on ? "600 " : "400 ") + "11px/1.25 var(--font-sans)", color: on ? "var(--text-primary)" : "var(--text-secondary)", textAlign: "center", maxHeight: 28, overflow: "hidden", textWrap: "balance", overflowWrap: "anywhere" }}>{p.name}</span>
          <span style={{ display: "flex", gap: 4, alignItems: "center", paddingTop: 4 }}>{cnt(p)}{p.focus && tag}</span>
        </button>; })}
    </div>
    <div aria-hidden="true" style={{ position: "relative", height: 3, background: "var(--border-hairline)" }}>{idx >= 0 && <span style={{ position: "absolute", top: 0, bottom: 0, left: at(idx), width: 48, marginLeft: -24, background: "var(--border-ink)", transition: "left 200ms var(--ease-in-out)" }}></span>}</div>
    {phases && <div aria-hidden="true" style={{ position: "relative", height: 30 }}>{phases.map(([nm, r, a, b]) => { const ia = positions.findIndex((p) => major(p.code) === a), ib = positions.map((p) => major(p.code)).lastIndexOf(b); if (ia < 0 || ib < 0) return null; const L = parseFloat(at(ia)), R = parseFloat(at(ib)); return <span key={nm} style={{ position: "absolute", top: 8, left: "calc(" + L + "% - 20px)", width: "calc(" + (R - L) + "% + 40px)", borderTop: "1px solid var(--border-strong)", paddingTop: 4, display: "flex", gap: 6, justifyContent: "center", alignItems: "baseline", overflow: "hidden" }}><span style={{ font: "600 12px/1.2 var(--font-sans)" }}>{nm}</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{r}</span></span>; })}</div>}
  </div>;
}
NS.SwingTimeline = SwingTimeline;
}
{
/** AK-formelen i mono. Leddet som sist ble endret markeres med grafitt understrek. Ledd som ikke gjelder utelates av kalleren. */
function FormulaCode({ parts, code, highlight = -1, size = "md", label = "AK-formelen" }) {
  const p = parts || String(code || "").split("_").filter(Boolean), big = size === "lg";
  return <code title={label} aria-label={label + ": " + p.join("_")} style={{ display: "inline-block", maxWidth: "100%", boxSizing: "border-box", font: (big ? "500 15px/1.5 " : "500 12px/1.45 ") + "var(--font-mono)", color: "var(--text-primary)", background: "var(--surface-sunken)", border: "1px solid var(--border-hairline)", borderRadius: "var(--radius)", padding: big ? "8px 12px" : "4px 10px", overflowWrap: "anywhere", wordBreak: "break-all" }}>
    {p.length ? p.map((s, i) => <React.Fragment key={i}>{i > 0 && <span style={{ color: "var(--text-muted)" }}>_</span>}<span style={i === highlight ? { color: "var(--action)", boxShadow: "inset 0 -2px 0 var(--action)", transition: "color 200ms var(--ease-out)" } : { transition: "color 200ms var(--ease-out)" }}>{s}</span></React.Fragment>) : "—"}
  </code>;
}
NS.FormulaCode = FormulaCode;
}
{
const num = (v) => v == null ? "—" : String(v).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
/** Repetisjoner per læringssteg: gjort / mål med prosent. Valgfri strek = skjema til nå. */
function RepBars({ rows = [], source, unit = "" }) {
  return <div style={{ display: "flex", flexDirection: "column", gap: 10, minWidth: 0 }}>
    {rows.map((r) => { const p = r.goal ? Math.round((r.done || 0) / r.goal * 100) : null, w = p == null ? 0 : Math.min(100, p), m = r.marker != null && r.goal ? Math.min(100, r.marker / r.goal * 100) : null;
      return <div key={r.label} style={{ display: "flex", flexDirection: "column", gap: 4, opacity: r.locked ? 0.55 : 1 }}>
        <span style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "baseline" }}><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{r.label}{r.code && <span style={{ font: "var(--type-meta)", color: "var(--text-muted)", marginLeft: 6 }}>{r.code}</span>}</span><span style={{ font: "500 13px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" }}>{r.goal == null ? "—" : num(r.done || 0) + " / " + num(r.goal) + (unit ? " " + unit : "") + " (" + p + " %)"}</span></span>
        <span role="img" aria-label={r.label + ": " + (r.goal == null ? "ikke i planen" : num(r.done || 0) + " av " + num(r.goal) + ", " + p + " prosent")} style={{ position: "relative", display: "block", height: 8, background: "var(--surface-sunken)" }}><span style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: w + "%", background: r.locked ? "var(--border-strong)" : "var(--primary)", transition: "width 200ms var(--ease-out)" }}></span>{m != null && <span style={{ position: "absolute", top: -3, bottom: -3, left: m + "%", width: 2, marginLeft: -1, background: "var(--action)" }}></span>}</span>
      </div>; })}
    {source && <span style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)" }}>{source}</span>}
  </div>;
}
NS.RepBars = RepBars;
}
{
const dec = (v, d) => v == null ? "—" : (v < 0 ? "−" : v > 0 && d.plus ? "+" : "") + Math.abs(v).toFixed(d.n).replace(".", ",");
/** Målboks på skala med tre merker: utgangspunkt (hul ring), målboks (ramme), måling nå (fylt prikk). Legende med tall under. Mangler måling: «—» og en setning om hvorfor. */
function TargetWindow({ label, hint, lo, hi, value = null, base = null, min, max, ticks, decimals = 1, signed = false, unit = "", emptyText = "Ingen måling registrert.", source }) {
  const d = { n: decimals, plus: signed }, u = unit ? (unit === "°" ? "°" : " " + unit) : "", span = hi - lo || 1;
  const a = min != null ? min : Math.min(lo, value ?? lo, base ?? lo) - span * 0.6, b = max != null ? max : Math.max(hi, value ?? hi, base ?? hi) + span * 0.6, x = (v) => Math.max(0, Math.min(100, (v - a) / (b - a) * 100));
  const tk = ticks || [a, lo, hi, b], inside = value != null && value >= lo && value <= hi, U = (v) => dec(v, d) + (v != null ? u : "");
  const leg = (mark, k, v) => <span style={{ display: "flex", gap: 6, alignItems: "center", minWidth: 0 }}>{mark}<span style={{ display: "flex", flexDirection: "column", minWidth: 0 }}><span style={{ font: "var(--type-meta)", fontSize: 10, letterSpacing: ".04em", color: "var(--text-muted)" }}>{k}</span><span style={{ font: "500 13px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums" }}>{v}</span></span></span>;
  return <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <span style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "baseline" }}><span title={hint} style={{ font: "600 14px/1.3 var(--font-sans)", textDecoration: hint ? "underline dotted var(--border-control)" : "none", textUnderlineOffset: 3 }}>{label}</span><span style={{ font: "500 12px/1.3 var(--font-sans)", color: value == null ? "var(--text-muted)" : "var(--text-primary)" }}>{value == null ? "—" : inside ? "Innenfor målboksen" : "Utenfor målboksen"}</span></span>
    <div role="img" aria-label={label + ": utgangspunkt " + U(base) + ", målboks " + dec(lo, d) + " til " + dec(hi, d) + u + ", måling nå " + (value == null ? "mangler" : U(value))} style={{ position: "relative", height: 32, borderBottom: "1px solid var(--border-ink)", margin: "0 8px" }}>
      <span style={{ position: "absolute", left: x(lo) + "%", width: (x(hi) - x(lo)) + "%", top: 4, bottom: 0, background: "var(--surface-sunken)", borderLeft: "2px solid var(--border-ink)", borderRight: "2px solid var(--border-ink)", boxSizing: "border-box" }}></span>
      {base != null && <span aria-hidden="true" style={{ position: "absolute", left: x(base) + "%", bottom: 6, width: 12, height: 12, marginLeft: -6, borderRadius: 999, border: "2px solid var(--text-secondary)", background: "var(--surface-card)", boxSizing: "border-box" }}></span>}
      {value != null && <span aria-hidden="true" style={{ position: "absolute", left: x(value) + "%", bottom: 4, width: 16, height: 16, marginLeft: -8, borderRadius: 999, background: "var(--text-primary)", boxShadow: "0 0 0 2px var(--surface-card)" }}></span>}
    </div>
    <div aria-hidden="true" style={{ position: "relative", height: 14, margin: "0 8px" }}>{tk.map((t, i) => <span key={i} style={{ position: "absolute", left: x(t) + "%", transform: i === 0 ? "translateX(-8px)" : i === tk.length - 1 ? "translateX(calc(-100% + 8px))" : "translateX(-50%)", font: "var(--type-meta)", color: "var(--text-muted)", whiteSpace: "nowrap" }}>{dec(t, d)}</span>)}</div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,112px),1fr))", gap: 8 }}>
      {leg(<span aria-hidden="true" style={{ width: 10, height: 10, borderRadius: 999, border: "2px solid var(--text-secondary)", flex: "none" }}></span>, "UTGANGSPUNKT", U(base))}
      {leg(<span aria-hidden="true" style={{ width: 14, height: 10, borderLeft: "2px solid var(--border-ink)", borderRight: "2px solid var(--border-ink)", background: "var(--surface-sunken)", flex: "none", boxSizing: "border-box" }}></span>, "MÅLBOKS", dec(lo, d) + " til " + dec(hi, d) + u)}
      {leg(<span aria-hidden="true" style={{ width: 10, height: 10, borderRadius: 999, background: "var(--text-primary)", flex: "none" }}></span>, "MÅLING NÅ", U(value))}
    </div>
    {value == null && <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{emptyText}</span>}
    {source && <span style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)", overflowWrap: "anywhere" }}>{source}</span>}
  </div>;
}
NS.TargetWindow = TargetWindow;
}
{
/** Treffprotokoll som ruter: fylt = godkjent, hul = ikke godkjent, stiplet = ikke slått ennå. Setningen står alltid over. */
function HitGrid({ results = [], window: win = 20, required = 16, text, cell = 12 }) {
  const last = results.slice(-win), hits = last.filter((v) => v === true).length, pct = Math.round(required / win * 100);
  const cells = Array.from({ length: win }, (_, i) => last[i] ?? null);
  return <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <span style={{ font: "500 14px/1.4 var(--font-sans)", textWrap: "pretty" }}>{text || "Rullende vindu: " + required + " av de siste " + win + " slagene skal godkjennes (" + pct + " %)."}</span>
    <div role="img" aria-label={hits + " av " + last.length + " registrerte slag godkjent. Krav " + required + " av " + win + "."} style={{ display: "flex", flexWrap: "wrap", gap: 3 }}>{cells.map((v, i) => <span key={i} style={{ width: cell, height: cell, boxSizing: "border-box", background: v === true ? "var(--primary)" : "var(--surface-card)", border: "1px " + (v == null ? "dashed var(--border-strong)" : "solid var(--border-control)") }}></span>)}</div>
    <span style={{ font: "500 13px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums", color: hits >= required ? "var(--text-primary)" : "var(--text-secondary)" }}>{last.length ? hits + " av " + last.length + " godkjent · krav " + required + " av " + win : "— · ingen slag registrert"}</span>
  </div>;
}
NS.HitGrid = HitGrid;
}
{
const L = [["TURN", "Turnering", "turn"], ["SPILL", "Spill", "spill"], ["SLAG", "Golfslag", "slag"], ["TEK", "Teknisk", "tek"], ["FYS", "Fysisk", "fys"]];
/** Utviklingspyramiden, fem lag. FYS er grunnflaten, TURN toppen. Aksefargen står bare i staven. Valgt lag har grafitt toppstrek. */
function DevelopmentPyramid({ value, onChange, layers = L, meta = {}, compact = false }) {
  return <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <div role="group" aria-label="Utviklingspyramiden" style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      {layers.map(([k, n, a], i) => { const on = value === k, w = 44 + i * 14;
        return <button key={k} type="button" aria-pressed={on} onClick={() => onChange && onChange(k)} style={{ all: "unset", boxSizing: "border-box", width: w + "%", minWidth: 160, maxWidth: "100%", margin: "0 auto", minHeight: compact ? 48 : 60, display: "flex", alignItems: "center", gap: 12, paddingRight: 14, cursor: onChange ? "pointer" : "default", background: on ? "var(--surface-ink)" : "var(--surface-card)", color: on ? "var(--text-inverse)" : "var(--text-primary)", border: "1px solid " + (on ? "var(--surface-ink)" : "var(--border-hairline)"), borderTop: "3px solid " + (on ? "var(--action)" : "var(--border-hairline)"), transition: "background-color 200ms var(--ease-out), color 200ms var(--ease-out)" }}>
          <span aria-hidden="true" style={{ alignSelf: "stretch", width: 4, flex: "none", background: "var(--axis-" + a + ")" }}></span>
          <span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0, flex: 1 }}><span style={{ font: "600 16px/1.1 var(--font-mono)" }}>{k}</span><span style={{ font: "400 13px/1.2 var(--font-sans)", color: on ? "var(--text-inverse-soft)" : "var(--text-secondary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{meta[k] || n}</span></span>
          <span style={{ font: "var(--type-meta)", color: on ? "var(--text-inverse-soft)" : "var(--text-muted)" }}>{String(layers.length - i).padStart(2, "0")}</span>
        </button>; })}
    </div>
    <div aria-hidden="true" style={{ display: "flex", justifyContent: "space-between", font: "var(--type-meta)", fontSize: 10, letterSpacing: ".06em", color: "var(--text-muted)", borderTop: "1px solid var(--border-strong)", paddingTop: 8 }}><span>GRUNNFLATE · FYS</span><span>TOPP · TURN</span></div>
  </div>;
}
NS.DevelopmentPyramid = DevelopmentPyramid;
}
{
const sg = (v, d) => v == null ? "—" : (v > 0 ? "+" : v < 0 ? "−" : "") + Math.abs(v).toFixed(d).replace(".", ",");
/** Fortegnsstolper rundt null (Strokes Gained mot referanse). Fortegnet står i tallet. Valgt rad har grafitt innstrek. */
function SignedBars({ rows = [], value, onSelect, domain, decimals = 2, zeroLabel = "0", labelWidth = 180 }) {
  const m = domain || Math.max(0.5, ...rows.map((r) => Math.abs(r.value || 0))) * 1.1, x = (v) => 50 + (v / m) * 50;
  return <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
    {rows.map((r) => { const on = value === r.id, v = r.value, l = v == null ? 50 : Math.min(x(0), x(v)), w = v == null ? 0 : Math.abs(x(v) - x(0)), Tag = onSelect ? "button" : "div";
      return <Tag key={r.id || r.label} {...(onSelect ? { type: "button", "aria-pressed": on, onClick: () => onSelect(r.id) } : {})} style={{ all: "unset", boxSizing: "border-box", width: "100%", display: "grid", gridTemplateColumns: "minmax(0," + labelWidth + "px) minmax(0,1fr) 64px", gap: 12, alignItems: "center", minHeight: 56, padding: "8px 0 8px 10px", borderBottom: "1px solid var(--border-hairline)", background: on ? "var(--surface-sunken)" : "transparent", boxShadow: on ? "inset 3px 0 0 var(--action)" : "none", cursor: onSelect ? "pointer" : "default", transition: "background-color 200ms var(--ease-out)" }}>
        <span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: (on ? "600 " : "500 ") + "15px/1.2 var(--font-sans)" }}>{r.label}</span>{r.sub && <span style={{ font: "var(--type-meta)", fontSize: 10, letterSpacing: ".04em", color: "var(--text-muted)" }}>{r.sub}</span>}</span>
        <span aria-hidden="true" style={{ position: "relative", height: 24 }}><span style={{ position: "absolute", top: -6, bottom: -6, left: x(0) + "%", width: 1, background: "var(--border-ink)" }}></span>{v != null && <span style={{ position: "absolute", top: 4, height: 16, left: l + "%", width: w + "%", background: v >= 0 ? "var(--data-over)" : "var(--data-under)", transition: "left 200ms var(--ease-in-out), width 200ms var(--ease-in-out)" }}></span>}</span>
        <span style={{ font: "600 16px/1 var(--font-mono)", textAlign: "right", fontVariantNumeric: "tabular-nums", color: v == null ? "var(--text-muted)" : "var(--text-primary)" }}>{sg(v, decimals)}</span>
      </Tag>; })}
    <div aria-hidden="true" style={{ display: "grid", gridTemplateColumns: "minmax(0," + labelWidth + "px) minmax(0,1fr) 64px", gap: 12, paddingTop: 6, paddingLeft: 10 }}><span></span><span style={{ display: "flex", justifyContent: "space-between", font: "var(--type-meta)", color: "var(--text-muted)" }}><span>{sg(-m, 1)}</span><span>{zeroLabel}</span><span>{sg(m, 1)}</span></span><span></span></div>
  </div>;
}
NS.SignedBars = SignedBars;
}
{
/** Faktisk andel mot anbefalt norm per akse. Fyll = faktisk (aksefarge), grafitt strek = anbefalt. */
function NormBars({ rows = [], tolerance = 3, source }) {
  return <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
    {rows.map((r) => { const diff = r.actual == null ? null : r.actual - r.recommended, st = r.status || (diff == null ? "—" : Math.abs(diff) <= tolerance ? "I balanse" : diff > 0 ? "Over norm" : "Under norm");
      return <div key={r.code} style={{ display: "grid", gridTemplateColumns: "52px minmax(0,1fr) minmax(72px,110px)", gap: 12, alignItems: "center", padding: "10px 0", borderBottom: "1px solid var(--border-hairline)" }}>
        <span style={{ font: "600 13px/1 var(--font-mono)" }}>{r.code}</span>
        <span style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span role="img" aria-label={r.code + ": faktisk " + (r.actual ?? "—") + " %, anbefalt " + r.recommended + " %"} style={{ position: "relative", height: 12, background: "var(--surface-sunken)" }}><span style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: Math.min(100, r.actual || 0) + "%", background: "var(--axis-" + String(r.code).toLowerCase() + ")" }}></span><span style={{ position: "absolute", top: -4, bottom: -4, left: Math.min(100, r.recommended) + "%", width: 2, marginLeft: -1, background: "var(--border-ink)" }}></span></span><span style={{ font: "var(--type-meta)", fontSize: 10, letterSpacing: ".02em", color: "var(--text-muted)" }}>FAKTISK {r.actual == null ? "—" : r.actual + " %"} · ANBEFALT {r.recommended} %</span></span>
        <span style={{ font: "500 12px/1.3 var(--font-sans)", textAlign: "right", textWrap: "pretty" }}>{st}</span>
      </div>; })}
    <span style={{ paddingTop: 8, font: "var(--type-meta)", fontSize: 10, letterSpacing: ".04em", color: "var(--text-muted)" }}>FYLL = FAKTISK ANDEL · STREK = ANBEFALT · ±{tolerance} PROSENTPOENG = I BALANSE{source ? " · " + source : ""}</span>
  </div>;
}
NS.NormBars = NormBars;
}
{
const dec = (v, d) => v == null ? "—" : Math.abs(v).toFixed(d).replace(".", ",");
/** Én verdi på skala med anbefalt sone (f.eks. ACWR 0,8–1,3). Setningen forklarer alltid tallet. */
function ZoneGauge({ label, value = null, lo, hi, min = 0, max = 2, decimals = 2, text, source }) {
  const x = (v) => Math.max(0, Math.min(100, (v - min) / (max - min) * 100));
  return <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <span style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span className="kicker">{label}</span><span style={{ font: "600 21px/1 var(--font-mono)" }}>{dec(value, decimals)}</span></span>
    <div role="img" aria-label={label + " " + dec(value, decimals) + ", anbefalt sone " + dec(lo, 1) + " til " + dec(hi, 1)} style={{ position: "relative", height: 20, border: "1px solid var(--border-ink)", background: "var(--surface-card)", boxSizing: "border-box" }}>
      <span style={{ position: "absolute", top: 0, bottom: 0, left: x(lo) + "%", width: (x(hi) - x(lo)) + "%", background: "var(--surface-sunken)", borderLeft: "1px solid var(--border-control)", borderRight: "1px solid var(--border-control)", boxSizing: "border-box" }}></span>
      {value != null && <span style={{ position: "absolute", top: -4, bottom: -4, left: x(value) + "%", width: 4, marginLeft: -2, background: "var(--primary)" }}></span>}
    </div>
    <span aria-hidden="true" style={{ display: "flex", justifyContent: "space-between", font: "var(--type-meta)", color: "var(--text-muted)" }}><span>{dec(min, 1)}</span><span>SONE {dec(lo, 1)}–{dec(hi, 1)}</span><span>{dec(max, 1)}</span></span>
    {text && <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{text}</span>}
    {source && <span style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)" }}>{source}</span>}
  </div>;
}
NS.ZoneGauge = ZoneGauge;
}
{
/** Milepæler som faser over uker med «i dag»-strek. Gjennomført = grafitt fyll, aktiv = ramme, planlagt = stiplet. Under 520 px blir fasene en liste. */
function PhaseTrack({ phases = [], today = null, todayLabel = "I DAG", start, end }) {
  const ref = React.useRef(null), [w, setW] = React.useState(null);
  React.useLayoutEffect(() => { const el = ref.current; if (!el) return; const f = () => setW(el.clientWidth); f(); if (!window.ResizeObserver) return; const ro = new ResizeObserver(f); ro.observe(el); return () => ro.disconnect(); }, []);
  const st = { done: "Gjennomført", active: "Pågår", planned: "Planlagt" };
  const box = (p) => ({ background: p.state === "done" ? "var(--surface-ink)" : p.state === "active" ? "var(--surface-sunken)" : "var(--surface-card)", color: p.state === "done" ? "var(--text-inverse)" : "var(--text-primary)", border: "1px " + (p.state === "planned" ? "dashed var(--border-control)" : "solid " + (p.state === "done" ? "var(--surface-ink)" : "var(--border-ink)")) });
  if (w != null && w < 520) return <div ref={ref} style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}>
    {today != null && <span style={{ font: "600 11px/1 var(--font-mono)", letterSpacing: ".04em" }}>{todayLabel}</span>}
    {phases.map((p) => <div key={p.label} style={{ ...box(p), display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 8, alignItems: "center", padding: "10px 12px", borderRadius: "var(--radius)", minHeight: 48, boxSizing: "border-box" }}><span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "var(--type-meta)", fontSize: 10, letterSpacing: ".04em", opacity: 0.85 }}>{p.range}</span><span style={{ font: "600 13px/1.25 var(--font-sans)" }}>{p.label}</span></span><span style={{ font: "500 12px/1.2 var(--font-sans)" }}>{st[p.state]}</span></div>)}
    {(start || end) && <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{start} – {end}</span>}
  </div>;
  return <div ref={ref} style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}>
    <div style={{ position: "relative", paddingTop: 16 }}>
      <div style={{ display: "flex", gap: 2 }}>{phases.map((p) => <div key={p.label} style={{ ...box(p), flex: p.weeks + " 1 0", minWidth: 0, minHeight: 56, padding: "8px 10px", boxSizing: "border-box", display: "flex", flexDirection: "column", gap: 2 }}><span style={{ font: "var(--type-meta)", fontSize: 10, letterSpacing: ".04em", opacity: 0.85 }}>{p.range} · {st[p.state].toUpperCase()}</span><span style={{ font: "600 13px/1.25 var(--font-sans)", overflowWrap: "anywhere" }}>{p.label}</span></div>)}</div>
      {today != null && <><span aria-hidden="true" style={{ position: "absolute", top: 12, bottom: -6, left: (today * 100) + "%", width: 2, marginLeft: -1, background: "var(--border-ink)" }}></span><span style={{ position: "absolute", top: 0, left: (today * 100) + "%", transform: today > 0.7 ? "translateX(-100%)" : "none", marginLeft: today > 0.7 ? -6 : 6, font: "600 10px/1 var(--font-mono)", color: "var(--text-primary)", whiteSpace: "nowrap" }}>{todayLabel}</span></>}
    </div>
    {(start || end) && <div style={{ display: "flex", justifyContent: "space-between", font: "var(--type-meta)", color: "var(--text-muted)" }}><span>{start}</span><span>{end}</span></div>}
  </div>;
}
NS.PhaseTrack = PhaseTrack;
}
})();
