(() => {
const fmtV = (t, v) => v == null ? "—" : (t.unit === "m" || t.unit === "mph") ? window.PHQ.dec(v) + " " + t.unit : v + " " + t.unit;
const delta = (t) => { const h = t.hist; if (h.length < 2) return null; const d = h[h.length - 1][0] - h[h.length - 2][0]; const good = t.better === "hi" ? d > 0 : d < 0; return { d, good, txt: (d > 0 ? "+" : d < 0 ? "−" : "±") + window.PHQ.dec(Math.abs(d), t.unit === "m" || t.unit === "mph" ? 1 : 0).replace("−", "") }; };
function History({ t, go, onReg }) {
  const { Button, Sparkline, DataTable, AxisBadge, KeyValue } = window.PHQ.ns();
  const P = window.PHQ, dl = delta(t);
  const rows = [...t.hist].reverse().map(([v, d], i) => ({ id: i, d: d + ".2026", v: fmtV(t, v), n: i === 0 ? "Siste" : "" }));
  return <div style={{ display: "flex", flexDirection: "column", gap: 16, minWidth: 0 }}>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}><AxisBadge axis={t.axis} /><P.Meta>{t.attempts} FORSØK · {t.better === "hi" ? "HØYERE ER BEDRE" : "LAVERE ER BEDRE"}</P.Meta></div>
    <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{t.protocol}</p>
    <div style={{ display: "flex", alignItems: "baseline", gap: 12, flexWrap: "wrap" }}><span style={{ font: "var(--type-metric-l)", color: "var(--text-primary)" }}>{t.last == null ? "—" : (t.unit === "m" || t.unit === "mph") ? P.dec(t.last) : t.last}</span><P.Num s={{ color: "var(--text-muted)" }}>{t.unit}</P.Num>{dl && <P.Meta s={{ color: dl.good ? "var(--text-primary)" : "var(--text-muted)" }}>{dl.txt} {t.unit === "av 10" || t.unit === "av 20" || t.unit === "av 60" ? "" : t.unit} SIDEN FORRIGE</P.Meta>}</div>
    {t.hist.length >= 2 ? <Sparkline values={t.hist.map((h) => h[0])} goal={t.goal} height={48} label={"Utvikling " + t.name} /> : <P.Meta>FOR FÅ RESULTATER TIL KURVE</P.Meta>}
    {t.hist.length ? <DataTable caption="Historikk" columns={[{ key: "d", label: "Dato", mono: true }, { key: "v", label: "Resultat", mono: true, align: "right" }, { key: "n", label: "" }]} rows={rows} /> : <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen resultater ennå. Gjennomfør testen for å få første måling.</p>}
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}><Button fullWidth icon="play" onClick={() => go("PH-15")}>Gjennomfør test</Button><Button variant="secondary" fullWidth icon="pencil-line" onClick={onReg}>Registrer resultat</Button></div>
  </div>;
}
function PH14({ state, go }) {
  const { PageHeader, Button, SearchField, EmptyState, Sheet, Sparkline, AxisBadge, FormField, TextInput, Segmented, Stepper, Icon } = window.PHQ.ns();
  const P = window.PHQ, D = window.PHQ_DATA, { mob, pad, desk } = P.useW(), empty = state === "tom", split = desk || pad;
  const [groups, setGroups] = React.useState(empty ? [] : D.tests), [sel, setSel] = React.useState(split && !empty ? "tn3" : null), [q, setQ] = React.useState("");
  const [reg, setReg] = React.useState(false), [val, setVal] = React.useState(""), [own, setOwn] = React.useState(false);
  const [on, setOn] = React.useState(""), [ou, setOu] = React.useState("m"), [oa, setOa] = React.useState(10), [ob, setOb] = React.useState("Lavere er bedre"), [tried, setTried] = React.useState(false);
  const flat = groups.flatMap((g) => g.items), cur = flat.find((t) => t.id === sel);
  const hit = (t) => t.name.toLowerCase().includes(q.toLowerCase());
  const saveReg = () => { const v = parseFloat(String(val).replace(",", ".")); if (isNaN(v)) return; setGroups((G) => G.map((g) => ({ ...g, items: g.items.map((t) => t.id === cur.id ? { ...t, last: v, hist: [...t.hist, [v, "26.09"]] } : t) }))); setReg(false); setVal(""); P.toast("Resultatet er registrert", (cur.name + " · " + fmtV(cur, v) + " · 26.09").toUpperCase()); };
  const saveOwn = () => { setTried(true); if (!on.trim()) return; const id = "own" + Date.now(); setGroups((G) => { const g = G.find((x) => x.group === "Mine tester"); const t = { id, name: on, axis: "slag", unit: ou, better: ob === "Høyere er bedre" ? "hi" : "lo", last: null, hist: [], attempts: oa, protocol: "Egen test. " + oa + " forsøk." }; return g ? G.map((x) => x === g ? { ...x, items: [...x.items, t] } : x) : [...G, { group: "Mine tester", items: [t] }]; }); setSel(id); setOwn(false); setOn(""); setTried(false); P.toast("Egen test er opprettet", "ANDERS SER DEN I TESTOVERSIKTEN"); };
  const list = <P.Stack>
    <SearchField value={q} onChange={setQ} placeholder="Søk test" count={flat.filter(hit).length} />
    {groups.length === 0 && <EmptyState icon="clipboard-list" title="Ingen tester ennå" text="Team Norway-testbatteriet blir tilgjengelig når coachen din har registrert deg. Du kan lage en egen test nå." action="Lag egen test" onAction={() => setOwn(true)} />}
    {groups.map((g) => { const items = g.items.filter(hit); if (!items.length) return null; return <div key={g.group} className="pa-card" style={{ padding: 0, overflow: "hidden" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", padding: "12px 16px", borderBottom: "1px solid var(--border-hairline)", background: "var(--surface-flat)" }}><span className="kicker">{g.group}</span><P.Meta>{items.length} TESTER</P.Meta></div>
      {items.map((t, i) => { const a = t.id === sel, dl = delta(t); return <button key={t.id} type="button" onClick={() => setSel(t.id)} aria-pressed={a} style={{ all: "unset", cursor: "pointer", display: "grid", gridTemplateColumns: "minmax(0,1fr) " + (mob ? "" : "72px ") + "auto", gap: 12, alignItems: "center", padding: "12px 16px", borderTop: i ? "1px solid var(--border-hairline)" : "none", background: a ? "var(--surface-flat)" : "transparent", boxShadow: a ? "inset 2px 0 0 var(--border-ink)" : "none", minHeight: 56 }}>
        <span style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{t.name}</span><P.Meta>{t.hist.length ? "SISTE " + t.hist[t.hist.length - 1][1] + " · " + t.hist.length + " MÅLINGER" : "IKKE TESTET"}</P.Meta></span>
        {!mob && (t.hist.length >= 2 ? <Sparkline values={t.hist.map((h) => h[0])} height={24} /> : <P.Meta>—</P.Meta>)}
        <span style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 2 }}><P.Num s={{ font: "var(--type-num-s)" }}>{fmtV(t, t.last)}</P.Num>{dl && <P.Meta s={{ color: dl.good ? "var(--text-primary)" : "var(--text-muted)" }}>{dl.txt}</P.Meta>}</span>
      </button>; })}
    </div>; })}
  </P.Stack>;
  return <P.Page max={1320}>
    <PageHeader kicker="Plan · Tester" title="Tester" sub="Team Norway-testbatteriet, AK Golf-tester og egne tester. Resultatene vises i Stats." actions={<><Button variant="secondary" icon="plus" onClick={() => setOwn(true)}>Lag egen test</Button>{cur && <Button icon="play" onClick={() => go("PH-15")}>Gjennomfør test</Button>}</>} />
    <P.Gate state={state} loading="Henter testprotokollene …" error={{ title: "Testene kunne ikke hentes", text: "Resultatene dine er ikke slettet. Prøv igjen.", code: "FEIL 503 · TESTER" }}>
      <P.Cols tpl={desk ? "minmax(0,1fr) 400px" : pad ? "minmax(0,1fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
        {list}
        {split && <div className="pa-card" style={{ padding: 16, position: "sticky", top: 24, minWidth: 0, gap: 12 }}>{cur ? <><span className="kicker">Test</span><div style={{ font: "var(--type-title-s)", color: "var(--text-primary)" }}>{cur.name}</div><History t={cur} go={go} onReg={() => setReg(true)} /></> : <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{empty ? "—" : "Velg en test for å se historikk og registrere resultat."}</p>}</div>}
      </P.Cols>
    </P.Gate>
    {!split && <Sheet open={!!cur && !reg} onClose={() => setSel(null)} kicker="Test" title={cur ? cur.name : ""}>{cur && <History t={cur} go={go} onReg={() => setReg(true)} />}</Sheet>}
    <Sheet open={reg && !!cur} onClose={() => setReg(false)} kicker={"Registrer resultat · 26.09"} title={cur ? cur.name : ""} footer={<><Button fullWidth icon="check" disabled={isNaN(parseFloat(String(val).replace(",", ".")))} onClick={saveReg}>Lagre resultat</Button><Button variant="ghost" fullWidth onClick={() => setReg(false)}>Avbryt</Button></>}>
      {cur && <FormField label={"Resultat (" + cur.unit + ")"} hint={cur.protocol} required><TextInput mono inputMode="decimal" value={val} onChange={(e) => setVal(e.target.value)} placeholder={cur.last == null ? "—" : String(cur.last).replace(".", ",")} /></FormField>}
    </Sheet>
    <Sheet open={own} onClose={() => setOwn(false)} kicker="Mine tester" title="Lag egen test" footer={<><Button fullWidth icon="check" onClick={saveOwn}>Opprett test</Button><Button variant="ghost" fullWidth onClick={() => setOwn(false)}>Avbryt</Button></>}>
      <FormField label="Navn" required error={tried && !on.trim() ? "Gi testen et navn, for eksempel «Chip 10 m · 10 slag»." : null}><TextInput value={on} onChange={(e) => setOn(e.target.value)} placeholder="Chip 10 m · 10 slag" /></FormField>
      <FormField label="Enhet"><Segmented options={["m", "ft", "slag", "treff"]} value={ou} onChange={setOu} /></FormField>
      <Stepper label="Antall forsøk" value={oa} min={1} max={100} onChange={setOa} />
      <FormField label="Retning"><Segmented options={["Lavere er bedre", "Høyere er bedre"]} value={ob} onChange={setOb} /></FormField>
    </Sheet>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-14"] = { id: "PH-14", parent: "PH-16", name: "Tester", tab: "plan", route: "/portal/tren/tester", Component: PH14 };
})();
