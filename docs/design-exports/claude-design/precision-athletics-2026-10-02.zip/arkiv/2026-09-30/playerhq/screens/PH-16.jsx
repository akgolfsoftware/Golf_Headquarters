(() => {
const SRC = ["Alle", "Runde", "Økt", "TrackMan", "Test"];
function PH16({ state, go }) {
  const { PageHeader, Button, DataTable, Timeline, SegmentedFilter, EmptyState, Sparkline, Icon, StatusPill } = window.PHQ.ns();
  const P = window.PHQ, A = window.PHQ_AN, Q = window.PHQA, { mob, pad, desk } = P.useW(), empty = state === "tom";
  const [per, setPer] = React.useState("10"), [src, setSrc] = React.useState("Alle");
  const rounds = empty ? [] : A.rounds.slice(0, per === "5" ? 5 : 7);
  const f = per === "5" ? 1.15 : per === "s" ? 0.9 : 1;
  const cats = A.sg.cats.map(([k, n, v]) => [k, n, empty ? null : Math.round(v * f * 10) / 10]);
  const tot = empty ? null : Math.round(cats.reduce((a, c) => a + c[2], 0) * 10) / 10;
  const worst = empty ? null : cats.reduce((a, c) => c[2] < a[2] ? c : a);
  const hist = empty ? [] : A.history.filter((h) => src === "Alle" || h.src === src);
  const perLabel = per === "5" ? "Siste 5 runder" : per === "s" ? "Sesong 2026" : "Siste 10 runder";
  const tiles = [["PH-A01", "Treningsanalyse", "activity", "Belastning, øktkvalitet, slag, putting, tester"], ["PH-17", "TrackMan", "crosshair", "96 slag · 24.09"], ["PH-18", "Runder og statistikk", "flag", empty ? "—" : A.rounds.length + " runder i år"], ["PH-19", "Målsetning og talent", "target", empty ? "—" : "3 aktive mål"], ["PH-20", "Gameplan og banekart", "map", "Fredrikstad GK"]];
  return <P.Page max={1320}>
    <PageHeader kicker={"Stats · " + perLabel} title="Stats" sub="Strokes Gained mot kategori D, siste runder og økter, og alt som er registrert." actions={<Button variant="secondary" icon="flag" onClick={() => go("PH-09")}>Registrer runde</Button>} />
    <SegmentedFilter label="Periode" value={per} onChange={setPer} options={[{ value: "5", label: "Siste 5 runder" }, { value: "10", label: "Siste 10 runder" }, { value: "s", label: "Sesong 2026" }]} />
    <P.Gate state={state} loading="Regner ut Strokes Gained …" error={{ title: "Analysen kunne ikke lastes", text: "Rundene og øktene dine er lagret. Tallene hentes på nytt når du prøver igjen.", code: "FEIL 503 · SG-MOTOR" }}>
      <P.Cols tpl={desk ? "minmax(0,1.2fr) minmax(0,1fr)" : pad ? "repeat(2,minmax(0,1fr))" : "minmax(0,1fr)"}>
        <div className="pa-card" style={{ padding: 16, gap: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "baseline" }}><span className="kicker">Strokes Gained per runde</span><Q.Src>{empty ? "—" : A.sg.src}</Q.Src></div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 12, flexWrap: "wrap" }}><span style={{ font: "var(--type-metric-l)", color: "var(--text-primary)" }}>{Q.sgc(tot)}</span><P.Meta>SG TOTAL · SNITT</P.Meta></div>
          {cats.map(([k, n, v]) => <Q.SGBar key={k} label={k} sub={n} v={v} />)}
          {empty ? <EmptyState icon="flag" title="Ingen runder registrert" text="Strokes Gained regnes ut fra rundene dine. Registrer minst tre runder for første analyse." action="Registrer runde" actionIcon="flag" onAction={() => go("PH-09")} />
            : <div style={{ padding: 12, borderRadius: 8, background: "var(--surface-sunken)", display: "flex", flexDirection: "column", gap: 4 }}><P.Meta>STØRSTE TAP</P.Meta><span style={{ font: "500 14px/1.4 var(--font-sans)", color: "var(--text-primary)", textWrap: "pretty" }}>{worst[1]} ({worst[0]}) koster {Q.sgc(worst[2]).replace("−", "")} slag per runde. Mest fra 100–150 m.</span></div>}
          <div><P.Meta>SG TOTAL · SISTE 6 PERIODER</P.Meta><div style={{ marginTop: 8 }}>{empty ? <P.Meta>—</P.Meta> : <Sparkline values={A.sg.trend} height={40} label="SG total over tid" />}</div></div>
        </div>
        <P.Stack>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 8 }}>{tiles.map(([id, n, ic, m]) => <button key={id} type="button" onClick={() => go(id)} className="pa-card pa-card--interactive" style={{ padding: 14, gap: 8, textAlign: "left", font: "inherit", cursor: "pointer", minWidth: 0, minHeight: 88 }}><span style={{ display: "flex", justifyContent: "space-between" }}><Icon name={ic} size={18} /><Icon name="arrow-up-right" size={16} /></span><span style={{ font: "600 14px/1.25 var(--font-sans)", color: "var(--text-primary)" }}>{n}</span><P.Meta>{m.toUpperCase()}</P.Meta></button>)}</div>
          <div className="pa-card" style={{ padding: 16, gap: 6 }}><div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">Etterlevelse · siste fire uker</span><Q.Src>{empty ? "—" : "UKE " + A.adherence.weeks + " · " + A.adherence.src}</Q.Src></div><div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-metric)", color: "var(--text-primary)" }}>{empty ? "—" : Math.round(A.adherence.done / A.adherence.plan * 100) + " %"}</span><P.Meta>{empty ? "—" : ("GJENNOMFØRT " + A.adherence.done.toFixed(1) + " AV " + A.adherence.plan.toFixed(1) + " T PLANLAGT").replace(/\./g, ",")}</P.Meta></div></div>
          <div className="pa-card" style={{ padding: "12px 16px" }}><div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", paddingBottom: 4 }}><span className="kicker">Siste økter</span><P.Meta>{empty ? "—" : A.sessions.length + " ØKTER · 7 DAGER"}</P.Meta></div>
            {empty ? <p style={{ margin: "4px 0 8px", font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen økter registrert.</p> : A.sessions.map((s, i) => <div key={s.id} style={{ display: "flex", gap: 10, alignItems: "center", minHeight: 52, borderTop: i ? "1px solid var(--border-hairline)" : "none", flexWrap: "wrap" }}><span style={{ width: 4, alignSelf: "stretch", background: "var(--axis-" + s.axis + ")", margin: "8px 0" }}></span><span style={{ flex: "1 1 140px", minWidth: 0, display: "flex", flexDirection: "column", gap: 2 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{s.title}</span><P.Meta>{s.meta}</P.Meta></span><P.Meta>{s.date.slice(0, 5)} · {s.min} MIN</P.Meta></div>)}
          </div>
        </P.Stack>
      </P.Cols>
      <P.Cols tpl={desk ? "minmax(0,1.2fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
        {rounds.length ? <DataTable caption={"Siste runder · " + perLabel.toLowerCase()} rowKey="id" onSelect={() => go("PH-18")} columns={[{ key: "date", label: "Dato", mono: true, sortable: true, sortValue: (r) => r.date.split(".").reverse().join("") }, { key: "course", label: "Bane" }, { key: "score", label: "Brutto", mono: true, align: "right", sortable: true, render: (r) => r.score + " slag (" + P.toPar(r.score - r.par) + ")" + (r.holes === 9 ? " · 9 hull" : "") }, { key: "sg", label: "SG total", mono: true, align: "right", sortable: true, render: (r) => Q.sgc(r.sg) }]} rows={rounds} />
          : <div className="pa-card" style={{ padding: 16 }}><span className="kicker">Siste runder</span><p style={{ margin: "8px 0 0", font: "var(--type-body-s)", color: "var(--text-secondary)" }}>—</p></div>}
        <div className="pa-card" style={{ padding: 16, gap: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">Historikk</span><P.Meta>{hist.length ? hist.length + " HENDELSER" : "—"}</P.Meta></div>
          <SegmentedFilter label="Kilde" value={src} onChange={setSrc} options={SRC.map((x) => ({ value: x, label: x, count: empty ? 0 : x === "Alle" ? A.history.length : A.history.filter((h) => h.src === x).length }))} />
          {hist.length ? <Timeline items={hist} dense /> : <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>{empty ? "Ingenting registrert ennå." : "Ingen hendelser fra " + src + " i perioden."}</p>}
        </div>
      </P.Cols>
    </P.Gate>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-16"] = { id: "PH-16", name: "Stats", tab: "analyse", route: "/portal/analysere", Component: PH16 };
})();
