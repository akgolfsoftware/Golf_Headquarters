/* PH-19 Målsetning — runde 23. «Mål» heter Målsetning. Tegnes i Workbench i runde 29; her bare lenke fra Meg.
   Talentradar vises aldri for spilleren. Talent «Min plan», roadmap og sammenligning med andre spillere utgår (28.09). */
(() => {
function PH19({ state, go }) {
  const { PageHeader, Button, EmptyState } = window.PHQ.ns();
  const P = window.PHQ, G = window.PHQ_AN.goals, empty = state === "tom";
  return <P.Page max={880}>
    <PageHeader kicker="Plan › Workbench · Målsetning" title="Målsetninger" sub="Tegnes ferdig i Workbench i runde 29." actions={<Button variant="secondary" icon="arrow-left" onClick={() => go("PH-24")}>Meg</Button>} />
    <P.Gate state={state} loading="Henter målsetningene …" error={{ title: "Målsetningene kunne ikke hentes", text: "Ingenting er endret. Prøv igjen.", code: "FEIL 503 · MÅLSETNING" }}>
      {empty ? <EmptyState icon="target" title="Ingen målsetninger ennå" text="Lag målsetningene sammen med coachen i Workbench." action="Åpne Workbench" actionIcon="layers" onAction={() => go("PH-11")} />
        : <section aria-label="Målsetninger" className="pa-card" style={{ padding: 16, gap: 4, minWidth: 0 }}><div role="list">{G.map((g, i) => <div role="listitem" key={g.id} style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 60, borderTop: i ? "1px solid var(--border-hairline)" : "none", padding: "8px 0" }}><span style={{ display: "flex", flexDirection: "column", gap: 3, minWidth: 0 }}><span style={{ font: "500 14px/1.35 var(--font-sans)", color: "var(--text-primary)", textWrap: "pretty" }}>{g.sentence}</span><P.Meta>{g.src} · FRIST {g.due}</P.Meta></span><span style={{ display: "flex", flexDirection: "column", gap: 3, alignItems: "flex-end" }}><P.Num s={{ font: "600 14px/1 var(--font-mono)" }}>{P.dec(g.now, g.now % 1 ? 1 : 0)} {g.unit}</P.Num><P.Meta>MÅL {P.dec(g.target, g.target % 1 ? 1 : 0)}</P.Meta></span></div>)}</div></section>}
    </P.Gate>
  </P.Page>;
}
window.PHQ_SCREENS["PH-19"] = { id: "PH-19", parent: "PH-24", name: "Målsetning (lenke fra Meg)", tab: "plan", route: "/portal/mal", Component: PH19 };
})();
