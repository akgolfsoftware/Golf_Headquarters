(() => {
function useClock(start, run) {
  const [s, setS] = React.useState(start);
  React.useEffect(() => { if (!run) return; const t = setInterval(() => setS((x) => x + 1), 1000); return () => clearInterval(t); }, [run]);
  return String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
}
const big = { height: 72, font: "600 21px/1 var(--font-mono)" };
function PH05({ state, go }) {
  const { Button, IconButton, StatusPill, AxisBadge, Dialog, EmptyState } = window.PHQ.ns();
  const P = window.PHQ, D = window.PHQ_DATA, S = D.session, { mob } = P.useW(), empty = state === "tom";
  const [cur, setCur] = React.useState(empty ? 0 : 1);
  const [reps, setReps] = React.useState(empty ? [0, 0, 0, 0] : [30, 18, 0, 0]);
  const [pause, setPause] = React.useState(false), [end, setEnd] = React.useState(false);
  const clock = useClock(empty ? 0 : 1452, state === "data" && !pause);
  const e = S.ex[cur], r = reps[cur];
  const add = (n) => setReps((x) => x.map((v, i) => i === cur ? Math.max(0, v + n) : v));
  const last = cur === S.ex.length - 1;
  const top = <><StatusPill tone="live">Live</StatusPill><P.Meta>{S.title.toUpperCase()}</P.Meta><span style={{ flex: 1 }}></span><Button size="xl" variant="secondary" icon={pause ? "play" : "pause"} onClick={() => setPause(!pause)} style={{ height: 56 }}>{pause ? "Fortsett" : "Pause"}</Button><Button variant="ghost" onClick={() => setEnd(true)} style={{ height: 56 }}>Avslutt</Button></>;
  const action = state === "data" || state === "tom" ? <Button size="xl" fullWidth iconRight={last ? "check" : "arrow-right"} style={{ height: 64 }} onClick={() => last ? go("PH-07") : setCur(cur + 1)}>{last ? "Fullfør økt" : "Neste øvelse"}</Button> : null;
  return <P.Focus top={top} action={action}>
    <P.Gate state={state} loading="Kobler til økta …" error={{ title: "Mistet kontakten med økta", text: "Slagene du har registrert er lagret på telefonen og sendes når nettet er tilbake.", code: "FRAKOBLET · 14:52 · 48 SLAG LOKALT" }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 12, flexWrap: "wrap" }}>
        <span style={{ font: mob ? "500 56px/1 var(--font-mono)" : "var(--type-clock)", color: pause ? "var(--text-muted)" : "var(--text-primary)", fontVariantNumeric: "tabular-nums" }} aria-label={"Tid " + clock}>{clock}</span>
        <P.Meta>{pause ? "PAUSE" : "AV " + S.min + " MIN"}</P.Meta>
      </div>
      <div role="list" aria-label="Øvelser" style={{ display: "grid", gridTemplateColumns: "repeat(" + S.ex.length + ",minmax(0,1fr))", gap: 4 }}>
        {S.ex.map((x, i) => { const d = reps[i] >= x.qty, on = i === cur; return <button key={i} role="listitem" type="button" onClick={() => setCur(i)} aria-current={on ? "step" : undefined} style={{ height: 56, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), borderRadius: 8, background: on ? "var(--surface-card)" : "transparent", color: "var(--text-primary)", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "flex-start", gap: 6, padding: "0 10px", cursor: "pointer", minWidth: 0 }}>
          <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{String(i + 1).padStart(2, "0")}</span>
          <span style={{ display: "block", width: "100%", height: 4, background: "var(--surface-sunken)" }}><span style={{ display: "block", height: "100%", width: Math.min(100, reps[i] / x.qty * 100) + "%", background: "var(--text-primary)", opacity: d ? 1 : .6 }}></span></span>
        </button>; })}
      </div>
      {empty && <EmptyState icon="circle-dashed" title="Ingen repetisjoner registrert" text="Start på øvelse 1. Trykk +1 for hvert slag." />}
      <div className="pa-card" style={{ padding: 16, gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}><AxisBadge axis={e.axis} /><P.Meta>ØVELSE {cur + 1} AV {S.ex.length} · {e.unit === "putter" ? "ANTALL PUTTER" : "ANTALL SLAG"}</P.Meta></div>
        <div style={{ font: "var(--type-title-m)", color: "var(--text-primary)", textWrap: "pretty" }}>{e.n}</div>
        <div style={{ font: "500 12px/1.35 var(--font-mono)", color: "var(--text-secondary)", overflowWrap: "anywhere" }}>{e.code}</div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}><span style={{ font: "var(--type-metric-l)", color: "var(--text-primary)", fontVariantNumeric: "tabular-nums" }}>{r || (empty ? "—" : 0)}</span><P.Num s={{ color: "var(--text-muted)" }}>/ {e.qty} {e.unit}</P.Num></div>
        <div style={{ height: 6, background: "var(--surface-sunken)" }}><div style={{ height: "100%", width: Math.min(100, r / e.qty * 100) + "%", background: "var(--primary)", transition: "width 200ms var(--ease-out)" }}></div></div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "56px minmax(0,1fr) minmax(0,1fr)", gap: 8 }}>
        <IconButton icon="undo-2" label="Angre én" variant="secondary" onClick={() => add(-1)} style={{ width: 56, height: 72 }} />
        <Button variant="secondary" onClick={() => add(5)} style={big}>+5</Button>
        <Button variant="secondary" onClick={() => add(1)} style={big}>+1</Button>
      </div>
      <button type="button" onClick={() => go("PH-06")} style={{ all: "unset", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, minHeight: 56, font: "var(--type-label)", color: "var(--text-secondary)" }}>Åpne slagtelleren med kølle og TrackMan</button>
    </P.Gate>
    <Dialog open={end} title="Avslutte økta?" onClose={() => setEnd(false)} footer={<><Button size="xl" variant="secondary" onClick={() => setEnd(false)}>Fortsett</Button><Button size="xl" onClick={() => go("PH-07")}>Avslutt og lagre</Button></>}>{reps.reduce((a, b) => a + b, 0)} repetisjoner er registrert. Øvelser som ikke er fullført lagres som ikke gjennomført.</Dialog>
  </P.Focus>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-05"] = { id: "PH-05", name: "Live-økt: aktiv", tab: "idag", night: true, route: "/portal/live/[id]/active", Component: PH05 };
})();
