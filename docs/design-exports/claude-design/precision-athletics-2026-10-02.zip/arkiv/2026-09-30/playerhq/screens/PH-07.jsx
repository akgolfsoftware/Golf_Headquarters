(() => {
function PH07({ state, go }) {
  const { Button, IconButton, StatusPill, Metric, Chart, BarRow, DataTable, FormField, TextInput, Switch, EmptyState } = window.PHQ.ns();
  const P = window.PHQ, D = window.PHQ_DATA, M = D.summary, empty = state === "tom";
  const [share, setShare] = React.useState(true), [saved, setSaved] = React.useState(null), [note, setNote] = React.useState("");
  const top = <><IconButton icon="x" label="Lukk" variant="secondary" onClick={() => go("PH-01")} style={{ width: 56, height: 56 }} /><div style={{ flex: 1, minWidth: 0 }}><div className="kicker">Øktoppsummering</div><P.Meta>LØR 26.09 · 14:30–15:42</P.Meta></div></>;
  const action = state === "data" ? (saved ? <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", minHeight: 64 }}><StatusPill tone="ok">Lagret</StatusPill><P.Meta>{saved}</P.Meta><span style={{ flex: 1 }}></span><Button variant="secondary" onClick={() => go("PH-01")}>Til I dag</Button></div>
    : <Button size="xl" fullWidth icon="check" style={{ height: 64 }} onClick={() => { const m = "LAGRET 15:44" + (share ? " · DELT MED ANDERS" : " · IKKE DELT"); setSaved(m); P.toast("Økta er lagret", m); }}>Lagre økt</Button>)
    : state === "tom" ? <Button size="xl" fullWidth icon="arrow-left" style={{ height: 64 }} onClick={() => go("PH-05")}>Tilbake til økta</Button> : null;
  const cols = [{ key: "n", label: "Øvelse" }, { key: "qty", label: "Mengde", mono: true }, { key: "min", label: "Tid", mono: true, align: "right" }, { key: "hit", label: "Treff", mono: true, align: "right" }];
  return <P.Focus top={top} action={action} max={720}>
    <P.Gate state={state} loading="Regner ut oppsummeringen …" error={{ title: "Oppsummeringen kunne ikke lagres", text: "Økta er lagret på telefonen. Oppsummeringen sendes til Anders når nettet er tilbake.", code: "KØ · 1 ØKT VENTER" }}>
      <div><div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>{!empty && <StatusPill tone="ok">Gjennomført</StatusPill>}<P.Meta>{D.session.title.toUpperCase()}</P.Meta></div><h1 style={{ margin: "8px 0 0", font: "var(--type-title-l)", color: "var(--text-primary)" }}>{empty ? "Ingen slag registrert" : "Bra jobbet, " + D.player.first}</h1></div>
      {empty ? <EmptyState icon="circle-dashed" title="Økta har ingen registreringer" text="Det er ikke registrert slag eller putter. Gå tilbake og registrer, eller marker økta som hoppet over." /> : null}
      <div className="pa-card" style={{ padding: 16 }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(120px,1fr))", gap: 16 }}>
          <Metric label="Slag og putter" value={empty ? null : M.shots} />
          <Metric label="Tid" value={empty ? null : P.hm(M.min)} meta={"PLAN " + P.hm(M.plan).toUpperCase()} />
          <Metric label="Øvelser" value={empty ? null : "4 av 4"} />
          <Metric label="Dagsform" value={empty ? null : M.form} />
        </div>
      </div>
      <div className="pa-card" style={{ padding: 16 }}>
        <Chart kicker="Pyramidefordeling" title="Minutter per akse" axis={{ min: 0, max: 80, ticks: 5, unit: "min" }} footer="MÅL-LINJE = PLANLAGT">
          {M.axes.map(([a, v, g]) => <BarRow key={a} label={a.toUpperCase()} axis={a} value={empty ? null : v} max={80} goal={g || null} display={v == null ? null : String(v)} unit="min" />)}
        </Chart>
      </div>
      {!empty && <DataTable caption="Per øvelse" columns={cols} rows={M.rows} />}
      {!empty && <div className="pa-card" style={{ padding: 16, gap: 16 }}>
        <FormField label="Notat til coach" optional hint="Kort om hvordan det gikk."><TextInput value={note} onChange={(e) => setNote(e.target.value)} placeholder="Lengdekontroll satt bedre på 50 m enn 100 m" /></FormField>
        <Switch checked={share} onChange={(e) => setShare(e.target.checked)} label="Del med Anders Kristiansen" />
      </div>}
    </P.Gate>
  </P.Focus>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-07"] = { id: "PH-07", name: "Øktoppsummering", tab: "idag", night: true, route: "/portal/live/[id]/summary", Component: PH07 };
})();
