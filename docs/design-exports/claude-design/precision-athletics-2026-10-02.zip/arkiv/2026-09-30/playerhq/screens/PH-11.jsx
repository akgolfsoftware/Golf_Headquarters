(() => {
/* Kilde på øvelse i coach-Workbench: fra testforslag eller teknisk oppgave. Trykk åpner kilden. */
const withOrigin = (list) => list.map((s) => s.id === "g" ? { ...s, drills: [...s.drills, { id: "fx1", axis: "slag", title: "Putting 5–10 fot · Ballstart · port", meta: "40 putter · SLAG_PUTTING5-10_TRENINGSOMRÅDE_ALENE · utkast", min: 20, from: { kind: "test", label: "Fra test · Putt 5–10 fot · 24.09", to: "AG-15" } }] } : s.id === "c" ? { ...s, drills: [...s.drills, { id: "fx2", axis: "tek", title: "Kortere baksving · Uten ball", meta: "40 repetisjoner · TEK_UTSLAG_AUTO_BANE_OBSERVERT · utkast", min: 15, from: { kind: "tp", label: "Fra teknisk oppgave · P4.0", to: "AG-10" } }] } : s);
const clone = (list) => list.map((s) => ({ ...s, id: Math.random().toString(36).slice(2, 8), drills: s.drills.map((d) => ({ ...d, id: Math.random().toString(36).slice(2, 8) })) }));
const fromPlan = (list) => list.map((s) => ({ id: s.id, name: s.title, day: s.day, t: s.t, drills: [{ id: s.id + "d", axis: s.axis, title: s.title, meta: s.place, min: s.min }] }));
const tone = (p, t) => { if (!t) return null; const r = p / t; return r > 1.05 ? ["warn", "over"] : r < 0.9 ? ["neutral", "under"] : ["ok", "i rute"]; };

function Cell({ level, name, planned, target, sub, onClick, active }) {
  const P = window.PHQ, st = tone(planned, target);
  return <button type="button" onClick={onClick} className="pa-card pa-card--interactive" style={{ minWidth: 0, padding: 12, gap: 6, textAlign: "left", font: "inherit", cursor: onClick ? "pointer" : "default", boxShadow: active ? "inset 0 0 0 1px var(--border-ink)" : undefined, borderColor: active ? "var(--border-ink)" : undefined }}>
    <span style={{ display: "flex", gap: 6, alignItems: "center" }}><span className="kicker" style={{ color: active ? "var(--text-primary)" : undefined }}>{level}</span><span style={{ flex: 1 }}></span>{st && <P.Meta>{st[1].toUpperCase()}</P.Meta>}</span>
    <span style={{ font: "500 13px/1.2 var(--font-sans)", color: "var(--text-secondary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{name}</span>
    <span style={{ display: "flex", alignItems: "baseline", gap: 4, flexWrap: "wrap" }}><span style={{ font: "600 21px/1 var(--font-mono)", color: "var(--text-primary)" }}>{planned == null ? "—" : P.dec(planned).replace(/\B(?=(\d{3})+(?!\d),)/g, " ")}</span>{target != null && <span style={{ font: "var(--type-num-s)", color: "var(--text-muted)" }}>/ {String(Math.round(target)).replace(/\B(?=(\d{3})+(?!\d))/g, " ")} t</span>}</span>
    <span style={{ height: 4, background: "var(--surface-sunken)", display: "block" }}><span style={{ display: "block", height: "100%", width: target ? Math.min(100, (planned || 0) / target * 100) + "%" : "100%", background: "var(--primary)", transition: "width 200ms var(--ease-out)" }}></span></span>
    <P.Meta s={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{sub}</P.Meta>
  </button>;
}

function PH11({ state, go, coach }) {
  const { PageHeader, Button, IconButton, StatusPill, Segmented, EmptyState, AxisBadge, Select, Icon, MoveSheet, ConflictSheet, ConfirmDialog } = window.PHQ.ns();
  const P = window.PHQ, D = window.PHQ_DATA, PM = window.PM, { mob, desk, nav } = P.useW(), empty = state === "tom";
  const [pub, setPub] = React.useState(false), [mvS, setMvS] = React.useState(null), [mvTo, setMvTo] = React.useState(null), [mvScope, setMvScope] = React.useState("Bare denne økta"), [cf, setCf] = React.useState(null);
  const DAY_MAX = 180;
  const [weeks, setWeeks] = React.useState(() => empty ? {} : { 39: fromPlan(D.plan.sessions), 40: coach ? withOrigin(clone(PM.sessions)) : clone(PM.sessions) });
  const [wk, setWk] = React.useState(40), [sel, setSel] = React.useState(null), [seed, setSeed] = React.useState("Kopier forrige uke");
  const [drag, setDrag] = React.useState(null), [sent, setSent] = React.useState(false);
  const dragRef = React.useRef(null);
  const list = weeks[wk], prev = weeks[wk - 1];
  const dates = D.wk(wk), days = D.dayNames.map((n, i) => n + " " + String(dates[i].getDate()).padStart(2, "0"));
  const wkMin = (w) => (weeks[w] || []).reduce((a, s) => a + PM.sessionMin(s), 0);
  const tgt = (w) => (PM.weeks.find((x) => x.w === w) || {}).planned;
  const period = PM.periods.find((p) => wk >= p.from && wk <= p.to);
  const monthIdx = dates[3].getMonth(), monthWeeks = [36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48].filter((w) => D.wk(w)[3].getMonth() === monthIdx);
  const sumH = (ws) => ws.reduce((a, w) => a + (weeks[w] ? wkMin(w) / 60 : w < 39 ? (PM.weeks.find((x) => x.w === w) || {}).done || 0 : 0), 0);
  const perH = sumH(Array.from({ length: period.to - period.from + 1 }, (_, i) => period.from + i));
  const yearH = PM.weeks.reduce((a, w) => a + (w.w < 39 ? w.done : 0), 0) + wkMin(39) / 60 + wkMin(40) / 60 + Object.keys(weeks).filter((w) => +w > 40).reduce((a, w) => a + wkMin(+w) / 60, 0);
  const cur = list && list.find((s) => s.id === sel);
  const upd = (fn) => setWeeks((W) => ({ ...W, [wk]: fn(W[wk]) }));

  React.useEffect(() => {
/* Kilde på øvelse i coach-Workbench: fra testforslag eller teknisk oppgave. Trykk åpner kilden. */
const withOrigin = (list) => list.map((s) => s.id === "g" ? { ...s, drills: [...s.drills, { id: "fx1", axis: "slag", title: "Putting 5–10 fot · Ballstart · port", meta: "40 putter · SLAG_PUTTING5-10_TRENINGSOMRÅDE_ALENE · utkast", min: 20, from: { kind: "test", label: "Fra test · Putt 5–10 fot · 24.09", to: "AG-15" } }] } : s.id === "c" ? { ...s, drills: [...s.drills, { id: "fx2", axis: "tek", title: "Kortere baksving · Uten ball", meta: "40 repetisjoner · TEK_UTSLAG_AUTO_BANE_OBSERVERT · utkast", min: 15, from: { kind: "tp", label: "Fra teknisk oppgave · P4.0", to: "AG-10" } }] } : s);
    if (!drag) return;
    const main = document.querySelector("main");
    const mv = (e) => { const el = document.elementFromPoint(e.clientX, e.clientY); const t = el && el.closest("[data-drop-day]"); const over = t ? +t.dataset.dropDay : null; dragRef.current = { ...dragRef.current, x: e.clientX, y: e.clientY, over }; setDrag({ ...dragRef.current }); if (main) { if (e.clientY > window.innerHeight - 72) main.scrollTop += 14; else if (e.clientY < 72) main.scrollTop -= 14; } };
    const up = () => { const d = dragRef.current; if (d && d.over != null && d.over !== d.from) tryMove(d.id, d.over); dragRef.current = null; setDrag(null); };
    window.addEventListener("pointermove", mv); window.addEventListener("pointerup", up); window.addEventListener("pointercancel", up);
    return () => { window.removeEventListener("pointermove", mv); window.removeEventListener("pointerup", up); window.removeEventListener("pointercancel", up); };
  }, [!!drag]);
  const startDrag = (e, s) => { e.preventDefault(); const d = { id: s.id, from: s.day, over: s.day, x: e.clientX, y: e.clientY, title: PM.sessionTitle(s), axis: PM.sessionAxis(s) || "fys" }; dragRef.current = d; setDrag(d); setSel(s.id); };

  /* Én vei for all flytting: dra, tastatur, Select og MoveSheet. Sjekker volum per dag og viser konflikt før noe endres. */
  const dayMin = (w, di, skip) => (weeks[w] || []).filter((s) => s.day === di && s.id !== skip).reduce((a, s) => a + PM.sessionMin(s), 0);
  const apply = (id, toWk, toDay, series, copy) => { const before = weeks; setWeeks((W) => { const src = W[wk].find((s) => s.id === id); if (!src) return W; const n = { ...W };
      const targets = series ? [toWk, toWk + 1, toWk + 2].filter((w) => n[w]) : [toWk];
      targets.forEach((w, i) => { const cp = { ...clone([src])[0], id: (copy || w !== wk ? "c" + Date.now() + i : src.id), day: toDay }; n[w] = [...(n[w] || []).filter((s) => copy || w !== wk || s.id !== id), cp]; });
      if (!copy && toWk !== wk) n[wk] = n[wk].filter((s) => s.id !== id); return n; });
    const s = list.find((x) => x.id === id), label = (s ? PM.sessionTitle(s) : "Økta") + " → " + (toWk !== wk ? "uke " + toWk + " " : "") + days[toDay];
    nav ? nav.undo(copy ? "Økta er duplisert" : "Økta er flyttet", label.toUpperCase() + (series ? " · HELE SERIEN" : ""), () => setWeeks(before)) : P.toast(copy ? "Økta er duplisert" : "Økta er flyttet", label.toUpperCase()); };
  const tryMove = (id, toDay, opts = {}) => { const s = list.find((x) => x.id === id), toWk = opts.wk || wk; if (!s || (toDay === s.day && toWk === wk && !opts.copy)) return;
    const after = dayMin(toWk, toDay, opts.copy ? null : id) + PM.sessionMin(s), items = [];
    if (after > DAY_MAX) items.push({ kind: "volum", text: days[toDay] + " får " + PM.fmtHM(after) + " trening. Anbefalt maks er " + PM.fmtHM(DAY_MAX) + " per dag.", meta: "UKE " + toWk + " · PLANMOTOR" });
    if (toDay === 5 && toWk === 40) items.push({ kind: "kalender", text: "Lørdag 03.10 er turneringsdag (Srixon Tour, Larvik).", meta: "KALENDER · TURNERING" });
    if (items.length) setCf({ id, toDay, toWk, series: opts.series, copy: opts.copy, items }); else apply(id, toWk, toDay, opts.series, opts.copy); };
  const keyMove = (e, s) => { if (e.key === "ArrowRight" || e.key === "ArrowLeft") { e.preventDefault(); const to = s.day + (e.key === "ArrowRight" ? 1 : -1); if (to >= 0 && to < 7) tryMove(s.id, to); } else if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setMvS(s); setMvTo(null); } };
  const create = () => { const base = seed === "Kopier forrige uke" && prev ? clone(prev) : []; setWeeks((W) => ({ ...W, [wk]: base })); P.toast("Uke " + wk + " er opprettet", seed === "Kopier forrige uke" && prev ? "KOPIERT FRA UKE " + (wk - 1) + " · " + base.length + " ØKTER" : "TOM UKE"); };
  const addSession = (di) => { const id = "n" + Date.now(); upd((l) => [...l, { id, name: "Ny økt", day: di, t: "16:00", drills: [] }]); setSel(id); };

  const board = list && <div style={{ display: "grid", gridTemplateColumns: mob ? "minmax(0,1fr)" : "repeat(7,minmax(0,1fr))", gap: mob ? 12 : 6, alignItems: "stretch", userSelect: drag ? "none" : "auto" }}>
    {days.map((day, di) => { const items = list.filter((s) => s.day === di).sort((a, b) => a.t.localeCompare(b.t)), dm = items.reduce((a, s) => a + PM.sessionMin(s), 0), over = drag && drag.over === di;
      return <div key={di} data-drop-day={di} style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0, padding: 4, borderRadius: 8, background: over ? "var(--surface-flat)" : "transparent", boxShadow: over ? "inset 0 0 0 2px var(--border-ink)" : "none", minHeight: mob ? 0 : 220 }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 6, padding: "4px 2px 6px", borderBottom: "1px solid var(--border-hairline)" }}><span style={{ font: "600 13px/1 var(--font-sans)", color: "var(--text-primary)" }}>{day.split(" ")[0]}</span><span style={{ font: "var(--type-num-s)", color: "var(--text-muted)" }}>{day.split(" ")[1]}</span><span style={{ flex: 1 }}></span><span style={{ font: "var(--type-num-s)", color: dm ? "var(--text-secondary)" : "var(--text-faint)" }}>{dm ? PM.fmtHM(dm) : "—"}</span></div>
        {items.map((s) => { const ax = PM.sessionAxis(s) || "fys", on = s.id === sel, m = PM.sessionMin(s), ghost = drag && drag.id === s.id, org = coach && s.drills.find((d) => d.from);
          return <div key={s.id} style={{ position: "relative", overflow: "hidden", display: "flex", alignItems: "stretch", borderRadius: 8, background: "var(--surface-card)", border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), boxShadow: on ? "0 0 0 1px var(--border-ink)" : "none", opacity: ghost ? .4 : 1, minWidth: 0, minHeight: 64, flexWrap: "wrap" }}>
            <span aria-hidden="true" style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 4, background: PM.stripe(PM.axisMix(s)) }}></span>
            <button type="button" onClick={() => setSel(s.id)} style={{ all: "unset", cursor: "pointer", flex: 1, minWidth: 0, padding: "8px 4px 8px 13px", display: "flex", flexDirection: "column", gap: 4 }}>
              <span style={{ display: "flex", gap: 4, font: "500 11px/1 var(--font-mono)", color: "var(--text-secondary)", flexWrap: "wrap" }}><span>{s.t}</span><span>{m ? PM.fmtHM(m) : "—"}</span></span>
              <span style={{ font: "500 13px/1.25 var(--font-sans)", color: "var(--text-primary)", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", overflowWrap: "anywhere" }}>{PM.sessionTitle(s)}</span>
            </button>
            <span role="button" tabIndex={0} aria-label={"Flytt " + PM.sessionTitle(s) + ". Piltast venstre eller høyre flytter en dag, Enter åpner Flytt."} title="Dra, bruk piltastene eller trykk Enter" onKeyDown={(e) => keyMove(e, s)} onPointerDown={(e) => startDrag(e, s)} style={{ width: 44, minHeight: 44, flex: "none", display: "grid", placeItems: "center", cursor: "grab", touchAction: "none", color: "var(--text-muted)" }}><Icon name="grip-vertical" size={16} /></span>
            {org && <button type="button" onClick={() => go(org.from.to)} aria-label={org.from.label + ". Åpner kilden."} style={{ all: "unset", cursor: "pointer", boxSizing: "border-box", flexBasis: "100%", minHeight: 44, padding: "4px 8px 8px 13px", display: "flex", gap: 6, alignItems: "center", borderTop: "1px solid var(--border-hairline)", font: "500 11px/1.3 var(--font-mono)", color: "var(--text-secondary)", overflowWrap: "anywhere" }}><Icon name="link" size={14} /><span style={{ minWidth: 0 }}>{org.from.label}</span></button>}
          </div>; })}
        <button type="button" onClick={() => addSession(di)} aria-label={"Ny økt " + day} style={{ height: 44, borderRadius: 8, border: "1px dashed var(--border-strong)", background: "transparent", color: "var(--text-muted)", font: "500 13px/1 var(--font-sans)", cursor: "pointer", marginTop: "auto" }}>+ Økt</button>
      </div>; })}
  </div>;

  const panel = cur ? <div className="pa-card" style={{ minWidth: 0, position: desk ? "sticky" : "static", top: 24 }}>
    <div style={{ padding: "16px 16px 12px", borderBottom: "1px solid var(--border-hairline)", display: "flex", flexDirection: "column", gap: 6 }}>
      <span className="kicker">Økt · {days[cur.day]} · {cur.t}</span>
      <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-title-s)", color: "var(--text-primary)", flex: "1 1 160px", minWidth: 0, overflowWrap: "anywhere" }}>{PM.sessionTitle(cur)}</span><span style={{ font: "600 21px/1 var(--font-mono)", color: "var(--text-primary)" }}>{PM.sessionMin(cur) ? PM.fmtHM(PM.sessionMin(cur)) : "—"}</span></div>
    </div>
    <div>{cur.drills.length === 0 && <div style={{ padding: 16, font: "var(--type-body-s)", color: "var(--text-muted)" }}>Ingen øvelser ennå. Hent fra øvelsesbanken.</div>}
      {cur.drills.map((d) => <div key={d.id} className="pa-row" style={{ gap: 8, padding: "8px 8px 8px 12px", alignItems: "center" }}>
        <span style={{ width: 4, alignSelf: "stretch", background: "var(--axis-" + d.axis + ")", flex: "none" }}></span>
        <span className="pa-row__main"><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{d.title}</span>{coach && d.from && <button type="button" onClick={() => go(d.from.to)} style={{ all: "unset", cursor: "pointer", minHeight: 44, display: "inline-flex", gap: 6, alignItems: "center", font: "500 11px/1.3 var(--font-mono)", color: "var(--text-secondary)", textDecoration: "underline", textUnderlineOffset: 3 }}><Icon name="link" size={14} />{d.from.label}</button>}<span style={{ font: "var(--type-meta)", color: "var(--text-muted)", overflowWrap: "anywhere" }}>{String(d.meta || "").toUpperCase()}</span></span>
        <IconButton icon="minus" label="5 min mindre" onClick={() => upd((l) => l.map((s) => s.id === cur.id ? { ...s, drills: s.drills.map((x) => x.id === d.id ? { ...x, min: Math.max(5, x.min - 5) } : x) } : s))} />
        <span style={{ width: 28, textAlign: "center", font: "var(--type-num-s)", color: "var(--text-primary)" }}>{d.min}</span>
        <IconButton icon="plus" label="5 min mer" onClick={() => upd((l) => l.map((s) => s.id === cur.id ? { ...s, drills: s.drills.map((x) => x.id === d.id ? { ...x, min: x.min + 5 } : x) } : s))} />
      </div>)}</div>
    <div style={{ padding: 12, borderTop: "1px solid var(--border-hairline)", display: "flex", flexDirection: "column", gap: 8 }}>
      <Select label="Flytt til dag" value={cur.day} onChange={(e) => tryMove(cur.id, +e.target.value)} options={days.map((d, i) => ({ value: i, label: d }))} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 8 }}><Button variant="secondary" icon="move" onClick={() => { setMvS(cur); setMvTo(null); setMvScope("Bare denne økta"); }}>Flytt …</Button><Button variant="secondary" icon="copy" onClick={() => tryMove(cur.id, cur.day === 6 ? 5 : cur.day + 1, { copy: true })}>Dupliser</Button></div>
      <Button variant="secondary" fullWidth icon="plus" onClick={() => coach ? go("AG-14") : go("PH-13")}>Legg til øvelse</Button>
      <Button variant="ghost" fullWidth icon="trash-2" onClick={() => { const before = weeks, t0 = PM.sessionTitle(cur); upd((l) => l.filter((s) => s.id !== cur.id)); setSel(null); nav ? nav.undo("Økta er fjernet", t0.toUpperCase() + " · KAN ANGRES", () => setWeeks(before)) : P.toast("Økta er fjernet", ""); }}>Fjern økt</Button>
    </div>
  </div> : <div className="pa-card" style={{ padding: 16, gap: 8 }}><span className="kicker">Økt</span><p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Velg en økt for å se øvelsene. Dra i håndtaket for å flytte økta til en annen dag.</p></div>;

  return <P.Page max={1400}>
    {coach ? <PageHeader kicker={coach.kicker} title="Workbench" meta={<span style={{ display: "inline-flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><StatusPill tone={sent ? "ok" : "neutral"}>{sent ? "Publisert" : "Utkast"}</StatusPill>{sent && <span>{"PUBLISERT AV ANDERS KRISTIANSEN · UKE " + wk}</span>}</span>} actions={<Button icon="send" disabled={!list || sent || state !== "data"} onClick={() => setPub(true)}>{coach.group ? "Publiser uke " + wk + " til " + coach.count : "Publiser uke " + wk}</Button>} /> : <PageHeader kicker={"Sesongplan 2026 · " + D.player.name} title="Workbench" meta={<span style={{ display: "inline-flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><StatusPill>Utkast</StatusPill>{sent && <span>SENDT TIL ANDERS 08:14 · VENTER PÅ COACH</span>}</span>} actions={<><Button variant="secondary" icon="wand-sparkles" onClick={() => go("PH-12")}>Planbygger</Button><Button icon="send" disabled={!list || sent || state !== "data"} onClick={() => { setSent(true); P.toast("Uke " + wk + " er sendt til Anders", "COACHEN GODKJENNER FØR PLANEN BLIR AKTIV"); }}>Send uke {wk} til coach</Button></>} />}
    {coach && coach.top}
    <P.Gate state={state} loading="Henter sesongplanen …" error={{ title: "Sesongplanen kunne ikke hentes", text: "Endringer du har gjort er lagret lokalt og sendes når nettet er tilbake.", code: "FEIL 503 · PLANMOTOR" }}>
      <div className="pa-card" style={{ padding: 16, gap: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">År 2026 · uke 1–52</span><P.Meta>{empty ? "INGEN PLAN" : "TRYKK PÅ EN PERIODE"}</P.Meta></div>
        {empty ? <EmptyState icon="layers" title="Ingen sesongplan" text="Lag en plan med periodene dine først. Planbyggeren foreslår perioder ut fra turneringene du skal spille." action="Åpne planbygger" actionIcon="wand-sparkles" onAction={() => go(coach ? "AG-14" : "PH-12")} /> : <window.YearCurve weeks={PM.weeks} range={[1, 52]} selected={wk} currentMin={wkMin(40)} currentAxes={Object.fromEntries(PM.AXES.map((x) => [x, (weeks[40] || []).reduce((t, s) => t + s.drills.filter((d) => d.axis === x).reduce((u, d) => u + d.min, 0), 0)]))} activePeriod={period.id} onPickPeriod={(id) => { const p = PM.periods.find((x) => x.id === id); setWk(Math.max(39, Math.min(p.to, Math.max(p.from, 39)))); setSel(null); }} />}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,150px),1fr))", gap: 8 }}>
        <Cell level="År" name="Sesong 2026" planned={empty ? null : yearH} target={PM.YEAR_TARGET} sub={"MÅL " + PM.fmtN(PM.YEAR_TARGET) + " T"} />
        <Cell level="Periode" name={period.name} planned={empty ? null : perH} target={period.budget} sub={"UKE " + period.from + "–" + period.to} />
        <Cell level="Måned" name={D.monthNames[monthIdx][0].toUpperCase() + D.monthNames[monthIdx].slice(1)} planned={empty ? null : sumH(monthWeeks)} target={monthWeeks.reduce((a, w) => a + (tgt(w) || 0), 0)} sub={"UKE " + monthWeeks[0] + "–" + monthWeeks[monthWeeks.length - 1]} />
        <Cell level="Uke" name={"Uke " + wk} planned={list ? wkMin(wk) / 60 : null} target={tgt(wk)} sub={String(dates[0].getDate()).padStart(2, "0") + "." + String(dates[0].getMonth() + 1).padStart(2, "0") + "–" + String(dates[6].getDate()).padStart(2, "0") + "." + String(dates[6].getMonth() + 1).padStart(2, "0")} active />
        <Cell level="Økt" name={cur ? PM.sessionTitle(cur) : "Ingen valgt"} planned={cur ? PM.sessionMin(cur) / 60 : null} sub={cur ? cur.drills.length + " ØVELSER" : "VELG I UKA"} />
      </div>
      <div role="group" aria-label="Uker i måneden" style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
        <IconButton icon="chevron-left" label="Forrige uke" variant="secondary" disabled={wk <= 39} onClick={() => { setWk(wk - 1); setSel(null); }} />
        {[39, 40, 41, 42, 43, 44].map((w) => { const on = w === wk; return <button key={w} type="button" aria-pressed={on} onClick={() => { setWk(w); setSel(null); }} className="pa-filter__opt" style={{ height: 44 }}><span className="pa-filter__label">Uke {w}</span><span className="pa-filter__count">{weeks[w] ? PM.fmtH(wkMin(w)) + " t" : "—"}</span></button>; })}
        <IconButton icon="chevron-right" label="Neste uke" variant="secondary" disabled={wk >= 44} onClick={() => { setWk(wk + 1); setSel(null); }} />
      </div>
      {list ? <P.Cols tpl={desk ? "minmax(0,1fr) 340px" : "minmax(0,1fr)"}>
        <div className="pa-card" style={{ padding: 12, gap: 8, minWidth: 0 }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", padding: "0 4px" }}><span className="kicker">Uke {wk} · {list.length} økter</span><P.Meta>{mob ? "TRYKK ØKTA · FLYTT I PANELET" : "DRA HÅNDTAKET · PILTASTER · ENTER = FLYTT"}</P.Meta></div>
          {list.length ? board : <>{board}<p style={{ margin: 0, padding: "0 4px", font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Uka er tom. Legg til økter med + Økt.</p></>}
        </div>
        {panel}
      </P.Cols> : <div className="pa-card" style={{ padding: 20, gap: 16, maxWidth: 640 }}>
        <div><span className="kicker">Ny uke</span><div style={{ font: "var(--type-title-s)", color: "var(--text-primary)", marginTop: 6 }}>Uke {wk} er ikke planlagt</div></div>
        <Segmented options={["Kopier forrige uke", "Tom uke"]} value={seed} onChange={setSeed} fullWidth />
        <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{seed === "Kopier forrige uke" ? (prev ? "Alle " + prev.length + " økter fra uke " + (wk - 1) + " kopieres med samme dag og tid. Du kan flytte dem etterpå." : "Uke " + (wk - 1) + " er tom, så det er ingenting å kopiere. Velg Tom uke.") : "Uka opprettes uten økter."}</p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button icon="copy-plus" disabled={seed === "Kopier forrige uke" && !prev} onClick={create}>Opprett uke {wk}</Button></div>
      </div>}
    </P.Gate>
    {drag && <div aria-hidden="true" style={{ position: "fixed", left: drag.x - 80, top: drag.y - 28, width: 160, padding: "8px 10px", borderRadius: 8, background: "var(--surface-card)", border: "1px solid var(--border-hairline)", boxShadow: "inset 4px 0 0 var(--axis-" + drag.axis + "), var(--shadow-modal)", font: "500 13px/1.25 var(--font-sans)", color: "var(--text-primary)", pointerEvents: "none", zIndex: 300, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{drag.title}</div>}
  <MoveSheet open={!!mvS} onClose={() => setMvS(null)} item={mvS ? PM.sessionTitle(mvS) : ""} title="Flytt økt" scope={["Bare denne økta", "Hele serien"]} scopeValue={mvScope} onScope={setMvScope}
      targets={[wk, wk + 1].filter((w) => weeks[w]).flatMap((w) => days.map((d, i) => ({ id: w + ":" + i, label: (w !== wk ? "Uke " + w + " · " : "") + d, meta: PM.fmtHM(dayMin(w, i, mvS && mvS.id)) + " PLANLAGT", warn: mvS && dayMin(w, i, mvS.id) + PM.sessionMin(mvS) > DAY_MAX, reason: mvS && dayMin(w, i, mvS.id) + PM.sessionMin(mvS) > DAY_MAX ? "OVER " + PM.fmtHM(DAY_MAX) + " ETTER FLYTTING" : null, disabled: mvS && w === wk && i === mvS.day })))}
      value={mvTo} onChange={setMvTo} note={coach ? "Spilleren ser endringen når uka publiseres." : "Dette endrer ikke coachens plan før Anders godkjenner."} onConfirm={() => { const [w, d] = mvTo.split(":").map(Number); const id = mvS.id; setMvS(null); tryMove(id, d, { wk: w, series: mvScope === "Hele serien" }); }} />
    <ConflictSheet open={!!cf} onClose={() => setCf(null)} conflicts={cf ? cf.items : []} options={[{ id: "likevel", label: cf && cf.copy ? "Dupliser likevel" : "Flytt likevel", description: "Konflikten vises for coach i Kø." }, { id: "annen", label: "Velg annen dag", description: "Åpner Flytt med alle dager og volum." }]} onResolve={(o) => { const c = cf; setCf(null); if (o === "likevel") apply(c.id, c.toWk, c.toDay, c.series, c.copy); else { setMvS(list.find((s) => s.id === c.id)); setMvTo(null); } }} />
  {coach && <ConfirmDialog open={pub} kind="publish" title={"Publisere uke " + wk + (coach.group ? " til " + coach.group + "?" : " til " + coach.name + "?")} confirmLabel="Publiser" consequences={[(list ? list.length : 0) + " økter blir synlige i Plan og I dag.", coach.group ? coach.count + " spillere får varsel. Individuelle økter beholdes." : coach.name + " får varsel. Forelder får kopi under 18 år.", "Kan trekkes tilbake etterpå."]} onCancel={() => setPub(false)} onConfirm={() => { setPub(false); setSent(true); nav ? nav.undo("Uke " + wk + " er publisert", (coach.group ? "TIL " + coach.group + " · " + coach.count + " SPILLERE" : "TIL " + coach.name).toUpperCase(), () => setSent(false)) : P.toast("Uke " + wk + " er publisert", ""); }} />}
  </P.Page>;
}
window.PHQ_WB = PH11;
/* Runde 21: spillerens PH-11 er nå PH-11-rediger.jsx (Rediger i Plan). Denne motoren brukes videre av coach (AG-11). */
})();
