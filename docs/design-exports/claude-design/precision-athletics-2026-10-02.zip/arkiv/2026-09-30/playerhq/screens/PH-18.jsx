(() => {
const TABS = [{ value: "runder", label: "Runder" }, { value: "stat", label: "Statistikk" }, { value: "hull", label: "Hull" }, { value: "sesong", label: "Sesonger" }];
function Mark({ s, par }) {
  const d = s - par, b = d <= -1 ? "999px" : d >= 1 ? "2px" : 0, dbl = d <= -2 || d >= 2;
  return <span style={{ display: "inline-grid", placeItems: "center", width: 30, height: 30, borderRadius: b, border: d ? "1.5px solid var(--text-primary)" : "none", boxShadow: dbl ? "0 0 0 2px var(--surface-card), 0 0 0 3.5px var(--text-primary)" : "none", font: "600 14px/1 var(--font-mono)", color: "var(--text-primary)" }}>{s}</span>;
}
function Card({ r }) {
  const P = window.PHQ, C = window.PHQ_DATA.course;
  const half = (a) => <div style={{ display: "grid", gridTemplateColumns: "repeat(9,minmax(0,1fr)) minmax(36px,auto)", rowGap: 6, alignItems: "center", textAlign: "center", minWidth: 0 }}>
    {C.par.slice(a, a + 9).map((_, k) => <span key={"h" + k} style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{a + k + 1}</span>)}<span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{a ? "INN" : "UT"}</span>
    {C.par.slice(a, a + 9).map((p, k) => <span key={"p" + k} style={{ font: "var(--type-num-s)", color: "var(--text-secondary)" }}>{p}</span>)}<span style={{ font: "var(--type-num-s)", color: "var(--text-secondary)" }}>{C.par.slice(a, a + 9).reduce((x, y) => x + y, 0)}</span>
    {r.card.slice(a, a + 9).map((s, k) => <span key={"s" + k}><Mark s={s} par={C.par[a + k]} /></span>)}<span style={{ font: "600 15px/1 var(--font-mono)", color: "var(--text-primary)" }}>{r.card.slice(a, a + 9).reduce((x, y) => x + y, 0)}</span>
  </div>;
  return <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>{half(0)}{half(9)}<div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}><P.Meta>RUND = BIRDIE · FIRKANT = BOGEY · DOBBEL = ±2</P.Meta></div></div>;
}
function SeasonChart({ seasons }) {
  const P = window.PHQ, W = 600, H = 220, max = 16, n = 7;
  const x = (i) => 30 + i * (W - 50) / (n - 1), y = (v) => 16 + (1 - v / max) * (H - 40);
  const months = ["APR", "MAI", "JUN", "JUL", "AUG", "SEP", "OKT"];
  const ink = ["var(--graphite-400)", "var(--graphite-500)", "var(--graphite-600)", "var(--text-primary)"];
  return <div style={{ width: "100%", minWidth: 0 }}><svg viewBox={"0 0 " + W + " " + H} style={{ width: "100%", height: "auto", display: "block" }} role="img" aria-label="Til par per måned, fire sesonger">
    {[0, 4, 8, 12, 16].map((v) => <g key={v}><line x1="30" x2={W - 20} y1={y(v)} y2={y(v)} stroke="var(--border-hairline)" /><text x="24" y={y(v) + 4} textAnchor="end" style={{ font: "400 11px var(--font-mono)", fill: "var(--text-muted)" }}>{v ? "+" + v : "±0"}</text></g>)}
    {months.map((m, i) => <text key={m} x={x(i)} y={H - 4} textAnchor="middle" style={{ font: "400 11px var(--font-mono)", fill: "var(--text-muted)" }}>{m}</text>)}
    {seasons.map((s, si) => { const pts = s.pts.map((v, i) => v == null ? null : [x(i), y(v)]).filter(Boolean); return <g key={s.y}><polyline points={pts.map((p) => p.join(",")).join(" ")} fill="none" stroke={ink[si]} strokeWidth={si === 3 ? 2.5 : 1.5} strokeDasharray={si === 3 ? "none" : "4 3"} /><text x={pts[pts.length - 1][0] + 6} y={pts[pts.length - 1][1] + 4} style={{ font: "600 11px var(--font-mono)", fill: ink[si] }}>{s.y}</text></g>; })}
  </svg></div>;
}
const REV = { r10: { done: true, cats: [0.4, -0.8, -0.3, -0.4], p3: 2, src: "MANUELL · ANNEN APP · 21.09.2026" }, r9: { done: false, cats: [0.3, -0.5, null, null], p3: null, src: "MANUELL · 13.09.2026" } };
const CATS = [["OTT", "Utslag"], ["APP", "Innspill"], ["ARG", "Nærspill"], ["PUTT", "Putting"]];
function PH18({ state, go }) {
  const { PageHeader, Button, DataTable, StatusPill, Select, Sparkline, EmptyState, Sheet, Switch, KeyValue, TextInput, FormField } = window.PHQ.ns();
  const [rev, setRev] = React.useState(false), [srcK, setSrcK] = React.useState("Annen app");
  const P = window.PHQ, A = window.PHQ_AN, Q = window.PHQA, D = window.PHQ_DATA, { mob, pad, desk } = P.useW(), empty = state === "tom";
  const [tab, setTab] = React.useState("runder"), [rid, setRid] = React.useState("r10"), [metric, setMetric] = React.useState("Snitt brutto"), [share, setShare] = React.useState(false), [sSG, setSSG] = React.useState(true), [sCoach, setSCoach] = React.useState(true);
  const rounds = empty ? [] : A.rounds, r = rounds.find((x) => x.id === rid);
  const mk = { "Snitt brutto": (x) => x.holes === 9 ? null : x.score, "Fairway treff": (x) => x.fw, "GIR": (x) => x.gir, "Putter per runde": (x) => x.holes === 9 ? null : x.putts, "Scrambling": (x) => x.scr };
  const mu = A.metrics.find((m) => m[0] === metric);
  const series = [...rounds].reverse().map((x) => mk[metric](x));
  const valid = series.filter((v) => v != null), avg = valid.length ? valid.reduce((a, b) => a + b, 0) / valid.length : null;
  const fmtM = (v) => v == null ? null : mu[1] === "%" ? v + " %" : mu[1] === "slag" ? P.dec(v) + " slag" : P.dec(v) + " " + mu[1];
  let body;
  if (tab === "runder") body = <P.Cols tpl={desk ? "minmax(0,1fr) minmax(0,1.2fr)" : "minmax(0,1fr)"}>
    <DataTable caption="Runder 2026" rowKey="id" selected={rid} onSelect={setRid} columns={[{ key: "date", label: "Dato", mono: true }, { key: "course", label: "Bane" }, { key: "score", label: "Brutto", mono: true, align: "right", render: (x) => x.score + " slag (" + P.toPar(x.score - x.par) + ")" + (x.holes === 9 ? " · 9 hull" : "") }, { key: "sg", label: "SG", mono: true, align: "right", render: (x) => Q.sgc(x.sg) }]} rows={rounds} />
    {r && <div className="pa-card" style={{ padding: 16, gap: 16, minWidth: 0 }}>
      <div style={{ display: "flex", gap: 12, alignItems: "flex-start", flexWrap: "wrap" }}><div style={{ flex: "1 1 200px", minWidth: 0 }}><span className="kicker">{r.date} · {r.kind}</span><div style={{ font: "var(--type-title-s)", color: "var(--text-primary)", marginTop: 4 }}>{r.course}</div></div><Button variant="secondary" icon="share-2" onClick={() => setShare(true)}>Del runde</Button></div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-metric-l)", color: "var(--text-primary)" }}>{r.score}</span><P.Num s={{ color: "var(--text-muted)" }}>slag ({P.toPar(r.score - r.par)}) · brutto</P.Num></div>
      {r.card ? <Card r={r} /> : <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Scorekort per hull er ikke registrert for denne runden. Bare totalen er lagret.</p>}
      <KeyValue columns={mob ? 1 : 2} items={[["SG total", Q.sgc(r.sg), { hint: "BASELINE KATEGORI D · " + r.date }], ["Fairway treff", r.fw + " %"], ["GIR", r.gir + " %"], ["Putter", r.putts], ["Scrambling", r.scr + " %"], ["SG mot PGA Tour", r.id === "r10" ? Q.sgc(A.dgRound.sg) : null, { hint: r.id === "r10" ? A.dgRound.src : "IKKE BEREGNET" }]]} />
      {r.id === "r10" && <Q.DG />}
      {(() => { const v = REV[r.id] || { done: false, cats: [null, null, null, null], p3: null, src: null }; return <div style={{ display: "flex", flexDirection: "column", gap: 12, paddingTop: 16, borderTop: "1px solid var(--border-hairline)" }}>
        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 180px" }}>Etter-runden-gjennomgang</span><StatusPill tone={v.done ? "ok" : "neutral"}>{v.done ? "Fullført" : "Delvis lagret"}</StatusPill></div>
        <KeyValue columns={mob ? 1 : 2} items={[...CATS.map(([c, l], k) => ["SG " + c + " · " + l, Q.sgc(v.cats[k])]), ["3-putter", v.p3]]} />
        <Q.Src>{v.src || "IKKE LAGT INN"}</Q.Src>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Button variant="secondary" icon="clipboard-list" onClick={() => setRev(true)}>{v.done ? "Endre gjennomgang" : "Fullfør gjennomgang"}</Button><Button variant="ghost" icon="flag" onClick={() => go("PH-09")}>Hull for hull</Button></div>
      </div>; })()}
    </div>}
  </P.Cols>;
  if (tab === "stat") body = <P.Cols tpl={desk ? "minmax(0,1.3fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
    <div className="pa-card" style={{ padding: 16, gap: 12 }}>
      <div style={{ maxWidth: 320 }}><Select label="Metrikk" value={metric} onChange={(e) => setMetric(e.target.value)} options={A.metrics.map((m) => m[0])} /></div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span style={{ font: "var(--type-metric-l)", color: "var(--text-primary)" }}>{avg == null ? "—" : mu[1] === "%" ? Math.round(avg) : P.dec(avg)}</span><P.Num s={{ color: "var(--text-muted)" }}>{mu[1]} · snitt {valid.length} runder</P.Num></div>
      <Sparkline values={series} height={120} label={metric + " over tid"} />
      <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><P.Meta>09.08</P.Meta><Q.Src>RUNDER · {mu[2] === "lo" ? "LAVERE ER BEDRE" : "HØYERE ER BEDRE"} · 20.09.2026</Q.Src><P.Meta>20.09</P.Meta></div>
      {metric !== "Fairway treff" && metric !== "GIR" && metric !== "Scrambling" && <P.Meta>9-HULLSRUNDER TELLER IKKE I SNITT BRUTTO OG PUTTER</P.Meta>}
    </div>
    <DataTable caption={metric + " per runde"} columns={[{ key: "date", label: "Dato", mono: true }, { key: "course", label: "Bane" }, { key: "v", label: metric, mono: true, align: "right", render: (x) => fmtM(mk[metric](x)) }]} rows={rounds} />
  </P.Cols>;
  if (tab === "hull") { const C = D.course, hs = A.holes; const best = hs.indexOf(Math.min(...hs)), worst = hs.indexOf(Math.max(...hs));
    body = <P.Cols tpl={desk ? "minmax(0,1.4fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
      <div className="pa-card" style={{ padding: 16, gap: 6 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", marginBottom: 6 }}><span className="kicker">Snitt til par per hull · {C.name}</span><Q.Src>14 RUNDER · 2026</Q.Src></div>
        {hs.map((v, i) => <div key={i} style={{ display: "grid", gridTemplateColumns: "72px minmax(0,1fr) 48px", gap: 10, alignItems: "center", minHeight: 28 }}>
          <span style={{ font: "var(--type-num-s)", color: "var(--text-primary)" }}>Hull {i + 1}</span>
          <span style={{ height: 10, background: "var(--surface-sunken)", position: "relative" }}><span style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: (v / 1.2 * 100) + "%", background: i === worst ? "var(--text-primary)" : "var(--text-secondary)" }}></span></span>
          <span style={{ font: "var(--type-num-s)", color: "var(--text-primary)", textAlign: "right" }}>+{P.dec(v)}</span>
        </div>)}
        <P.Meta>PAR {C.par.join(" · ")}</P.Meta>
      </div>
      <P.Stack>
        <div className="pa-card" style={{ padding: 16, gap: 8 }}><span className="kicker">Dyreste hull</span><div style={{ font: "var(--type-title-s)", color: "var(--text-primary)" }}>Hull {worst + 1} · par {C.par[worst]} · {C.len[worst]} m</div><p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Snitt +{P.dec(hs[worst])} til par. 9 av 14 runder med bogey eller verre. Utslaget havner i bunker høyre i 5 av 14.</p><div><Button variant="secondary" icon="map" onClick={() => go("PH-20")}>Se hullet i gameplan</Button></div></div>
        <div className="pa-card" style={{ padding: 16, gap: 8 }}><span className="kicker">Beste hull</span><div style={{ font: "var(--type-title-s)", color: "var(--text-primary)" }}>Hull {best + 1} · par {C.par[best]} · {C.len[best]} m</div><P.Meta>SNITT +{P.dec(hs[best])} TIL PAR · 14 RUNDER</P.Meta></div>
      </P.Stack>
    </P.Cols>; }
  if (tab === "sesong") body = <P.Cols tpl={desk ? "minmax(0,1.4fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
    <div className="pa-card" style={{ padding: 16, gap: 12 }}><div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">Til par per måned · 18 hull</span><Q.Src>RUNDER · 2023–2026</Q.Src></div><SeasonChart seasons={A.seasons} /><P.Meta>OKTOBER 2026 · —</P.Meta></div>
    <DataTable caption="Snitt brutto per sesong" columns={[{ key: "y", label: "Sesong", mono: true }, { key: "avg", label: "Snitt brutto", mono: true, align: "right", render: (x) => P.dec(x.avg) + " slag" }, { key: "kat", label: "Kategori", render: (x) => x.avg < 76 ? "D" : x.avg < 78 ? "E" : x.avg < 80 ? "F" : x.avg < 85 ? "G" : "H" }]} rows={A.seasons.map((s) => ({ ...s, id: s.y })).reverse()} />
  </P.Cols>;
  return <P.Page max={1320}>
    <PageHeader kicker="Stats · Runder og statistikk" title="Runder og statistikk" sub="Score er alltid brutto. Til par regnes av par på hullene du har spilt." actions={<Button icon="flag" onClick={() => go("PH-09")}>Registrer runde</Button>} />
    <P.Gate state={state} loading="Henter rundene dine …" error={{ title: "Rundene kunne ikke hentes", text: "Ingen runder er slettet. Prøv igjen, eller registrer en ny runde som lagres lokalt.", code: "FEIL 502 · RUNDER" }}>
      <Q.Tabs value={tab} onChange={setTab} options={TABS} />
      {empty ? <EmptyState icon="flag" title="Ingen runder i 2026" text="Registrer første runde for å få scorekort, statistikk og hull-analyse." action="Registrer runde" actionIcon="flag" onAction={() => go("PH-09")} secondary="Spill med live-registrering" onSecondary={() => go("PH-08")} /> : body}
    </P.Gate>
    <Sheet open={share && !!r} onClose={() => setShare(false)} kicker="Del runde" title={r ? r.course + " · " + r.date : ""} footer={<><Button fullWidth icon="link" onClick={() => { setShare(false); P.toast("Lenken er kopiert", "GYLDIG I 7 DAGER · KUN LESETILGANG"); }}>Kopier lenke</Button><Button variant="ghost" fullWidth onClick={() => setShare(false)}>Avbryt</Button></>}>
      {r && <><p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Mottakeren ser brutto score og scorekort. Du velger resten.</p><Switch checked={sSG} onChange={(e) => setSSG(e.target.checked)} label="Vis Strokes Gained" /><Switch checked={sCoach} onChange={(e) => setSCoach(e.target.checked)} label="Send også til Anders Kristiansen" /><KeyValue items={[["Viser", r.score + " slag (" + P.toPar(r.score - r.par) + ")"], ["Fullt navn", "Nei · initialer E. S.", { mono: false }]]} /></>}
    </Sheet>
    <Sheet open={rev && !!r} onClose={() => setRev(false)} kicker="Etter-runden-gjennomgang" title={r ? r.course + " · " + r.date : ""} footer={<><Button fullWidth icon="check" onClick={() => { setRev(false); P.toast("Gjennomgangen er lagret", srcK.toUpperCase() + " · " + (r ? r.date : "")); }}>Lagre gjennomgang</Button><Button variant="secondary" fullWidth onClick={() => { setRev(false); P.toast("Delvis lagret", "DU KAN FULLFØRE SENERE"); }}>Lagre delvis</Button></>}>
      {r && <><p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Legg inn det du har. Tomme felt lagres som «—», ikke 0. Score er alltid brutto.</p>
        <Select label="Kilde" value={srcK} onChange={(e) => setSrcK(e.target.value)} options={["Manuell", "Annen app"]} />
        {srcK === "Annen app" && <FormField label="Lim inn fra annen app" hint="Tall kopiert fra appen du brukte. Ingen kobling hentes automatisk." optional><TextInput mono placeholder="OTT +0,4 · APP −0,8 · ARG −0,3 · PUTT −0,4" /></FormField>}
        <FormField label="Brutto score"><TextInput mono inputMode="numeric" defaultValue={r.score} /></FormField>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,120px),1fr))", gap: 12 }}>{CATS.map(([c, l], k) => { const v = (REV[r.id] || {}).cats; return <FormField key={c} label={"SG " + c} hint={l} optional><TextInput mono placeholder="—" defaultValue={v && v[k] != null ? Q.sgc(v[k]) : ""} /></FormField>; })}</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,120px),1fr))", gap: 12 }}><FormField label="Putter" optional><TextInput mono inputMode="numeric" defaultValue={r.putts} /></FormField><FormField label="3-putter" optional><TextInput mono inputMode="numeric" placeholder="—" /></FormField></div>
        <FormField label="Noter" optional><TextInput placeholder="Hva tar du med til neste økt?" /></FormField>
        <P.Meta>SLAG, LIE OG AVSTAND PER HULL LEGGES INN I HULL FOR HULL</P.Meta></>}
    </Sheet>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-18"] = { id: "PH-18", parent: "PH-16", name: "Runder og statistikk", tab: "analyse", route: "/portal/mal/runder", Component: PH18 };
})();
