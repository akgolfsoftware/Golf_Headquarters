/* PH-11 Rediger plan — runde 21. «Rediger» i Plan åpner komplett Workbench på samme sted.
   Akse velges i pyramiderekkefølge FYS · TEK · SLAG · SPILL · TURN; økter legges på en dag og dras (håndtak, piltaster, eller «Flytt til»).
   Spilleren kan endre alt selv. Coach varsles diskré når en økt coachen la inn endres, og når en turnering legges til, fjernes eller flyttes. */
(() => {
const AXL = { fys: "FYS", tek: "TEK", slag: "SLAG", spill: "SPILL", turn: "TURN" };
function Rediger({ state, go, nav }) {
  const { PageHeader, Button, IconButton, ChoicePill, Select, EmptyState, Icon } = window.PHQ.ns();
  const P = window.PHQ, D = window.PHQ_DATA, PD = window.PLAN_DATA, V = window.PLANV, S = window.PLANS, { mob, cw } = P.useW(), empty = state === "tom";
  const [week, setWeek] = React.useState(PD.today.week), [axis, setAxis] = React.useState("fys"), [day, setDay] = React.useState(PD.today.day), [help, setHelp] = React.useState(false);
  const [W, setW] = React.useState(() => empty ? { 39: [], 40: [], 41: [], 42: [] } : { 39: V.weekItems(39, null).ses, 40: V.weekItems(40, null).ses, 41: [], 42: [] });
  const [drag, setDrag] = React.useState(null), dref = React.useRef(null);
  const list = W[week] || [], dates = D.wk(week), it = V.weekItems(week, { golf: true, fys: true, turn: true, samling: true, opptatt: true, google: true, __google: !empty });
  const grid = cw >= 1180;
  const per = PD.periods.find((p) => week >= p.from && week <= p.to);
  const wkMin = list.reduce((a, s) => a + s.min, 0);
  const note = (s, verb) => s && (s.by === "coach" || s.axis === "turn") ? " · ANDERS FÅR BESKJED" : "";
  const commit = (fn, msg, meta) => { const before = W; setW((x) => ({ ...x, [week]: fn(x[week] || []) })); nav ? nav.undo(msg, meta, () => setW(before)) : P.toast(msg, meta); };
  const move = (id, to) => { const s = list.find((x) => x.id === id); if (!s || s.day === to) return; commit((l) => l.map((x) => x.id === id ? { ...x, day: to } : x), "Økta er flyttet", (s.title + " → " + D.dayNames[to] + " " + V.dd(dates[to])).toUpperCase() + note(s)); };
  const remove = (s) => commit((l) => l.filter((x) => x.id !== s.id), s.axis === "turn" ? "Turneringen er fjernet" : "Økta er fjernet", s.title.toUpperCase() + note(s) + " · KAN ANGRES");
  const add = (o) => { const id = "n" + Date.now(), s = { kind: "okt", id, day, t: o.t || "16:00", min: o.min, axis, title: o.name, place: o.place || "—", status: "Planlagt", by: "meg" }; commit((l) => [...l, s], axis === "turn" ? "Turneringen er lagt til" : "Økta er lagt til", (o.name + " · " + D.dayNames[day] + " " + V.dd(dates[day])).toUpperCase() + (axis === "turn" ? " · ANDERS FÅR BESKJED" : "")); };
  const bank = axis === "turn" ? [{ id: "tt", name: "Treningsturnering · 18 hull", min: 270, t: "09:00" }, { id: "tk", name: "Konkurranse · legg til turnering", min: 300, t: "09:00" }] : D.bank.filter((b) => b.axis === axis).map((b) => ({ id: b.id, name: b.name, min: b.min, qty: b.qty, code: b.code }));
  React.useEffect(() => {
    if (!drag) return;
    const mv = (e) => { const el = document.elementFromPoint(e.clientX, e.clientY), t = el && el.closest("[data-drop-day]"); dref.current = { ...dref.current, x: e.clientX, y: e.clientY, over: t ? +t.dataset.dropDay : null }; setDrag({ ...dref.current }); };
    const up = () => { const d = dref.current; if (d && d.over != null) move(d.id, d.over); dref.current = null; setDrag(null); };
    window.addEventListener("pointermove", mv); window.addEventListener("pointerup", up); window.addEventListener("pointercancel", up);
    return () => { window.removeEventListener("pointermove", mv); window.removeEventListener("pointerup", up); window.removeEventListener("pointercancel", up); };
  }, [!!drag]);
  const startDrag = (e, s) => { e.preventDefault(); const d = { id: s.id, over: s.day, x: e.clientX, y: e.clientY, title: s.title, axis: s.axis }; dref.current = d; setDrag(d); };
  const keyMove = (e, s) => { if (e.key === "ArrowRight" || e.key === "ArrowLeft") { e.preventDefault(); const to = s.day + (e.key === "ArrowRight" ? 1 : -1); if (to >= 0 && to < 7) move(s.id, to); } };

  const Row = ({ s }) => <div style={{ display: "flex", alignItems: "stretch", minHeight: 56, borderRadius: 6, background: "var(--surface-card)", border: "1px solid var(--border-hairline)", boxShadow: "inset 4px 0 0 var(--axis-" + s.axis + ")", opacity: drag && drag.id === s.id ? .4 : 1, minWidth: 0, flexWrap: "wrap" }}>
    <div style={{ flex: "1 1 120px", minWidth: 0, padding: "6px 4px 6px 12px", display: "flex", flexDirection: "column", gap: 2 }}>
      <P.Meta s={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.t} · {s.min} MIN{s.by === "coach" ? " · FRA ANDERS" : ""}</P.Meta>
      <span style={{ font: "500 13px/1.25 var(--font-sans)", color: "var(--text-primary)", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", overflowWrap: "anywhere" }}>{s.title}</span>
    </div>
    {grid ? <span role="button" tabIndex={0} aria-label={"Flytt " + s.title + ". Piltast venstre eller høyre flytter en dag."} onKeyDown={(e) => keyMove(e, s)} onPointerDown={(e) => startDrag(e, s)} style={{ width: 36, flex: "none", display: "grid", placeItems: "center", cursor: "grab", touchAction: "none", color: "var(--text-muted)" }}><Icon name="grip-vertical" size={16} /></span>
      : <div style={{ display: "flex", alignItems: "center", gap: 4, padding: "0 4px" }}><div style={{ width: 112 }}><Select label="Flytt til" value={s.day} onChange={(e) => move(s.id, +e.target.value)} options={D.dayNames.map((n, i) => ({ value: i, label: n + " " + V.dd(dates[i]) }))} /></div><IconButton icon="trash-2" label={"Fjern " + s.title} onClick={() => remove(s)} /></div>}
  </div>;
  const busyLine = (di) => { const b = [...it.busy, ...it.goog].filter((x) => x.day === di); return b.length ? <P.Meta s={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>OPPTATT {b.map((x) => x.t).join(" · ")}</P.Meta> : null; };

  const board = grid ? <div style={{ display: "grid", gridTemplateColumns: "repeat(7,minmax(0,1fr))", gap: 6, userSelect: drag ? "none" : "auto", minWidth: 0 }}>
    {D.dayNames.map((n, di) => { const items = list.filter((s) => s.day === di).sort((a, b) => a.t.localeCompare(b.t)), on = di === day, over = drag && drag.over === di, ad = it.allday.filter((a) => di >= a.from && di <= a.to);
      return <div key={di} data-drop-day={di} style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0, padding: 4, borderRadius: 8, minHeight: 280, background: over ? "var(--surface-flat)" : "transparent", boxShadow: over || on ? "inset 0 0 0 2px var(--border-ink)" : "none" }}>
        <button type="button" onClick={() => setDay(di)} aria-pressed={on} style={{ all: "unset", cursor: "pointer", display: "flex", flexDirection: "column", gap: 2, padding: "4px 4px 6px", borderBottom: "1px solid var(--border-hairline)", minHeight: 44, boxSizing: "border-box" }}><span style={{ display: "flex", gap: 6, alignItems: "baseline" }}><span style={{ font: "600 13px/1 var(--font-sans)", color: "var(--text-primary)" }}>{n}</span><span style={{ font: "var(--type-num-s)", color: "var(--text-muted)" }}>{V.dd(dates[di])}</span></span>{busyLine(di)}</button>
        {ad.map((a) => <V.AllDay key={a.id} a={a} onOpen={() => {}} compact />)}
        {items.map((s) => <Row key={s.id} s={s} />)}
      </div>; })}
  </div> : <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <div role="group" aria-label="Dag" style={{ display: "grid", gridTemplateColumns: "repeat(7,minmax(0,1fr))", gap: 4 }}>{D.dayNames.map((n, i) => { const on = i === day, ax = [...new Set(list.filter((s) => s.day === i).map((s) => s.axis))]; return <button key={n} type="button" aria-pressed={on} onClick={() => setDay(i)} style={{ height: 60, borderRadius: 8, border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), background: on ? "var(--primary)" : "var(--surface-card)", color: on ? "var(--text-on-primary)" : "var(--text-primary)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, cursor: "pointer", minWidth: 0, padding: 0 }}><span style={{ font: "500 11px/1 var(--font-sans)", opacity: .8 }}>{n}</span><span style={{ font: "600 15px/1 var(--font-mono)" }}>{V.dd(dates[i]).slice(0, 2)}</span><span style={{ display: "flex", gap: 2, height: 4 }}>{ax.map((a) => <span key={a} style={{ width: 4, height: 4, borderRadius: 999, background: on ? "var(--text-on-primary)" : "var(--axis-" + a + ")" }}></span>)}</span></button>; })}</div>
    <section aria-label={D.dayNames[day] + " " + V.dd(dates[day])} className="pa-card" style={{ padding: 12, gap: 8 }}>
      <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span style={{ font: "600 15px/1 var(--font-sans)", color: "var(--text-primary)", flex: "1 1 auto" }}>{D.dayNames[day]} {V.dd(dates[day])}</span>{busyLine(day)}</div>
      {it.allday.filter((a) => day >= a.from && day <= a.to).map((a) => <V.AllDay key={a.id} a={a} onOpen={() => {}} />)}
      {list.filter((s) => s.day === day).sort((a, b) => a.t.localeCompare(b.t)).map((s) => <Row key={s.id} s={s} />)}
      {!list.some((s) => s.day === day) && <P.Meta>INGEN ØKTER · LEGG TIL UNDER</P.Meta>}
    </section>
  </div>;

  const addPanel = <section aria-label="Legg til" className="pa-card" style={{ padding: 16, gap: 12, minWidth: 0, position: grid ? "sticky" : "static", top: 16 }}>
    <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>Legg til {AXL[axis]}</span><P.Meta>PÅ {D.dayNames[day].toUpperCase()} {V.dd(dates[day])}</P.Meta></div>
    <div role="list">{bank.map((b) => <div role="listitem" key={b.id} style={{ display: "flex", gap: 8, alignItems: "center", minHeight: 56, borderTop: "1px solid var(--border-hairline)", minWidth: 0 }}>
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 2 }}><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{b.name}</span><P.Meta>{b.qty ? b.qty.toUpperCase() + " · " : ""}{b.min} MIN</P.Meta></div>
      <IconButton icon="plus" variant="secondary" label={"Legg " + b.name + " på " + D.dayNames[day]} onClick={() => add(b)} />
    </div>)}</div>
    {axis === "turn" && <S.CoachNote>ANDERS FÅR BESKJED NÅR EN TURNERING LEGGES TIL, FJERNES ELLER FLYTTES</S.CoachNote>}
    <Button variant="ghost" icon="library" onClick={() => go("PH-13")}>Hele øvelsesbanken</Button>
  </section>;

  return <P.Page max={1400}>
    <PageHeader kicker={"Plan · Rediger · " + PD.periodTypes[per.type].name} title="Rediger plan" actions={<><IconButton icon="circle-help" label="Hjelp · Rediger" onClick={() => setHelp(true)} /><Button icon="check" onClick={() => go("PH-10")}>Ferdig</Button></>} />
    <P.Gate state={state} loading="Henter planen …" error={{ title: "Planen kunne ikke hentes", text: "Endringer du har gjort er lagret på telefonen og sendes når nettet er tilbake.", code: "FEIL 503 · WORKBENCH · " + D.date.now }}>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <IconButton icon="chevron-left" label="Forrige uke" variant="secondary" disabled={week <= 39} onClick={() => setWeek(week - 1)} />
        <span style={{ font: "600 15px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>Uke {week} · {V.dd(dates[0])}–{V.dd(dates[6])}</span>
        <IconButton icon="chevron-right" label="Neste uke" variant="secondary" disabled={week >= 42} onClick={() => setWeek(week + 1)} />
        <span style={{ flex: 1 }}></span>
        <P.Meta>{wkMin ? P.hm(wkMin).toUpperCase() + " PLANLAGT" : "—"} · {PD.periodTypes[per.type].name.toUpperCase()} UKE {per.from}–{per.to}</P.Meta>
      </div>
      <div role="radiogroup" aria-label="Akse i pyramiderekkefølge" style={{ display: "grid", gridTemplateColumns: "repeat(5,minmax(0,1fr))", gap: 6 }}>{V.AX.map((a) => <ChoicePill key={a} role="radio" aria-checked={axis === a} selected={axis === a} axis={a} onClick={() => setAxis(a)} style={{ justifyContent: "center", minWidth: 0 }}>{AXL[a]}</ChoicePill>)}</div>
      {empty && !list.length && <EmptyState icon="layers" title={"Uke " + week + " er tom"} text="Velg akse, velg dag og legg til økter. Eller velg en treningsplan som fyller ukene." action="Velg treningsplan" actionIcon="list-checks" onAction={() => go("PH-12")} />}
      <P.Cols tpl={grid ? "minmax(0,1fr) 320px" : "minmax(0,1fr)"}>{board}{addPanel}</P.Cols>
      <P.Meta>{grid ? "DRA HÅNDTAKET · PILTASTER FLYTTER EN DAG · TRYKK DAGEN FOR Å LEGGE TIL" : "VELG DAG · «FLYTT TIL» FLYTTER ØKTA"}</P.Meta>
      <S.CoachNote>DU KAN ENDRE ALT SELV · ENDRER DU EN ØKT ANDERS LA INN, FÅR HAN BESKJED</S.CoachNote>
    </P.Gate>
    {drag && <div aria-hidden="true" style={{ position: "fixed", left: drag.x - 80, top: drag.y - 24, width: 160, padding: "8px 10px", borderRadius: 8, background: "var(--surface-card)", border: "1px solid var(--border-hairline)", boxShadow: "inset 4px 0 0 var(--axis-" + drag.axis + "), var(--shadow-modal)", font: "500 13px/1.25 var(--font-sans)", color: "var(--text-primary)", pointerEvents: "none", zIndex: 300, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{drag.title}</div>}
    <S.HelpSheet level={help ? "Rediger" : null} onClose={() => setHelp(false)} />
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-11"] = { id: "PH-11", parent: "PH-10", name: "Rediger plan (Workbench)", tab: "plan", route: "/portal/planlegge/workbench", Component: Rediger };
})();
