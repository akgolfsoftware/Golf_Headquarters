(() => {
const TABS = [{ value: "okter", label: "Økter" }, { value: "gap", label: "Gapping" }, { value: "utstyr", label: "Utstyr" }, { value: "stasjon", label: "Stasjon" }];
const GEAR_TONE = { "OK": "ok", "Sjekk loft": "warn", "Slitte riller": "warn" };
function PH17({ state, go }) {
  const { PageHeader, Button, KeyValue, DataTable, StatusPill, ChoicePill, EmptyState, Icon, Metric } = window.PHQ.ns();
  const P = window.PHQ, A = window.PHQ_AN.tm, D = window.PHQ_DATA, Q = window.PHQA, { mob, pad, desk } = P.useW(), empty = state === "tom";
  const [tab, setTab] = React.useState("okter"), [sid, setSid] = React.useState("tm1"), [club, setClub] = React.useState("54°");
  const ses = A.sessions.find((s) => s.id === sid);
  const pickS = (id) => { setSid(id); setClub(A.sessions.find((s) => s.id === id).clubs[0]); };
  const tm = D.tm[club], pts = A.shots[club] || [], rng = club === "Driver" ? 24 : ["6i", "7i", "8i"].includes(club) ? 9 : 6;
  const src = "TRACKMAN · " + ses.bay.toUpperCase() + " · " + ses.date;
  let body;
  if (tab === "okter") body = <P.Cols tpl={desk ? "320px minmax(0,1fr)" : pad ? "minmax(0,1fr) minmax(0,1.4fr)" : "minmax(0,1fr)"}>
    <div className="pa-card" style={{ padding: 0, overflow: "hidden" }}>
      <div style={{ padding: "12px 16px", borderBottom: "1px solid var(--border-hairline)", background: "var(--surface-flat)", display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">TrackMan-økter</span><P.Meta>{A.sessions.length} · 30 DAGER</P.Meta></div>
      {A.sessions.map((s, i) => { const on = s.id === sid; return <button key={s.id} type="button" aria-pressed={on} onClick={() => pickS(s.id)} style={{ all: "unset", cursor: "pointer", display: "flex", flexDirection: "column", gap: 4, padding: "12px 16px", borderTop: i ? "1px solid var(--border-hairline)" : "none", background: on ? "var(--surface-flat)" : "transparent", boxShadow: on ? "inset 2px 0 0 var(--border-ink)" : "none", minHeight: 56 }}>
        <span style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", flex: 1, minWidth: 0 }}>{s.title}</span><P.Num s={{ font: "var(--type-num-s)" }}>{s.shots} slag</P.Num></span>
        <P.Meta>{s.date} · {s.bay.toUpperCase()} · {s.clubs.join(" · ").toUpperCase()}</P.Meta>
      </button>; })}
    </div>
    <P.Stack>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{ses.clubs.map((c) => <ChoicePill key={c} mono selected={c === club} onClick={() => setClub(c)}>{c}</ChoicePill>)}</div>
      <div className="pa-card" style={{ padding: 16, gap: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">Spredning · {club} · {pts.length} slag</span><Q.Src>{src}</Q.Src></div>
        <Q.Scatter pts={pts} range={rng} height={mob ? 260 : 320} label={"Spredning " + club} />
      </div>
      <div className="pa-card" style={{ padding: 16, gap: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">Snitt · {club}</span><Q.Src>{src}</Q.Src></div>
        {tm ? <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(112px,1fr))", rowGap: 16, columnGap: 12 }}>
          <Metric size="s" label="Carry" value={P.dec(tm[0])} unit="m" /><Metric size="s" label="Club Speed" value={P.dec(tm[1])} unit="mph" /><Metric size="s" label="Ball Speed" value={P.dec(tm[2])} unit="mph" /><Metric size="s" label="Smash Factor" value={P.dec(tm[3], 2)} /><Metric size="s" label="Launch Angle" value={P.dec(tm[4])} unit="°" /><Metric size="s" label="Club Path" value={P.dec(tm[5])} unit="°" /><Metric size="s" label="Face to Path" value={null} unit="°" /><Metric size="s" label="Spin Rate" value={club === "54°" ? "9 180" : club === "58°" ? "9 840" : club === "PW" ? "8 120" : club === "50°" ? "8 640" : null} unit="rpm" />
        </div> : <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>—</p>}
        <P.Meta>FACE TO PATH MANGLER · BAY 3 MÅLER IKKE KØLLEBLAD</P.Meta>
      </div>
    </P.Stack>
  </P.Cols>;
  if (tab === "gap") { const rows = A.gap.map(([c, carry, sp], i) => { const nx = A.gap[i + 1]; const g = nx ? carry - nx[1] : null; return { id: c, c, carry, sp, g, flag: g == null ? null : g < 8 ? "Overlapp" : g > 18 ? "Hull" : null }; });
    body = <P.Cols tpl={desk ? "minmax(0,1.3fr) minmax(0,1fr)" : "minmax(0,1fr)"}>
      <div className="pa-card" style={{ padding: 16, gap: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}><span className="kicker">Carry per kølle</span><Q.Src>TRACKMAN · 3 ØKTER · 10.09–24.09.2026</Q.Src></div>
        {rows.map((r) => <div key={r.c} style={{ display: "grid", gridTemplateColumns: "56px minmax(0,1fr) 72px", gap: 10, alignItems: "center", minHeight: 30 }}>
          <span style={{ font: "600 13px/1 var(--font-mono)", color: "var(--text-primary)" }}>{r.c}</span>
          <span style={{ position: "relative", height: 12, background: "var(--surface-sunken)" }}><span style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: (r.carry / 240 * 100) + "%", background: "var(--text-primary)" }}></span><span style={{ position: "absolute", top: -3, bottom: -3, left: ((r.carry - r.sp) / 240 * 100) + "%", width: (r.sp * 2 / 240 * 100) + "%", borderLeft: "1px solid var(--text-muted)", borderRight: "1px solid var(--text-muted)" }}></span></span>
          <span style={{ font: "var(--type-num-s)", color: "var(--text-primary)", textAlign: "right" }}>{P.dec(r.carry)} m</span>
        </div>)}
        <P.Meta>STREK = ± SPREDNING I LENGDE (1 SD)</P.Meta>
      </div>
      <DataTable caption="Gapping mellom køller" columns={[{ key: "c", label: "Kølle", mono: true }, { key: "carry", label: "Carry", mono: true, align: "right", render: (r) => P.dec(r.carry) + " m" }, { key: "g", label: "Gap til neste", mono: true, align: "right", render: (r) => r.g == null ? null : P.dec(r.g) + " m" }, { key: "flag", label: "Vurdering", render: (r) => r.flag ? <span style={{ display: "inline-flex", gap: 6, alignItems: "center", font: "var(--type-label)", color: "var(--warn)" }}><Icon name="triangle-alert" size={14} />{r.flag}{r.flag === "Overlapp" ? " · under 8 m" : " · over 18 m"}</span> : "Jevnt" }]} rows={rows} />
    </P.Cols>; }
  if (tab === "utstyr") body = <P.Stack>
    <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", maxWidth: 680, textWrap: "pretty" }}>Utstyrshelse bygger på siste fitting og endringer i TrackMan-tall over tid. Slitasje på riller er et estimat fra fall i Spin Rate.</p>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,280px),1fr))", gap: 12 }}>{A.gear.map((g) => <div key={g.club} className="pa-card" style={{ padding: 16, gap: 10 }}>
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}><span style={{ font: "600 17px/1 var(--font-mono)", color: "var(--text-primary)", flex: 1 }}>{g.club}</span><StatusPill tone={GEAR_TONE[g.status]}>{g.status}</StatusPill></div>
      <KeyValue items={[["Oppsett", g.model, { mono: false }], ["Siste fitting", g.check], ["Merknad", g.note === "—" ? null : g.note, { mono: false }]]} />
      <Q.Src est={g.est}>{g.est ? "TRACKMAN · APRIL–SEPTEMBER 2026" : "FITTING · " + g.check}</Q.Src>
    </div>)}</div>
  </P.Stack>;
  if (tab === "stasjon") { const S = A.station; body = <P.Stack>
    <div className="pa-card" style={{ padding: 16, gap: 12 }}>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}><span className="kicker" style={{ flex: "1 1 200px" }}>Stasjonsmodus · {S.club} mot proff-referanse</span><Q.DG /></div>
      <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>Slå 10 slag med samme kølle. Tallene sammenlignes med PGA Tour-snitt fra Data Golf og normen for kategori C.</p>
      <DataTable columns={[{ key: "k", label: "Parameter" }, { key: "me", label: "Tobias", mono: true, align: "right" }, { key: "pga", label: "PGA Tour", mono: true, align: "right" }, { key: "c", label: "Kategori C", mono: true, align: "right" }, { key: "d", label: "Avvik PGA", mono: true, align: "right" }]} rows={S.rows.map(([k, u, me, pga, c]) => { const dd = k === "Smash Factor" ? 2 : 1, f = (v) => k === "Spin Rate" ? String(Math.round(v)).replace(/\B(?=(\d{3})+(?!\d))/g, " ") : P.dec(v, dd); const diff = me - pga; return { id: k, k, me: f(me) + (u ? " " + u : ""), pga: f(pga) + (u ? " " + u : ""), c: f(c) + (u ? " " + u : ""), d: (diff > 0 ? "+" : diff < 0 ? "−" : "±") + f(Math.abs(diff)) + (u ? " " + u : "") }; })} />
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}><Q.Src>TOBIAS · TRACKMAN · BAY 3 · 24.09.2026</Q.Src><Q.Src>PGA TOUR · DATA GOLF · SESONG 2025</Q.Src><Q.Src est>KATEGORI C · AK GOLF-NORM</Q.Src></div>
    </div>
    <div><Button icon="play" onClick={() => P.toast("Stasjonsmodus startet", "7I · 10 SLAG · BAY 3")}>Start stasjon · 10 slag</Button></div>
  </P.Stack>; }
  return <P.Page max={1320}>
    <PageHeader kicker="Stats · TrackMan" title="TrackMan" sub="Økter importeres automatisk fra bay-ene på Fredrikstad GK. Tallene står på engelsk slik TrackMan viser dem." actions={<Button variant="secondary" icon="arrow-left" onClick={() => go("PH-16")}>Stats</Button>} />
    <P.Gate state={state} loading="Henter TrackMan-økter …" error={{ title: "TrackMan svarer ikke", text: "Øktene er lagret hos TrackMan og hentes når koblingen er tilbake. Ingenting er tapt.", code: "TRACKMAN API · 504 · 26.09 08:14" }}>
      <Q.Tabs value={tab} onChange={setTab} options={TABS} />
      {empty ? <EmptyState icon="crosshair" title="Ingen TrackMan-økter" text="Koble TrackMan-kontoen din, eller book en bay. Øktene dukker opp her etter første slag." action="Koble TrackMan" actionIcon="link" secondary="Book bay" /> : body}
    </P.Gate>
  </P.Page>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-17"] = { id: "PH-17", parent: "PH-16", name: "TrackMan", tab: "analyse", route: "/portal/analysere/trackman", Component: PH17 };
})();
