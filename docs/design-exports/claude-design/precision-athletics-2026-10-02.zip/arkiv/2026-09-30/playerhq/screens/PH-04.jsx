(() => {
function PH04({ state, go }) {
  const { Button, IconButton, AxisBadge, EmptyState } = window.PHQ.ns();
  const P = window.PHQ, D = window.PHQ_DATA, S = D.session, empty = state === "tom";
  const top = <><IconButton icon="x" label="Lukk" variant="secondary" onClick={() => go("PH-03")} style={{ width: 56, height: 56 }} /><div style={{ flex: 1, minWidth: 0 }}><div className="kicker">Live-økt · brief</div><P.Meta>{S.time} · RANGE 3</P.Meta></div></>;
  const action = state === "data" ? <Button size="xl" fullWidth icon="play" onClick={() => go("PH-05")} style={{ height: 64 }}>Start økt</Button>
    : state === "tom" ? <Button size="xl" fullWidth icon="arrow-left" onClick={() => go("PH-03")} style={{ height: 64 }}>Tilbake til øktarket</Button> : null;
  return <P.Focus top={top} action={action}>
    <P.Gate state={state} loading="Henter briefen …" error={{ title: "Briefen kunne ikke lastes", text: "Du er frakoblet. Økta kan startes når nettet er tilbake, eller fra øktarket.", code: "FRAKOBLET · 14:28" }}>
      <div><h1 style={{ margin: 0, font: "var(--type-title-l)", color: "var(--text-primary)" }}>{S.title}</h1><P.Meta s={{ display: "block", marginTop: 6 }}>{S.min} MIN · {empty ? "—" : S.ex.length} ØVELSER · {S.belastning.toUpperCase()} · {S.press.toUpperCase()}</P.Meta></div>
      {empty ? <EmptyState icon="list-plus" title="Ingen øvelser i økta" text="Anders har ikke lagt inn øvelser. Start ikke før økta er klar." /> : <>
        <div className="pa-card" style={{ padding: 16, gap: 12 }}>
          <span className="kicker">Dagens målsetning</span>
          <div style={{ font: "600 21px/1.3 var(--font-sans)", color: "var(--text-primary)", textWrap: "pretty" }}>{S.goal}</div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", paddingTop: 12, borderTop: "1px solid var(--border-hairline)" }}><span className="pa-field__label" style={{ color: "var(--text-secondary)" }}>Fokus</span><span style={{ font: "600 17px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{S.focus}</span><P.Meta s={{ marginLeft: "auto" }}>ÉN TEKNISK DIMENSJON</P.Meta></div>
        </div>
        <div className="pa-card" style={{ padding: "12px 16px" }}>
          {S.ex.map((e, i) => <div key={e.code} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 64, borderTop: i ? "1px solid var(--border-hairline)" : "none" }}>
            <P.Meta s={{ font: "var(--type-num-s)" }}>{String(i + 1).padStart(2, "0")}</P.Meta>
            <div style={{ minWidth: 0 }}><div style={{ font: "500 15px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{e.n}</div><P.Meta>{e.club.toUpperCase()}{e.p ? " · " + e.p : ""}</P.Meta></div>
            <div style={{ textAlign: "right" }}><P.Num>{e.qty}</P.Num><P.Meta s={{ display: "block" }}>{e.unit.toUpperCase()} · {e.min} MIN</P.Meta></div>
          </div>)}
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><AxisBadge axis="slag" /><P.Meta s={{ alignSelf: "center" }}>TRACKMAN KOBLET · BAY 3</P.Meta></div>
      </>}
    </P.Gate>
  </P.Focus>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-04"] = { id: "PH-04", name: "Live-økt: brief", tab: "idag", night: true, route: "/portal/live/[id]/brief", Component: PH04 };
})();
