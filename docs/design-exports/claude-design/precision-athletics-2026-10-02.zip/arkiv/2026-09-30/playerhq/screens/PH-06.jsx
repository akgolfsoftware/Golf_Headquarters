(() => {
function PH06({ state, go }) {
  const { Button, IconButton, StatusPill, Metric, Dialog, EmptyState } = window.PHQ.ns();
  const P = window.PHQ, D = window.PHQ_DATA, empty = state === "tom";
  const [club, setClub] = React.useState("PW");
  const [reps, setReps] = React.useState(empty ? 0 : 18);
  const [end, setEnd] = React.useState(false);
  const goal = 30, tm = empty ? null : D.tm[club];
  const add = (n) => { setReps((r) => Math.max(0, r + n)); if (n > 0) P.toast("+" + n + " slag · " + club, Math.max(0, reps + n) + " AV " + goal + " SLAG"); };
  const top = <><StatusPill tone="live">Live</StatusPill><P.Meta>SLAGTELLER · ØVELSE 1 AV 4</P.Meta><span style={{ flex: 1 }}></span><Button variant="ghost" onClick={() => setEnd(true)} style={{ height: 56 }}>Avslutt</Button></>;
  const action = state === "data" || state === "tom" ? <>
    <div style={{ display: "grid", gridTemplateColumns: "72px minmax(0,1fr)", gap: 8 }}>
      <IconButton icon="undo-2" label="Angre ett slag" variant="secondary" onClick={() => add(-1)} style={{ width: 72, height: 72 }} />
      <Button variant="secondary" onClick={() => add(5)} style={{ height: 72, font: "600 21px/1 var(--font-sans)" }}>+5 slag</Button>
    </div>
    <Button size="xl" fullWidth onClick={() => add(1)} style={{ height: 96, font: "600 29px/1 var(--font-sans)" }}>+1 slag</Button>
  </> : null;
  return <P.Focus top={top} action={action}>
    <P.Gate state={state} loading="Kobler til TrackMan …" error={{ title: "TrackMan svarer ikke", text: "Du kan fortsatt telle slag. Tallene fra TrackMan hentes når bay 3 er koblet til igjen.", code: "TRACKMAN · BAY 3 · 14:41" }}>
      <div className="pa-card" style={{ padding: 16, gap: 10 }}>
        <div style={{ font: "var(--type-title-s)", color: "var(--text-primary)" }}>Innspill 100–150 m · Lengdekontroll</div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}><span style={{ font: "600 56px/1 var(--font-mono)", color: "var(--text-primary)", fontVariantNumeric: "tabular-nums" }}>{empty && !reps ? "—" : reps}</span><P.Num s={{ color: "var(--text-muted)" }}>/ {goal} slag</P.Num></div>
        <div style={{ height: 6, background: "var(--surface-sunken)" }}><div style={{ height: "100%", width: Math.min(100, reps / goal * 100) + "%", background: "var(--primary)", transition: "width 200ms var(--ease-out)" }}></div></div>
      </div>
      <div>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, marginBottom: 8, flexWrap: "wrap" }}><span className="pa-field__label" style={{ color: "var(--text-secondary)" }}>Kølle fra bagen</span><P.Meta>14 KØLLER</P.Meta></div>
        <div role="group" aria-label="Kølle" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(72px,1fr))", gap: 6 }}>
          {D.bag.map((c) => <button key={c} type="button" onClick={() => setClub(c)} aria-pressed={c === club} style={{ height: 56, borderRadius: 8, border: "1px solid " + (c === club ? "var(--border-ink)" : "var(--border-hairline)"), background: c === club ? "var(--primary)" : "var(--surface-card)", color: c === club ? "var(--text-on-primary)" : "var(--text-primary)", font: "600 15px/1 var(--font-mono)", cursor: "pointer", minWidth: 0 }}>{c}</button>)}
        </div>
      </div>
      <div className="pa-card" style={{ padding: 16, gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}><span className="kicker" style={{ flex: 1 }}>TrackMan · siste slag</span><P.Meta>{tm ? "AUTO-IMPORT · 14:41" : "—"}</P.Meta></div>
        {empty ? <EmptyState icon="radar" title="Ingen slag fra TrackMan ennå" text="Slå første slag. Tallene kommer inn automatisk." />
          : !tm ? <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>TrackMan måler ikke putter. Tell puttene med +1.</p>
          : <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(96px,1fr))", rowGap: 14, columnGap: 8 }}>
            <Metric size="s" label="Carry" value={P.dec(tm[0])} unit="m" />
            <Metric size="s" label="Club Speed" value={P.dec(tm[1])} unit="mph" />
            <Metric size="s" label="Ball Speed" value={P.dec(tm[2])} unit="mph" />
            <Metric size="s" label="Smash Factor" value={P.dec(tm[3], 2)} />
            <Metric size="s" label="Launch Angle" value={P.dec(tm[4])} unit="°" />
            <Metric size="s" label="Club Path" value={P.dec(tm[5])} unit="°" />
          </div>}
      </div>
    </P.Gate>
    <Dialog open={end} title="Avslutte økta?" onClose={() => setEnd(false)} footer={<><Button size="xl" variant="secondary" onClick={() => setEnd(false)}>Fortsett</Button><Button size="xl" onClick={() => go("PH-07")}>Avslutt og lagre</Button></>}>{reps} av {goal} slag er registrert på denne øvelsen. Resten lagres som ikke gjennomført.</Dialog>
  </P.Focus>;
}
window.PHQ_SCREENS = window.PHQ_SCREENS || {};
window.PHQ_SCREENS["PH-06"] = { id: "PH-06", name: "Slagteller", tab: "idag", night: true, route: "/portal/live/[id]/tapper", Component: PH06 };
})();
