/* PH-WB-FYS og PH-WB-TURN — runde 21: lag i Plan, ikke egne sider. Gamle ruter åpner Plan med laget i fokus
   (FYS: neste fysiske økt åpen · TURN: uke 40 med turneringsreisen åpen). Registreringen av sett skjer i økta (Start økt). */
(() => {
const Plan = (focus) => (p) => window.PHQ_PLAN ? React.createElement(window.PHQ_PLAN, { ...p, focus }) : null;
window.PHQ_SCREENS["PH-WB-FYS"] = { id: "PH-WB-FYS", name: "Plan · lag Fysisk", tab: "plan", route: "/portal/tren/fys-plan → /portal/planlegge?lag=fys", Component: Plan("fys") };
window.PHQ_SCREENS["PH-WB-TURN"] = { id: "PH-WB-TURN", name: "Plan · lag Turneringer", tab: "plan", route: "/portal/tren/turneringer/[id] → /portal/planlegge?turnering=[id]", Component: Plan("turn") };
})();
