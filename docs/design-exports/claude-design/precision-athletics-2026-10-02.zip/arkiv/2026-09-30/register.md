# Arkivregister 30.09.2026 (runde 36)

Bare det som faktisk er flyttet. Ingenting slettet. Tilbakevei: kopier filen tilbake til opprinnelig plassering og legg scriptlinjen inn i vertsfilen igjen.

| Fil | Opprinnelig plassering | Erstattet av | Vert oppdatert | Status | Begrunnelse |
|---|---|---|---|---|---|
| AG-23.jsx | ui_kits/agencyos/screens/ | AG23 i AG-mer.jsx (seks faner) | screen.html | Arkivert | Lastet etter AG-mer og overstyrte den med åtte gamle faner |
| AG-24.jsx | ui_kits/agencyos/screens/ | AG-24, AG-24-GDPR, AG-24-HJELP i AG-mer.jsx (utgår, videresender til Oppsett) | screen.html | Arkivert | Overstyrte videresendingen |
| AG-24-drift.jsx | ui_kits/agencyos/screens/ | GDPR-handlingene (Utfør sletting, Avvis) er flyttet inn i AG23 i AG-mer.jsx | screen-ag24.html | Arkivert | Eneste unike innhold var GDPR-knappene |

Ikke flyttet ennå (registrert, ikke vurdert): PH-04.jsx, PH-05.jsx, PH-07.jsx overstyres av PH-live.jsx (screen.html laster begge; PH-live vinner). PH-06.jsx og PH-live sin PH06 er dobbeltregistrert på samme måte. Skal vurderes med register per definisjon før flytting.

Kilder i Training Motor lest inn som historikk i `_kilde/`: Arbeidsdokument.html, Treningsmotor-aktiv.html (AK Treningsmotor.dc.html), TekniskPlan-v2.html. Treningsmotor2.html og TekniskPlan.html er beholdt som historikk.

Runde 37: ingen filer flyttet. Nye filer: ui_kits/_shared/tp-v2.jsx, ui_kits/_shared/data-tp2.js, ui_kits/reisetest.html, reisetest-tp.html, audit-tp.html, overlevering/teknisk-plan-v2-2026-09-30.md, overlevering/knapp-skjerm-kart-2026-09-30.md. AG-mer.jsx Row utvidet med barn (GDPR-knapper).

Runde 37 (fortsatt): ds-plan.jsx er fjernet fra screen.html i PlayerHQ og AgencyOS (bundelen inneholder components/plan). Filen er IKKE flyttet: tre andre verter laster den (screen-ag04-mal.html, AG-07-NY-forhaand.html, screen-ag16b.html). Flyttes når disse er avklart. Arkivert i tillegg: oversikter/Masterutforsker.dc.html, ui_kits/agencyos/planmotor.html, drillvelger.html, screen-ag24.html (se arkiv/2026-09-30/index.html). Ny: ui_kits/_shared/WB3-vol.jsx (Workbench › Volum), overlevering/training-motor-overforing-2026-09-30.md, knapp-skjerm-kart-2026-09-30.json/.md, ui_kits/knappkart.html.

## Runde 37 · arkivering av fullt overstyrte skjermdefinisjoner (avhengighetskontroll utført)
Kontroll: alle 27 filer er IIFE uten `window.*`-tilordninger eller `ns`-utvidelser utenom skjermregistreringen; `AG_SCREENS`/`PHQ_SCREENS` initialiseres i ag-parts.jsx/parts.jsx; eneste last-tids-lesing av en annen registrering er PH-02 (leser PH-01, som beholdes). Alle ID-er de registrerte vinnes av en nyere fil i vertsfilen (PH-live.jsx, PH-11-wb3.jsx, PH-16-stats.jsx, AG-cockpit.jsx, AG-innboks.jsx, AG-kalender.jsx, AG-stall.jsx, AG-360.jsx, AG-11-wb3.jsx, AG-mer.jsx). Tilbakevei: kopier filen tilbake til `ui_kits/<kit>/screens/` og legg `<script type="text/babel" src="screens/<fil>"></script>` inn i screen.html før vinneren.

| Fil (arkiv/2026-09-30/…) | Størrelse | sha256 (12 første) |
|---|---|---|
| playerhq/screens/PH-04.jsx | 3344 B | a2be52def058 |
| playerhq/screens/PH-05.jsx | 6075 B | 5826603274f9 |
| playerhq/screens/PH-06.jsx | 5067 B | ba9769bd57da |
| playerhq/screens/PH-07.jsx | 4142 B | 5b3341f43242 |
| playerhq/screens/PH-11-rediger.jsx | 13708 B | 861763e2b20a |
| playerhq/screens/PH-14.jsx | 9685 B | 23889738317e |
| playerhq/screens/PH-16.jsx | 8017 B | 2b0683ac425d |
| playerhq/screens/PH-17.jsx | 10284 B | 8723dd523181 |
| playerhq/screens/PH-18.jsx | 16533 B | 7d89d81f4dc2 |
| playerhq/screens/PH-19.jsx | 2146 B | 31c96a4f293e |
| agencyos/screens/AG-01.jsx | 7715 B | eaa432ecf7ab |
| agencyos/screens/AG-02.jsx | 16295 B | 179bf5c49abc |
| agencyos/screens/AG-03.jsx | 5148 B | 7787feb276a0 |
| agencyos/screens/AG-05.jsx | 18253 B | b2bc290c5cc6 |
| agencyos/screens/AG-06.jsx | 12342 B | b6fa23673009 |
| agencyos/screens/AG-07.jsx | 8953 B | daa366522c70 |
| agencyos/screens/AG-08.jsx | 8701 B | 3eb9c5f8d806 |
| agencyos/screens/AG-09.jsx | 7607 B | fdbda0d396ad |
| agencyos/screens/AG-11.jsx | 3468 B | 0c4431217598 |
| agencyos/screens/AG-12.jsx | 5535 B | ea364618d205 |
| agencyos/screens/AG-13.jsx | 5804 B | 438a88c990f4 |
| agencyos/screens/AG-16.jsx | 6142 B | de1ce4e4edf2 |
| agencyos/screens/AG-17.jsx | 9396 B | a938e3e7fc61 |
| agencyos/screens/AG-18.jsx | 7107 B | 8474aa70dd3e |
| agencyos/screens/AG-20.jsx | 5877 B | 443ff41324b7 |
| agencyos/screens/AG-21.jsx | 5398 B | 79224b7ffd77 |
| agencyos/screens/AG-22.jsx | 6418 B | 06cfbb8ccb4a |

Beholdt (ikke arkivert): AG-04.jsx (lastes av screen-ag04-mal.html), PH-11.jsx (lastet som hjelper i AG-vertens screen.html), PH-02.jsx, PH-01.jsx. Andre chats filer (AG-15-NORMER, AG-16a/b, PH-16b, PH-24d, PH-26/PH-26b) er ikke rørt.

## ds-plan.jsx
Fjernet fra alle verter (screen.html i PlayerHQ og AgencyOS, screen-ag04-mal.html, AG-07-NY-forhaand.html, screen-ag16b.html). Bundelens components/plan er nå eneste kilde. Filen flyttes til arkivet i denne runden.

Runde 37 (slutt): ui_kits/agencyos/index.html (gammel kit-inngang med PlanEngine.jsx, Cockpit.jsx m.fl.) er IKKE arkivert: filene deles med screen.html (PlanParts.jsx brukes av PH-11). Kandidat for senere arkivering etter avhengighetskontroll av hver hjelper. Kontrollene i PlanParts.jsx (CascadeCell, WeekBoard, SessionPanel) er merket inaktive i knappkartet.

## Gammel AgencyOS-kit-inngang (arkivert i siste omgang)
Avhengighetskontroll: `agencyos/index.html` var eneste vert for data.js (AOS_PLAYERS), data-admin.js (AOA_DATA), Parts.jsx (window.AOA), Cockpit.jsx, Godkjenninger.jsx, Caddie.jsx, Kalender.jsx, OktBygger.jsx, StallScreen.jsx, CalendarScreen.jsx, ExerciseComposer.jsx, PlanEngine.jsx og PlanParts.jsx. Ingen aktiv skjerm bruker window.AOA, AOS_PLAYERS, AOA_DATA, window.KIT (agencyos), PlanEngine, YearCurve eller volumeStatus. `PlanParts.jsx` og `playerhq/screens/PH-11.jsx` (window.PHQ_WB, ubrukt etter PH-11-wb3) ble derfor ikke trukket ut til en kanonisk modul: **ingen delte hjelpere var i aktiv bruk** (PH-10 bruker `plan-parts.jsx`/PLANV, ikke PlanParts). Fjernet fra screen.html i PlayerHQ og AgencyOS. Beholdt: `planmotor-data.js` (lastes av screen.html og av andre chats verter screen-ag04-mal.html/screen-ag16b.html). Alt ligger i `arkiv/2026-09-30/agencyos-kit/` (+ `playerhq/screens/PH-11.jsx`). Tilbakevei: kopier tilbake og legg scriptene tilbake i verten.
