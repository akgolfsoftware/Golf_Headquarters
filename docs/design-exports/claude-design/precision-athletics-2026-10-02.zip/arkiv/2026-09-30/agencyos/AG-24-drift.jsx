/* AG-24 Drift (kun admin) — Logger, GDPR og Hjelp som faner i Oppsett (AG23 i AG-mer.jsx, runde 30).
   Presisering for koden: GDPR-fanen viser Utfør sletting og Avvis (som i appen), Hjelp har Kontakt support.
   Lastes av screen-ag24.html i stedet for AG-23.jsx og AG-24.jsx (utgåtte). Oppdiktede data fra data-mer.js. */
(() => {
const D = () => window.MER;
const Sec = ({ k, meta, children, gap = 8 }) => <section aria-label={k} className="pa-card" style={{ padding: 16, gap, minWidth: 0 }}><div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}><span className="kicker" style={{ flex: "1 1 auto" }}>{k}</span>{meta != null && React.createElement(window.AGQ.Meta, null, meta)}</div>{children}</section>;
const Row = ({ a, sub, b, i, children }) => <div role="listitem" style={{ display: "flex", flexDirection: "column", gap: 8, borderTop: i ? "1px solid var(--border-hairline)" : "none", padding: "10px 0", minWidth: 0 }}><div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 12, alignItems: "center", minHeight: 36, minWidth: 0 }}><span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{a}</span>{sub && React.createElement(window.AGQ.Meta, null, sub)}</span>{b != null && <span style={{ font: "600 13px/1.3 var(--font-mono)", color: "var(--text-primary)", textAlign: "right", display: "flex", gap: 8, alignItems: "center", justifyContent: "flex-end", flexWrap: "wrap" }}>{b}</span>}</div>{children}</div>;
const TABS = [["profil", "Profil"], ["team", "Team og invitasjoner"], ["gdpr", "GDPR"], ["logg", "Logger"], ["mark", "Markedsføring"], ["hjelp", "Hjelp"]];
function AG24({ state, tab0 }) {
  const { PageHeader, Button, ChoicePill, StatusPill } = window.AGQ.ns(), A = window.AGQ, empty = state === "tom";
  const [tab, setTab] = React.useState(tab0 || "logg");
  const body = tab === "gdpr" ? <Sec k="GDPR" meta="SVAR INNEN 30 DAGER">{empty ? <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen forespørsler.</p> : <div role="list">{D().gdpr.map(([n, s, st], i) => <Row key={n} i={i} a={n} sub={s.toUpperCase()} b={<StatusPill tone={st === "Åpen" ? "warn" : "ok"}>{st}</StatusPill>}>{st === "Åpen" && <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{n.startsWith("Slette") && <Button size="sm" variant="secondary" icon="trash-2">Utfør sletting</Button>}<Button size="sm" variant="ghost">Avvis</Button></div>}</Row>)}</div>}</Sec>
    : tab === "hjelp" ? <Sec k="Hjelp" meta="AK GOLF HQ"><div role="list">{[["Kom i gang som assistant coach", "5 MIN"], ["Slik fungerer gruppeplanen", "3 MIN"], ["Tripletex-eksport steg for steg", "4 MIN"], ["Kontakt support", "post@akgolf.no"]].map(([n, s], i) => <Row key={n} i={i} a={n} b={s} />)}</div></Sec>
    : <Sec k="Logger" meta="ENDRINGER OG FEIL · 90 DAGER">{empty ? <p style={{ margin: 0, font: "var(--type-body-s)", color: "var(--text-secondary)" }}>Ingen hendelser.</p> : <div role="list">{D().logs.map(([t, w, h], i) => <Row key={t + h} i={i} a={h} sub={(t + " · " + w).toUpperCase()} />)}</div>}</Sec>;
  return <A.Page max={960}>
    <PageHeader kicker="Mer · Oppsett" title="Oppsett" />
    <A.Gate state={state} loading="Henter oppsett …" error={{ title: "Oppsett kunne ikke hentes", text: "Ingen innstillinger er endret.", code: "FEIL 503 · OPPSETT · 08:20" }}>
      <div role="tablist" aria-label="Oppsett" style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{TABS.map(([k, l]) => <ChoicePill key={k} role="tab" aria-selected={tab === k} selected={tab === k} onClick={() => setTab(k)}>{l}</ChoicePill>)}</div>
      <A.Stack>{body}</A.Stack>
    </A.Gate>
  </A.Page>;
}
const S = window.AG_SCREENS;
S["AG-24"] = { id: "AG-24", name: "Drift · Logger (fane i Oppsett)", route: "/admin/audit-log → /admin/oppsett?fane=logg", Component: (p) => <AG24 {...p} tab0="logg" /> };
S["AG-24-GDPR"] = { id: "AG-24-GDPR", parent: "AG-24", name: "Drift · GDPR", route: "/admin/gdpr → /admin/oppsett?fane=gdpr", Component: (p) => <AG24 {...p} tab0="gdpr" /> };
S["AG-24-HJELP"] = { id: "AG-24-HJELP", parent: "AG-24", name: "Drift · Hjelp", route: "/admin/hjelp → /admin/oppsett?fane=hjelp", Component: (p) => <AG24 {...p} tab0="hjelp" /> };
})();
