(() => {
const { KitShell, G } = window.KIT;
const NAV = [
  G("plan", "Planlegging", "calendar-range", [["ukeplan", "Ukeplan og fravær", "calendar-range"]]),
  G("test", "Tester", "clipboard-check", [["tester", "Fysiske tester", "dumbbell"]]),
];
function WangSkole() {
  return <KitShell nav={NAV} store="wang-page" fallback="ukeplan" who={{ name: "Anders Kristiansen", role: "TRENER · WANG TOPPIDRETT" }} screens={{ ukeplan: WangUkeplan, tester: WangFysiskeTester }} />;
}
window.WangSkole = WangSkole;
})();
