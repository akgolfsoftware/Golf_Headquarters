(() => {
const { Button, ChoicePill, Input, Select, InlineAlert, StatusPill } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, Grid, Mono, useW, nf } = window.KIT;
const mmss = (s) => Math.floor(s / 60) + ":" + String(Math.round(s % 60)).padStart(2, "0");
const TESTS = [
  { id: "squat", n: "1RM Knebøy", u: "kg", avg: 95, d: 0, hist: [[ "08.01", 90], ["02.04", 97.5], ["10.06", 102.5], ["18.09", 105]] },
  { id: "dead", n: "1RM Markløft", u: "kg", avg: 120, d: 0, hist: [["08.01", 115], ["02.04", 122.5], ["10.06", 127.5], ["18.09", 130]] },
  { id: "chins", n: "Chins", u: "stk", avg: 9, d: 0, hist: [["08.01", 7], ["02.04", 9], ["10.06", 10], ["18.09", 11]] },
  { id: "mball", n: "Medisinballkast rotasjon", u: "m", avg: 10.9, d: 1, hist: [["08.01", 10.2], ["02.04", 10.8], ["10.06", 11.5], ["18.09", 11.8]] },
  { id: "3000", n: "3000 m", u: "min", avg: 730, lower: true, hist: [["08.01", 768], ["02.04", 741], ["10.06", 719], ["18.09", 702]] },
];
const fmt = (t, v) => t.id === "3000" ? mmss(v) : nf(v, t.d || (v % 1 ? 1 : 0));
const parse = (t, s) => { if (t.id === "3000") { const [m, x] = s.split(/[:.,]/).map(Number); return m * 60 + (x || 0); } return Number(s.replace(",", ".")); };

function CompareChart({ w, data }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {data.map((t) => {
        const me = t.hist[t.hist.length - 1][1], max = Math.max(me, t.avg) * 1.12;
        const better = t.lower ? me < t.avg : me > t.avg;
        const diff = t.lower ? ((t.avg - me) / t.avg) * 100 : ((me - t.avg) / t.avg) * 100;
        return (
          <div key={t.id} style={{ display: "grid", gridTemplateColumns: w < 600 ? "minmax(0,1fr)" : "180px minmax(0,1fr) 64px", gap: w < 600 ? 6 : 16, alignItems: "center" }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 8, minWidth: 0 }}><span style={{ font: "500 14px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{t.n}</span>{w < 600 && <Mono s={{ color: better ? "var(--ok)" : "var(--text-muted)" }}>{(diff >= 0 ? "+" : "−") + nf(Math.abs(diff), 0)} %</Mono>}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}>
              {[["Jonas", me, "var(--primary)"], ["WANG snitt", t.avg, "var(--sand-400)"]].map(([l, v, c]) => (
                <div key={l} style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 0 }}>
                  <div style={{ flex: 1, minWidth: 0, height: 14, background: "var(--surface-sunken)", position: "relative" }}><div style={{ position: "absolute", inset: 0, width: (v / max) * 100 + "%", background: c, transition: "width 700ms cubic-bezier(.2,.8,.2,1)" }}></div></div>
                  <Mono s={{ width: 64, flexShrink: 0, textAlign: "right", color: l === "Jonas" ? "var(--text-primary)" : "var(--text-muted)", fontSize: 12 }}>{fmt(t, v)} {t.u}</Mono>
                </div>
              ))}
            </div>
            {w >= 600 && <Mono s={{ textAlign: "right", color: better ? "var(--ok)" : "var(--text-muted)", fontWeight: 600 }}>{(diff >= 0 ? "+" : "−") + nf(Math.abs(diff), 0)} %</Mono>}
          </div>
        );
      })}
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", font: "var(--type-meta)", color: "var(--text-muted)" }}>
        <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}><span style={{ width: 14, height: 10, background: "var(--primary)" }}></span>JONAS BERG · 18.09</span>
        <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}><span style={{ width: 14, height: 10, background: "var(--sand-400)" }}></span>WANG LANDSSNITT · GUTTER 17</span>
        <span>3000 M: LAVERE TID ER BEDRE</span>
      </div>
    </div>
  );
}

function WangFysiskeTester() {
  const w = useW();
  const [tid, setTid] = React.useState("squat");
  const [data, setData] = React.useState(TESTS);
  const [val, setVal] = React.useState("");
  const [msg, setMsg] = React.useState(null);
  const t = data.find((x) => x.id === tid);
  const reg = () => { const v = parse(t, val); if (!v || isNaN(v)) { setMsg({ err: t.id === "3000" ? "Skriv tiden som mm:ss, for eksempel 11:30" : "Skriv et tall, for eksempel 107,5" }); return; } setData(data.map((x) => x.id === tid ? { ...x, hist: [...x.hist, ["25.09", v]] } : x)); setVal(""); setMsg({ ok: fmt(t, v) + " " + t.u + " registrert for Jonas Berg" }); };
  const best = t.lower ? Math.min(...t.hist.map((h) => h[1])) : Math.max(...t.hist.map((h) => h[1]));
  const hmax = Math.max(...t.hist.map((h) => h[1]), t.avg);
  return (
    <div style={pageWrap}>
      <PageHead kicker="WANG Toppidrett · Fysiske tester · Høst 2026" title="WANG standard testbatteri" sub="Fem tester, fire ganger i året. Resultatene sammenlignes med WANG landssnitt for aldersgruppen." actions={<div style={{ minWidth: 220 }}><Select aria-label="Spiller" options={["Jonas Berg · VG2", "Sofie Lund · VG3", "Mathias Eriksen · VG1"]} /></div>} />
      <Panel kicker="Jonas Berg · Gutter 17 · Test 18.09.2026" title="Sammenlignet med WANG landssnitt"><CompareChart w={w} data={data} /></Panel>
      <Grid min={380} gap={24} style={{ alignItems: "start" }}>
        <Panel kicker="Registrere" title="Nytt testresultat">
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{data.map((x) => <ChoicePill key={x.id} selected={x.id === tid} onClick={() => { setTid(x.id); setMsg(null); setVal(""); }}>{x.n}</ChoicePill>)}</div>
          <Input label={t.n} mono size="lg" inputMode="decimal" suffix={t.u} placeholder={t.id === "3000" ? "11:30" : "0"} value={val} onChange={(e) => { setVal(e.target.value); setMsg(null); }} error={msg && msg.err} hint={"Beste så langt: " + fmt(t, best) + " " + t.u} onKeyDown={(e) => e.key === "Enter" && reg()} />
          <div><Button onClick={reg} disabled={!val}>Registrer resultat</Button></div>
          {msg && msg.ok && <InlineAlert tone="ok">{msg.ok}</InlineAlert>}
        </Panel>
        <Panel kicker="Historikk" title={t.n}>
          <div style={{ display: "grid", gridTemplateColumns: `repeat(${t.hist.length},minmax(0,1fr))`, gap: 8, alignItems: "end", height: 160, borderBottom: "1px solid var(--border-strong)", position: "relative" }}>
            <div style={{ position: "absolute", left: 0, right: 0, bottom: (t.avg / hmax) * 150 + "px", borderTop: "1px dashed var(--graphite-400)" }}><Mono s={{ position: "absolute", right: 0, top: -18, fontSize: 11, color: "var(--text-muted)" }}>SNITT {fmt(t, t.avg)}</Mono></div>
            {t.hist.map(([d, v], i) => <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, minWidth: 0 }}><Mono s={{ fontSize: 11, color: "var(--text-primary)" }}>{fmt(t, v)}</Mono><div style={{ width: "100%", maxWidth: 48, height: (v / hmax) * 150 - 20, background: i === t.hist.length - 1 ? "var(--primary)" : "var(--graphite-400)" }}></div></div>)}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: `repeat(${t.hist.length},minmax(0,1fr))`, gap: 8 }}>{t.hist.map(([d], i) => <Mono key={i} s={{ fontSize: 11, color: "var(--text-muted)", textAlign: "center" }}>{d}</Mono>)}</div>
          {t.lower && <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>LAVERE TID ER BEDRE</span>}
        </Panel>
      </Grid>
    </div>
  );
}
window.WangFysiskeTester = WangFysiskeTester;
})();
