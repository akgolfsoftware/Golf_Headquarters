(() => {
const { Button, AxisBadge, ChoicePill, StatusPill, Avatar, InlineAlert } = window.AKGolfPrecisionAthletics_7d7c29;
const { Panel, PageHead, pageWrap, Mono, useW } = window.KIT;
const TYPES = { morgen: ["Morgentrening", "fys"], basis: ["Basistrening", "tek"], helg: ["Helgesamling", "spill"] };
const PLAN = [
  { d: "Mandag", dt: "21.09", s: [{ id: "man", k: "basis", t: "13:00–15:00", n: "Slag · Innspill 80–120 m", sted: "GFGK range" }] },
  { d: "Tirsdag", dt: "22.09", s: [{ id: "tir", k: "morgen", t: "07:15–08:30", n: "Styrke · Underkropp", sted: "WANG gymsal" }] },
  { d: "Onsdag", dt: "23.09", s: [{ id: "ons", k: "basis", t: "13:00–15:00", n: "Teknikk · Nærspill", sted: "AK Golf Studio" }] },
  { d: "Torsdag", dt: "24.09", s: [{ id: "tor", k: "morgen", t: "07:15–08:30", n: "Mobilitet og rotasjon", sted: "WANG gymsal" }] },
  { d: "Fredag", dt: "25.09", s: [{ id: "fre", k: "basis", t: "12:30–15:00", n: "Spill · 9 hull med oppgaver", sted: "GFGK bane" }] },
  { d: "Helg", dt: "26–27.09", s: [{ id: "helg", k: "helg", t: "10:00–15:00", n: "Samling · Banestrategi", sted: "Gamle Fredrikstad GK" }] },
];
const ALL = PLAN.flatMap((p) => p.s.map((s) => ({ ...s, d: p.d, dt: p.dt })));
const ROSTER = ["Jonas Berg", "Sofie Lund", "Mathias Eriksen", "Ida Haugen", "Oliver Nilsen", "Thea Johansen", "Henrik Dahl", "Maja Olsen"].map((n, i) => ({ n, kl: ["VG1", "VG2", "VG3"][i % 3] }));
const REASONS = ["Skade", "Turnering", "Eksamen", "Sykdom", "Annet"];

function Session({ s, on, onPick }) {
  const [label, ax] = TYPES[s.k];
  return (
    <button type="button" aria-pressed={on} onClick={onPick} style={{ textAlign: "left", width: "100%", background: on ? "var(--surface-sunken)" : "var(--surface-card)", border: "1px solid " + (on ? "var(--border-ink)" : "var(--border-hairline)"), borderRadius: 8, padding: 12, display: "flex", flexDirection: "column", gap: 6, cursor: "pointer", minWidth: 0 }}>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 6, font: "var(--type-kicker)", letterSpacing: "var(--tracking-kicker)", textTransform: "uppercase", color: "var(--axis-" + ax + "-fg)" }}><span style={{ width: 8, height: 8, borderRadius: 999, background: "var(--axis-" + ax + ")" }}></span>{label}</span>
      <Mono s={{ color: "var(--text-primary)" }}>{s.t}</Mono>
      <span style={{ font: "500 13px/1.35 var(--font-sans)", color: "var(--text-primary)", overflowWrap: "anywhere" }}>{s.n}</span>
      <span style={{ font: "400 12px/1.3 var(--font-sans)", color: "var(--text-muted)" }}>{s.sted}</span>
    </button>
  );
}

function WangUkeplan() {
  const w = useW();
  const cols = w > 1100 ? 6 : w >= 700 ? 3 : 1;
  const [sel, setSel] = React.useState("fre");
  const [abs, setAbs] = React.useState({ fre: { "Sofie Lund": "Turnering", "Henrik Dahl": "Eksamen" }, tir: { "Ida Haugen": "Skade" } });
  const [open, setOpen] = React.useState(null);
  const cur = abs[sel] || {};
  const s = ALL.find((x) => x.id === sel);
  const setReason = (n, r) => { const c = { ...cur }; if (r) c[n] = r; else delete c[n]; setAbs({ ...abs, [sel]: c }); setOpen(null); };
  const present = ROSTER.length - Object.keys(cur).length;
  return (
    <div style={pageWrap}>
      <PageHead kicker="WANG Toppidrett Fredrikstad · Golf · Uke 39" title="Ukeplan for skolelaget" sub="Morgentrening tirsdag og torsdag, basistrening i skoletiden og helgesamling. Velg en økt for å registrere fravær."
        actions={<div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{Object.values(TYPES).map(([l, ax]) => <AxisBadge key={l} axis={ax} dot>{l}</AxisBadge>)}</div>} />
      <div style={{ display: "grid", gridTemplateColumns: `repeat(${cols},minmax(0,1fr))`, gap: cols === 1 ? 8 : 12 }}>
        {PLAN.map((p) => (
          <div key={p.d} style={{ display: cols === 1 ? "grid" : "flex", gridTemplateColumns: "72px minmax(0,1fr)", flexDirection: "column", gap: 8, minWidth: 0 }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 2, paddingTop: cols === 1 ? 12 : 0 }}><span style={{ font: "600 14px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{p.d}</span><Mono s={{ fontSize: 11, color: "var(--text-muted)" }}>{p.dt}</Mono></div>
            {p.s.map((x) => <Session key={x.id} s={x} on={x.id === sel} onPick={() => { setSel(x.id); setOpen(null); }} />)}
          </div>
        ))}
      </div>
      <Panel kicker={"Fraværsregistrering · " + s.d + " " + s.dt + " · " + s.t} title={s.n} action={<StatusPill tone={present === ROSTER.length ? "ok" : "neutral"}><span style={{ fontFamily: "var(--font-mono)" }}>{present} av {ROSTER.length}</span> til stede</StatusPill>}>
        <div style={{ display: "flex", flexDirection: "column" }}>
          {ROSTER.map((r, i) => { const why = cur[r.n], isOpen = open === r.n; return (
            <div key={r.n} style={{ borderTop: i ? "1px solid var(--border-hairline)" : "none", padding: "8px 0", display: "flex", flexDirection: "column", gap: 8 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, minHeight: 44, flexWrap: "wrap" }}>
                <Avatar name={r.n} size={32} />
                <div style={{ flex: "1 1 140px", minWidth: 0, display: "flex", flexDirection: "column", gap: 2 }}><span style={{ font: "500 14px/1.2 var(--font-sans)", color: "var(--text-primary)" }}>{r.n}</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{r.kl}</span></div>
                {why ? <StatusPill tone="warn" dot>{"Fravær · " + why}</StatusPill> : <StatusPill tone="ok" dot>Til stede</StatusPill>}
                <Button variant="ghost" size="sm" onClick={() => setOpen(isOpen ? null : r.n)}>{why ? "Endre" : "Registrer fravær"}</Button>
              </div>
              {isOpen && <div style={{ display: "flex", gap: 8, flexWrap: "wrap", paddingLeft: w < 600 ? 0 : 44 }}>
                {REASONS.map((x) => <ChoicePill key={x} selected={why === x} onClick={() => setReason(r.n, x)}>{x}</ChoicePill>)}
                {why && <ChoicePill onClick={() => setReason(r.n, null)}>Til stede likevel</ChoicePill>}
              </div>}
            </div>); })}
        </div>
        {Object.values(cur).includes("Skade") && <InlineAlert tone="warn" title="Skade registrert">Fysioterapeut på WANG får beskjed. Spilleren får tilpasset plan i PlayerHQ.</InlineAlert>}
      </Panel>
    </div>
  );
}
window.WangUkeplan = WangUkeplan;
})();
