# Training Motor → Precision · funksjonsoverføring 30.09.2026 (sluttversjon runde 37)

Kilde: prosjektet «AK Golf Training Motor» (skrivebeskyttet herfra). Aktive kilder per AK Arbeidsdokument.dc.html: `AK Treningsmotor.dc.html`, `Teknisk Plan v2.dc.html`, `Spilleranalyse v2.dc.html`, `Teknisk Progresjon.dc.html`. Kopier i `_kilde/` (Treningsmotor2.html og TekniskPlan.html er beholdt som historikk). Status: **tegnet og simulert i Precision. Ikke godkjent av Anders. Ingen appkode, database eller deploy.**

## Overføringstabell
| Funksjon | Precision (skjerm / fil) | Status |
|---|---|---|
| Teknisk plan v2: uketyper, prioritet, «Ikke med», mellomposisjoner P1.1–P9.9, slagvalg 3×3, før/etter (bilde og video) | AG-10, AG-TP-01, AG-TP-02, PH-TP-01 · `tp-v2.jsx`, `data-tp2.js` | Overført, testet (to kjøringer) |
| Teknisk progresjon: repmål, læringssteg, treffprotokoll, kvalitetssjekk | `tp-parts.jsx` (RepBars, HitGrid, TargetWindow) | Overført som veiledende; «bestått før neste steg» ikke videreført som sperre |
| Årsplan, periodisering, måned, uke, økt | AG-11-AR/PER/MND, Uke, Økt · PH-11 (`WB3.jsx`, `WB3-ar.jsx`) | Fantes fra før |
| Akkumulert volum planlagt mot gjennomført, ukebudsjett og fordeling | Workbench › Volum (AG-11-VOL, PH-11-VOL) · `WB3-vol.jsx` | Overført. Årsmål er «ikke satt» |
| Belastning (sRPE) | Workbench › Volum | Overført. ACWR vises som «—» uten fire ukers registrering |
| Analyse → tiltaksutkast → Workbench → publisering (coach bekrefter) | Workbench › Volum · «Analyse → tiltak» | Overført |
| **Øvelsesdesign (Systemkart, åtte trinn)** | Workbench Økt › «Egen øvelse i …» (`WB3.jsx`): pyramide, område, sted/miljø, måleutstyr, gjennomføring (motorikk, treningsmåte, teknisk fokus per område), press, mengde, mål, med AK-formel | **Overført**, testet (fokusvalg følger området, øvelsen legges i økta) |
| **Testsignal over tid** | Stats › Tester: siste, snitt, progresjon (Sparkline over daterte resultater), nivå A–K (`stats-deler.jsx`) | **Dekket** av eksisterende Stats; motorens «eksempel-signal» er ikke en diagnose og overføres ikke |
| **Testens egen protokoll** | PH-15 Gjennomfør test (`data-test.js`), kvalitetssjekk og treffprotokoll i teknisk plan | **Dekket**, kan brukes fra Stats › Tester og teknisk plan |
| **Spilleranalyse v2** | PH-16 Stats, AG-08 › Stats, Workbench › Volum | **Sammenlignet funksjon for funksjon**: se `spilleranalyse-v2-funksjonsregister-2026-09-30.md` (neste kategori beholdt) |
| Resultatkontekst (fire faktorer) og helseflyt | — | **Avgrenset eksisterende funksjonsområde**: beskyttet helseflyt, ikke med i prototypen, ingen persondata eller helse-/risikopåstander. Kildens hardkodede eksempel er ikke overført |
| Systemkart og AK-formelen | `oversikter/` (OV-01, OV-02) | Overført som faglig underlag (illustrasjon) |
| Masterutforsker | `arkiv/2026-09-30/oversikter/` | Arkivert |

## Ikke overført med vilje (ikke fastsatte produktregler)
CANON-normer og kategori-bånd, SG-baseline kategori A, ACWR-grenser (0,8–1,3), ukeøkning (+15 %), årsmål (1 250 t), tiltakstall (4 timer, 15 minutter) og demoens datoer.

## Training Motor
Prosjektet er skrivebeskyttet herfra. Codex markerer det historisk (lenke til Precision) etter kontrollert overføring; det er **ingen ekstra godkjenningsport** fra Anders før arkivering. Forslag til tekst der: «Historisk funksjonsunderlag. Aktiv versjon: AK Golf Precision Athletics (Workbench, Teknisk plan, Stats). Se overlevering/training-motor-overforing-2026-09-30.md». Bilder og personnavn fra kilden er ikke brukt.

## Kodegap
Se `knapp-skjerm-kart-2026-09-30.md` (kodegap) og `teknisk-plan-v2-2026-09-30.md`.
