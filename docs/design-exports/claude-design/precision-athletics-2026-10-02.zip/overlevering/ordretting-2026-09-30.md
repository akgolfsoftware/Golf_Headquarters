# Ordretting 30.09.2026

Fasit: guidelines/treningsplanlegging-master.md.

## Bolk 1 — Fasitfilene
Status: **Ferdig**

Filer endret: 7 (guidelines/ordmaster.md, assets/ak-vocabulary.js, guidelines/vocabulary.html, readme.md, SKILL.md, ui_kits/_shared/data-fas.js (følgefeil: matcher områdenavn), oversikt over tvil under).

Bytter:
- ordmaster.md skrevet om som kort speil; øverst: «Avledet av guidelines/treningsplanlegging-master.md. Ved avvik gjelder masteren»
- Innspill-områder ca. → 200 m og lengre / 150–200 m / 100–150 m / 50–100 m: 4 (vocab) + 4 (data-fas.js)
- Teknisk fokus: egne lister for 4 Innspill-bånd, Chip, Pitch, Lob (14.3); dimsFor oppdatert
- AXES SPILL «Banespill» → Spill: 1
- Treningsmiljø-verdier (BELASTNING): Innendørs → Innendørs golf, Treningsområde → Utendørs treningsområde, Bane → Golfbane, Konkurranse fjernet: 4
- TIERS TALENT/FULL → Gratis / Full: 2
- FORBUDT utvidet til hele byttelista
- vocabulary.html: Goal→Målsetning, Pro→Gratis · Full, Motorikk/Belastning/Hjem/Spesialisering lagt til: 8
- readme.md: fasit-henvisning, Gratis/Full, Venter på coach, Læringssteg/Treningsmiljø, «elever» fjernet: 12
- SKILL.md: fasit-henvisning: 1
- Nøkler og funksjonsnavn i ak-vocabulary.js er uendret.

## Tvilliste
- ui_kits/agencyos/OktBygger.jsx, ExerciseComposer.jsx, ui_kits/_shared/data-wb3.js: bruker gamle miljøverdier («Innendørs», «Treningsområde», «Bane», «Konkurranse») som valgt-tilstand mot AK_VOCAB.BELASTNING. Ny liste gir ingen forhåndsvalgt pill til de rettes. Tas i bolk 4 / 5.
- ui_kits/_shared/data-tp.js: AREAS og areaCode henter tall fra «Innspill ca. N m» (regex \D). Må rettes sammen med områdenavnene i bolk 5 (ikke bare tekst).
- ExerciseComposer.jsx bruker V.DIMENSIONS.innspill (beholdt som samlet liste); bør bytte til dimsFor i bolk 4.
- Kommentarer med «ordmasteren» i data-tp.js, components/plan/SwingTimeline.d.ts, overlevering/*: kodekommentarer røres ikke; overlevering/ tas i bolk 6.

## Bolk 2 — components/
Status: **Ferdig**

Filer endret: 9. Merk: TabBar i navigation.card.html bruker standardfanene fra TabBar.jsx via _ds_bundle.js (generert); «Stats» vises når pakken er ombygd ved slutten av økta. Bytter: Analyse → Stats 3 (TabBar.jsx, interaction.card.html, navigation.card.html «Stats & Banekart») + NavRail.d.ts 1 · Hjem → Cockpit 2 (navigation.card.html, NavRail.prompt.md) · Mål → Målsetning 3 (InsightCard, PeriodSelector, navigation.card.html) · Innspill ca. → 100–150 m / 50–100 m 3 (TopBar.prompt.md, navigation.card.html, data-display.card.html) · FULL → Full 1.

Tvilliste:
- components/interaction/MoveSheet.jsx:9 aria-label="Mål" — «mål» som destinasjon for flytting, ikke målsetning. Urørt.
- components/analysis/analysis.card.html:1–2 «Analyse» som kortnavn for komponentgruppen (ikke fane/meny). Urørt.
- components/display/display.card.html:16 Metric «Mål ±4 m» og data-display.card.html «MÅL-LINJE» — måltall, lovlig unntak.
- components/display/Timeline.prompt.md, InlineAlert.prompt.md, plan.card.html «Belastning · ACWR» — belastning om intensitet, lovlig.
- Kode: RepBars `goal`, TrendChart `goal`, ConflictSheet kind `belastning` er tekniske navn, urørt.
- components/plan/plan.card.html:31 «Full fart, range og bane» — «full» som adjektiv, ikke appnivå.

## Bolk 3 — ui_kits/playerhq/
Status: **Ferdig** (tekstkontroll gjort; måling av scrollWidth utført av verifiserer)

Filer endret: 24. Bytter (antall):
- Innspill ca. → nye bånd: 31 (data.js 16, data-analyse.js 4, data-meg.js 3, data-live.js 2, PH-12 2, PH-15 2, stats-data.js 1, PH-06 1)
- Drill/driller → Øvelse/øvelser: 16 (PH-live.jsx) + 2 (toast, PER ØVELSE)
- Ferdig som status → Gjennomført: 6 (PH-live.jsx ×3, PH-RD-2 ×2, PH-RD-live ×2); «Ferdig» som knapp beholdt (handlingsord 4.1)
- Logge/føre → Registrere/Registrer: 15 (PH-26b 12 hvorav visning, stats-deler 1, PH-RD-1 2)
- Mål → Målsetning: 15 (PH-12 9, PH-03, PH-04, PH-16, data-analyse, stats-data)
- Analyse → Stats: 3 (PH-17 knapp, PH-26, PH-24d)
- Belastning (sted) → Treningsmiljø: 2 etiketter (PH-03, PH-13) + 13 verdier i data.js (Innendørs golf · Utendørs treningsområde · Golfbane)
- Motorikk → Læringssteg: 2 (PH-13, stats-data)
- TALENT/FULL → Gratis/Full: 20 (PH-25 16, PH-24 2, data-meg.js 4)
- Trener → Coach: 9 (PH-27 6, PH-24 2, stats-deler 3 «trenerført/egenført» → coach-/egenregistrert; stats-data «Egenført» → «Egenregistrert» 5)
- Elev → Spiller: 1 (PH-27)
- Teknikk → Teknisk (aksefaktor): 1 (stats-data.js)

Tvilliste:
- screens/PH-13.jsx:10 «Mål» (øvelsens resultatkrav, f.eks. «7 av 10 innenfor 4 m»): resultatkrav/måltall. Urørt.
- screens/PH-19.jsx:11, PH-27.jsx:92, PH-A1.jsx:78, PH-15.jsx:35, PH-07.jsx:24, PH-11.jsx:117 «MÅL …» foran et tall: måltall. Urørt.
- screens/PH-27.jsx:97 «OMRÅDER FERDIG»: teller fullførte spørreområder; ikke statusordet. Urørt.
- screens/PH-TP.jsx:7 env «Treningsområde» og data-tp.js: kommer fra _shared/data-tp.js (bolk 5).
- «ØKTLOGG» i kildelinjer (data-analyse.js, stats-data.js, data.js): navnet på en datakilde, ikke verbet «logge». Urørt.
- Rutestrenger «/portal/analysere», «/portal/runde/logg», «/portal/drills», tab-id «analyse», nøkler drills/sessions/goal/belastning: tekniske navn.
- «Analysen kunne ikke hentes», «analyse og runderegistrering» (funksjonsliste): analyse som substantiv i løpende tekst, ikke fane. Urørt.
- «Mal» (mal/mal-kort i PH-12): norsk «mal», ikke «mål».

## Bolk 4 — ui_kits/agencyos/
Status: **Pågår** (verifisering av scrollWidth 390/1280 kjøres; «RUNDELOGG» → «RUNDEREGISTRERING» rettet i AG-07-NY)

Filer endret: 38. Bytter (antall):
- Innspill ca. → nye bånd: 50 (AG-14 13, data-admin 13, OktBygger 5, planmotor-data 5, data-ag 5, data-ag3 4, øvrige 5)
- Hjem → Cockpit: 8 (AG-01 ×3, AG-02, index.html ×3 inkl. undertittel, planmotor.html, README)
- Ferdig som status → Gjennomført: 8 (AG-cockpit ×5, data-cockpit, AG-21 ×2). Knappene «Ferdig» i AG-innboks og «Ferdig med prioritet» i AG-02 beholdt (handlingsord)
- Drill → Øvelse: 1 (AG-stall); «Drill» i drillvelger.html (filnavn) urørt
- Logge/føre → registrere: 6 (AG-08 ×2, AG-WB-FYS, data-inbox ×2, AG-08)
- Mål → Målsetning: 8 (AG-WB-FYS ×4, AG-WB-TURN ×2, AG-cockpit, AG-A1, data-stall)
- Motorikk → Læringssteg: 3 (AG-14, ExerciseComposer ×2 via label)
- Belastning (sted) → Treningsmiljø: 5 etiketter (AG-14, ExerciseComposer, OktBygger, AG-TP) + verdier: Innendørs golf · Utendørs treningsområde · Golfbane (data-ag3 5, data-admin 1, defaults i AG-14/ExerciseComposer/OktBygger). Konkurranse fjernet fra miljølista i AG-14. Formelkoden bevarer INNENDØRS/TRENINGSOMRÅDE/BANE via mapping.
- Pro/TALENT/FULL → Gratis/Full: 8 (AG-07-NY 2, AG-23 1, AG-08 1, Kalender 1, data-ag4 1) + visning av tier i AG-08 og Kalender via mapping (datakodene FULL/TALENT urørt)
- Trener → Coach: 12 (AG-23 9 «Ekstern coach», data-ag4 1)
- Teknikk → Teknisk: 2 (AG-16b, drillvelger.html); Spesialisering → Spesialperiode: 3 (AG-16b, Caddie ×2)
- Kode som fulgte: ExerciseComposer/OktBygger/AG-14 hentet områdenavn via siffer og includes(); rettet til nye båndnavn (spread, carry, kode INNSPILL100 osv.), AG-14 bruker AK_VOCAB.dimsFor for teknisk fokus.

Tvilliste:
- AG-24-drift.jsx / AG-mer.jsx «Logger» (systemlogger/audit-logg, substantiv): ikke verbet «logge». Urørt.
- AG-09.jsx «Stall-analyse» / «Spilleranalyse» (utgår 28.09 → Stats): faner på en utgående skjerm. Urørt.
- AG-A1 / AG-A2 «Analyse» i kicker og steg («1 · Analyse»): arbeidsflyt, ikke fane. Urørt.
- AG-stall.jsx «Trener nå» og Cockpit.jsx «Trener i dag»: verbet «trene» (spillere som trener nå). Urørt.
- data-admin.js/data-ag.js «Trenerkurs NGF»: eget navn på kurs. Urørt.
- AG-14.jsx:24 og andre «MÅL …» foran tall/resultatkrav: måltall. Urørt.
- «Talent U16» (gruppenavn) og «Innsikt og talent» (AG-22): gruppe/talentprogram, ikke appnivå. Urørt.
- ExerciseComposer «Tiger 5 analyse»: navn på spilleformat. Urørt.
- data-tp.js (_shared) matcher fortsatt gamle områdenavn via siffer; bolk 5.

## Bolk 5 — resten av ui_kits/ (booking, epost, forelder, gfgk, konto, statistikk, system, _shared, katalog.js)
Status: **Pågår** (verifisering av scrollWidth 390/1280 kjøres)

Filer endret: 28. Bytter (antall):
- Innspill ca. → nye bånd: 11 (data-tp.js 5, data-test.js 2, data-fo.js 2, WB3.jsx, data-iup.js) + kode: areaCode i data-tp.js henter nå første tall (INNSPILL100 osv.), fasiliteter.jsx viser navnet uendret
- Treningsmiljø-verdier (ENV, data-tp.js): Innendørs golf · Utendørs treningsområde · Golfbane, 29 forekomster; Konkurranse-rader fjernet fra miljøfordelingen (flyttet til Press); formelkode bevarer INNENDØRS/TRENINGSOMRÅDE/BANE; data-wb3.js belastning-lista samme; PH-TP.jsx standardmiljø og etikett «Treningsmiljø»
- Trener → Coach: 15 (booking 7, forelder 10 hvorav Dialog/Samtykke/data-fo, konto 5, GJ 1, data-iup 1, data-pub 1)
- TALENT/FULL → Gratis/Full (synlig): 21 (FO-04-06 10, AU-01-03 5 + visning av planvalg)
- Teknikk → Teknisk: 3 (ForelderHjem, BookingFlow «Teknisk trening»)
- Hjem → Cockpit: 1 (AU-04-06)
- Mål → Målsetning: 6 (AU-04-06 steg, SpillerProfil, WB3-ar ×2)
- Motorikk → Læringssteg / Belastning → Treningsmiljø: 2 (WB3.jsx)
- Logge/føre → registrere: 8 (FO-04-06, AU-04-06, SY-01, data-rd.js «Live-registrering» ×4, data-iup «Registrer dagsform»)
- Ferdig som status → Gjennomført: 2 (ST-04-06, katalog.js «Runde gjennomført»)
- Elev → Spiller: 1 (data-iup «WANG-SPILLER»)

Tvilliste:
- ui_kits/toppidrett/ (kildemateriale, ikke egen app): ikke rørt. Inneholder Innspill ca., Analyse, Mål, TALENT/FULL.
- ui_kits/marked/Forside.jsx og forelder/ForelderOkonomi.jsx: «TALENT/FULL» er treningskontingent (1 490 / 2 890 kr), ikke appnivå. Urørt. Markedssidene venter.
- forelder/ForelderShell.jsx og ForelderHjem.jsx «hjem»: forelderportal, ikke AgencyOS. Urørt.
- _shared/WB3.jsx:161 etikett «Mål» på målets måltall/verdifelt. Urørt (måltall).
- _shared/data-iup.js:34 og andre setninger fra spørreskjemaet (college-trenerne, «Pro tour»): kildetekst. Urørt.
- _shared/ia.js «Mål og dagens økt», «AG-08-TALENT», «Talent»-faner: kart over utgåtte navn / talentprogram. Urørt (bolk 6 rydder oversikten).
- ui_kits/audit.html, audit-tp.html «ferdig · N tilfeller»: revisjonsverktøy, ikke produkt-UI. Urørt.
- konto/Innlogging, AU-01-03 «Logg inn/ut»: beholdt (master 4.1).
- _shared/data-trening.js, data-wb.js: «belastning» om ACWR/intensitet — lovlig.

## Bolk 6 — oversikt.html, oversikter/, skjermliste.md, overlevering/
Status: **Pågår** (måling av scrollWidth 390/1280 gjenstår for oversikter/)

Filer endret: 10. Bytter (antall):
- Motorikk → Læringssteg / Belastning (sted) → Treningsmiljø: 12 i visning (AK-formelen.dc.html: etiketter, ValgPiller, BEL-lista; Systemkart.dc.html: overskrifter og formelleddtekster); i beskrivende AK-formel-lister «motorikk, belastning, press» → «læringssteg, treningsmiljø, press» (skjermliste 2, oversikt 0, codex 4, index 4)
- Konkurranse som miljø flyttet til Press: fjernet fra BEL i AK-formelen.dc.html; TURN får miljø Golfbane (standard) og press Turnering
- Innspill-bånd i diagrammer: 8 (AK-formelen 4, Systemkart 4)
- Drill → Øvelse: 6 (oversikt 4, skjermliste 4)
- Analyse → Stats: codex/index 4 (fane, PH-16-overskrift, «Produktregelen sier Stats er») + 2 i teknisk-plan; Hjem → Cockpit: 4
- TALENT/FULL (appnivå) → Gratis/Full: codex 6, index 6, skjermliste 1; oppgraderingsregelen i codex §Ukjent omskrevet til «Vis alltid Gratis/Full, aldri PRO/ELITE/TALENT»
- Elev → Spiller: 5; trenerført/Egenført → coachregistrert/Egenregistrert: 1
- Ferdig som status → Gjennomført (Runde): 5
- Mål → Målsetning: PH-19-overskrift 2, Masterutforsker 1
- Kartleggingsøkt: fjernet helt (codex punkt 13 med omnummerering, index-liste)
- logg → registrer: 2

Tvilliste:
- Rutestrenger /portal/drills, /portal/analysere, /portal/mal/goal, /admin/analyse og kodenavn (motorikk, belastning, sessionId, goal, loggedAt): tekniske navn. Urørt.
- «Belastning 1–10» / ACWR / belastningstak: intensitet. Lovlig.
- oversikter/Systemkart.dc.html «8 Mål» (trinn 8) og Masterutforsker «mål» foran tall: masteren kap. 17 bruker «Mål» som trinnnavn / måltall. Urørt.
- codex/index: «Logger» (AG-24), «Trener nå» (verb), «Performance Pro»: lovlige.
- Eldre 27.09-dokumenter i overlevering/ (better-ui-polish, test-til-okt, workbench-fys-turnering) har «rep-mål», «mål» foran tall og «Analyse» som overskrift over gamle komponenter. Historiske, urørt.
- ui_kits/toppidrett/ og ui_kits/marked/ er ikke rørt (se bolk 5).
