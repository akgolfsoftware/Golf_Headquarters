# Historisk Grok-overlevering

Dette dokumentet er arkivert og skal ikke brukes som implementeringsordre.

- **Codex eier all koding og teknisk implementering.**
- Claude Design er visuell designkilde og klikkbar prototype.
- Gjeldende spesifikasjon: `overlevering/codex.md`.
- Originalen er bevart i `arkiv/2026-10-01-codex-overgang/overlevering/grok-inngang-2026-09-30.md`.
