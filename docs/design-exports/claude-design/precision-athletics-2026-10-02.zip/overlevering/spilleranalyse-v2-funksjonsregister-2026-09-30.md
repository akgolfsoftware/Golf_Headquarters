# Spilleranalyse v2 → Precision · funksjonsregister 30.09.2026

Kilde: `Spilleranalyse v2.dc.html` (Training Motor, aktiv per Arbeidsdokument), kopiert i `_kilde/Spilleranalyse2.html`. Sammenlignet funksjon for funksjon, ikke linje for linje. **Precision bruker neste kategori som standard sammenligning (Anders 28.09); SG mot kategori A i kilden er ikke overført og byttes ikke.** Status: tegnet og simulert i prototypen, ikke godkjent av Anders.

| # | Kildefunksjon | Status | Grunn | Aktiv målskjerm |
|---|---|---|---|---|
| 1 | Spillerhode: kategori og «mangler X slag per runde til kategori A» med fremdrift mot opprykk | **Erstattet** | Precision viser «X slag til neste kategori» og kategori A–K uten kategori-bånd | PH-16 Stats › Snittscore (`stats-snitt.jsx` Kategori) · AG-08 › Stats |
| 2 | Periodevalg: siste 5 runder / siste 20 / sesong | **Bevart** | Filterlinje i Stats (periode og sammenligning) | PH-16 Stats (Q_FilterBar) |
| 3 | SG-gap per kategori (Total, OTT, APP, ARG, PUTT) med fortegn og søyler rundt null | **Bevart** | SG-stolper med fortegn i tallet; referanse er neste kategori (estimat) eller PGA Tour | PH-16 Stats › Strokes Gained · komponent `SignedBars` (components/plan) |
| 4 | Andel av totalgapet per område og etikett «styrke / hovedsvakhet / moderat gap» | **Erstattet** | Precision sorterer etter flest tapte slag og trend (Q_Top: positiv trend først, deretter tapte slag) uten egne tersklede etiketter | PH-16 Stats (toppfelt trend + tapte slag) |
| 5 | Drilldown APP (50–100, 100–150, 150–200 m) og PUTT (0–3, 3–5, 5–10, 10–25 fot, meter i parentes) med «størst gap» | **Bevart** | Skill-map per område med avstandsbånd; putting i fot | PH-16b Skill map (andre chats fil, ikke rørt) · PH-16 Stats › SG |
| 6 | Konklusjonssetning om størst gap | **Erstattet** | Toppfeltet «flest tapte slag» og tiltaksutkastet bærer samme innhold | PH-16 Stats · AG-11-VOL «Analyse → tiltak» |
| 7 | SG-svakhet koblet mot TrackMan-data (årsak i teknikken) | **Bevart** | TrackMan per kølle og SG i samme Stats, med kilde og dato; koblingen fortolkes av coach, ikke automatisk | PH-17/PH-16 Stats › Trening · AG-TP-01 målbokser |
| 8 | Tiger 5 per runde med mål og «Mål nådd / Over mål» | **Delvis bevart, terskler utgående** | Tiger 5 vises som antall per runde/sesong. Demoens målverdier (0, under 0,5, under 2,0) er ikke fastsatte produktregler og er ikke overført | PH-16 Stats › Snittscore (Tiger) |
| 9 | Treningsvolum siste 30 dager mot CANON-norm for kategori | **Uttrykkelig utgående** | Ingen CANON-normer eller kategori-bånd på skjerm (regel). Volum vises som planlagt mot gjennomført | AG-11-VOL / PH-11-VOL Workbench › Volum |
| 10 | ACWR 1,15 i sone 0,8–1,3 «lav skaderisiko» | **Uttrykkelig utgående** | ACWR-grenser og skaderisikopåstander er ikke fastsatte produktregler. ACWR vises som «—» uten fire ukers registrering, uten terskel | AG-11-VOL / PH-11-VOL |
| 11 | MasterBrain: tre foreslåtte tiltak, coach velger, coach godkjenner før publisering | **Bevart** | Analyse → utkast → Workbench → bekreft og publiser. Ingen automatisk utsending | AG-11-VOL «Analyse → tiltak» |
| 12 | «Opprett tiltaksplan i AgencyOS» | **Bevart** | «Legg i Workbench (uke 40)» åpner utkast i Workbench Økt | AG-11-VOL → AG-11-OKT |
| 13 | Tilbakevei fra drilldown til oversikt | **Bevart** | Filter/tilstand ligger i Stats-delene; Tilbake via skallet | PH-16 Stats |
| 14 | Rå score (snitt per periode) | **Bevart** | Snittscore og runder med scorekort | PH-16 Stats › Snittscore/Runder |

## Testsignal og testspesifikke protokoller
- **Testsignal over tid:** Stats › Tester viser siste resultat, snitt, progresjon (Sparkline over daterte resultater) og nivå A–K per test. Bruk: `stats-deler.jsx` (Tester) → PH-14-innhold; åpnes fra Stats.
- **Testens egen protokoll:** «Gjennomfør test» åpner PH-15 (`data-test.js`, egen protokoll per test, natt). Treffprotokoll og kvalitetssjekk i teknisk plan (`HitGrid`, `QCSheet`) er en egen protokoll og sperrer ikke neste steg.
- Ikke overført fra motoren: «Testsignal over tid · eksempel» som diagnose. Kilden sier selv at signalet ikke er en diagnose.

## Ikke gjort
Ingen ny visning er bygget for punkt 4 og 8 (tersklede etiketter og mål-nådd): de ville krevd nye produktregler. Punkt 5 ligger i en fil andre chats arbeider med.
