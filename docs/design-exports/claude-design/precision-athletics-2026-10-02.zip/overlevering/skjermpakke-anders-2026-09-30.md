# Skjermpakke til Anders · 30.09.2026 (runde 37)

Status: **tegnet og simulert i prototypen. Ingen visuell godkjenning er gitt eller antydet.** En aktiv ID per skjerm; den valgte kandidatversjonen er den som ligger i vertsfilen (`ui_kits/playerhq/screen.html`, `ui_kits/agencyos/screen.html`). Åpne skjermene via `oversikt.html` (katalog) eller `?id=<ID>&state=data|tom|laster|feil`. Bredder: 390 og 1280 er målt på reisenes skjermer uten avvik. 320, 360, 768 og 1440 er målt på alle aktive skjermer: 83 åpne avvik (mest treffmål under 400 px), se `overlevering/audit-alle-2026-09-30.md`. 1024 er ikke målt denne runden. Natt gjelder Live/uteflater (PH-04–PH-08, PH-15, PH-RD-live) og valgfri AG-13; AgencyOS natt er informativt, ikke godkjent.

Skjermnavn for PH-01: den gamle godkjente referansen (390 / lyst / Data / dialogen «Endring i dagens plan» åpen) er bevart som historisk valgt bilde. Tekstfargene er forbedret i tokens (kontrast), så dagens PH-01 er en **ny variant til gjennomgang**, ikke den godkjente.

## Reise 1 · Spiller: I dag → Plan → økt → Live → oppsummering
| Steg | ID | Brukeroppgave | Inn | Ut | Tilstander |
|---|---|---|---|---|---|
| 1 | PH-01 | Se dagens økter, trykk Start | – | Start golf → PH-04; Start fysisk → PH-06 (sessionId, kind bæres videre) | data · tom · laster · feil |
| 2 | PH-10 | Se plan (År/Måned/Uke/Dag), kort «Teknisk plan» | fane Plan | PH-TP-01 (kort), PH-11, PH-12 | data · tom · laster · feil |
| 3 | PH-12 | Velg standardplan A–K, send til coach | PH-10 | venter på coach | data · tom · laster · feil · sendt |
| 4 | PH-03 | Øktark | PH-01/PH-10 | PH-04 | data · tom |
| 5 | PH-04 → PH-05 | Før start, aktiv økt (golf) | Start | PH-07 | data · tom · laster · feil · avslutt-dialog |
| 6 | PH-06 | Fysisk økt | Start (fysisk) | PH-07-FYS | data · tom · laster · feil |
| 7 | PH-07 / PH-07-FYS | Oppsummering: tid, reps/serier, status «Gjennomført/Delvis», Lagre skilt fra gjennomføring | PH-05/PH-06 | PH-01 | data · tom · laster · feil · lagret |

## Reise 2 · Coach: Stats → teknisk plan → Workbench → publisering
| Steg | ID | Brukeroppgave | Inn | Ut | Tilstander |
|---|---|---|---|---|---|
| 1 | AG-08 | Spiller 360 › Stats | Stall | AG-10 | data · tom · laster · feil |
| 2 | AG-10 | Teknisk plan: posisjoner P1.0–P10.0 + mellomposisjoner, uketyper med prioritet og «Ikke med», Legg i økt | AG-08 | AG-TP-01, AG-TP-02, AG-11-OKT (taskId) | data · tom · laster · feil |
| 3 | AG-TP-01 | Oppgaveskjema: fokus (historikk bevares), høyde 3×3, skru, uketyper, før/etter, lagre og publiser revisjon | AG-10 | AG-10 | data · tom(ny) · laster · feil · lagret · publisert |
| 4 | AG-TP-02 | Før og etter (bilde/video, last opp, erstatt, fjern, bytt, sammenlign) | AG-10 | AG-10 | data · tom · laster · feil |
| 5 | AG-11-OKT | Workbench Økt: utkast fra teknisk plan, egen øvelse (8 trinn), publiser | AG-10 | – | data · tom · laster · feil |
| 6 | AG-11-VOL | Volum, fordeling, sRPE og analyse → tiltak → utkast → Workbench → publiser | AG-11 | – | data · tom · laster · feil |
| 7 | PH-TP-01 (spiller) | Ser publisert innhold (siste publiserte revisjon), uketype/prioritet, medier, registrering | publisering | – | data · tom · utkast · laster · feil |

## Åpne valg (ikke en del av ferdige reiser)
PH-26/PH-26B (utgående, uavklart) · PH-27 · markedsprofil · Team Norway/WANG-profiler · synlig navn Stats/Analyse er avgjort (behold /portal/analysere; navn endres ved implementering) · Fokus 1–10 i PH-07: foreslått som valgfritt eget felt (kandidat, ikke besluttet; appen har ikke feltet) · årsmål, ACWR-grenser, ukeøkning (ikke fastsatt).

## Knappkart og bevis
- Hver trykkbar kontroll med mål: `overlevering/knapp-skjerm-kart-2026-09-30.json` / `.md` / `ui_kits/knappkart.html` (846 aktive i faktisk lastrekkefølge, alle med utledet mål; 30 inaktive, 6 utgående, 11 utenfor leveransen).
- Funksjonstester: `ui_kits/reisetest.html`, `ui_kits/reisetest-tp.html`. Layout/kontrast/ID/klar-signal: `ui_kits/audit-tp.html`. Åpne uten query.
- Overleveringer: `overlevering/teknisk-plan-v2-2026-09-30.md`, `training-motor-overforing-2026-09-30.md`, `grok-inngang-2026-09-30.md`. Arkiv: `arkiv/2026-09-30/index.html` og `register.md`.
- Ikke gjort av Claude: visuell godkjenning, ekte appkontroll, eksport/kontrollsum (Codex).
