# Overleveringskontrakt til WANG/Team Norway-trenerdesign (utkast, 01.10.2026)

Ikke bygget i dette prosjektet: ingen trenerprofiler for WANG/TN. Codex eier kode. Ingen reell tilgangsendring; dette er flyt og datakrav.

- Spilleren eier én profil, historikk og utviklingsplan i PlayerHQ. Ingen separat TN-app, ingen dobbeltføring.
- Deling: Meg → Del tilgang → WANG eller Team Norway (uavhengig) → verifisert trener → nøyaktig innhold → godkjenning (foresatt under 16) → aktiv → Stopp deling. Domene er filter, ikke bevis på rolle. Gruppemedlemskap gir ikke innsyn. Nye datakategorier krever nytt uttrykkelig samtykke. Invitasjon 7 dager ≠ delings varighet.
- Trener kan lese det delte og foreslå; spiller bestemmer. Trukket deling: ingen beskyttede data i liste, detaljer, eksport eller gammel lenke. Skole/kompetansemål bare WANG.
- Treneroversikt trenger: status evaluering/prosessmål/tester, plan mot faktisk tid (tre atskilte tall: antall, planlagt, registrert), neste oppfølging.
- Samordning mellom tre prosjekter (profiler kopieres ikke hit): (1) Precision (dette) = spillerens produkt, PlayerHQ og felles data-/delingskontrakt; (2) Team Norway App delivery `bc3e41fc-0386-4624-9b14-27355b64e2f7` = TN-trenerkontekst; (3) WANG Golf UI prototype `6cfa623c-b2c7-494f-b1bd-9c254b02f335` (https://claude.ai/design/p/6cfa623c-b2c7-494f-b1bd-9c254b02f335) = ENESTE WANG-prosjekt for hele X01–X18: trenerhjem, elevliste, skolekontekst, planlegging, tester og deling. Ingen avhengighet til noe annet WANG-prosjekt; tidligere ansvarsdeling mot WANG Toppidrett Software er trukket tilbake (Anders' retting 01.10.2026). Sending er ikke utført herfra; kontrakten ligger her.
- Deling per organisasjon: tilstander ikke delt, venter foresatt, aktiv, begrenset, trukket, ingen tilgang. Stopp WANG stopper ikke TN. Helse kun med ny godkjenning. Trenerforslag atskilt fra spillerens svar; endret kilde gir konflikt.
- X11: eksakt tekst i kildemateriale/iup-2027-kilde-2026-10-01.json (versjon iup-2027-kilde-2026-10-01). Gamle svar beholder versjon. Wedge Gate 9 slag/Treff-Bom og standard fysisk batteri er ikke rørt.
- Åpent: scoring i X13/X15 er uavklart; trenerreise (liste → spiller → forslag → beslutning) er bare tegnet i enkel form i iup.html.
Se `ui_kits/iup-excel/iup.html` (fanen Dekning) for X01–X18.
