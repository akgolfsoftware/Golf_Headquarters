# Knapp- og skjermkart · 30.09.2026 (runde 37, sluttversjon)

Maskinlesbar kilde: `knapp-skjerm-kart-2026-09-30.json` (felt: id, vert, fil, linje, fra, rolle, tekst, måltype, mål, status, bevis, instanser, objekt, tilbake, retur, ulagret, feil_tilstand, gruppe, aktiv). Kontrollside: `ui_kits/knappkart.html`. Tidligere utkast (697 rader) er arkivert i `arkiv/2026-09-30/`.

**Generert fra faktisk aktiv lastrekkefølge** i `ui_kits/playerhq/screen.html` og `ui_kits/agencyos/screen.html`, per vert og komponentinstans (en delt komponent telles én gang per vert). Arkiverte og overstyrte filer inngår ikke som aktive.

## Tall (kandidater, ikke godkjent av Anders)
- **846 aktive kandidater** i faktisk lastrekkefølge per vert (PlayerHQ-vert 462, AgencyOS-vert 384). `godkjent_av_anders = 0`.
- **Konkrete mål: 836.** Generiske eller ukjente: 10.
- **Registerkontrollen FEILER** (441 delte komponent-rader mangler listet instans/hosting-skjerm per vert; ukjent 0, generisk 10). Ingen grønn status: raden må løses per instans før Grok kan bruke den uten å tolke.
- Hver rad har verbatim `handler`, `kilde_ref` (fil:linje#sha256) og `sha256`. Ugyldige fil/linje: 0.
- 11 rader tilhører PH-26/PH-26B, AG-15-NORMER, AG-16 eller PH-16b (andre chatter/uavklart); 6 er utgående; 30 er inaktive.

## Hva «utledet» betyr
Målet er lest fra prototypens kildekode, callsite hos forelder (per vert), og data. Det er **ikke kjørt** unntatt der `bevis` sier «test». 26 kontroller dekkes av `reisetest.html`/`reisetest-tp.html`. Ingen rad er kontrollert mot ekte app eller godkjent av Anders.

## Regler brukt
- Handling uten navigasjon står som «lokal tilstand …; ingen ny skjerm» og «retur ikke relevant».
- Avbryt/Lukk lukker overlegget uten å lagre; ulagrede endringer i arket forkastes.
- `ulagret`: kun filer som faktisk kaller `nav.setDirty(true)` har «Host ber om bekreftelse ved navigasjon». Andre filer sporer ingen ulagrede endringer.
- `feil_tilstand`: bare komponenter med `Gate` har laster/feil (state=laster|feil).
- Start og «Se økta» på I dag sender `sessionId` og `kind` (PHQ_SEL): Start golf → PH-04, Start fysisk → PH-06, Se økta → PH-03.
- Rettet i koden: PH-01 «Se økta» mangler ikke lenger objekt.
- Feil mål som ble funnet i forrige versjon er borte fordi filene er arkivert: `Cell` i PH-11.jsx (forelder ?→setWk), og PH-11.jsx-radene som sendte spilleren til AG-WB-FYS/AG-WB-TURN.

## Kodegap (Git 110b4ec8f, kontrollert separat, ikke implementert)
- Hovedrutene i appkoden er /portal, /portal/planlegge, /portal/analysere og /portal/meg. «Stats» heter Analyse i koden: behold /portal/analysere, endre synlig navn ved implementering (avgjort).
- /portal/live/{sessionId} fordeler til brief/active/tapper/summary etter status; ingen egen fysisk-rute. PH-06 er en fysisk visningsvariant i eksisterende Live-modell.
- AG-10 «Legg i økt» åpner i appen /admin/workbench/{playerId} uten taskId. Mulig koblingspunkt: `addDrillFromSource({sessionId, sourceId: "tek:"+taskId})`.
- `lagreOppgave(planId, f)` beholder returnert taskId etter første lagring. Prototypens revisjon finnes ikke i appen.
- `publiserTekniskPlan(planId)` aktiverer HELE planen uten oppgaverevisjon. Prototypens publiserte øyeblikksbilde per revisjon har ingen kodeforankring.
- `SessionSummary` lagrer bare `dineOrd`. Kvalitet 1–5 og RPE 1–10 lagres via `lagreSpillerVurdering` (serveren beregner sRPE). Prototypens Belastning 1–10 = RPE; Fokus 1–10 er et eget begrep og mappes ikke til kvalitet 1–5.
- `PositionTask` har én global `sortOrder` og én `bildeUrl`/`videoUrl`: prioritet per uketype, før-/etterpar, strukturert høyde 3×3 og skru har ingen dokumentert lagring. P1.1–P9.9 er kildeverifisert støttet.

## Fortsatt ikke utledbart av kode
Objekt-ID-er utover sessionId, kind, planId, taskId, revisjon og playerId, samt betingelser og suksess/feil-gren per handling, må bekreftes mot ekte app. Dette er rest, ikke ferdig.
