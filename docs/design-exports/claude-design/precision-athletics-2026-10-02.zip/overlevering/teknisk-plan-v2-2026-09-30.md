> **Status 01.10.2026:** Historisk funksjonsinventar. Aktiv implementering eies av Codex; P5.5 og mellomposisjoner er arkivert.

# Teknisk plan v2, Start med økttype og PH-12 · 30.09.2026 (runde 37)

Status: **tegnet og simulert i prototypen. Ingenting er godkjent av Anders. Ingen appkode, database, tilgang eller deploy er endret.** Kodekontrollgrunnlag er Git 110b4ec8f og er ikke oppdatert (ingen kode er lest denne runden).

## Kilder
Aktiv kilde er `Teknisk Plan v2.dc.html` (lenket fra AK Arbeidsdokument.dc.html i Training Motor), kopiert til `_kilde/TekniskPlan-v2.html`. Gammel kortvisning (`_kilde/TekniskPlan.html`) og `_kilde/Treningsmotor2.html` er beholdt som historikk. Bilder og personnavn fra kildene er ikke brukt; alle eksempler er syntetiske (Tobias Lindvik, Anders Kristiansen).

## Hva som er tegnet
| Funksjon | Hvor | Filer |
|---|---|---|
| Start på I dag bærer økt og type til Live og oppsummering (`PHQ_SEL`, `PHQ_SESSION` med sessionId) | PH-01 → PH-04/05/07 (golf), PH-06 → PH-07-FYS (fysisk) | PH-01.jsx, PH-live.jsx, PH-TP.jsx |
| Uketyper (Treningsuke, Utviklingsuke, Prestasjons- og turneringsuke) med egen prioritert rekkefølge, «Ikke med» uten sletting, samme oppgave i flere | AG-10 (rediger), PH-TP-01 (les) | tp-v2.jsx, data-tp2.js |
| Flytt opp/ned som alternativ til dra | AG-10 | tp-v2.jsx |
| Historisk P5.5/mellomposisjon | Arkivert 01.10.2026 | Aktiv løsning bruker bare P1.0–P10.0 |
| Slag: starthøyde × toppunkt (3×3), skru og startretning; skjules for putting | AG-TP-01, oppgavekort | tp-v2.jsx (StrokeChoice) |
| Før og etter: to daterte spor, bilde eller video, last opp/erstatt/fjern med bekreftelse/bytt/sammenlign, tilstandene laster, filfeil, for stor fil, manglende fil, ikke delt med spiller, tom | AG-TP-01, AG-TP-02, PH-TP-01 | tp-v2.jsx (MediaTrack) |
| Teknisk fokus rettet uten datatap | AG-TP-01, oppgavekort | AG-TP.jsx |
| PH-12 Velg treningsplan: fem planer fra språk-masteren § 2.8, kategori A–K, coach bekrefter | PH-12 | PH-12.jsx |
| PH-07 leser tid, reps, serier og status fra samme økt som Live skrev; «Gjennomført» skilt fra «Lagret» | PH-07, PH-07-FYS | PH-live.jsx |

## Teknisk fokus (funn og retting)
Master 14.3 gir gyldige fokus per område. I demodata var to oppgaver utenfor listen: t1 «Treffpunkt» på Innspill 150–200 m og t4 «Treffpunkt» på Pitch. Verdiene er **ikke endret i data**. Skjemaet viser nå «Tidligere fokus «X» finnes ikke for området», beholder verdien som `focusLegacy` (historikk), krever gyldig fokus for lagring, og ved områdebytte flyttes et fokus som ikke passer til historikk med «Angre områdebytte». Oppgavekortet merker «ikke gyldig for området». Demoverdiene er ikke brukt som migreringsregel; en ekte migrering må avgjøres av Anders.

## Lagringsstøtte som mangler (Codex må gjenbruke eksisterende kode og beskrive endringen separat)
- `PositionTask` har én global `sortOrder`. Prioritet **per uketype** og medlemskap per uketype er ikke dokumentert støttet.
- `PositionTask` har én `bildeUrl` og én `videoUrl`. **Før-/etterpar** (to daterte spor, hver med bilde eller video), dato per medie og «delt med spiller» er ikke dokumentert støttet.
- **Strukturert høyde (3×3) og skru** har ingen egne felt.
- **Mellomposisjoner** (desimalkoder) og tomme posisjoner: ukjent om posisjonsfeltet tillater dem.
- Filopplasting, filtyper og størrelsesgrense: prototypen bruker 50 MB som **ikke-fastsatt** prototypegrense.
Denne runden endrer ikke database eller tilgang for å skjule disse hullene.

## Bevisst utelatt
- «Bestått før neste steg»-regler fra Teknisk Progresjon er ikke videreført som sperrer. Kvalitetssjekk og treffprotokoll viser status. Repmål og læringssteg er veiledende.
- Demoens årsbudsjett, ukemål (200 rep), datoer og ACWR-grenser er eksempeldata, ikke produktregler. Manglende måling vises som «—».
- Pyramide/uke/økt-motoren (planlagt mot faktisk volum, ukebudsjett, øvelsesdesign, testprotokoll, analyse → tiltak → Workbench) er **ikke** lagt inn i denne runden.

## Rettinger etter gjennomgang (samme dag)
- Mellomposisjoner: alle .1–.9 mellom P1 og P10 kan velges (ikke bare .5), numerisk sortering, tom posisjon og kobling bevart.
- «Legg i økt» åpner AG-11 Økt med et observerbart øvelsesutkast (taskId, revisjon, status). Endret oppgave gir varsel og sperrer publisering til utkastet er oppdatert; «Publiser til spiller» kan bare kjøres på oppdatert revisjon.
- Lagring i AG-TP-01 beholder taskId, øker revisjon ved hver lagring, og publisering gjelder lagret revisjon. Ny oppgave gir én oppgave, én gang i ukene.
- Før/etter-medier: bruker siste medielisten (ref) og oppgave-id i asynkrone svar. Før og etter samtidig, og bytte av oppgave under lesing, bevarer begge sider og riktig oppgave. Skjult filfelt nås via en tilgjengelig knapp med navn.
- Live og oppsummering følger sessionId: `LIVE_DATA.sessions` (okt-2609, put-2609) og fysisk økt følger `PHQ_SEL`. Bare okt-2609 og fys-2609 kan startes fra PH-01 (PH-01 er ikke endret for å beholde godkjent visning). put-2609 har ingen inngang i grensesnittet ennå; den nås kun ved å sette PHQ_SEL, og er testet slik.
- Kode- og lagringsmodellforklaringer er tatt ut av produktvisningen og står bare her.
- Kontrast: `--text-faint` lyst graphite-500 (5,8:1 på hvit), natt #928e86; aksetekst (`--axis-*-ink`) mørknet til minst 4,5:1 på myk bakgrunn over hvit/sand: fys #556740, tek #825d15, spill #954661. Akseidentitet (fyll/prikk) er uendret. PH-01-visningen Anders godkjente er en ny variant til gjennomgang fordi tekstfarger er justert i tokens.

## Kontroll (kjørt i prototypen)
- `ui_kits/reisetest.html`: 23 kontroller, 0 feil (PH-12, PH-05 → PH-07, AG-23/24).
- `ui_kits/reisetest-tp.html`: **52 kontroller, 0 feil siste kjøring** (utvidet med to golføkter, fysisk økt, lagring med historikk, revisjon, publisering, tomme forsøk, samtidig mediaopplasting, oppgavebytte, filvelger med tastatur, Legg i økt; tidligere 34 (Start golf/fysisk, PH-06 → PH-07-FYS, uketyper, flytt, «Ikke med», mellomposisjon, fokus historikk, områdebytte og angre, 3×3, filfeil, laster, opplasting, fjern-bekreftelse, manglende fil, ikke delt, tom, videresending AG-24/-GDPR/-HJELP). Første kjøring ga 2 feil: fokusvarselet forsvant ved nytt områdevalg (rettet), og en tidsfeil i testen.
- `ui_kits/audit-tp.html`: bredde/rulling, treffmål og hardkodede farger på 390 og 1280, lys og natt, data/tom/laster/feil. Første kjøring: 16 avvik (PH-07 1–10 skala 32 px, PH-12 brødsmule 27×16, skjulte filfelt regnet som treffmål). Rettet: skala i 5 kolonner à minst 44 px, brødsmulen erstattet med «Plan»-knapp, filfelt utelatt (synlig knapp er kontrollen). Se sluttrapport for siste måling.

## Åpent etter denne omgangen
- Full layoutmåling (`audit-tp.html`, 390/1280, lys/natt, data/tom/laster/feil, med ny kontrast-, ID- og render-sjekk) ble startet men **ikke fullført**: forhåndsvisningen ble utilgjengelig underveis. Siste komplette måling (før rettingene av skala og brødsmule): 320 tilfeller, 16 avvik, alle rettet i kode men ikke målt på nytt.
- Ikke gjort: pyramide/uke/økt-motoren, ds-plan.jsx-konsistens, fullstendig knappkart (utkast med 697 kontroller, alle ubekreftet), skjermpakke til Anders, frosset eksport, oppdatert readme/SKILL/oversikt/kilderegister for hele runden, marking av Training Motor som historisk.
