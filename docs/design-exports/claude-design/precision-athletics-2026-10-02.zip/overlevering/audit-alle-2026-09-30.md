# Aktive skjermer, tre verter · layoutmåling 30.09.2026 (etter batchretting)

Fil: `ui_kits/audit-alle.html` (åpnes uten query). Tre faktiske verter: `playerhq/screen.html` (PHQ_SCREENS), `agencyos/screen.html` (AG_SCREENS) og `_shared/screen.html` (FO_SCREENS: forelder, konto, booking, GFGK, statistikk, system). Utgående ID-er utelatt. **Bredder 320, 360, 390, 768, 1024, 1280, 1440; tilstandene data, tom, laster, feil.** PHQ natt-flater i natt, alt annet lyst; AgencyOS/FO natt er ikke godkjent og ikke målt.

Deterministisk ferdig-rendering: vertene setter `data-render-id`, `data-render-state`, `data-render-theme` og `data-render-seq` på `<html>` etter Reacts render (parts.jsx, ag-parts.jsx). Auditen venter på riktig ID + tilstand + tema (maks 4 s), venter på `fonts.ready`, tar to stabilitetsprøver av `main`, og flagger timeout/feil ID/tom rendering/manglende klar-signal. Negative selvtester (timeout gir false, ukjent ID oppdages) er **OK på alle tre verter**.

**Kjørt omfang: 4 228 tilfeller, 495 s. Resultat: 41 avvik, hvorav 17 hos andre eiere/uavklart. 24 avvik i mitt omfang. Del A er ikke ferdig.** Før batchretting (to verter): 46.

## Rettet siden sist
Månedens ukeåpnere (PH/AG-11-MND) har egen ukevelger med 44 px-knapper og passer på 320–1440; kolonneoverskriftene er ren tekst. AU-01 «Glemt passord?»/«Ny bruker» har 44 px treffflate. Tallfeltene i periodeskjema bryter til rader (HoursRow). PH-21, PH-RD, AG-19, PH-10, PH-TP-01/AG-10 og de øvrige er 0.

## Gjenstår i mitt omfang (24)
- **PH-11-PERSKJEMA, AG-11-PERSKJEMA, PH-11-MNDSKJEMA, AG-11-MNDSKJEMA** [320, 360, 390]: tallfeltene («Timer per uke …», «Uke # …») er fortsatt 36 × 44 px. Bredden styres av TextInput-komponenten; `min-width` i CSS ga ingen effekt. Må rettes i `components/forms/TextInput` eller HoursRow.
- **PH-11-AR/-NY, AG-11-AR/-NY, AG-11-GRUPPE-AR** [768, 1024]: årsbåndet består av segmenter proporsjonale med varighet (`WB3-ar.jsx`, 40 px høye, noen få px brede, f.eks. «Treningssamling» 11 px). Krever en alternativ periodeliste med 44 px-knapper og at segmentene blir rent visuelle.
- **AG-A07** [320]: MAIN 297 ≠ 290 (7 px sidelengs overløp). Ikke undersøkt nærmere.
- **ST-02** [1024]: DataTable-sorteringsknapper («Plass», «Spiller», «Snitt brutto») 32 px høye; CSS-regel `th button{min-height:44px}` ga ingen effekt.

## Andre eiere (i totalen, ikke rørt)
- **PH-16b** [320, 360, 390]: treffmål i skill-map (eier: PH-16b-chatten).
- **PH-26B** [alle bredder]: hardkodede farger (eier: PH-26B-chatten, uavklart skjerm).
- PH-27, AG-15-NORMER, AG-16a/b: ingen egne avvik funnet i denne kjøringen.

## Reisetest
`reisetest-tp.html`: to kjøringer på rad med egen syntetisk spiller/plan og testnøkkel, **156 kontroller, 0 feil** etter data-attributtene. Kjørt før retting av månedsvelgeren og HoursRow-endringen; ikke kjørt på nytt etter dem.

## Ikke gjort
Visuell stikkprøve av månedsvisningen (målt, ikke sett). Knappkart for tredje vert og DelB.

## Oppdatering etter siste retting
- **HoursRow** (periode- og månedsskjema): grid min 80 px, `data-hours-row` og smalere wrapperpadding. Målt på PH-11-PERSKJEMA ved 320: alle fem timefelt er nå 48 × 44 px, MAIN 305/305. PH/AG-11-MNDSKJEMA bruker samme komponent, men er **ikke målt for seg**, og full 4 228-kjøring er **ikke kjørt på nytt**.
- **Fortsatt åpent i mitt omfang:** årsbåndet (PH/AG-11-AR/-NY, AG-11-GRUPPE-AR ved 768/1024: krever periodeknapper på 44 px atskilt fra tidsskalaen), AG-A07 ved 320 (7 px overløp; ingen enkeltelement stikker utenfor, så årsaken er ikke funnet), ST-02 ved 1024 (DataTable-sorteringsknapper 32 px).
- Andre eiere uendret: PH-16b (3), PH-26B (14).

## Oppdatering: de tre kodeendringene (ikke full måling)
- **YearBand** (`WB3-ar.jsx`): tidsproporsjonale segmenter og «outs»-markører er nå rent visuelle (`div`, `aria-hidden`, ingen onClick). Under båndet ligger «Åpne periode» med én 44 px-knapp per periode (navn + dato, samme `onP(period.id)`, valgt = `aria-pressed`). Månedsvelgeren er beholdt. **Målt:** PH-11-AR og PH-11-NY ved 768: 0 avvik, 10 periodeknapper, MAIN 753/753. AG-11-AR/-NY/-GRUPPE-AR og 1024 bruker samme komponent, men er ikke målt.
- **DataTable** (`components.css`): `.pa-table__sort` og `.pa-table__sortchip` fikk min 44 × 44. **Målt:** ST-02 ved 1024: 0 avvik, tre sorteringsknapper.
- **AG-A07**: overløpet kom fra en segmentert kontroll (Rapportbyggerens mottaker) som ikke kunne bryte. `.pa-seg` har nå `max-width:100%` og `flex-wrap:wrap` (global). **Målt:** AG-A07 ved 320: MAIN 290/290, 0 treffavvik.
- **Periode-/månedsskjema:** AG-11-PERSKJEMA og AG-11-MNDSKJEMA ved 320: MAIN 305/305, 0 treffavvik; PH-11-PERSKJEMA ved 320: 0 (tallfelt 48 × 44).
- **Ikke gjort:** full 4 228-kjøring, målinger ved 360/390/1024 for skjemaene og reisetesten på nytt etter disse endringene; visuell kontroll. Den globale `.pa-seg`-endringen kan påvirke andre skjermer og må fanges av full kjøring. Andre eiere uendret (PH-16b 3, PH-26B 14).

## Sluttkontroll Del A (30.09.2026)
**Full måling** (`ui_kits/audit-alle.html`, tre verter PHQ/AG/FO, 320/360/390/768/1024/1280/1440, data/tom/laster/feil, PHQ natt-flater i natt): **4 228 tilfeller, 495 s, 17 avvik. 0 egne. 17 hos andre eiere/uavklart** (PH-16b 3 på 320/360/390, PH-26B 14 hardkodede farger på alle bredder). Selvtestene (timeout→false, ukjent ID oppdages) er OK på alle tre verter. Denne kjøringen ble gjort etter siste globale `.pa-seg`-endring, YearBand-omleggingen, DataTable-regelen og HoursRow-CSS (wrapper min 60 px). Den tidligere kjøringen samme dag hadde 21 avvik (4 egne: HoursRow ved 360).

**Etter full måling er én kodeendring gjort:** HoursRow-gridets minste kolonne 80 → 100 px (`WB3-ar.jsx`). Ingen annen kode er endret. **Full 4 228-kjøring er ikke kjørt etter denne ene endringen.**

**Målrettet etterkontroll** (`ui_kits/audit-skjema.html`, kun PH/AG-11-PERSKJEMA og -MNDSKJEMA, 7 bredder × 4 tilstander): **112 tilfeller, 102 s, 0 avvik.** Selvtester OK.

**Reisetest** (`ui_kits/reisetest-tp.html`): to isolerte kjøringer (egen syntetisk spiller/plan og lagringsnøkkel), **156 kontroller, 0 feil**, kjørt etter HoursRow-endringen.

## Egenrest
Ingen kjente egne layoutavvik. Rester hos andre eiere: PH-16b (3), PH-26B (14). Visuell kontroll og eksport er ikke gjort av meg.
