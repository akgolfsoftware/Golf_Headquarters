/**
 * @startingPoint section="Core" subtitle="Graphite primary, secondary, ghost, rust signal" viewport="700x260"
 * Press .96 · 150ms ease-out (static at night). Icon side gets 2 px less padding (pa-btn--icon-l / -r). sm is 32 px tall but has a 44 px hit area via ::after. xl (56) on Live.
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** primary = graphite (one per surface) · secondary · ghost · signal = rust, only for important action signals */
  variant?: "primary" | "secondary" | "ghost" | "signal";
  /** sm 32 · md 40 · lg 48 · xl 56 (outdoor / Live) */
  size?: "sm" | "md" | "lg" | "xl";
  /** Lucide name, leading */
  icon?: string;
  iconRight?: string;
  fullWidth?: boolean;
  /** Replaces the label with a mono sentence */
  loading?: boolean;
  loadingText?: string;
  disabled?: boolean;
  children?: React.ReactNode;
}
export declare function Button(props: ButtonProps): JSX.Element;
