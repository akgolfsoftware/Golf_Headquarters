export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Lucide name */
  icon: string;
  /** Required: aria-label and tooltip text, Norwegian */
  label: string;
  variant?: "ghost" | "secondary" | "primary";
  /** md = 44px hit target · sm = 32px drawn, 44px hit area via ::after (dense desktop tables only). Press .96, static at night. */
  size?: "sm" | "md";
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
