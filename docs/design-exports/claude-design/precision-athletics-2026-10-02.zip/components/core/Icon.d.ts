export interface IconProps {
  /** Lucide icon name, kebab-case (e.g. "calendar-days"). */
  name: string;
  /** px. Visible stroke = size / 12 (Lucide 2 px in 24 grid): 16 meta (1,33) · 18 regular text and md buttons (1,5) · 20 default (1,67) · 24 semibold, headings, Live (2). One weight per surface. State via currentColor/opacity, never a separate SVG. Decorative: aria-hidden; meaning must come from a label. `play`/`send` are nudged 1 px right via data-icon. */
  size?: number;
  color?: string;
  className?: string;
  style?: React.CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element;
