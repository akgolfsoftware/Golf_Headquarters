type Axis = "fys" | "tek" | "slag" | "spill" | "turn";
export interface ChartProps { kicker?: string; title?: string; children?: any; /** Bottom axis with mono ticks. */ axis?: ChartAxisProps; /** Mono source line. */ footer?: string; className?: string; }
/** Figure frame: caption, stacked BarRows/Sparklines, shared axis, mono source line. */
export declare function Chart(props: ChartProps): JSX.Element;
export interface SparklineProps { values: (number | null)[]; min?: number; max?: number; /** Dashed goal level. */ goal?: number; /** Line in the axis hue (classification only). Default graphite. */ axis?: Axis; height?: number; label?: string; className?: string; }
/** Fluid line (width 100%). Fewer than 2 points renders "—". */
export declare function Sparkline(props: SparklineProps): JSX.Element;
export interface BarRowProps { label: string; /** null renders "—" and no bar. */ value?: number | null; min?: number; max?: number; goal?: number; goalLabel?: string; axis?: Axis; /** Formatted value, e.g. "+1,2". */ display?: string; unit?: string; meta?: string; className?: string; }
/** Horizontal 0-radius bar with mono value and optional goal line. */
export declare function BarRow(props: BarRowProps): JSX.Element;
export interface GoalLineProps { at: number; min?: number; max?: number; label?: string; }
/** 2 px graphite vertical mark inside a positioned track. */
export declare function GoalLine(props: GoalLineProps): JSX.Element;
export interface ChartAxisProps { min?: number; max?: number; ticks?: number; unit?: string; format?: (v: number) => string; }
/** Mono tick labels under bars. */
export declare function ChartAxis(props: ChartAxisProps): JSX.Element;
