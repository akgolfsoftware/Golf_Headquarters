export interface KeyValueItem { label: string; value?: any; /** Override list-level mono for this value. */ mono?: boolean; /** Mono meta under the value, e.g. "TRACKMAN · 24.09". */ hint?: string; }
export interface KeyValueProps {
  /** Objects, or tuples [label, value, { mono, hint }]. Empty value renders "—". */
  items: (KeyValueItem | [string, any, Partial<KeyValueItem>?])[];
  /** 1 = hairline rows (inspector). 2–3 = grid that collapses to 1 column under 480 px. */
  columns?: number;
  mono?: boolean;
  className?: string;
}
export declare function KeyValue(props: KeyValueProps): JSX.Element;
