export interface DataRowProps {
  /** Avatar, Icon or AxisBadge */
  leading?: React.ReactNode;
  title: React.ReactNode;
  sub?: React.ReactNode;
  /** Mono tabular value, right-aligned */
  value?: React.ReactNode;
  trailing?: React.ReactNode;
  /** 2px graphite inset on the left edge */
  selected?: boolean;
  onClick?: () => void;
  className?: string;
}
export declare function DataRow(props: DataRowProps): JSX.Element;
