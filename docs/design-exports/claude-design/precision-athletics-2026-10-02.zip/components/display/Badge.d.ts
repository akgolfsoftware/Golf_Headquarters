export interface BadgeProps {
  count?: number | null;
  /** Above max renders "99+". */
  max?: number;
  /**
   * neutral — informational count (graphite on sand).
   * signal  — rust: ONLY for counts that need the coach's action (Kø, ubesvarte). Max one per screen.
   * inverse — graphite fill, for use on light rows next to a selected item.
   */
  tone?: "neutral" | "signal" | "inverse";
  /** Show 0 (a measured zero). Default hides. */
  showZero?: boolean;
  /** Accessible noun: label="venter" → "9 venter". */
  label?: string;
  className?: string;
}
/** Mono count pill. */
export declare function Badge(props: BadgeProps): JSX.Element | null;
