export interface AxisBadgeProps {
  /** The five training axes: FYS (green) · TEK (ochre) · SLAG (blue) · SPILL (plum) · TURN (red) */
  axis: "fys" | "tek" | "slag" | "spill" | "turn";
  /** Override the label (defaults to FYS/TEK/SLAG/SPILL/TURN) */
  children?: React.ReactNode;
  size?: "md" | "lg";
  dot?: boolean;
  className?: string;
}
export declare function AxisBadge(props: AxisBadgeProps): JSX.Element;
export declare const AXES: Record<"fys" | "tek" | "slag" | "spill" | "turn", string>;
