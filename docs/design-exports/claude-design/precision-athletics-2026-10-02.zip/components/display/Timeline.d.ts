export interface TimelineItem {
  id?: string;
  /** Group heading, e.g. "LØR 26.09" — shown when it changes. */
  day?: string;
  /** Mono timestamp, 24 h: "13:48". */
  time?: string;
  dateTime?: string;
  title: any;
  body?: any;
  /** Mono meta line: "CADDIE · GODKJENT AV ANDERS". */
  meta?: string;
  /** Dot in the axis colour (classifies what the event is about — never status). */
  axis?: "fys" | "tek" | "slag" | "spill" | "turn";
  /** Hollow dot for pending/not-yet events. */
  hollow?: boolean;
  children?: any;
}
export interface TimelineProps { items: TimelineItem[]; dense?: boolean; className?: string; }
/** Activity list with mono timestamps and a hairline spine. */
export declare function Timeline(props: TimelineProps): JSX.Element;
