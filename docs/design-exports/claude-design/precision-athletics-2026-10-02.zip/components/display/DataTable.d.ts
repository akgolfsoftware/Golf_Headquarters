export interface DataTableColumn<T = any> {
  key: string;
  label: string;
  /** Numbers in Plex Mono tabular. */
  mono?: boolean;
  align?: "left" | "right";
  sortable?: boolean;
  width?: number | string;
  /** Custom cell. Return null/"" to show "—". */
  render?: (row: T) => any;
  /** Value used for sorting when render() is custom. Accepts "−0,4" / "1 200". */
  sortValue?: (row: T) => any;
}
export interface DataTableProps<T = any> {
  columns: DataTableColumn<T>[];
  rows: T[];
  /** Field that identifies a row. Default "id". */
  rowKey?: string;
  /** Selected row key — gets the 2 px graphite inset on the left. */
  selected?: string | number | null;
  onSelect?: (key: any, row: T) => void;
  /** Controlled sort. Omit for internal sort state. */
  sort?: { key: string; dir: "asc" | "desc" } | null;
  onSort?: (sort: { key: string; dir: "asc" | "desc" }) => void;
  defaultSort?: { key: string; dir: "asc" | "desc" };
  caption?: string;
  emptyText?: string;
  className?: string;
}
/** Table on wide surfaces; becomes card rows below 760 px container width (container query). Never scrolls sideways. */
export declare function DataTable<T = any>(props: DataTableProps<T>): JSX.Element;
