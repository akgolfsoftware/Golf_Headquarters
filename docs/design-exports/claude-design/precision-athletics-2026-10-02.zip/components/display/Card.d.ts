/**
 * @startingPoint section="Display" subtitle="White 8px card with kicker, title, mono footer" viewport="700x300"
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Uppercase kicker above the title */
  kicker?: React.ReactNode;
  title?: React.ReactNode;
  /** Right-aligned header slot — IconButton, Badge */
  action?: React.ReactNode;
  /** Mono meta row with hairline above */
  footer?: React.ReactNode;
  tone?: "raised" | "sunken";
  /** Pad children directly when no header */
  padded?: boolean;
  /** Hover darkens border; press scales var(--press-scale-card) = .99 (static at night / reduced motion). Hairline only, no shadow. */
  interactive?: boolean;
}
export declare function Card(props: CardProps): JSX.Element;
