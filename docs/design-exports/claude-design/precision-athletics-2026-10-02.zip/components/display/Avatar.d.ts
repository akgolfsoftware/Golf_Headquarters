export interface AvatarProps {
  name: string;
  /** Only cleared photos of current players/coaches. Otherwise initials. */
  src?: string;
  size?: number;
}
export declare function Avatar(props: AvatarProps): JSX.Element;
