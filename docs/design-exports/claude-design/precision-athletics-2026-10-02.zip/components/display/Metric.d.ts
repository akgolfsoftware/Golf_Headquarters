export interface MetricProps {
  label?: string;
  /** Rendered in Plex Mono tabular. null/undefined renders "—" (never 0). */
  value?: string | number | null;
  /** m · yds · ° · % · mph */
  unit?: string;
  /** Signed change, e.g. "+2,1" */
  delta?: string;
  deltaDir?: "up" | "down";
  /** Source/date line in mono, e.g. "TRACKMAN · 24.09" */
  meta?: string;
  size?: "s" | "md" | "l";
  className?: string;
}
export declare function Metric(props: MetricProps): JSX.Element;
