export interface StatusPillProps {
  /** neutral · ok · warn · info · signal (rust, needs attention) · live (solid rust, running) · solid (graphite) */
  tone?: "neutral" | "ok" | "warn" | "info" | "signal" | "live" | "solid";
  dot?: boolean;
  /** Always words — a status is a short sentence, never a colour alone */
  children: React.ReactNode;
  className?: string;
}
export declare function StatusPill(props: StatusPillProps): JSX.Element;
