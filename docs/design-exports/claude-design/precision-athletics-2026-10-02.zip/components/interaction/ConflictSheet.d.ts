export interface Conflict { kind: "kalender" | "volum" | "belastning" | "tilgang" | "versjon"; text: string; meta?: string; }
export interface ConflictOption { id: string; label: string; description?: string; }
export interface ConflictSheetProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  conflicts: Conflict[];
  /** Første er primær. F.eks. «Flytt likevel», «Velg annen dag», «Behold begge». */
  options: ConflictOption[];
  onResolve?: (id: string) => void;
}
/** Konflikt etter dra/flytt: kalender, volum, belastning, tilgang eller samtidig endring. */
export declare function ConflictSheet(props: ConflictSheetProps): JSX.Element | null;
