export interface ActionBarProps {
  /** Én primærknapp (grafitt). */
  primary?: any;
  /** Avbryt, Lagre delvis osv. */
  secondary?: any;
  /** Slett / Trekk tilbake — venstrestilt, alltid bak ConfirmDialog. */
  destructive?: any;
  status?: "idle" | "dirty" | "saving" | "saved" | "error" | "conflict";
  /** F.eks. klokkeslett «14:02». */
  statusMeta?: string;
  /** Mobil: fast nederst over tab-baren. Desktop: i PageHeader eller inspector. */
  sticky?: boolean;
  className?: string;
}
/** Handlingsrad med lagrestatus i mono. Én primær, destruktiv til venstre. */
export declare function ActionBar(props: ActionBarProps): JSX.Element;
