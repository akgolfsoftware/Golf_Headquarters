export interface SortableItem { id: string; label?: string; [k: string]: any; }
export interface SortableRenderCtx {
  index: number;
  dragging: boolean;
  /** Løftet med tastatur. */
  lifted: boolean;
  locked: boolean;
  /** 44×44 håndtak: draggable + tastatur (Mellomrom løfter, piler flytter, Mellomrom slipper, Escape avbryter). */
  handle: any;
  /** «Flytt»-knapp som åpner MoveSheet. Mobil og skjermleser. */
  moveButton: any;
}
export interface SortableListProps {
  items: SortableItem[];
  renderItem: (item: SortableItem, ctx: SortableRenderCtx) => any;
  /** Ny rekkefølge som id-liste. Vis UndoToast etterpå. */
  onReorder?: (ids: string[], change: { from: number; to: number }) => void;
  onMove?: (item: SortableItem) => void;
  label?: string;
  /** Id-er som ikke kan flyttes (f.eks. låst av coach). Viser lås i håndtaket. */
  locked?: string[];
  disabled?: boolean;
  dragType?: string;
}
/** Sortering: mus-dra, tastatur og Flytt-knapp. Dra-forhåndsvisning = halv opasitet, slippunkt = 2 px grafitt linje. */
export declare function SortableList(props: SortableListProps): JSX.Element;
