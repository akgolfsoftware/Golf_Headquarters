export interface UndoToastProps {
  open: boolean;
  message: string;
  /** Mono linje, f.eks. «FLYTTET TIL TOR 01.10 · KAN ANGRES». */
  meta?: string;
  onUndo?: () => void;
  onClose?: () => void;
  /** ms. Default 8000. */
  duration?: number;
  /** Render i flyt (katalog/kort) i stedet for fast nederst. */
  inline?: boolean;
}
export declare function UndoToast(props: UndoToastProps): JSX.Element | null;
