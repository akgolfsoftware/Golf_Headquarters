export interface ConfirmDialogProps {
  open: boolean;
  /** destructive = rust bekreft · publish = grafitt «Publiser» · unsaved = lagre/forkast/fortsett */
  kind?: "destructive" | "publish" | "unsaved";
  title?: string;
  children?: any;
  /** Hva skjer: «Tobias får varsel», «Kan angres i 8 sekunder». */
  consequences?: string[];
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
  /** unsaved: «Forkast endringer». */
  onSecondary?: () => void;
  secondaryLabel?: string;
  busy?: boolean;
}
export declare function ConfirmDialog(props: ConfirmDialogProps): JSX.Element | null;
