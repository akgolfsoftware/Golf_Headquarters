export interface BackBarProps {
  /** Navnet på forrige kontekst, f.eks. «Runder». Vises som knappetekst. */
  to?: string;
  label?: string;
  onBack: () => void;
  /** Plassering, siste element er gjeldende side. */
  trail?: { label: string; onClick?: () => void }[];
  actions?: any;
  className?: string;
}
/** Tilbake til forrige kontekst (historikk), aldri hardkodet hjem. 44 px treff. */
export declare function BackBar(props: BackBarProps): JSX.Element;
