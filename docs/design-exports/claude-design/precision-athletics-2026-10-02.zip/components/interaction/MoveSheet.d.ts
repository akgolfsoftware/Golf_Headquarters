export interface MoveTarget { id: string; label: string; meta?: string; /** Konflikt eller grunn til at målet er stengt. */ reason?: string; warn?: boolean; disabled?: boolean; }
export interface MoveSheetProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  /** Navn på det som flyttes. */
  item?: string;
  targets: MoveTarget[];
  value?: string | null;
  onChange?: (id: string) => void;
  /** F.eks. ["Bare denne", "Hele serien"]. */
  scope?: string[];
  scopeValue?: string;
  onScope?: (v: string) => void;
  /** F.eks. «Dette endrer ikke coachens plan før Anders godkjenner.» */
  note?: string;
  onConfirm: () => void;
  confirmLabel?: string;
}
/** Flytt uten å dra: radioliste med mål, konflikt i mono per mål. */
export declare function MoveSheet(props: MoveSheetProps): JSX.Element | null;
