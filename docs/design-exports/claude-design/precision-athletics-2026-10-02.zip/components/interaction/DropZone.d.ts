export interface DropZoneProps {
  label: string;
  hint?: string;
  /** Tekst når sonen er tom, f.eks. «DRA ØVELSER HIT ELLER BRUK LEGG TIL». */
  empty?: string;
  onDrop?: (id: string, e: DragEvent) => void;
  /** dataTransfer-typer sonen tar imot. */
  accept?: string[];
  /** false = viser ugyldig (rust stiplet) og nekter slipp. */
  valid?: boolean;
  reason?: string;
  children?: any;
  minHeight?: number;
}
/** Slippmål: idle (stiplet), over (2 px grafitt), ugyldig (rust stiplet + grunn). */
export declare function DropZone(props: DropZoneProps): JSX.Element;
