export interface SignedRow { id?: string; label: string; sub?: string; /** null = mangler grunnlag («—»). */ value: number | null; }
export interface SignedBarsProps { rows: SignedRow[]; value?: string; onSelect?: (id: string) => void; /** Halv bredde av skalaen. */ domain?: number; decimals?: number; zeroLabel?: string; labelWidth?: number; }
/** Stolper rundt null, over/under i fortegnsfargene. Aldri --warn eller --action for «under». */
export declare function SignedBars(props: SignedBarsProps): JSX.Element;
