import React from "react";
const PH = [["Baksving", "P1–P4", 1, 4], ["Nedsving", "P5–P7", 5, 7], ["Gjennomsving", "P8–P10", 8, 10]];
const major = (c) => parseInt(String(c).slice(1), 10);
/** P1.0–P10.0 som klikkbare noder. Valgt = grafitt fyll. Ruller aldri sidelengs: under minWidth blir linjen et rutenett med fem kolonner (2 × 5). */
export function SwingTimeline({ positions = [], value = null, onChange, phases = PH, minWidth = 640, showCounts = true, countLabel = ["oppgave", "oppgaver"], ariaLabel = "Svingtidslinje P1.0–P10.0" }) {
  const ref = React.useRef(null), [w, setW] = React.useState(null);
  React.useLayoutEffect(() => { const el = ref.current; if (!el) return; const f = () => setW(el.clientWidth); f(); if (!window.ResizeObserver) return; const ro = new ResizeObserver(f); ro.observe(el); return () => ro.disconnect(); }, []);
  const grid = w != null && w < minWidth, n = positions.length || 1, at = (i) => (5 + (90 * (n === 1 ? 0.5 : i / (n - 1)))) + "%";
  const idx = positions.findIndex((p) => p.code === value);
  const aria = (p) => p.code + " " + (p.label || p.name) + (showCounts ? " · " + (p.count || 0) + " " + (p.count === 1 ? countLabel[0] : countLabel[1]) : "") + (p.focus ? " · hovedfokus" : "");
  const tag = <span style={{ font: "600 9px/1 var(--font-mono)", letterSpacing: ".04em", color: "var(--text-inverse)", background: "var(--surface-ink)", borderRadius: 999, padding: "2px 5px" }}>FOKUS</span>;
  const cnt = (p) => showCounts && <span style={{ font: "500 12px/1 var(--font-mono)", color: p.count ? "var(--text-primary)" : "var(--text-muted)" }}>{p.count ? p.count : "—"}</span>;
  if (grid) return <div ref={ref} style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <div role="group" aria-label={ariaLabel} style={{ display: "grid", gridTemplateColumns: "repeat(5,minmax(0,1fr))", gap: 6 }}>
      {positions.map((p) => { const on = p.code === value;
        return <button key={p.code} type="button" aria-pressed={on} aria-label={aria(p)} title={p.label || p.name} onClick={() => onChange && onChange(on ? null : p.code)} style={{ all: "unset", boxSizing: "border-box", cursor: "pointer", minWidth: 0, minHeight: 64, padding: "8px 6px", display: "flex", flexDirection: "column", gap: 6, justifyContent: "space-between", background: on ? "var(--surface-ink)" : "var(--surface-card)", color: on ? "var(--text-inverse)" : "var(--text-primary)", borderRadius: "var(--radius)", border: "1px solid " + (on ? "var(--surface-ink)" : "var(--border-hairline)"), transition: "background-color 200ms var(--ease-out), color 200ms var(--ease-out)" }}>
          <span style={{ font: "600 13px/1 var(--font-mono)" }}>{p.code}</span>
          <span style={{ display: "flex", gap: 4, alignItems: "center", flexWrap: "wrap", minWidth: 0 }}>{showCounts && <span style={{ font: "500 12px/1 var(--font-mono)", opacity: p.count ? 1 : 0.7 }}>{p.count ? p.count : "—"}</span>}{p.focus && (on ? <span style={{ font: "600 9px/1 var(--font-mono)", letterSpacing: ".04em", color: "var(--text-primary)", background: "var(--surface-card)", borderRadius: 999, padding: "2px 5px" }}>FOKUS</span> : tag)}</span>
        </button>; })}
    </div>
    {phases && <span style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)" }}>{phases.map(([nm, r]) => nm.toUpperCase() + " " + r).join(" · ")}</span>}
  </div>;
  return <div ref={ref} style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
    <div role="group" aria-label={ariaLabel} style={{ position: "relative", height: 132, background: "var(--surface-flat)", border: "1px solid var(--border-hairline)", borderBottom: 0, boxSizing: "border-box" }}>
      <span aria-hidden="true" style={{ position: "absolute", left: "5%", right: "5%", top: 41, height: 2, background: "var(--border-ink)" }}></span>
      {positions.map((p, i) => { const on = p.code === value, d = on ? 20 : 14;
        return <button key={p.code} type="button" aria-pressed={on} aria-label={aria(p)} title={p.label || p.name} onClick={() => onChange && onChange(on ? null : p.code)}
          style={{ all: "unset", boxSizing: "border-box", position: "absolute", top: 8, left: at(i), transform: "translateX(-50%)", width: "calc(" + (90 / Math.max(1, n - 1)) + "% - 4px)", maxWidth: 96, minWidth: 48, minHeight: 112, display: "flex", flexDirection: "column", alignItems: "center", cursor: "pointer", color: "var(--text-primary)" }}>
          <span style={{ height: 16, font: "600 13px/16px var(--font-mono)" }}>{p.code}</span>
          <span style={{ height: 36, display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ width: d, height: d, boxSizing: "border-box", borderRadius: 999, border: "2px " + (p.count || on ? "solid " : "dashed ") + "var(--border-ink)", background: on ? "var(--surface-ink)" : "var(--surface-card)", boxShadow: on ? "0 0 0 3px var(--surface-flat), 0 0 0 4px var(--border-ink)" : "none", transition: "background-color 200ms var(--ease-out), width 200ms var(--ease-out), height 200ms var(--ease-out)" }}></span></span>
          <span style={{ font: (on ? "600 " : "400 ") + "11px/1.25 var(--font-sans)", color: on ? "var(--text-primary)" : "var(--text-secondary)", textAlign: "center", maxHeight: 28, overflow: "hidden", textWrap: "balance", overflowWrap: "anywhere" }}>{p.name}</span>
          <span style={{ display: "flex", gap: 4, alignItems: "center", paddingTop: 4 }}>{cnt(p)}{p.focus && tag}</span>
        </button>; })}
    </div>
    <div aria-hidden="true" style={{ position: "relative", height: 3, background: "var(--border-hairline)" }}>{idx >= 0 && <span style={{ position: "absolute", top: 0, bottom: 0, left: at(idx), width: 48, marginLeft: -24, background: "var(--border-ink)", transition: "left 200ms var(--ease-in-out)" }}></span>}</div>
    {phases && <div aria-hidden="true" style={{ position: "relative", height: 30 }}>{phases.map(([nm, r, a, b]) => { const ia = positions.findIndex((p) => major(p.code) === a), ib = positions.map((p) => major(p.code)).lastIndexOf(b); if (ia < 0 || ib < 0) return null; const L = parseFloat(at(ia)), R = parseFloat(at(ib)); return <span key={nm} style={{ position: "absolute", top: 8, left: "calc(" + L + "% - 20px)", width: "calc(" + (R - L) + "% + 40px)", borderTop: "1px solid var(--border-strong)", paddingTop: 4, display: "flex", gap: 6, justifyContent: "center", alignItems: "baseline", overflow: "hidden" }}><span style={{ font: "600 12px/1.2 var(--font-sans)" }}>{nm}</span><span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{r}</span></span>; })}</div>}
  </div>;
}
