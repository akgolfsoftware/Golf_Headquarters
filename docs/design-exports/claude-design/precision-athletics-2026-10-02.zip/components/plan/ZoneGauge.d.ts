export interface ZoneGaugeProps { label: string; value?: number | null; lo: number; hi: number; min?: number; max?: number; decimals?: number; /** Én setning om hva verdien betyr. Påkrevd i praksis — tall står aldri alene. */ text?: string; source?: string; }
/** Verdi på skala med anbefalt sone. Ingen trafikklys. */
export declare function ZoneGauge(props: ZoneGaugeProps): JSX.Element;
