export interface HitGridProps { /** true = godkjent, false = ikke godkjent, null = ikke slått. Eldst først. */ results: (boolean | null)[]; window?: number; required?: number; /** Overstyr setningen. */ text?: string; cell?: number; }
/** Treffprotokoll (rullende vindu) som ruter med regel i én setning. */
export declare function HitGrid(props: HitGridProps): JSX.Element;
