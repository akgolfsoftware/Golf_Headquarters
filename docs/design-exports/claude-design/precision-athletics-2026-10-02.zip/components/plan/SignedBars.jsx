import React from "react";
const sg = (v, d) => v == null ? "—" : (v > 0 ? "+" : v < 0 ? "−" : "") + Math.abs(v).toFixed(d).replace(".", ",");
/** Fortegnsstolper rundt null (Strokes Gained mot referanse). Fortegnet står i tallet. Valgt rad har grafitt innstrek. */
export function SignedBars({ rows = [], value, onSelect, domain, decimals = 2, zeroLabel = "0", labelWidth = 180 }) {
  const m = domain || Math.max(0.5, ...rows.map((r) => Math.abs(r.value || 0))) * 1.1, x = (v) => 50 + (v / m) * 50;
  return <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
    {rows.map((r) => { const on = value === r.id, v = r.value, l = v == null ? 50 : Math.min(x(0), x(v)), w = v == null ? 0 : Math.abs(x(v) - x(0)), Tag = onSelect ? "button" : "div";
      return <Tag key={r.id || r.label} {...(onSelect ? { type: "button", "aria-pressed": on, onClick: () => onSelect(r.id) } : {})} style={{ all: "unset", boxSizing: "border-box", width: "100%", display: "grid", gridTemplateColumns: "minmax(0," + labelWidth + "px) minmax(0,1fr) 64px", gap: 12, alignItems: "center", minHeight: 56, padding: "8px 0 8px 10px", borderBottom: "1px solid var(--border-hairline)", background: on ? "var(--surface-sunken)" : "transparent", boxShadow: on ? "inset 3px 0 0 var(--action)" : "none", cursor: onSelect ? "pointer" : "default", transition: "background-color 200ms var(--ease-out)" }}>
        <span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: (on ? "600 " : "500 ") + "15px/1.2 var(--font-sans)" }}>{r.label}</span>{r.sub && <span style={{ font: "var(--type-meta)", fontSize: 10, letterSpacing: ".04em", color: "var(--text-muted)" }}>{r.sub}</span>}</span>
        <span aria-hidden="true" style={{ position: "relative", height: 24 }}><span style={{ position: "absolute", top: -6, bottom: -6, left: x(0) + "%", width: 1, background: "var(--border-ink)" }}></span>{v != null && <span style={{ position: "absolute", top: 4, height: 16, left: l + "%", width: w + "%", background: v >= 0 ? "var(--data-over)" : "var(--data-under)", transition: "left 200ms var(--ease-in-out), width 200ms var(--ease-in-out)" }}></span>}</span>
        <span style={{ font: "600 16px/1 var(--font-mono)", textAlign: "right", fontVariantNumeric: "tabular-nums", color: v == null ? "var(--text-muted)" : "var(--text-primary)" }}>{sg(v, decimals)}</span>
      </Tag>; })}
    <div aria-hidden="true" style={{ display: "grid", gridTemplateColumns: "minmax(0," + labelWidth + "px) minmax(0,1fr) 64px", gap: 12, paddingTop: 6, paddingLeft: 10 }}><span></span><span style={{ display: "flex", justifyContent: "space-between", font: "var(--type-meta)", color: "var(--text-muted)" }}><span>{sg(-m, 1)}</span><span>{zeroLabel}</span><span>{sg(m, 1)}</span></span><span></span></div>
  </div>;
}
