export interface FormulaCodeProps { /** Leddene i rekkefølge: PYRAMIDE, OMRÅDE, MOTORIKK, BELASTNING, PRESS. */ parts?: string[]; /** Alternativ: hel kode, deles på «_». */ code?: string; /** Indeks for leddet som sist ble endret (understrek). */ highlight?: number; size?: "md" | "lg"; label?: string; }
/** AK-formelen som mono-merke. Formelen er en merkelapp avledet av valgene — den styrer ikke planleggingen. */
export declare function FormulaCode(props: FormulaCodeProps): JSX.Element;
