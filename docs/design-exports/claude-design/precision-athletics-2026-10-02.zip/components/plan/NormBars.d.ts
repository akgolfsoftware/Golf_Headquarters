export interface NormRow { /** FYS | TEK | SLAG | SPILL | TURN — gir aksefargen. */ code: string; /** Faktisk andel i prosent. null = ikke registrert. */ actual: number | null; recommended: number; status?: string; }
export interface NormBarsProps { rows: NormRow[]; tolerance?: number; source?: string; }
/** Treningsvolum per akse mot norm for kategorien. */
export declare function NormBars(props: NormBarsProps): JSX.Element;
