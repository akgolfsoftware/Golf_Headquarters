import React from "react";
/** Faktisk andel mot anbefalt norm per akse. Fyll = faktisk (aksefarge), grafitt strek = anbefalt. */
export function NormBars({ rows = [], tolerance = 3, source }) {
  return <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
    {rows.map((r) => { const diff = r.actual == null ? null : r.actual - r.recommended, st = r.status || (diff == null ? "—" : Math.abs(diff) <= tolerance ? "I balanse" : diff > 0 ? "Over norm" : "Under norm");
      return <div key={r.code} style={{ display: "grid", gridTemplateColumns: "52px minmax(0,1fr) minmax(72px,110px)", gap: 12, alignItems: "center", padding: "10px 0", borderBottom: "1px solid var(--border-hairline)" }}>
        <span style={{ font: "600 13px/1 var(--font-mono)" }}>{r.code}</span>
        <span style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}><span role="img" aria-label={r.code + ": faktisk " + (r.actual ?? "—") + " %, anbefalt " + r.recommended + " %"} style={{ position: "relative", height: 12, background: "var(--surface-sunken)" }}><span style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: Math.min(100, r.actual || 0) + "%", background: "var(--axis-" + String(r.code).toLowerCase() + ")" }}></span><span style={{ position: "absolute", top: -4, bottom: -4, left: Math.min(100, r.recommended) + "%", width: 2, marginLeft: -1, background: "var(--border-ink)" }}></span></span><span style={{ font: "var(--type-meta)", fontSize: 10, letterSpacing: ".02em", color: "var(--text-muted)" }}>FAKTISK {r.actual == null ? "—" : r.actual + " %"} · ANBEFALT {r.recommended} %</span></span>
        <span style={{ font: "500 12px/1.3 var(--font-sans)", textAlign: "right", textWrap: "pretty" }}>{st}</span>
      </div>; })}
    <span style={{ paddingTop: 8, font: "var(--type-meta)", fontSize: 10, letterSpacing: ".04em", color: "var(--text-muted)" }}>FYLL = FAKTISK ANDEL · STREK = ANBEFALT · ±{tolerance} PROSENTPOENG = I BALANSE{source ? " · " + source : ""}</span>
  </div>;
}
