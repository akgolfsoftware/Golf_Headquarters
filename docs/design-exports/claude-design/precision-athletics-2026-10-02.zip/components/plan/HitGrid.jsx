import React from "react";
/** Treffprotokoll som ruter: fylt = godkjent, hul = ikke godkjent, stiplet = ikke slått ennå. Setningen står alltid over. */
export function HitGrid({ results = [], window: win = 20, required = 16, text, cell = 12 }) {
  const last = results.slice(-win), hits = last.filter((v) => v === true).length, pct = Math.round(required / win * 100);
  const cells = Array.from({ length: win }, (_, i) => last[i] ?? null);
  return <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <span style={{ font: "500 14px/1.4 var(--font-sans)", textWrap: "pretty" }}>{text || "Rullende vindu: " + required + " av de siste " + win + " slagene skal godkjennes (" + pct + " %)."}</span>
    <div role="img" aria-label={hits + " av " + last.length + " registrerte slag godkjent. Krav " + required + " av " + win + "."} style={{ display: "flex", flexWrap: "wrap", gap: 3 }}>{cells.map((v, i) => <span key={i} style={{ width: cell, height: cell, boxSizing: "border-box", background: v === true ? "var(--primary)" : "var(--surface-card)", border: "1px " + (v == null ? "dashed var(--border-strong)" : "solid var(--border-control)") }}></span>)}</div>
    <span style={{ font: "500 13px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums", color: hits >= required ? "var(--text-primary)" : "var(--text-secondary)" }}>{last.length ? hits + " av " + last.length + " godkjent · krav " + required + " av " + win : "— · ingen slag registrert"}</span>
  </div>;
}
