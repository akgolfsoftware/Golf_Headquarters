import React from "react";
/** AK-formelen i mono. Leddet som sist ble endret markeres med grafitt understrek. Ledd som ikke gjelder utelates av kalleren. */
export function FormulaCode({ parts, code, highlight = -1, size = "md", label = "AK-formelen" }) {
  const p = parts || String(code || "").split("_").filter(Boolean), big = size === "lg";
  return <code title={label} aria-label={label + ": " + p.join("_")} style={{ display: "inline-block", maxWidth: "100%", boxSizing: "border-box", font: (big ? "500 15px/1.5 " : "500 12px/1.45 ") + "var(--font-mono)", color: "var(--text-primary)", background: "var(--surface-sunken)", border: "1px solid var(--border-hairline)", borderRadius: "var(--radius)", padding: big ? "8px 12px" : "4px 10px", overflowWrap: "anywhere", wordBreak: "break-all" }}>
    {p.length ? p.map((s, i) => <React.Fragment key={i}>{i > 0 && <span style={{ color: "var(--text-muted)" }}>_</span>}<span style={i === highlight ? { color: "var(--action)", boxShadow: "inset 0 -2px 0 var(--action)", transition: "color 200ms var(--ease-out)" } : { transition: "color 200ms var(--ease-out)" }}>{s}</span></React.Fragment>) : "—"}
  </code>;
}
