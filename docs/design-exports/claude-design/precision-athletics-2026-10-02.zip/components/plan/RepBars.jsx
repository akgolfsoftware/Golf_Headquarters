import React from "react";
const num = (v) => v == null ? "—" : String(v).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
/** Repetisjoner per læringssteg: gjort / mål med prosent. Valgfri strek = skjema til nå. */
export function RepBars({ rows = [], source, unit = "" }) {
  return <div style={{ display: "flex", flexDirection: "column", gap: 10, minWidth: 0 }}>
    {rows.map((r) => { const p = r.goal ? Math.round((r.done || 0) / r.goal * 100) : null, w = p == null ? 0 : Math.min(100, p), m = r.marker != null && r.goal ? Math.min(100, r.marker / r.goal * 100) : null;
      return <div key={r.label} style={{ display: "flex", flexDirection: "column", gap: 4, opacity: r.locked ? 0.55 : 1 }}>
        <span style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "baseline" }}><span style={{ font: "500 13px/1.3 var(--font-sans)", color: "var(--text-primary)" }}>{r.label}{r.code && <span style={{ font: "var(--type-meta)", color: "var(--text-muted)", marginLeft: 6 }}>{r.code}</span>}</span><span style={{ font: "500 13px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" }}>{r.goal == null ? "—" : num(r.done || 0) + " / " + num(r.goal) + (unit ? " " + unit : "") + " (" + p + " %)"}</span></span>
        <span role="img" aria-label={r.label + ": " + (r.goal == null ? "ikke i planen" : num(r.done || 0) + " av " + num(r.goal) + ", " + p + " prosent")} style={{ position: "relative", display: "block", height: 8, background: "var(--surface-sunken)" }}><span style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: w + "%", background: r.locked ? "var(--border-strong)" : "var(--primary)", transition: "width 200ms var(--ease-out)" }}></span>{m != null && <span style={{ position: "absolute", top: -3, bottom: -3, left: m + "%", width: 2, marginLeft: -1, background: "var(--action)" }}></span>}</span>
      </div>; })}
    {source && <span style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)" }}>{source}</span>}
  </div>;
}
