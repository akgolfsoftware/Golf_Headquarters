import React from "react";
const dec = (v, d) => v == null ? "—" : Math.abs(v).toFixed(d).replace(".", ",");
/** Én verdi på skala med anbefalt sone (f.eks. ACWR 0,8–1,3). Setningen forklarer alltid tallet. */
export function ZoneGauge({ label, value = null, lo, hi, min = 0, max = 2, decimals = 2, text, source }) {
  const x = (v) => Math.max(0, Math.min(100, (v - min) / (max - min) * 100));
  return <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <span style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}><span className="kicker">{label}</span><span style={{ font: "600 21px/1 var(--font-mono)" }}>{dec(value, decimals)}</span></span>
    <div role="img" aria-label={label + " " + dec(value, decimals) + ", anbefalt sone " + dec(lo, 1) + " til " + dec(hi, 1)} style={{ position: "relative", height: 20, border: "1px solid var(--border-ink)", background: "var(--surface-card)", boxSizing: "border-box" }}>
      <span style={{ position: "absolute", top: 0, bottom: 0, left: x(lo) + "%", width: (x(hi) - x(lo)) + "%", background: "var(--surface-sunken)", borderLeft: "1px solid var(--border-control)", borderRight: "1px solid var(--border-control)", boxSizing: "border-box" }}></span>
      {value != null && <span style={{ position: "absolute", top: -4, bottom: -4, left: x(value) + "%", width: 4, marginLeft: -2, background: "var(--primary)" }}></span>}
    </div>
    <span aria-hidden="true" style={{ display: "flex", justifyContent: "space-between", font: "var(--type-meta)", color: "var(--text-muted)" }}><span>{dec(min, 1)}</span><span>SONE {dec(lo, 1)}–{dec(hi, 1)}</span><span>{dec(max, 1)}</span></span>
    {text && <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{text}</span>}
    {source && <span style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)" }}>{source}</span>}
  </div>;
}
