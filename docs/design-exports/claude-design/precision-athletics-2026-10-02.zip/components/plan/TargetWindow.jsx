import React from "react";
const dec = (v, d) => v == null ? "—" : (v < 0 ? "−" : v > 0 && d.plus ? "+" : "") + Math.abs(v).toFixed(d.n).replace(".", ",");
/** Målboks på skala med tre merker: utgangspunkt (hul ring), målboks (ramme), måling nå (fylt prikk). Legende med tall under. Mangler måling: «—» og en setning om hvorfor. */
export function TargetWindow({ label, hint, lo, hi, value = null, base = null, min, max, ticks, decimals = 1, signed = false, unit = "", emptyText = "Ingen måling registrert.", source }) {
  const d = { n: decimals, plus: signed }, u = unit ? (unit === "°" ? "°" : " " + unit) : "", span = hi - lo || 1;
  const a = min != null ? min : Math.min(lo, value ?? lo, base ?? lo) - span * 0.6, b = max != null ? max : Math.max(hi, value ?? hi, base ?? hi) + span * 0.6, x = (v) => Math.max(0, Math.min(100, (v - a) / (b - a) * 100));
  const tk = ticks || [a, lo, hi, b], inside = value != null && value >= lo && value <= hi, U = (v) => dec(v, d) + (v != null ? u : "");
  const leg = (mark, k, v) => <span style={{ display: "flex", gap: 6, alignItems: "center", minWidth: 0 }}>{mark}<span style={{ display: "flex", flexDirection: "column", minWidth: 0 }}><span style={{ font: "var(--type-meta)", fontSize: 10, letterSpacing: ".04em", color: "var(--text-muted)" }}>{k}</span><span style={{ font: "500 13px/1.3 var(--font-mono)", fontVariantNumeric: "tabular-nums" }}>{v}</span></span></span>;
  return <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <span style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "baseline" }}><span title={hint} style={{ font: "600 14px/1.3 var(--font-sans)", textDecoration: hint ? "underline dotted var(--border-control)" : "none", textUnderlineOffset: 3 }}>{label}</span><span style={{ font: "500 12px/1.3 var(--font-sans)", color: value == null ? "var(--text-muted)" : "var(--text-primary)" }}>{value == null ? "—" : inside ? "Innenfor målboksen" : "Utenfor målboksen"}</span></span>
    <div role="img" aria-label={label + ": utgangspunkt " + U(base) + ", målboks " + dec(lo, d) + " til " + dec(hi, d) + u + ", måling nå " + (value == null ? "mangler" : U(value))} style={{ position: "relative", height: 32, borderBottom: "1px solid var(--border-ink)", margin: "0 8px" }}>
      <span style={{ position: "absolute", left: x(lo) + "%", width: (x(hi) - x(lo)) + "%", top: 4, bottom: 0, background: "var(--surface-sunken)", borderLeft: "2px solid var(--border-ink)", borderRight: "2px solid var(--border-ink)", boxSizing: "border-box" }}></span>
      {base != null && <span aria-hidden="true" style={{ position: "absolute", left: x(base) + "%", bottom: 6, width: 12, height: 12, marginLeft: -6, borderRadius: 999, border: "2px solid var(--text-secondary)", background: "var(--surface-card)", boxSizing: "border-box" }}></span>}
      {value != null && <span aria-hidden="true" style={{ position: "absolute", left: x(value) + "%", bottom: 4, width: 16, height: 16, marginLeft: -8, borderRadius: 999, background: "var(--text-primary)", boxShadow: "0 0 0 2px var(--surface-card)" }}></span>}
    </div>
    <div aria-hidden="true" style={{ position: "relative", height: 14, margin: "0 8px" }}>{tk.map((t, i) => <span key={i} style={{ position: "absolute", left: x(t) + "%", transform: i === 0 ? "translateX(-8px)" : i === tk.length - 1 ? "translateX(calc(-100% + 8px))" : "translateX(-50%)", font: "var(--type-meta)", color: "var(--text-muted)", whiteSpace: "nowrap" }}>{dec(t, d)}</span>)}</div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,112px),1fr))", gap: 8 }}>
      {leg(<span aria-hidden="true" style={{ width: 10, height: 10, borderRadius: 999, border: "2px solid var(--text-secondary)", flex: "none" }}></span>, "UTGANGSPUNKT", U(base))}
      {leg(<span aria-hidden="true" style={{ width: 14, height: 10, borderLeft: "2px solid var(--border-ink)", borderRight: "2px solid var(--border-ink)", background: "var(--surface-sunken)", flex: "none", boxSizing: "border-box" }}></span>, "MÅLBOKS", dec(lo, d) + " til " + dec(hi, d) + u)}
      {leg(<span aria-hidden="true" style={{ width: 10, height: 10, borderRadius: 999, background: "var(--text-primary)", flex: "none" }}></span>, "MÅLING NÅ", U(value))}
    </div>
    {value == null && <span style={{ font: "var(--type-body-s)", color: "var(--text-secondary)", textWrap: "pretty" }}>{emptyText}</span>}
    {source && <span style={{ font: "var(--type-meta)", letterSpacing: ".04em", color: "var(--text-muted)", overflowWrap: "anywhere" }}>{source}</span>}
  </div>;
}
