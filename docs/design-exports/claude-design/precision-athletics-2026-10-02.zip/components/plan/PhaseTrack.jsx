import React from "react";
/** Milepæler som faser over uker med «i dag»-strek. Gjennomført = grafitt fyll, aktiv = ramme, planlagt = stiplet. Under 520 px blir fasene en liste. */
export function PhaseTrack({ phases = [], today = null, todayLabel = "I DAG", start, end }) {
  const ref = React.useRef(null), [w, setW] = React.useState(null);
  React.useLayoutEffect(() => { const el = ref.current; if (!el) return; const f = () => setW(el.clientWidth); f(); if (!window.ResizeObserver) return; const ro = new ResizeObserver(f); ro.observe(el); return () => ro.disconnect(); }, []);
  const st = { done: "Gjennomført", active: "Pågår", planned: "Planlagt" };
  const box = (p) => ({ background: p.state === "done" ? "var(--surface-ink)" : p.state === "active" ? "var(--surface-sunken)" : "var(--surface-card)", color: p.state === "done" ? "var(--text-inverse)" : "var(--text-primary)", border: "1px " + (p.state === "planned" ? "dashed var(--border-control)" : "solid " + (p.state === "done" ? "var(--surface-ink)" : "var(--border-ink)")) });
  if (w != null && w < 520) return <div ref={ref} style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}>
    {today != null && <span style={{ font: "600 11px/1 var(--font-mono)", letterSpacing: ".04em" }}>{todayLabel}</span>}
    {phases.map((p) => <div key={p.label} style={{ ...box(p), display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 8, alignItems: "center", padding: "10px 12px", borderRadius: "var(--radius)", minHeight: 48, boxSizing: "border-box" }}><span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}><span style={{ font: "var(--type-meta)", fontSize: 10, letterSpacing: ".04em", opacity: 0.85 }}>{p.range}</span><span style={{ font: "600 13px/1.25 var(--font-sans)" }}>{p.label}</span></span><span style={{ font: "500 12px/1.2 var(--font-sans)" }}>{st[p.state]}</span></div>)}
    {(start || end) && <span style={{ font: "var(--type-meta)", color: "var(--text-muted)" }}>{start} – {end}</span>}
  </div>;
  return <div ref={ref} style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}>
    <div style={{ position: "relative", paddingTop: 16 }}>
      <div style={{ display: "flex", gap: 2 }}>{phases.map((p) => <div key={p.label} style={{ ...box(p), flex: p.weeks + " 1 0", minWidth: 0, minHeight: 56, padding: "8px 10px", boxSizing: "border-box", display: "flex", flexDirection: "column", gap: 2 }}><span style={{ font: "var(--type-meta)", fontSize: 10, letterSpacing: ".04em", opacity: 0.85 }}>{p.range} · {st[p.state].toUpperCase()}</span><span style={{ font: "600 13px/1.25 var(--font-sans)", overflowWrap: "anywhere" }}>{p.label}</span></div>)}</div>
      {today != null && <><span aria-hidden="true" style={{ position: "absolute", top: 12, bottom: -6, left: (today * 100) + "%", width: 2, marginLeft: -1, background: "var(--border-ink)" }}></span><span style={{ position: "absolute", top: 0, left: (today * 100) + "%", transform: today > 0.7 ? "translateX(-100%)" : "none", marginLeft: today > 0.7 ? -6 : 6, font: "600 10px/1 var(--font-mono)", color: "var(--text-primary)", whiteSpace: "nowrap" }}>{todayLabel}</span></>}
    </div>
    {(start || end) && <div style={{ display: "flex", justifyContent: "space-between", font: "var(--type-meta)", color: "var(--text-muted)" }}><span>{start}</span><span>{end}</span></div>}
  </div>;
}
