export interface RepRow { label: string; /** Formelkode, f.eks. LAV_HAST. */ code?: string; done?: number | null; /** null = ikke i planen («—»). */ goal: number | null; /** Skjema til nå — tegnes som strek. */ marker?: number | null; locked?: boolean; }
export interface RepBarsProps { rows: RepRow[]; /** Kilde og dato, f.eks. «KILDE LIVE-ØKT · 24.09.2026». */ source?: string; unit?: string; }
/** Rep-søyler per læringssteg (repsGjort / repsMaal). Grafitt fyll, grafitt skjemastrek. */
export declare function RepBars(props: RepBarsProps): JSX.Element;
