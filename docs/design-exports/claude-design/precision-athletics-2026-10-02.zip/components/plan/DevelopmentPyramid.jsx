import React from "react";
const L = [["TURN", "Turnering", "turn"], ["SPILL", "Spill", "spill"], ["SLAG", "Golfslag", "slag"], ["TEK", "Teknisk", "tek"], ["FYS", "Fysisk", "fys"]];
/** Utviklingspyramiden, fem lag. FYS er grunnflaten, TURN toppen. Aksefargen står bare i staven. Valgt lag har grafitt toppstrek. */
export function DevelopmentPyramid({ value, onChange, layers = L, meta = {}, compact = false, controlIdPrefix }) {
  return <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
    <div role="group" aria-label="Utviklingspyramiden" style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      {layers.map(([k, n, a], i) => { const on = value === k, w = 44 + i * 14;
        return <button key={k} type="button" data-axis={a} data-control-id={controlIdPrefix ? controlIdPrefix + "-" + a : undefined} aria-pressed={on} onClick={() => onChange && onChange(k)} style={{ all: "unset", boxSizing: "border-box", width: w + "%", minWidth: 160, maxWidth: "100%", margin: "0 auto", minHeight: compact ? 48 : 60, display: "flex", alignItems: "center", gap: 12, paddingRight: 14, cursor: onChange ? "pointer" : "default", background: on ? "var(--surface-ink)" : "var(--surface-card)", color: on ? "var(--text-inverse)" : "var(--text-primary)", border: "1px solid " + (on ? "var(--surface-ink)" : "var(--border-hairline)"), borderTop: "3px solid " + (on ? "var(--action)" : "var(--border-hairline)"), transition: "background-color 200ms var(--ease-out), color 200ms var(--ease-out)" }}>
          <span aria-hidden="true" style={{ alignSelf: "stretch", width: 4, flex: "none", background: "var(--axis-" + a + ")" }}></span>
          <span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0, flex: 1 }}><span style={{ font: "600 16px/1.1 var(--font-mono)" }}>{k}</span><span style={{ font: "400 13px/1.2 var(--font-sans)", color: on ? "var(--text-inverse-soft)" : "var(--text-secondary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{meta[k] || n}</span></span>
          <span style={{ font: "var(--type-meta)", color: on ? "var(--text-inverse-soft)" : "var(--text-muted)" }}>{String(layers.length - i).padStart(2, "0")}</span>
        </button>; })}
    </div>
    <div aria-hidden="true" style={{ display: "flex", justifyContent: "space-between", font: "var(--type-meta)", fontSize: 10, letterSpacing: ".06em", color: "var(--text-muted)", borderTop: "1px solid var(--border-strong)", paddingTop: 8 }}><span>GRUNNFLATE · FYS</span><span>TOPP · TURN</span></div>
  </div>;
}
