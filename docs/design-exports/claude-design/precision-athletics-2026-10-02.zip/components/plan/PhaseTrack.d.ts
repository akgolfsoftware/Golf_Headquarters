export interface Phase { label: string; /** «UKE 1–4». */ range: string; weeks: number; state: "done" | "active" | "planned"; }
export interface PhaseTrackProps { phases: Phase[]; /** Andel 0–1 av hele sporet. */ today?: number | null; todayLabel?: string; start?: string; end?: string; }
/** Faseplan over uker med «i dag»-strek i grafitt. Under 520 px: liste med status per fase. */
export declare function PhaseTrack(props: PhaseTrackProps): JSX.Element;
