export interface SourceBadgeProps {
  /** «TrackMan», «GolfBox», «Manuell · annen app». */
  source?: string;
  kind?: "trackman" | "golfbox" | "manuell" | "annen_app" | "okt" | "test" | "caddie" | "coach" | "datagolf";
  /** «24.09.2026» */
  date?: string;
  /** Antall observasjoner. null = vises ikke. */
  n?: number | null;
  /** «slag», «runder», «økter». */
  unit?: string;
  /** «8 uker» */
  period?: string;
  est?: boolean;
}
/** Hvert måltall har kilde, periode, dato og n. Uten kilde: «KILDE MANGLER». */
export declare function SourceBadge(props: SourceBadgeProps): JSX.Element;
