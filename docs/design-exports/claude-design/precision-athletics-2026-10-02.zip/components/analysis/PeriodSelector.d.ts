export interface PeriodSelectorProps {
  value: string;
  onChange: (v: string) => void;
  options?: string[];
  compare?: string;
  onCompare?: (v: string) => void;
  compareOptions?: string[];
  label?: string;
}
/** Periode (segmentert) + valgfri sammenligning (select). Bryter linje, ruller aldri sidelengs. */
export declare function PeriodSelector(props: PeriodSelectorProps): JSX.Element;
