export interface ChartTableProps { chart: any; columns: any[]; rows: any[]; caption?: string; defaultView?: "Graf" | "Tabell"; rowKey?: string; aside?: any; }
/** Tilgjengelig datatabell som alternativ til hver graf (Graf | Tabell). */
export declare function ChartTable(props: ChartTableProps): JSX.Element;
