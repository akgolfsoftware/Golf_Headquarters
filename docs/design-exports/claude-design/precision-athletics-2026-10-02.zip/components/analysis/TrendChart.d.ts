export interface TrendSeries { label: string; /** null = ikke målt (brudd i linjen), aldri 0. */ values: (number | null)[]; }
export interface TrendChartProps {
  series: TrendSeries[];
  labels?: string[];
  /** Lik skala over og under null — standard for SG. */
  symmetric?: boolean;
  /** Tykk nullinje. */
  zero?: boolean;
  min?: number; max?: number;
  height?: number;
  format?: (v: number | null) => string;
  goal?: number;
  caption?: string;
  unit?: string;
}
/** Maks to serier (heltrukket = nå, stiplet = sammenligning). Tekstalternativ i aria-label; bruk ChartTable for tabell. */
export declare function TrendChart(props: TrendChartProps): JSX.Element;
