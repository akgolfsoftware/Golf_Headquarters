export interface EvidenceRow { label: string; value: string | number | null; source?: string; date?: string; n?: number | null; }
export interface EvidenceDrawerProps { open: boolean; onClose: () => void; title: string; rows: EvidenceRow[]; uncertainty?: string; method?: string; missing?: string[]; }
/** Sideark med grunnlaget bak en innsikt. Tabell, ikke graf. */
export declare function EvidenceDrawer(props: EvidenceDrawerProps): JSX.Element | null;
