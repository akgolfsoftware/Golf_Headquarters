export interface DataQualityBadgeProps {
  level?: "god" | "tynn" | "mangler" | "utdatert" | "manuell";
  have?: number | null;
  /** Minste antall for en konklusjon. */
  need?: number;
  unit?: string;
  /** «21 dager siden». */
  age?: string;
}
/** Datagrunnlagets kvalitet i ord. tynn/mangler skal stenge «forbedring»-påstander. */
export declare function DataQualityBadge(props: DataQualityBadgeProps): JSX.Element;
