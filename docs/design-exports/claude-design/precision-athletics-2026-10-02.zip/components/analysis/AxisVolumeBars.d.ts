export interface AxisVolumeRow { label: string; /** Minutter per akse. null = ikke registrert («—»). */ parts: Partial<Record<"fys" | "tek" | "slag" | "spill" | "turn", number>> | null; plan?: number | null; }
export interface AxisVolumeBarsProps { rows: AxisVolumeRow[]; max?: number; unit?: string; legend?: boolean; }
/** Stablet volum per akse med planstrek. Bruk ChartTable for tabellalternativ. */
export declare function AxisVolumeBars(props: AxisVolumeBarsProps): JSX.Element;
