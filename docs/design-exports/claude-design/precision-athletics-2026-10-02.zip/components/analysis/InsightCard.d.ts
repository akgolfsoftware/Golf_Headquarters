import type { SourceBadgeProps } from "./SourceBadge";
import type { DataQualityBadgeProps } from "./DataQualityBadge";
export interface InsightAction { label: string; icon?: string; primary?: boolean; onClick?: () => void; }
export interface InsightCardProps {
  kind?: "haster" | "trend" | "mal" | "datamangel" | "stabil";
  title: string;
  /** Hvorfor: én setning. */
  cause?: string;
  /** [etikett, verdi] — null blir «—». */
  evidence?: [string, string | number | null][];
  recommendation?: string;
  source?: SourceBadgeProps;
  quality?: DataQualityBadgeProps;
  /** Obligatorisk: minst én av «Legg i plan», «Be coach vurdere», «Se økt», «Registrer data», «Sammenlign periode». */
  actions: InsightAction[];
  onEvidence?: () => void;
  /** Laget av Caddie — må godkjennes. */
  draft?: boolean;
}
/** Analysen skal alltid føre til et neste steg. Rust bare for kind="haster". */
export declare function InsightCard(props: InsightCardProps): JSX.Element;
