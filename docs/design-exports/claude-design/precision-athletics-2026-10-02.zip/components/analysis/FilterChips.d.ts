export interface FilterChipsProps {
  options: (string | { value: string; label: string; axis?: "fys" | "tek" | "slag" | "spill" | "turn" })[];
  /** Tom liste = Alle. */
  value?: string[];
  onChange: (v: string[]) => void;
  allLabel?: string | null;
  label?: string;
  single?: boolean;
}
export declare function FilterChips(props: FilterChipsProps): JSX.Element;
