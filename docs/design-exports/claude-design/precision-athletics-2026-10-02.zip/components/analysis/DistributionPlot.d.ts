export interface DistributionPlotProps { points: { x: number; y: number }[]; /** ± enheter fra sentrum. */ range?: number; unitX?: string; unitY?: string; target?: boolean; label?: string; height?: number; xLabel?: string; yLabel?: string; }
/** Spredningsplott med snitt (stiplet ring) og tekstsammendrag (n, snitt, standardavvik). */
export declare function DistributionPlot(props: DistributionPlotProps): JSX.Element;
