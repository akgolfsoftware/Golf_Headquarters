export interface EmptyAnalysisStateProps { title: string; have?: number | null; need?: number; unit?: string; text?: string; action?: string; actionIcon?: string; onAction?: () => void; secondary?: string; onSecondary?: () => void; }
/** Tom analyse: fremdrift mot minste datagrunnlag + konkret neste handling. */
export declare function EmptyAnalysisState(props: EmptyAnalysisStateProps): JSX.Element;
