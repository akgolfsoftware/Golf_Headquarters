export interface DialogProps {
  open?: boolean;
  title: React.ReactNode;
  children?: React.ReactNode;
  /** Buttons, right-aligned: secondary then primary */
  footer?: React.ReactNode;
  onClose?: () => void;
  /** Position within nearest relative parent instead of the viewport (previews) */
  inline?: boolean;
  width?: number;
}
export declare function Dialog(props: DialogProps): JSX.Element | null;
