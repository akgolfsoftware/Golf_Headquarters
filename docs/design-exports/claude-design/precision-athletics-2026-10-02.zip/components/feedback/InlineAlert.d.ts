export interface InlineAlertProps {
  tone?: "neutral" | "info" | "ok" | "warn" | "signal";
  title?: React.ReactNode;
  children?: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}
export declare function InlineAlert(props: InlineAlertProps): JSX.Element;
