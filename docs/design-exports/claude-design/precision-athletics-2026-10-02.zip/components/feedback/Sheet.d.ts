export interface SheetProps {
  open: boolean;
  onClose?: () => void;
  kicker?: string;
  title?: string;
  children?: any;
  /** Sticky action area — buttons stack full width. */
  footer?: any;
  /**
   * auto   — bottom sheet up to 1024 px, right-hand Inspector (340 px) above.
   * bottom — always a bottom sheet. right — always a side panel.
   * docked — Inspector column inside the layout (no scrim), for desktop split views.
   */
  mode?: "auto" | "bottom" | "right" | "docked";
  /** Position inside the nearest positioned parent instead of the viewport (cards, previews). */
  inline?: boolean;
  label?: string;
  className?: string;
}
/** Bottom sheet on mobile, Inspector side panel on desktop. Also serves as the Drawer. */
export declare function Sheet(props: SheetProps): JSX.Element | null;
