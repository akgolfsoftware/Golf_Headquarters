export interface ToastProps {
  children: React.ReactNode;
  /** Mono timestamp/trace, e.g. "LAGRET 08:41 · IKKE DELT" */
  meta?: string;
  /** Single verb, e.g. "Angre" */
  action?: string;
  onAction?: () => void;
  tone?: "default" | "signal";
  className?: string;
}
export declare function Toast(props: ToastProps): JSX.Element;
