export interface LoadingStateProps { /** Mono sentence. Default "Henter …". No spinner, no shimmer. */ text?: string; className?: string; }
export declare function LoadingState(props: LoadingStateProps): JSX.Element;
export interface EmptyStateProps { icon?: string; title: string; /** One sentence: why it is empty. */ text?: string; /** Next logical action (secondary button). */ action?: string; actionIcon?: string; onAction?: () => void; secondary?: string; onSecondary?: () => void; className?: string; /** Optional data-control-id forwarded to the inner action button. */ actionControlId?: string; }
export declare function EmptyState(props: EmptyStateProps): JSX.Element;
export interface ErrorStateProps { title?: string; /** What went wrong and what is safe: "Tilkoblingen falt ut. Ingenting er lagret." */ text?: string; /** Mono code, e.g. "FEIL 503 · 14:02". */ code?: string; onRetry?: () => void; /** Valgfri data-control-id på retry-knappen. */ retryControlId?: string; retryLabel?: string; className?: string; }
export declare function ErrorState(props: ErrorStateProps): JSX.Element;
export interface StateProps { status: "loading" | "empty" | "error" | "ready"; loadingText?: string; empty?: EmptyStateProps; error?: ErrorStateProps; children?: any; }
/** Switch between the three states and the loaded content. */
export declare function State(props: StateProps): JSX.Element | null;
