export interface BreadcrumbItem { label: string; href?: string; onClick?: () => void; }
export interface BreadcrumbProps { /** Last item is the current page. */ items: BreadcrumbItem[]; className?: string; }
/** Wrapping path: Stall › Junior elite › Ida Berg. Never truncates the current page. */
export declare function Breadcrumb(props: BreadcrumbProps): JSX.Element;
