export interface TabBarItem { id: string; label: string; icon: string }
export interface TabBarProps {
  /** Defaults to PlayerHQ's four: I dag · Plan · Data · Meg */
  tabs?: TabBarItem[];
  active: string;
  onSelect?: (id: string) => void;
}
export declare function TabBar(props: TabBarProps): JSX.Element;
export declare const PLAYERHQ_TABS: TabBarItem[];
