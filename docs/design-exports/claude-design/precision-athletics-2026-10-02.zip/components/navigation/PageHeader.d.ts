export interface PageHeaderProps {
  /** Mono/caps context: "UKE 39 · LØR 26.09". Ellipsizes. */
  kicker?: string;
  title: any;
  sub?: any;
  /** Optional <Breadcrumb /> above the title. */
  breadcrumb?: any;
  /** Mono meta line under the text. */
  meta?: any;
  /** Buttons. Wrap onto new lines; under 600 px container width they stretch to share the row. */
  actions?: any;
  className?: string;
}
/** Screen title block for every AgencyOS/PlayerHQ page. Title clamps 22–28 px. */
export declare function PageHeader(props: PageHeaderProps): JSX.Element;
