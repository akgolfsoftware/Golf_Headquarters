export interface MenuBarProps {
  /** Discreet logo, ~20 px tall */
  brand?: React.ReactNode;
  onMenu: () => void;
  /** Drawer open state (aria-expanded) */
  open?: boolean;
  /** Optional 44 px IconButtons left of the hamburger */
  actions?: React.ReactNode;
}
/** 56 px top line for mobile and tablet (≤1024 px): logo left, two-line hamburger right. */
export declare function MenuBar(props: MenuBarProps): JSX.Element;
