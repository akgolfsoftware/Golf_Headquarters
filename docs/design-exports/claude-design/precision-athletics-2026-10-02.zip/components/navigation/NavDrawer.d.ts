import type { NavGroup } from "./NavRail";
export interface NavDrawerProps {
  open: boolean;
  onClose: () => void;
  brand?: React.ReactNode;
  /** Same groups as NavRail. Groups with one item navigate directly; others expand. */
  groups: NavGroup[];
  active?: string;
  onSelect?: (id: string) => void;
  /** Bottom slot — Avatar + name */
  footer?: React.ReactNode;
}
/** Slide-out menu for mobile/tablet. 48 px rows, scrim, Esc to close. Position the parent `relative` — the drawer fills it with `inset:0`. */
export declare function NavDrawer(props: NavDrawerProps): JSX.Element;
