export interface TopBarProps {
  title: React.ReactNode;
  /** Mono sub-line (date, sync state) */
  sub?: string;
  onBack?: () => void;
  /** Right slot — IconButtons, Button */
  actions?: React.ReactNode;
  leading?: React.ReactNode;
  transparent?: boolean;
}
export declare function TopBar(props: TopBarProps): JSX.Element;
