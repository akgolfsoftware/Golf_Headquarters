export interface PaginationProps {
  /** 1-based. */
  page: number;
  pageCount: number;
  onChange: (page: number) => void;
  /** Shows "21–40 AV 312" in mono. */
  total?: number;
  perPage?: number;
  label?: string;
  className?: string;
}
/** Page buttons that wrap onto a new line — never a horizontal scroller. */
export declare function Pagination(props: PaginationProps): JSX.Element | null;
