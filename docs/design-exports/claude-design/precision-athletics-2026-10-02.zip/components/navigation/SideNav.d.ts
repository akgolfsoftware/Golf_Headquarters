export interface SideNavItem { id?: string; label?: string; icon?: string; count?: number; signal?: boolean; group?: string }
export interface SideNavProps {
  brand?: React.ReactNode;
  /** Items, or { group: "Label" } headings */
  items: SideNavItem[];
  active?: string;
  onSelect?: (id: string) => void;
  footer?: React.ReactNode;
}
export declare function SideNav(props: SideNavProps): JSX.Element;
