export interface NavItem {
  id: string;
  label: string;
  /** Lucide icon name */
  icon?: string;
  /** Shows a dot on the rail and a mono count in the drawer */
  count?: number;
  signal?: boolean;
  /** Cross-module link — navigates instead of calling onSelect */
  href?: string;
}
export interface NavGroup {
  id: string;
  /** Top-level label: I dag · Planlegging · Stats & Banekart · Tester · Profil */
  label: string;
  icon: string;
  items: NavItem[];
}
export interface NavRailProps {
  /** 28×28 mark, e.g. <img src="…/ak-golf-logo-ink.svg"> */
  brand?: React.ReactNode;
  groups: NavGroup[];
  active?: string;
  onSelect?: (id: string) => void;
  /** Bottom slot — Avatar */
  footer?: React.ReactNode;
}
/** Desktop (>1024 px) 56 px icon rail. Below 1024 px use MenuBar + NavDrawer with the same groups. */
export declare function NavRail(props: NavRailProps): JSX.Element;
