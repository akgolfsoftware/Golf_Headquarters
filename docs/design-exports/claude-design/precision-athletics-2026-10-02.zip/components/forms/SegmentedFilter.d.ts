export interface SegmentedFilterOption { value: string; label: string; /** Mono count; 0 is shown. */ count?: number; }
export interface SegmentedFilterProps {
  options: (SegmentedFilterOption | string)[];
  /** string for single, string[] for multi. */
  value: string | string[];
  onChange: (value: any) => void;
  multi?: boolean;
  label?: string;
  className?: string;
}
/** Filter chips that wrap onto new lines (unlike Segmented, which is a fixed 2–4 option track). */
export declare function SegmentedFilter(props: SegmentedFilterProps): JSX.Element;
