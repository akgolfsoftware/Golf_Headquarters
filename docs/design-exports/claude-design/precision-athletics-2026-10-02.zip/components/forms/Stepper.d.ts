export interface StepperProps {
  label?: string;
  value: number;
  onChange?: (value: number) => void;
  step?: number;
  min?: number;
  max?: number;
  /** Mono unit after the value: m · % · min · RIR */
  unit?: string;
  format?: (value: number) => string;
  /** md 48px · sm 40px · xl 56px (Live / utendørs, --hit-outdoor) */
  size?: "md" | "sm" | "xl";
  className?: string;
}
export declare function Stepper(props: StepperProps): JSX.Element;
