export interface ChoicePillProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  selected?: boolean;
  /** Axis variant: selected state takes the axis soft background + axis edge instead of graphite fill */
  axis?: "fys" | "tek" | "slag" | "spill" | "turn";
  /** md 40px · lg 52px (tactile, outdoor) */
  size?: "md" | "lg";
  /** Plex Mono label — P1–P10, S1–S5, numbers */
  mono?: boolean;
  /** Keyboard hint shown in mono, e.g. "1" */
  kbd?: string;
  children: React.ReactNode;
}
export declare function ChoicePill(props: ChoicePillProps): JSX.Element;
