export interface FormFieldProps {
  label?: string;
  /** Shown under the label, before the control. */
  hint?: string;
  /** Error as a full sentence — shown as text with an icon, never colour alone. */
  error?: string;
  /** Adds the "PÅKREVD" mark and aria-required. */
  required?: boolean;
  /** Adds "VALGFRITT" instead (use when most fields are required). */
  optional?: boolean;
  id?: string;
  /** One control. It receives id, aria-describedby, aria-invalid. */
  children: any;
  className?: string;
}
/** Label + hint + control + error for any control (TextInput, Select, Stepper, ChoicePill group). */
export declare function FormField(props: FormFieldProps): JSX.Element;
export interface TextInputProps extends Record<string, any> { mono?: boolean; className?: string; }
/** Bare .pa-control input for use inside FormField. */
export declare function TextInput(props: TextInputProps): JSX.Element;
