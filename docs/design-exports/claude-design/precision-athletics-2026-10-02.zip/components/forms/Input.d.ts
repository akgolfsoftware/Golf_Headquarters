export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size" | "prefix"> {
  label?: string;
  hint?: string;
  /** Error sentence — replaces hint, turns the border rust */
  error?: string;
  prefix?: React.ReactNode;
  /** Unit shown in mono, e.g. "m", "yds", "°" */
  suffix?: React.ReactNode;
  /** Use Plex Mono tabular for numeric fields */
  mono?: boolean;
  size?: "md" | "lg";
}
export declare function Input(props: InputProps): JSX.Element;
