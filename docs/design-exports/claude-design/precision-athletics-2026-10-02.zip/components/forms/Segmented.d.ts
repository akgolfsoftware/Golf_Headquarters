export interface SegmentedProps {
  options: Array<string | { value: string; label: string; icon?: string }>;
  value?: string;
  onChange?: (value: string) => void;
  /** lg = 44px options, for mobile/outdoor */
  size?: "md" | "lg";
  fullWidth?: boolean;
  className?: string;
}
export declare function Segmented(props: SegmentedProps): JSX.Element;
