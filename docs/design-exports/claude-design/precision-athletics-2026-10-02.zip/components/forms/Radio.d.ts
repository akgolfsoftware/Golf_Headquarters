export interface RadioProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: React.ReactNode;
  /** Share a name across a group */
  name?: string;
}
export declare function Radio(props: RadioProps): JSX.Element;
