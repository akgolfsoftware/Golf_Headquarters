export interface SearchFieldProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  /** Accessible label. Visually hidden by default. */
  label?: string;
  hideLabel?: boolean;
  /** Result count shown in mono while searching. 0 is shown ("0 TREFF"). */
  count?: number;
  id?: string;
  className?: string;
}
export declare function SearchField(props: SearchFieldProps): JSX.Element;
