/* @ds-bundle: {"format":4,"namespace":"TeamNorwayGolfDesignSystem_3416f2","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"FlagRule","sourcePath":"components/core/FlagRule.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"Logo","sourcePath":"components/core/Logo.jsx"},{"name":"Stat","sourcePath":"components/core/Stat.jsx"},{"name":"Placement","sourcePath":"components/data/Placement.jsx"},{"name":"ProgressBar","sourcePath":"components/data/ProgressBar.jsx"},{"name":"Table","sourcePath":"components/data/Table.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"Notice","sourcePath":"components/feedback/Notice.jsx"},{"name":"Skeleton","sourcePath":"components/feedback/Skeleton.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"ErrorSummary","sourcePath":"components/forms/ErrorSummary.jsx"},{"name":"Fieldset","sourcePath":"components/forms/Fieldset.jsx"},{"name":"FileUpload","sourcePath":"components/forms/FileUpload.jsx"},{"name":"FormRow","sourcePath":"components/forms/FormRow.jsx"},{"name":"HelpText","sourcePath":"components/forms/HelpText.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Navbar","sourcePath":"components/navigation/Navbar.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Avatar","sourcePath":"components/people/Avatar.jsx"},{"name":"PlayerCard","sourcePath":"components/people/PlayerCard.jsx"},{"name":"DateRange","sourcePath":"components/program/DateRange.jsx"},{"name":"ScheduleItem","sourcePath":"components/program/ScheduleItem.jsx"},{"name":"Timeline","sourcePath":"components/program/Timeline.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"5d220cd821fd","components/core/Button.jsx":"e6754536c337","components/core/Card.jsx":"1b3628e08c6e","components/core/Eyebrow.jsx":"090071ea72ae","components/core/FlagRule.jsx":"70b904c241e9","components/core/Icon.jsx":"1eedc122a334","components/core/Logo.jsx":"8d873014916e","components/core/Stat.jsx":"4a7157121331","components/data/Placement.jsx":"9a5e9b803c89","components/data/ProgressBar.jsx":"c2ff200b87b0","components/data/Table.jsx":"db589c6a7610","components/feedback/Dialog.jsx":"4eabb3111ee2","components/feedback/EmptyState.jsx":"e0a23a577d8d","components/feedback/Notice.jsx":"12913eb3ca13","components/feedback/Skeleton.jsx":"5da95ac9b652","components/feedback/Toast.jsx":"32ad2a7c3e07","components/forms/Checkbox.jsx":"5cdea6b15f9d","components/forms/ErrorSummary.jsx":"f93b7b3dcbd6","components/forms/Fieldset.jsx":"a06fd64342f2","components/forms/FileUpload.jsx":"4a383f462f4a","components/forms/FormRow.jsx":"759cb7d5b5ce","components/forms/HelpText.jsx":"963ee456d5ca","components/forms/Input.jsx":"a51f12ad4903","components/forms/Radio.jsx":"3ba1b563fc73","components/forms/Select.jsx":"cfa57ce2c1e4","components/forms/Switch.jsx":"303a3752b475","components/navigation/Navbar.jsx":"8cc74d714223","components/navigation/Tabs.jsx":"7c321355b08e","components/people/Avatar.jsx":"43bb532e22c0","components/people/PlayerCard.jsx":"c5a38e131847","components/program/DateRange.jsx":"54fbcf9f657d","components/program/ScheduleItem.jsx":"af65d2207114","components/program/Timeline.jsx":"11d17050a458"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.TeamNorwayGolfDesignSystem_3416f2 = window.TeamNorwayGolfDesignSystem_3416f2 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function Badge({
  tone = 'navy',
  outline = false,
  children,
  style
}) {
  const map = {
    navy: ['var(--tng-navy)', 'var(--text-on-navy)'],
    red: ['var(--tng-red)', 'var(--text-on-red)'],
    neutral: ['var(--tng-paper-2)', 'var(--text-strong)'],
    success: ['var(--success)', '#fff']
  };
  const [bg, fg] = map[tone] || map.navy;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '11px',
      fontWeight: 500,
      textTransform: 'uppercase',
      letterSpacing: '.16em',
      padding: '5px 10px',
      borderRadius: 'var(--radius-sm)',
      background: outline ? 'transparent' : bg,
      color: outline ? bg : fg,
      border: '1px solid ' + bg,
      display: 'inline-block',
      lineHeight: 1.1,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const pad = {
  sm: '8px 16px',
  md: '12px 24px',
  lg: '16px 34px'
};
const fs = {
  sm: '12px',
  md: '13px',
  lg: '14px'
};
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  fullWidth = false,
  as = 'button',
  href,
  children,
  onClick,
  style,
  ...rest
}) {
  const base = {
    font: 'inherit',
    fontFamily: 'var(--font-display)',
    fontWeight: 500,
    fontSize: fs[size] || fs.md,
    textTransform: 'uppercase',
    letterSpacing: '.14em',
    padding: pad[size] || pad.md,
    borderRadius: 'var(--radius-sm)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    display: fullWidth ? 'flex' : 'inline-flex',
    width: fullWidth ? '100%' : 'auto',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '10px',
    textDecoration: 'none',
    lineHeight: 1,
    transition: 'background var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard)',
    opacity: disabled ? 0.38 : 1
  };
  const variants = {
    primary: {
      background: 'var(--tng-navy)',
      color: 'var(--text-on-navy)'
    },
    accent: {
      background: 'var(--tng-red)',
      color: 'var(--text-on-red)'
    },
    secondary: {
      background: 'transparent',
      color: 'var(--tng-navy)',
      borderColor: 'var(--tng-navy)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-strong)',
      padding: 0,
      borderBottom: '1px solid var(--tng-red)',
      borderRadius: 0
    },
    inverse: {
      background: 'var(--tng-paper)',
      color: 'var(--tng-navy)'
    }
  };
  const El = as === 'a' ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(El, _extends({
    href: href,
    disabled: El === 'button' ? disabled : undefined,
    onClick: disabled ? undefined : onClick,
    style: {
      ...base,
      ...(variants[variant] || variants.primary),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  tone = 'paper',
  elevated = false,
  bordered = true,
  padding = 24,
  accentBar = false,
  children,
  style,
  ...rest
}) {
  const tones = {
    paper: {
      background: 'var(--surface-card)',
      color: 'var(--text-body)'
    },
    sunken: {
      background: 'var(--surface-sunken)',
      color: 'var(--text-body)'
    },
    navy: {
      background: 'var(--surface-inverse)',
      color: 'var(--text-on-navy)'
    }
  };
  const t = tones[tone] || tones.paper;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      ...t,
      padding,
      borderRadius: 'var(--radius-md)',
      border: bordered && tone !== 'navy' ? '1px solid var(--border-subtle)' : '1px solid transparent',
      boxShadow: elevated ? 'var(--shadow-2)' : 'none',
      borderTop: accentBar ? '3px solid var(--tng-red)' : undefined,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function Eyebrow({
  children,
  tone = 'muted',
  style
}) {
  const colors = {
    muted: 'var(--text-muted)',
    accent: 'var(--tng-red)',
    inverse: 'rgba(255,255,255,.72)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '11px',
      fontWeight: 400,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: colors[tone] || colors.muted,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/FlagRule.jsx
try { (() => {
function FlagRule({
  orientation = 'vertical',
  length = 120,
  thickness = 6,
  gap = 5,
  style
}) {
  const v = orientation === 'vertical';
  const bar = c => ({
    background: c,
    ...(v ? {
      width: thickness,
      height: length
    } : {
      height: thickness,
      width: length
    })
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: v ? 'row' : 'column',
      gap,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: bar('var(--tng-navy)')
  }), /*#__PURE__*/React.createElement("div", {
    style: bar('var(--tng-red)')
  }));
}
Object.assign(__ds_scope, { FlagRule });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/FlagRule.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const NAMES = ['calendar', 'clock', 'map-pin', 'users', 'user', 'mail', 'phone', 'download', 'external-link', 'chevron-right', 'chevron-down', 'arrow-right', 'check', 'x', 'triangle-alert', 'info', 'search', 'menu', 'plus', 'file-text'];
function Icon({
  name,
  size = 20,
  color = 'currentColor',
  base = 'assets/icons',
  title,
  style,
  ...rest
}) {
  const url = `${base}/${name}.svg`;
  return /*#__PURE__*/React.createElement("span", _extends({
    role: title ? 'img' : 'presentation',
    "aria-label": title,
    "aria-hidden": title ? undefined : true,
    style: {
      display: 'inline-block',
      width: size,
      height: size,
      flex: '0 0 auto',
      backgroundColor: color,
      WebkitMaskImage: `url("${url}")`,
      maskImage: `url("${url}")`,
      WebkitMaskRepeat: 'no-repeat',
      maskRepeat: 'no-repeat',
      WebkitMaskPosition: 'center',
      maskPosition: 'center',
      WebkitMaskSize: 'contain',
      maskSize: 'contain',
      verticalAlign: 'text-bottom',
      ...style
    }
  }, rest));
}
Icon.names = NAMES;
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Logo.jsx
try { (() => {
function Logo({
  height = 64,
  onDark = false,
  alt = 'Team Norway Golf',
  style
}) {
  const src = onDark ? 'logo-team-norway-golf-knockout-white.png' : 'logo-team-norway-golf-transparent.png';
  return /*#__PURE__*/React.createElement("img", {
    src: 'assets/' + src,
    alt: alt,
    style: {
      height,
      width: 'auto',
      display: 'block',
      ...style
    }
  });
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Logo.jsx", error: String((e && e.message) || e) }); }

// components/core/Stat.jsx
try { (() => {
function Stat({
  value,
  label,
  tone = 'default',
  align = 'left'
}) {
  const fg = tone === 'inverse' ? 'var(--text-on-navy)' : 'var(--text-strong)';
  const sub = tone === 'inverse' ? 'rgba(255,255,255,.7)' : 'var(--text-muted)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: align
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 300,
      fontSize: '46px',
      lineHeight: 1,
      letterSpacing: '.02em',
      color: fg
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '11px',
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: sub,
      marginTop: 10
    }
  }, label));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stat.jsx", error: String((e && e.message) || e) }); }

// components/data/Placement.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  sm: 22,
  md: 28,
  lg: 36
};
function Placement({
  rank,
  size = 'md',
  style,
  ...rest
}) {
  const d = sizes[size] || sizes.md;
  const top = Number(rank) <= 3;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: d,
      height: d,
      flex: '0 0 auto',
      fontFamily: 'var(--font-display)',
      fontWeight: top ? 500 : 400,
      fontSize: d * 0.46,
      lineHeight: 1,
      letterSpacing: '.02em',
      color: top ? 'var(--text-on-navy)' : 'var(--text-muted)',
      background: top ? 'var(--tng-navy)' : 'transparent',
      border: top ? 'none' : '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-sm)',
      fontVariantNumeric: 'tabular-nums',
      ...style
    }
  }, rest), rank);
}
Object.assign(__ds_scope, { Placement });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Placement.jsx", error: String((e && e.message) || e) }); }

// components/data/ProgressBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ProgressBar({
  value = 0,
  max = 100,
  label,
  showCount = true,
  tone = 'navy',
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  const full = pct >= 100;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: '100%',
      ...style
    }
  }, rest), (label || showCount) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      marginBottom: 7
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 10,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: 'var(--text-muted)'
    }
  }, label), showCount && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: full ? 'var(--tng-red)' : 'var(--text-body)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, value, " / ", max)), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 6,
      background: 'var(--surface-sunken)',
      borderRadius: 'var(--radius-0)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: pct + '%',
      height: '100%',
      background: tone === 'accent' || full ? 'var(--tng-red)' : 'var(--tng-navy)',
      transition: 'width var(--dur-slow) var(--ease-standard)'
    }
  })));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/data/Table.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** columns: [{ key, label, align, mono, width }] */
function Table({
  columns = [],
  rows = [],
  caption,
  dense = false,
  zebra = false,
  style,
  ...rest
}) {
  const padY = dense ? 8 : 12;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: '100%',
      ...style
    }
  }, rest), caption && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 11,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: 'var(--text-muted)',
      marginBottom: 10
    }
  }, caption), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--size-body-sm)',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      width: c.width,
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: 10,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: 'var(--text-muted)',
      padding: `0 12px ${padY}px 0`,
      borderBottom: '1px solid var(--tng-navy)',
      whiteSpace: 'nowrap'
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      background: zebra && i % 2 ? 'var(--surface-sunken)' : 'transparent'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      padding: `${padY}px 12px ${padY}px 0`,
      borderBottom: '1px solid var(--border-subtle)',
      fontFamily: c.mono ? 'var(--font-mono)' : 'inherit',
      fontVariantNumeric: c.mono ? 'tabular-nums' : 'normal',
      whiteSpace: c.mono ? 'nowrap' : 'normal'
    }
  }, r[c.key])))))));
}
Object.assign(__ds_scope, { Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Table.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open = true,
  title,
  children,
  primaryLabel = 'OK',
  secondaryLabel,
  onPrimary,
  onSecondary,
  onClose
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'rgba(1,43,93,.42)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: 'var(--surface-card)',
      maxWidth: 460,
      width: '100%',
      boxShadow: 'var(--shadow-3)',
      borderRadius: 'var(--radius-md)',
      borderTop: '3px solid var(--tng-red)',
      padding: 32
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: 'var(--size-h2)',
      letterSpacing: 'var(--track-heading)',
      margin: '0 0 12px'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--size-body-sm)',
      lineHeight: 'var(--lh-body)',
      color: 'var(--text-body)'
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'flex-end',
      marginTop: 28
    }
  }, secondaryLabel && /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "secondary",
    size: "sm",
    onClick: onSecondary
  }, secondaryLabel), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "sm",
    onClick: onPrimary
  }, primaryLabel))));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function EmptyState({
  title,
  children,
  action,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      padding: '38px 28px',
      textAlign: 'center',
      border: '1px dashed var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-sunken)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 24,
      height: 6,
      background: 'var(--tng-navy)',
      margin: '0 auto 16px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 14,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-heading)',
      color: 'var(--text-strong)'
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 8,
      lineHeight: 1.55,
      maxWidth: '46ch',
      marginLeft: 'auto',
      marginRight: 'auto'
    }
  }, children), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, action));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Notice.jsx
try { (() => {
function Notice({
  tone = 'info',
  title,
  children,
  style
}) {
  const map = {
    info: ['var(--tng-navy-050)', 'var(--tng-navy)'],
    success: ['#eef5f0', 'var(--success)'],
    warning: ['var(--tng-red-050)', 'var(--tng-red)']
  };
  const [bg, accent] = map[tone] || map.info;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: bg,
      borderLeft: '3px solid ' + accent,
      padding: '16px 20px',
      borderRadius: 'var(--radius-sm)',
      ...style
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '12px',
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: accent,
      marginBottom: 6
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--size-body-sm)',
      lineHeight: 'var(--lh-body)'
    }
  }, children));
}
Object.assign(__ds_scope, { Notice });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Notice.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Skeleton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Skeleton({
  lines = 3,
  height,
  width = '100%',
  style,
  ...rest
}) {
  const bar = (w, h, key) => /*#__PURE__*/React.createElement("div", {
    key: key,
    style: {
      width: w,
      height: h,
      background: 'var(--surface-sunken)',
      borderRadius: 'var(--radius-sm)',
      border: '1px solid var(--border-subtle)'
    }
  });
  if (height) return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width,
      ...style
    }
  }, rest), bar('100%', height));
  const widths = ['100%', '92%', '68%', '84%', '55%'];
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 9,
      width,
      ...style
    }
  }, rest), Array.from({
    length: lines
  }, (_, i) => bar(widths[i % widths.length], 11, i)));
}
Object.assign(__ds_scope, { Skeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Skeleton.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  info: {
    bar: 'var(--tng-navy)'
  },
  success: {
    bar: 'var(--success)'
  },
  warning: {
    bar: 'var(--tng-red-700)'
  }
};
function Toast({
  tone = 'info',
  title,
  children,
  onClose,
  style,
  ...rest
}) {
  const t = tones[tone] || tones.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start',
      minWidth: 280,
      maxWidth: 420,
      padding: '14px 16px',
      background: 'var(--surface-card)',
      borderLeft: '4px solid ' + t.bar,
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-2)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 11,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: 'var(--text-strong)'
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-body)',
      marginTop: title ? 6 : 0,
      lineHeight: 1.5
    }
  }, children)), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Lukk",
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 0,
      lineHeight: 1,
      fontSize: 16,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-body)'
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked = false,
  disabled = false,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'center',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      flex: '0 0 20px',
      border: '1px solid ' + (checked ? 'var(--tng-navy)' : 'var(--border-strong)'),
      background: checked ? 'var(--tng-navy)' : 'transparent',
      borderRadius: 'var(--radius-sm)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'background var(--dur-fast) var(--ease-standard)'
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 5,
      borderLeft: '2px solid #fff',
      borderBottom: '2px solid #fff',
      transform: 'rotate(-45deg) translate(1px,-2px)'
    }
  })), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--size-body-sm)'
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/ErrorSummary.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** errors: [{ field, message }] */
function ErrorSummary({
  title = 'Skjemaet mangler noe',
  errors = [],
  onJump,
  style,
  ...rest
}) {
  if (!errors.length) return null;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "alert",
    tabIndex: -1,
    style: {
      padding: '16px 18px',
      background: 'var(--tng-red-050)',
      borderLeft: '4px solid var(--tng-red-700)',
      borderRadius: 'var(--radius-sm)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 11,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: 'var(--tng-red-700)'
    }
  }, title), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: '10px 0 0',
      padding: 0,
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, errors.map((e, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      fontSize: 13,
      lineHeight: 1.5
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: '#' + (e.field || ''),
    onClick: onJump ? ev => {
      ev.preventDefault();
      onJump(e);
    } : undefined,
    style: {
      color: 'var(--tng-red-700)',
      textDecoration: 'none',
      borderBottom: '1px solid currentColor'
    }
  }, e.message)))));
}
Object.assign(__ds_scope, { ErrorSummary });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/ErrorSummary.jsx", error: String((e && e.message) || e) }); }

// components/forms/Fieldset.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Fieldset({
  legend,
  hint,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("fieldset", _extends({
    style: {
      border: 'none',
      borderTop: '1px solid var(--tng-navy)',
      margin: 0,
      padding: '18px 0 0',
      ...style
    }
  }, rest), legend && /*#__PURE__*/React.createElement("legend", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 11,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: 'var(--text-strong)',
      padding: '0 12px 0 0'
    }
  }, legend), hint && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-muted)',
      marginBottom: 18,
      maxWidth: '56ch',
      lineHeight: 1.55
    }
  }, hint), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, children));
}
Object.assign(__ds_scope, { Fieldset });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Fieldset.jsx", error: String((e && e.message) || e) }); }

// components/forms/FileUpload.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function FileUpload({
  label,
  hint,
  accept,
  multiple = false,
  files = [],
  onFiles,
  disabled = false,
  style,
  ...rest
}) {
  const ref = React.useRef(null);
  const [over, setOver] = React.useState(false);
  const take = list => onFiles && onFiles(Array.from(list || []));
  return /*#__PURE__*/React.createElement("div", _extends({
    style: style
  }, rest), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 11,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: 'var(--text-muted)',
      display: 'block',
      marginBottom: 8
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    onClick: () => !disabled && ref.current && ref.current.click(),
    onDragOver: e => {
      e.preventDefault();
      setOver(true);
    },
    onDragLeave: () => setOver(false),
    onDrop: e => {
      e.preventDefault();
      setOver(false);
      if (!disabled) take(e.dataTransfer.files);
    },
    style: {
      padding: '22px 18px',
      textAlign: 'center',
      cursor: disabled ? 'not-allowed' : 'pointer',
      border: '1px dashed ' + (over ? 'var(--tng-navy)' : 'var(--border-strong)'),
      borderRadius: 'var(--radius-sm)',
      background: over ? 'var(--tng-navy-050)' : 'var(--surface-sunken)',
      opacity: disabled ? 0.5 : 1,
      transition: 'background var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 11.5,
      textTransform: 'uppercase',
      letterSpacing: '.14em',
      color: 'var(--tng-navy)'
    }
  }, "Velg fil"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 12.5,
      color: 'var(--text-muted)',
      marginTop: 7
    }
  }, "eller dra den hit"), /*#__PURE__*/React.createElement("input", {
    ref: ref,
    type: "file",
    accept: accept,
    multiple: multiple,
    disabled: disabled,
    onChange: e => take(e.target.files),
    style: {
      display: 'none'
    }
  })), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 'var(--size-caption)',
      color: 'var(--text-muted)',
      marginTop: 7
    }
  }, hint), !!files.length && /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: '11px 0 0',
      padding: 0,
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 5
    }
  }, files.map((f, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11.5,
      color: 'var(--text-body)',
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      borderBottom: '1px solid var(--border-subtle)',
      paddingBottom: 5
    }
  }, /*#__PURE__*/React.createElement("span", null, f.name || f), f.size != null && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, Math.round(f.size / 1024), " kB")))));
}
Object.assign(__ds_scope, { FileUpload });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/FileUpload.jsx", error: String((e && e.message) || e) }); }

// components/forms/FormRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function FormRow({
  columns = 2,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
      gap: 18,
      alignItems: 'start',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { FormRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/FormRow.jsx", error: String((e && e.message) || e) }); }

// components/forms/HelpText.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function HelpText({
  tone = 'muted',
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'block',
      fontSize: 'var(--size-caption)',
      lineHeight: 1.55,
      color: tone === 'error' ? 'var(--danger)' : 'var(--text-muted)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { HelpText });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/HelpText.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const fieldStyle = (invalid, disabled) => ({
  fontFamily: 'var(--font-body)',
  fontSize: 'var(--size-body)',
  color: 'var(--text-strong)',
  background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
  border: '1px solid ' + (invalid ? 'var(--danger)' : 'var(--border-subtle)'),
  borderBottomWidth: '2px',
  borderBottomColor: invalid ? 'var(--danger)' : 'var(--tng-navy-400)',
  borderRadius: 'var(--radius-sm)',
  padding: '11px 14px',
  width: '100%',
  boxSizing: 'border-box',
  outline: 'none'
});
function Input({
  label,
  hint,
  invalid = false,
  disabled = false,
  type = 'text',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '11px',
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: 'var(--text-muted)',
      display: 'block',
      marginBottom: 8
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    disabled: disabled,
    style: fieldStyle(invalid, disabled)
  }, rest)), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--size-caption)',
      color: invalid ? 'var(--danger)' : 'var(--text-muted)',
      display: 'block',
      marginTop: 6
    }
  }, hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function Radio({
  label,
  checked = false,
  disabled = false,
  name,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'center',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      flex: '0 0 20px',
      borderRadius: '50%',
      border: '1px solid ' + (checked ? 'var(--tng-navy)' : 'var(--border-strong)'),
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: 'var(--tng-navy)'
    }
  })), /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--size-body-sm)'
    }
  }, label));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const fieldStyle = (invalid, disabled) => ({
  fontFamily: 'var(--font-body)',
  fontSize: 'var(--size-body)',
  color: 'var(--text-strong)',
  background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
  border: '1px solid ' + (invalid ? 'var(--danger)' : 'var(--border-subtle)'),
  borderBottomWidth: '2px',
  borderBottomColor: invalid ? 'var(--danger)' : 'var(--tng-navy-400)',
  borderRadius: 'var(--radius-sm)',
  padding: '11px 14px',
  width: '100%',
  boxSizing: 'border-box',
  outline: 'none'
});
function Select({
  label,
  options = [],
  disabled = false,
  invalid = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '11px',
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: 'var(--text-muted)',
      display: 'block',
      marginBottom: 8
    }
  }, label), /*#__PURE__*/React.createElement("select", _extends({
    disabled: disabled,
    style: {
      ...fieldStyle(invalid, disabled),
      appearance: 'none',
      backgroundImage: 'linear-gradient(45deg,transparent 50%,var(--tng-navy) 50%),linear-gradient(135deg,var(--tng-navy) 50%,transparent 50%)',
      backgroundPosition: 'calc(100% - 20px) 50%,calc(100% - 14px) 50%',
      backgroundSize: '6px 6px,6px 6px',
      backgroundRepeat: 'no-repeat'
    }
  }, rest), options.map(o => /*#__PURE__*/React.createElement("option", {
    key: typeof o === 'string' ? o : o.value,
    value: typeof o === 'string' ? o : o.value
  }, typeof o === 'string' ? o : o.label))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  label,
  checked = false,
  disabled = false,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'center',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: disabled ? undefined : onChange,
    style: {
      width: 44,
      height: 24,
      flex: '0 0 44px',
      borderRadius: 'var(--radius-pill)',
      background: checked ? 'var(--tng-navy)' : 'var(--tng-ink-300)',
      position: 'relative',
      transition: 'background var(--dur-base) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 3,
      left: checked ? 23 : 3,
      width: 18,
      height: 18,
      borderRadius: '50%',
      background: '#fff',
      transition: 'left var(--dur-base) var(--ease-standard)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--size-body-sm)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Navbar.jsx
try { (() => {
function Navbar({
  items = [],
  active,
  onNavigate,
  cta,
  tone = 'light',
  logoBase = 'assets'
}) {
  const dark = tone === 'dark';
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 40,
      padding: '20px var(--gutter-page)',
      background: dark ? 'var(--tng-navy)' : 'var(--surface-card)',
      borderBottom: '1px solid ' + (dark ? 'var(--border-inverse)' : 'var(--border-subtle)')
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: logoBase + '/' + (dark ? 'logo-team-norway-golf-knockout-white.png' : 'logo-team-norway-golf-transparent.png'),
    alt: "Team Norway Golf",
    style: {
      height: 46
    }
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 28,
      marginLeft: 'auto'
    }
  }, items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it,
    onClick: () => onNavigate && onNavigate(it),
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--font-display)',
      fontSize: '12px',
      textTransform: 'uppercase',
      letterSpacing: '.16em',
      color: dark ? it === active ? '#fff' : 'rgba(255,255,255,.66)' : it === active ? 'var(--text-strong)' : 'var(--text-muted)',
      paddingBottom: 3,
      borderBottom: '1px solid ' + (it === active ? 'var(--tng-red)' : 'transparent')
    }
  }, it))), cta && /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: dark ? 'inverse' : 'accent',
    size: "sm"
  }, cta));
}
Object.assign(__ds_scope, { Navbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Navbar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  onChange,
  tone = 'default'
}) {
  const inverse = tone === 'inverse';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 32,
      borderBottom: '1px solid ' + (inverse ? 'var(--border-inverse)' : 'var(--border-subtle)')
    }
  }, items.map(it => {
    const key = typeof it === 'string' ? it : it.value;
    const label = typeof it === 'string' ? it : it.label;
    const active = key === value;
    return /*#__PURE__*/React.createElement("button", {
      key: key,
      onClick: () => onChange && onChange(key),
      style: {
        background: 'none',
        border: 'none',
        padding: '0 0 12px',
        cursor: 'pointer',
        fontFamily: 'var(--font-display)',
        fontSize: '12px',
        textTransform: 'uppercase',
        letterSpacing: '.16em',
        color: active ? inverse ? '#fff' : 'var(--text-strong)' : inverse ? 'rgba(255,255,255,.6)' : 'var(--text-muted)',
        borderBottom: '2px solid ' + (active ? 'var(--tng-red)' : 'transparent'),
        marginBottom: '-1px'
      }
    }, label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/people/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const initials = n => (n || '').trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
function Avatar({
  name = '',
  src,
  size = 44,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: size,
      height: size,
      flex: '0 0 auto',
      borderRadius: 'var(--radius-sm)',
      overflow: 'hidden',
      background: 'var(--tng-navy)',
      color: 'var(--text-on-navy)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-display)',
      fontSize: size * 0.34,
      letterSpacing: '.06em',
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    }
  }) : initials(name));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/people/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/people/PlayerCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function PlayerCard({
  name,
  club,
  hcp,
  year,
  photo,
  note,
  tone = 'paper',
  style,
  ...rest
}) {
  const dark = tone === 'navy';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start',
      padding: 16,
      background: dark ? 'var(--surface-inverse)' : 'var(--surface-card)',
      color: dark ? 'var(--text-on-navy)' : 'var(--text-body)',
      border: dark ? '1px solid transparent' : '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: name,
    src: photo,
    size: 48,
    style: dark ? {
      background: 'var(--tng-paper)',
      color: 'var(--tng-navy)'
    } : undefined
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 15,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-heading)',
      color: dark ? 'var(--text-on-navy)' : 'var(--text-strong)',
      lineHeight: 1.25
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: dark ? 'rgba(255,255,255,.72)' : 'var(--text-muted)',
      marginTop: 4
    }
  }, [club, year].filter(Boolean).join(' · ')), note && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      marginTop: 7,
      lineHeight: 1.5,
      color: dark ? 'rgba(255,255,255,.86)' : 'var(--text-body)'
    }
  }, note)), hcp != null && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right',
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 17,
      color: dark ? 'var(--text-on-navy)' : 'var(--text-strong)',
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1
    }
  }, hcp), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 8.5,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: dark ? 'rgba(255,255,255,.62)' : 'var(--text-muted)',
      marginTop: 5
    }
  }, "hcp")));
}
Object.assign(__ds_scope, { PlayerCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/people/PlayerCard.jsx", error: String((e && e.message) || e) }); }

// components/program/DateRange.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const pad = n => String(n).padStart(2, '0');
const parse = d => d instanceof Date ? d : new Date(d);
const fmt = d => `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`;
function DateRange({
  from,
  to,
  size = 'md',
  tone = 'default',
  style,
  ...rest
}) {
  const a = from ? parse(from) : null;
  const b = to ? parse(to) : null;
  let text = '';
  if (a && b) {
    const sameYear = a.getFullYear() === b.getFullYear();
    const sameMonth = sameYear && a.getMonth() === b.getMonth();
    text = sameMonth ? `${pad(a.getDate())}.–${fmt(b)}` : sameYear ? `${pad(a.getDate())}.${pad(a.getMonth() + 1)}.–${fmt(b)}` : `${fmt(a)}–${fmt(b)}`;
  } else if (a) text = fmt(a);
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: size === 'sm' ? 11 : size === 'lg' ? 15 : 12.5,
      color: tone === 'muted' ? 'var(--text-muted)' : 'var(--text-body)',
      fontVariantNumeric: 'tabular-nums',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), text);
}
Object.assign(__ds_scope, { DateRange });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/program/DateRange.jsx", error: String((e && e.message) || e) }); }

// components/program/ScheduleItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ScheduleItem({
  time,
  endTime,
  title,
  place,
  note,
  tone = 'default',
  style,
  ...rest
}) {
  const past = tone === 'past';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'grid',
      gridTemplateColumns: '78px 1fr',
      gap: 16,
      alignItems: 'baseline',
      padding: '13px 0',
      borderBottom: '1px solid var(--border-subtle)',
      opacity: past ? 0.45 : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12.5,
      color: tone === 'now' ? 'var(--tng-red)' : 'var(--text-body)',
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1.5
    }
  }, time, endTime && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "\u2013", endTime)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 14,
      fontWeight: 400,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-heading)',
      color: 'var(--text-strong)',
      lineHeight: 1.3
    }
  }, title), (place || note) && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--size-caption)',
      color: 'var(--text-muted)',
      marginTop: 4,
      lineHeight: 1.5
    }
  }, place, place && note ? ' · ' : '', note)));
}
Object.assign(__ds_scope, { ScheduleItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/program/ScheduleItem.jsx", error: String((e && e.message) || e) }); }

// components/program/Timeline.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** days: [{ label, date, items: [{ time, title, place }] }] */
function Timeline({
  days = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${days.length || 1}, minmax(0, 1fr))`,
      gap: 1,
      background: 'var(--border-subtle)',
      ...style
    }
  }, rest), days.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: 'var(--surface-card)',
      padding: '14px 14px 18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 11,
      textTransform: 'uppercase',
      letterSpacing: 'var(--track-eyebrow)',
      color: 'var(--text-strong)'
    }
  }, d.label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-muted)',
      marginTop: 3
    }
  }, d.date), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--tng-navy)',
      margin: '11px 0 4px'
    }
  }), (d.items || []).map((it, j) => /*#__PURE__*/React.createElement("div", {
    key: j,
    style: {
      padding: '8px 0',
      borderBottom: j < d.items.length - 1 ? '1px solid var(--border-subtle)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-muted)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, it.time), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-body)',
      lineHeight: 1.45,
      marginTop: 2
    }
  }, it.title), it.place && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, it.place))))));
}
Object.assign(__ds_scope, { Timeline });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/program/Timeline.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.FlagRule = __ds_scope.FlagRule;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Placement = __ds_scope.Placement;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.Notice = __ds_scope.Notice;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.ErrorSummary = __ds_scope.ErrorSummary;

__ds_ns.Fieldset = __ds_scope.Fieldset;

__ds_ns.FileUpload = __ds_scope.FileUpload;

__ds_ns.FormRow = __ds_scope.FormRow;

__ds_ns.HelpText = __ds_scope.HelpText;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Navbar = __ds_scope.Navbar;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.PlayerCard = __ds_scope.PlayerCard;

__ds_ns.DateRange = __ds_scope.DateRange;

__ds_ns.ScheduleItem = __ds_scope.ScheduleItem;

__ds_ns.Timeline = __ds_scope.Timeline;

})();
