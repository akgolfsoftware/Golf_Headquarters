# Team Norway Golf — Design System

Brand and interface system for **Team Norway Golf**, built from the single asset supplied by the client: `uploads/teamnorwaygolf.jpg` (the logo, JPG on white). No codebase, Figma file, website, deck or written brand guide was provided, so everything below is derived from the logo itself plus the golf-programme context the client described (presentations, documents, letters, email, social posts for Facebook/Instagram/Snapchat, posters, video and image assets).

## Sources
- `uploads/teamnorwaygolf.jpg` — supplied logo, 930×930 JPG, white background. The only ground truth.
- No Figma link, repository or live site was given. Anything not visible in the logo (fonts, secondary palette, tone of voice specifics) is a **proposal** and marked as such.

## Brand context
Team Norway Golf reads as a national-team-style golf programme: a squad identity for Norwegian players, with a parent/club-facing administrative side (training weeks, tournament schedules, entries, reports) and an outward-facing side (social media, posters, video). The visual language is deliberately understated — the nation, not the player, is the loudest element: two flag bars, thin geometric caps, and a lot of white.

## Logo
Two files, both derived programmatically from the supplied JPG (never redrawn):
- `assets/logo-team-norway-golf-transparent.png` — trimmed, white knocked out to alpha. Primary, for light grounds.
- `assets/logo-team-norway-golf-knockout-white.png` — white ink on transparent ground (red bar retained). Use on navy, photography and any dark field.
- `assets/logo-team-norway-golf-white.png` — trimmed, white ground retained. Print and placements that need a solid white plate behind the mark.

No vector original was supplied. **Ask the client for an AI/EPS/PDF/SVG master** — the PNGs will not scale cleanly beyond roughly 800px wide or print above A4.
Clearspace: the height of the flag bars on every side (≈32px at a 120px-tall mark). Minimum width 120px on screen, 30mm in print. Never recolour, stretch, add effects, or set the wordmark in a different typeface.

## CONTENT FUNDAMENTALS
Language is **Norwegian bokmål** first, English for international tournaments and sponsors. Copy is practical and low-drama — a coach speaking plainly to players and parents.

- **Person:** "vi" for the programme, "du/dere" for players and parents. Never third-person about ourselves ("Team Norway Golf tilbyr …" → "Vi trener …").
- **Sentence length:** short, declarative, verb-forward. One idea per sentence. Facts before framing: *"Påmelding stenger 1. mars. Plassene er begrenset til 24 spillere."*
- **Casing:** display type and labels are ALL CAPS with wide tracking (mirroring the wordmark). Headings and body are sentence case — never Title Case in Norwegian.
- **Emoji:** never in official communication (letters, email, documents, decks, posters). Acceptable *sparingly* in Instagram/Snapchat captions, and then only 🇳🇴⛳ — never as bullets or section markers.
- **Numbers:** always concrete. Scores, dates, times and figures in mono (`--font-mono`) when they are data; in body type when they are prose.
- **Words we use:** økt, samling, treningsuke, sesongmål, kvalifisering, rangering, spiller, lag, foresatt.
- **Words we avoid:** "reise" as a metaphor, "unlock/potensial", "verdensklasse", superlatives without a number, exclamation marks (max one per piece, and rarely).
- **Examples**
  - Headline: *Sesongen 2026*  · Eyebrow: *TURNERINGSRAPPORT · 2026*
  - CTA: *Meld på* / *Les programmet* — imperative, two words, no "her".
  - Instagram caption: *Fire dager i Spania. To økter om dagen. Sesongen starter nå.*

## VISUAL FOUNDATIONS
- **Colour.** Navy `#012B5D` and red `#D40E3A` sampled directly from the logo, on white. Navy is structural (headers, inverse panels, links, primary buttons); red is *accent only* — one red element per composition, never a body-text background. Ink `#141414` for type, `#6B6B6B` for secondary. One supporting colour outside the flag: fairway green `#1F6B45`, used only for "success/qualified" states. Max two background colours per deck or document: white and navy.
- **Type.** Display = geometric sans, Light (300), ALL CAPS, .16em tracking — the wordmark's voice, used for titles, buttons, labels, stats. Body = humanist sans, 16px/1.62, 66ch measure. Data = mono. Display type never below 24px on a 1920×1080 slide; body never below 12pt in print.
- **Layout.** Asymmetric, left-aligned, generous white space. A vertical flag rule or the wordmark anchors the top-left; content hangs off a single strong left margin (`--gutter-page`). Full-bleed photography for openers and posters; white pages for anything that has to be read. Fixed elements: header/nav at top, page footer with wordmark at 46px.
- **Backgrounds.** Plain white or plain navy. No gradients as decoration — the single permitted gradient is `--overlay-scrim`, a navy-to-transparent protection scrim under text on photography. No patterns, no textures, no hand-drawn illustration.
- **Imagery.** Photography only (course, players, weather), cool-toned and natural: Nordic light, green turf, grey-blue sky. No heavy grain, no warm filters, no duotone. Crop wide and let the horizon run. Always place text over the scrim, never over open sky-to-turf contrast. Black-and-white is reserved for group and environment shots (see `assets/images/juniorer-putting-bw.png`). The client-supplied library lives in `assets/images/`: `spiller-ved-vannet.jpg` (full-bleed opener), `putting-green.jpg`, `tee-naerbilde.jpg`, `baller-ngf.jpg`, `barn-putting-farge.png`, `juniorer-putting-bw.png`. `assets/reference/ngf-aarsrapport-oppslag.png` is a Norges Golfforbund annual-report spread kept **as reference only** — its purple palette belongs to NGF, not to this system, and must not be adopted.
- **Borders & radii.** Hairline 1px `--border-subtle`. Radii are near-square: 0 for full-bleed and slides, 2px for buttons and inputs, 4px for cards. The only pill in the system is the Switch track.
- **Shadows.** Flat by default. `--shadow-1` for a hairline lift, `--shadow-2` for cards and dropdowns, `--shadow-3` for modals. All shadows are tinted navy, never neutral black. No inner shadows.
- **Motion.** Restrained and fast: 120/200/340ms on `cubic-bezier(.2,.6,.2,1)`. Fades and 8–16px translations only — no bounce, no spring, no scale-in-from-zero. Slide transitions cut or cross-fade. Respects `prefers-reduced-motion`.
- **States.** Hover = fill darkens one step (navy → `--tng-navy-700`), or on ghost/text the red underline appears. Press = no shrink; the fill darkens a second step. Focus = 2px `--focus-ring` (red) outline, offset 2px — visible, never removed. Disabled = 38% opacity, no colour change.
- **Transparency & blur.** Almost never. Permitted: the navy 42% dialog scrim, and white at 66–72% for captions over photography. No frosted glass, no backdrop blur.

## ICONOGRAPHY
No icon set was supplied with the logo, and none was drawn. The system now ships a **closed set of 20 icons** in `assets/icons/`, vendored from Lucide (MIT) and normalised to 1.5px stroke with square caps — the closest match to the logo's thin, geometric line. They are self-hosted; nothing is fetched at render time. Rules:
- Prefer *no* icon. Caps labels and the flag rule carry hierarchy in this brand; most UI does not need glyphs.
- The set is closed: `calendar clock map-pin users user mail phone download external-link chevron-right chevron-down arrow-right check x triangle-alert info search menu plus file-text`. A 21st icon is a system decision, not a page decision.
- Render them through the `Icon` component so they inherit `currentColor`. Never colour one red on its own — red is one accent per surface, and a 20px glyph is never worth spending it on.
- Sizes: 16 in dense tables, 20 in body text, 24 in navigation. Set the icon 4px under the cap height of any uppercase label it sits beside — the label stays the loudest thing in the row.
- Provenance: Lucide (MIT), `https://unpkg.com/lucide-static@0.544.0` — the closest match to the logo's thin, geometric, uniform-weight line. **This is a substitution**; replace the folder if the client has an existing set.
- Purely decorative marks (chevrons, checkmarks) are drawn in CSS inside the components (Select, Checkbox) rather than pulled in as assets.
- Emoji are not iconography here — see CONTENT FUNDAMENTALS.
- Unicode symbols are allowed as typographic connectors only: · – → ° and the flag 🇳🇴 in social captions.

## LÅST vs. VENTER

**Låst — endres ikke uten ny beslutning**
- Logo kun fra de tre PNG-ene i `assets/`. Aldri redraw, aldri satt på nytt i Jost. NGF-løven/skjoldet rekonstrueres aldri.
- Navy `#012B5D`, rød `#D40E3A` (én gang per flate), paper hvit. Fairway `#1F6B45` kun success, rød-700 `#A60B2D` kun frist/feil. Ingen nye farger, ingen NGF-lilla, ingen krem eller gull.
- Jost Light ALL CAPS `.16em` / Lato 16/1,62 / IBM Plex Mono for data. Dato `dd.mm.åååå`.
- FlagRule er det eneste grafiske grepet. Radius 0 / 2 / 4. Lukket ikonsett på 20 — ingen andre glyfer.
- Foto med navy-scrim (0,55 / 0,78 / 0,88). Kjølig og naturlig, ingen filter.
- Bokmål, vi om programmet, du/dere om spiller og foresatt. Økt, spiller, samling. CTA på to ord uten «her».
- Motion 120 / 200 / 340 ms på `cubic-bezier(.2,.6,.2,1)`. Fade og 8–16 px. Ingen sprett.
- Ingen app, ingen produkt-UI: systemet dekker kommunikasjonsflater.

**Venter på kunden**
- **Vektorfil av logoen** (AI/EPS/PDF/SVG). PNG-ene tåler 829 px ≈ 70 mm ved 300 dpi. Plakat A3, rollup og storformat er blokkert til vektor foreligger — se kortet «MANGLER VEKTOR».
- **Skriftfil eller navn på ordmerkets typesnitt.** Jost er nærmeste match, ikke identisk; byttes i `tokens/fonts.css` alene.
- **NGF-merket som vektor**, hvis lockup skal brukes. Plassholderen i NGF-lockup-kortet står tom med vilje.
- Flere foto: portrett 9:16 og vinterøkt innendørs mangler i biblioteket.

## Typeface substitution (needs client input)
The wordmark's original typeface was not supplied. The system specifies **Jost** (Futura-lineage geometric sans, Google Fonts) for display and **Lato** for body, with **IBM Plex Mono** for data. Jost is a close but not exact match to the logo's caps. **Please send the licensed original font files** (or name the typeface) and the substitution will be swapped out in `tokens/fonts.css` alone.

## Index
- `styles.css` — the single entry point consumers link. `@import` lines only.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `elevation.css`, `motion.css`.
- `assets/` — three logo files (transparent, knockout-white, white-ground), `assets/fonts/` self-hosted woff2 (Jost variable, Lato, IBM Plex Mono — latin + latin-ext), `assets/icons/` the closed 20-icon set, `assets/images/` photo library, `assets/reference/` non-brand reference material.
- `guidelines/` — 47 specimen cards in groups Brand, Colors, Type, Spacing, Motion, Voice: logo (varianter, do/don't, NGF-lockup, minstemål, MANGLER VEKTOR), ikoner (hele settet), type (Jost mot ordmerket, typeplakat, grid A4/16:9/9:16, FlagRule i tre lengder), farge (**kontrastmatrise som regnes ut fra tokens ved innlasting**, kontrast på foto, semantikk, tre scrim-styrker), foto do/don't, **do/don't per komponentgruppe**, **anatomi for knapp, felt og kort**, motion 120/200/340, video-outro + 9:16 trygg sone, stemme (setninger, ordbok, CTA).
- `components/core/` — Button, Logo, FlagRule, Card, Badge, Eyebrow, Stat, Icon.
- `components/forms/` — Input, Select, Checkbox, Radio, Switch, Fieldset, FormRow, HelpText, ErrorSummary, FileUpload.
- `components/navigation/` — Navbar, Tabs.
- `components/feedback/` — Dialog, Notice, EmptyState, Skeleton, Toast.
- `components/data/` — Table, Placement, ProgressBar.
- `components/program/` — ScheduleItem, Timeline, DateRange.
- `components/people/` — PlayerCard, Avatar.
- `templates/` — ready-to-copy starting artefacts:
  - `presentation/` Presentasjon (6 lysbilder, 1280×720)
  - `brev/` Brev og dokument (A4)
  - `rapport/` Rapport (3 sider A4, tabeller + nøkkeltall)
  - `program/` Program og sportsplan (2 sider A4)
  - `tilbud/` Tilbud og møtereferat (2 sider A4)
  - `epost/` E-post (600px, tabellbasert)
  - `sosiale-instagram/` Instagram 1:1, 4:5, 9:16, karusell
  - `sosiale-facebook/` Facebook lenkebilde, feed, cover, arrangement + LinkedIn-banner
  - `sosiale-story/` Snapchat, TikTok/Reels, story-resultatliste + YouTube-miniatyr
  - `plakat/` Plakat A3 (navy og hvit), diplom A4 liggende, rollup 850×2000 mm
  - `sosiale-medier/` samlekort med de vanligste formatene
  - `turnering/` Turneringsinnbydelse A4 + påmeldingsskjema
  - `ukeplan/` Ukeplan A4 liggende (hele uken + én dag i detalj)
  - `resultatliste/` Resultatliste A4 + story 1080×1920
  - `uttak/` Uttak og tropp A4 + feed 1080×1350
  - `signatur/` E-postsignatur i tre lengder + Teams/Zoom-bakgrunn
- `content/` — `no.json` and `en.json`: CTA strings, labels, states and number formats for both language layers. English is not a word-for-word translation — see the "Engelsk lag" card under Voice.

  Lys og navy finnes nå i presentasjon, brev, e-post, rapport, program, plakat, Instagram og story. `tilbud/` og `rapport`-innsidene er bevisst kun lyse: de leses, og navy paper koster lesbarhet.
- `thumbnail.html` — the system's homepage tile.
- `CHANGELOG.md` — semantic version history: what changed, why, and what you have to do about it.
- `CONTRIBUTING.md` — who may change what, the six-point checklist before a component ships, and the quarterly review.
- `decisions.md` — why the rules are the rules. Read this before arguing with one.
- `SKILL.md` — makes this folder usable as an Agent Skill.

### Intentional additions
- **Logo** — a component wrapper so consumers reference the supplied files instead of retyping the wordmark.
- **FlagRule** — the logo's two bars as a reusable accent; it is the brand's only graphic device.
- **Eyebrow / Stat** — the two typographic patterns the surfaces the client listed (decks, reports, social) need repeatedly.

### Not built (no source)
No UI kit is included: the client has no app or website in the supplied material. Building one would mean inventing a product. If a site or member portal exists, send the URL or repository and it will be recreated properly.
