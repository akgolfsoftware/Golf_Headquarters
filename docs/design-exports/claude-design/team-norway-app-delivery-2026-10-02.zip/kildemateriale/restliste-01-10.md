# Restliste — bestilling fra Anders 01.10.2026 (mottatt)

Status: mottatt og planlagt i Team Norway App.dc.html. Ingen endringer er gjort i appen i denne omgangen, fordi kapasitetsgrensen ble nådd før første bygg. Ingenting er godkjent, publisert eller endret i tilgang.

## Utgangspunkt som bevares
- Skjerm-ID-er og nyeste rettinger: Wedge Gate 9 slag (Treff/Bom, «X / 9 treff»), AK-kategori A–K etter brutto snittscore, nivåregler (Ung 8.–10. klasse, født 2011–2013; Junior til og med året man fyller 19; WANG etter klassetrinn), fireukersoppfølging bare WANG/TN, delingslenke 7 dager.
- Gjeldende utviklingssjekk i appen er 2025-versjonen (skala 1–8, Ung 34 · Junior 41 · Amatør 41 · Profesjonell 38). Den beholdes som historikk med sin versjon og omregnes ikke.

## Må bygges (i rekkefølge)
1. **IUP 2027-kilde.** Lagre den personfrie JSON-malen ordrett i `kildemateriale/iup-2027.json` (versjon `iup-2027-kilde-2026-10-01`). Bytt utviklingssjekken til 34/43/47/38 spørsmål med skala 1–5 og instruksen «1 ikke i det hele tatt oppfylt … 5 helt oppfylt». Vis versjon på hvert svar. Gamle 2025-svar vises med 1–8 og egen versjonsmerking.
2. **Sesongevaluering (X04).** Tre fritekstsvar, ti spørsmål 1–4, faktisk og ønsket prosentfordeling på fem pyramideområder, minst tre forbedringspunkter med «Lag prosessmål» som tar med kilde og begrunnelse.
3. **Deling per organisasjon.** Statuser: ikke delt · venter på foresatt · aktiv · begrenset · trukket · ingen tilgang. Separat samtykke for WANG og for Team Norway. Stopp av WANG-deling stopper ikke TN. Ingen helse/private opplysninger uten nytt samtykke. Ingen lekkasje i lister, varsler, tellere, direkte lenker eller eksport. Invitasjonens 7 dager er ikke varigheten på etablert deling.
4. **Tilstander.** Legg til lagringsfeil, ingen tilgang og trukket (i tillegg til data · tom · laster · feil) på spillerflatene, også ved direkte lenke.
5. **Klikkbar reise.** Trenerliste → delt spiller → mål/evaluering → år/periode/uke/økt → faktisk trening/test → vurdering → forslag → spillerbeslutning. Trenerens vurdering og forslag er egne objekter, atskilt fra spillerens svar. Endret kilde før godkjenning gir konflikt. Dobbeltklikk og avslag endrer ikke planen.
6. **Funksjonsregister X01–X18** som egen skjerm: eksakt skjerm-ID, fil, inngang, felt, handling og tilstand, med separat status for design · kode · beregning · tilgang · brukerreise. Bare «tegnet» der det faktisk er tegnet.
7. **Detaljkrav som ikke må forsvinne.**
   - Ark 3: ranking, brutto turnering/utenfor turnering, beste/verste, SG totalt/utslag/innspill (100–150, 151–200)/nærspill/putting, putting per intervall (0–3, 3–5, 5–10, 10–15, 15–25, 25–40, 40+ fot), PEI totalt og 40–80 … 200+ m, slaglengde, avvik fra mållinje, FT %, GIR %, scrambling %, antall konkurranser/runder, treningsrunder 9/18, golf- og fysisk tid. Manglende data er ukjent, ikke 0.
   - Teknikktest: sju felt (Swing Direction, Club Path, Attack Angle, Face to Path, Spin Loft, Smash Factor, Club Speed). Motstrid i A/B-områder krever én versjonert protokoll før beregning.
   - Kildeavvik (dagbokens år, J2/J4 summerer antall og tid, D33/H33, MEDIAN mot AVERAGE, fysisk score B9, yards × 0,9, eksempelbilder) skal føres som regresjonstilfeller, ikke kopieres som fasit.
   - Standard fysisk batteri er uendret. 3000 m og CMJ innføres ikke.
8. **Måling.** 390 og 1280/1440, alle tilstander, tastatur, minst 44 px, scrollWidth === clientWidth. Se berørte skjermer visuelt.

## Samordning og ansvar (rettet 01.10)
Tre prosjekter, ingen flere:
- **Precision**: 7d7c2994-cf63-4c5f-9bdc-fdaf67655a70
- **Team Norway App delivery**: dette prosjektet (Team Norway-trenerflaten, X01–X18 i TN-drakt)
- **WANG Golf UI prototype**: https://claude.ai/design/p/6cfa623c-b2c7-494f-b1bd-9c254b02f335 — eneste WANG-prosjekt for hele X01–X18: trenerhjem, elevliste, skolekontekst, planlegging, tester og deling.

Anders: «Ikke to ulike Wang prosjekter.» Den tidligere ansvarsdelingen mot WANG Toppidrett Software (e77c6ef7) var feil og er trukket tilbake. Ingen avhengighet til Software-prosjektet.

Overleveringskontrakt: samme X01–X18-register, samme spillerdata og samme delingsregler i alle tre prosjekter. WANG-flatene hentes ikke herfra, og denne filen kopierer ikke WANG-skjermer. Skjerm-ID-er og nyeste rettinger i hvert prosjekt bevares.

## Ikke i dette arbeidet
Ingen import av arbeidsbok, ingen appkode, ingen tilgangsendring, ingen publisering, ingen automatisk godkjenning. Koordinering med Precision og WANG Golf UI prototype skjer når Team Norway-versjonen er tegnet.
