# Team Norway App delivery: faste instrukser

## Språkregel (Anders 02.10.2026)
- AK Golf HQs ordbok `docs/treningsplanlegging.md` er ENESTE master for norsk ordvalg, staving, menynavn, statuser, meldinger, tall/enheter og treningsbegreper. Kopi: `kildemateriale/treningsplanlegging-master.md` (kopiert fra Precision `guidelines/treningsplanlegging-master.md`, låst 30.09.2026, PR #1061).
- Gjelder alle Team Norway-skjermer: testbatteri, felles testdag, IUP, Workbench og overlevering.
- Ved konflikt vinner masteren over eldre TN-terminologikort, prototypetekst og Excel-etiketter.
- Står ordet ikke i masteren: behold dagens tekst og merk det uavklart. Ikke gjett.
- Eksempler: Spiller (ikke elev som approlle) · Coach · Målsetning (det spilleren sikter mot; «mål» bare om måltall) · Øvelse (ikke drill) · Registrer (føre data) · Økt · Nærspill · Spesialperiode · Gjennomført (økt) · Låst/Åpen.
- Statusord: Lagring = Ikke lagret · Lagrer · Lagret · Kunne ikke lagres. Plan = Utkast · Venter på spiller · Godtatt · Avvist · Aktiv · Arkivert. Økt = Planlagt · Pågår · Gjennomført · Avlyst · Hoppet over.
- Meldinger: «Lagret.» · «Endringene kunne ikke lagres. Prøv igjen.» · «Ingen målinger ennå.»
- Tall: bokmål, desimalkomma, mellomrom før % og enhet (73 %, 150 m), tusenskille med mellomrom, kl. 09:00, putting i fot, øvrige avstander i meter, Club/Ball Speed i mph. Manglende verdi «—», reell null 0. Brutto score.
- TrackMan-parametere beholder engelsk navn (Attack Angle, Club Path, Face Angle …).
- Team Norway beholder sitt eget visuelle designsystem. Masteren styrer bare språk.

## Uavklart mot masteren (bevart til Anders avgjør)
- Fagroller som «Fysisk trener», «Mental trener», «Svingtrener» og skjermnavnet «Trenere og tilgang»: masteren sier Coach om AK Golfs coach. For NGF/Olympiatoppen-fagroller er det ikke avklart.
- «Assist Coach» er Anders' tidligere vedtak og beholdes.
- «WANG-elev» om opptaksgrunnlaget (avtaleteksten, ikke approlle).

## Prosjekter
Tre prosjekter: Precision (7d7c2994), Team Norway App delivery (dette), WANG Golf UI prototype (6cfa623c, eneste WANG-prosjekt). Ingen kobling til WANG Toppidrett Software.

## Vedtatte testregler (utdrag)
- 8-ball blocked/variation: 24 slag, nedre intervallgrenser: rest <0,1 m = 4 · 0,1–<1 = 3 · 1–<2 = 2 · 2–<3 = 1 · ≥3 m = 0. Bare hele poeng, maks 96. 24 × 1 m = 48/96.
- 9 hull lengde: senket/≤0,1 fot 6 · ≤1 3 · ≤2 1 · ≤4 0,5 · over 0. Enhet for målserien må avklares.
- Wedge Gate: 9 slag, Treff/Ikke treff. Driver Gate 6 godkjent/ikke. PEI lagres som brøk, vises i prosent.
