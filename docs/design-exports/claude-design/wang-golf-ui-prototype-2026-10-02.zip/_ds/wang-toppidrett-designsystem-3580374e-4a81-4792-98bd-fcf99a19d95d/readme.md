# WANG Toppidrett — designsystem 2026

Dette er designsystemet som skal eie all visuell kommunikasjon fra WANG: programvare, dokumenter, treningsplaner, e-post, signatur, presentasjon, SoMe, foto og merch. Det oversetter WANGs trykte designmanual fra 2021 til produkt- og kommunikasjonsflater i 2026 — uten å finne opp en ny merkevare på veien.

## Hva WANG er

WANG er en norsk privatskolekjede som kombinerer utdanning med idrett på høyt nivå. Merkevaren har tre segmenter under samme skjold: **WANG Ung** (ungdomsskole), **WANG Toppidrett** (videregående) og **WANG StudSpes** (studiespesialisering). Visjonen fra manualen: «Norges mest kompetente skole på utvikling av unge utøvere.» Adferdsverdiene heter BEST — Bygge tillit, Endringsvillig, Skaper resultater, Tenker helhet. Merkevareløftet: «Vi hjelper deg til å lykkes og inspirerer deg på veien.» Slagordet i omløp: «Rå på skole – rå på idrett.» WANG kvalitetssikres av Olympiatoppen.

Manualen deler profilen i tre frihetsgrader, og systemet følger samme inndeling:

| Nivå | Hva | Hvor strengt |
|---|---|---|
| Nivå 1 — formelt | Skilt, postalia, web, PPT-mal, faktura, e-postsignatur | Strengest. Ingen avvik. |
| Nivå 2 — offisielt | Brosjyre, plakat, programvare-skall, dokument | Fast ramme, rom for variasjon i foto og utsnitt |
| Nivå 3 — aktivitet | SoMe, merch, kampanje, video, arrangement | Mer luft til karakter, samme DNA |

## Produktene systemet dekker

1. **Intern plattform for WANG Toppidrett** (demo 13.10.2026, først Fredrikstad). Roller: elev 16–19 (telefon først), trener (nettbrett/desktop), admin/ledelse, foresatt (begrenset innsyn). Moduler: i dag/uke, økt og oppmøte, mål og utvikling, belastning/helse (varsomt, GDPR, mindreårige), meldinger skole ↔ hjem, admin (brukere, grupper, nærvær). UI-kittene `ui_kits/elev-mobil` og `ui_kits/trener-desktop` er de to nøkkelopplevelsene.
2. **Dokument og plan** — treningsplan, ukeplan, utviklingssamtale, nærværsrapport. Se malen `templates/treningsplan`.
3. **Kommunikasjon og kampanje** — e-post, signatur, presentasjon, SoMe, merch. Se `kanaler/`, `slides/` og `templates/presentasjon`.

## Kilder jeg fikk (behold dem — de er sannhetskilden)

- `uploads/wang-designmanual-2021.pdf` — *WANG Designmanual og merkevareplattform, 2021*, 30 sider. Eneste autoritative merkevarekilde: farger (s. 38–41), fonter (s. 26–35), logo og luft (s. 16–23), stil og tone (s. 12–13), fotomanér (s. 44), skiltikoner (s. 48).
- `uploads/WANG-designsystem-brief-2026.md` — brief som oversetter boken til produkt og kanal, med craft-regler og fase 1-leveranse.
- **Offisielle logo-originaler** (PNG på transparent, komplett sett levert 21.09.2026) — kopiert til `assets/logo/`. Ni lockup i inntil seks toner: `symbol`, `vertikal`, `vertikal-toppidrett`, `horisontal-toppidrett`, `horisontal-ung`, `horisontal-toppidrett-ung`, `typo`, `typo-toppidrett`, `typo-studspes`. Toner: farger, sort, hvit, sort-outline, hvit-outline og — på de vertikale — farger-hvit-typo. Skjoldet er nå en egen original, ikke lenger beskåret fra de vertikale filene. Se kortet «Logofamilien» og `components/brand/Logo.prompt.md`. Tidligere leverte SVG-er («Treningsplattform»-lockup) er fjernet — de var avledede produktmerker, ikke merkevareoriginaler.
- `uploads/wang-stills/` — 25 stills (1920×1080) fra WANGs egen hero-film `hero_wang.mp4`. Utvalg kopiert til `assets/photo/`, hele listen ligger i `assets/photo/README.md`.
- Fire skjermbilder fra wang.no (Olympiatoppen-banner, idretts-piktogrammer, strek-illustrasjoner, «Helhetlig helse»-hero) — lagret i `guidelines/reference/`. Brukt som digital arv, ikke kopiert 1:1.

Ingen kodebase og ingen Figma-fil var vedlagt. Produktkomponentene er derfor bygget fra briefens spesifikasjon og manualens karakter, ikke fra eksisterende produktkode.

---

## CONTENT FUNDAMENTALS

**Stemmen fra manualen (s. 12–13), ordrett:** åpen, men ikke flåsete eller utleverende. Pålitelig, men ikke bedrevitende eller selvhøytidelig. Nytenkende, men ikke vanskelig å forstå. Samhandlende, men ikke usikker. Nær, men ikke påtrengende.

Manualen plasserer også kanalene på en akse fra rasjonell til emosjonell: SoMe og web er emosjonelle (nær, bryr seg), rapporter og økonomi er rasjonelle (enkelt, effektivt, tilgjengelig), presentasjoner ligger midt imellom. Produktet skal ligge rasjonelt-nært: nøkternt språk, varm avsender.

**Konkrete regler**

- **Språk:** bokmål. Aldri engelsk UI. Dato `DD.MM.ÅÅÅÅ`. Klokke 24-timer (`07:00`, ikke `7 AM`).
- **Person:** «du» til eleven, «vi» om skolen. Aldri «brukeren». Trener og elev omtales med navn der det er naturlig.
- **Casing:** setningsform overalt — «Bekreft oppmøte», ikke «Bekreft Oppmøte» og ikke «BEKREFT OPPMØTE». CAPS finnes bare i lockup (`WANG TOPPIDRETT`) og korte kicker-labels på nivå 3 (`ÅPEN DAG 08.11`).
- **Lengde:** én setning der én setning holder. Punktum. Utropstegn nesten aldri.
- **Emoji:** nei. Ikke i produkt, ikke i e-post, ikke i dokument. Nivå 3 kan bruke foto for temperatur — ikke ikonfjes.
- **Ingen gamification-språk:** ingen streaks, «Keep going!», flammer, «du er på god vei!».
- **Helse er varsel, ikke underholdning.** «Moderat uke. Snakk med trener hvis noe kjennes tungt.» — ikke «Du har lav recovery-score 😬».
- **Personvern:** eksterne eksempler bruker fiktive navn. Elevdata minimeres. Begrunnelse for fravær lagres ikke i systemet.

**Eksempler — vi sier / vi sier ikke**

| Vi sier | Vi sier ikke |
|---|---|
| Økt i morgen 07:00 — hall B. | 🚀 Klar for en ny knallhard uke?! |
| Du har ikke møtt på to økter. Snakk med Ingrid. | Oops! Du mistet streaken din 🔥 |
| Foresatt får varsel i dag 16:00. | Vi har informert dine foresatte om situasjonen |
| Ingen økter i dag. | Ingenting her ennå — kom tilbake senere! |
| Bekreft oppmøte | Send inn |
| Vi hjelper deg til å lykkes. | Vi maksimerer ditt potensial |
| Registrer fravær | Marker som fraværende |
| Moderat belastning. Egenrapportert. | Din treningsbelastning er optimal ✅ |

Knappetekst er alltid verb + objekt: «Bekreft oppmøte», «Ta oppmøte», «Meld fravær», «Lagre notat». Push og e-postemne starter med faktum, ikke med hilsen: «Økt i morgen 07:00 — hall B». Tom tilstand er én setning og én handling: «Ingen økter i dag.» + «Se uka».

---

## VISUAL FOUNDATIONS

**Farge.** Hvitt er en merkevarefarge — manualen sier det rett ut: mye hvitt gir rent, moderne og naturlig. Hovedflaten i produktet er derfor hvit. WANG-blå `#17446F` er struktur (app-skall, sidemeny, cover, e-posthode) og tekstfarge på lys flate. WANG-grønn `#2E857D` er felt og hero, og betyr «ferdig/bekreftet». Mint `#49CA9F` er lys type på mørk flate — aldri 40 % av en lys side. Kontrastrosa `#D12A5C` er handlingsfargen (streken på «HEI.»-forsiden i boken) og brukes til **én** primærhandling per flate, pluss lenker. Sekundærfargene (oransje, gul, lys blå, lilla) brukes bare når noe betyr noe: de er bundet til status, ikke til pynt. Grå `#D2D2D2` er kant. Alt av flater utover dette er blanding av paletten, ikke nye farger. Se `tokens/colors.css` og kortene i gruppen «Colors».

**Type.** Montserrat til titler, tall, label og lockup; Quattrocento Sans til brød, planer, e-postbrød og UI-mengde. Sidetittel er Montserrat **Light** i stor grad (30–64 px) med −0.015em tracking — det er den viktigste enkeltbeslutningen som skiller WANG fra et standard dashbord. Ett nøkkel-tall per flate får Montserrat ExtraBold. Brød 16–18 px / 1.55. Label Montserrat Medium 13–14 px i setningsform. CAPS bare i lockup, med 0.18em tracking. Print: 28 pt tittel, 11,5 pt brød, aldri under 9 pt.

**Spacing og layout.** 4/8-grid. `--space-1` … `--space-20`. Mobilmarg 20, desktopmarg 32, maks innholdsbredde 1180, sidemeny 248, topbar 64, tabbar 64, dokumentmarg 18 mm. Minste treffflate 44 px. Luft er en merkevareegenskap: det er bedre å fjerne et kort enn å krympe luften.

**Bakgrunner.** Hvitt som standard. Lys blåtone `#F2F5F8` for seksjonsskille. Blå eller grønn heldekkende flate for struktur og hero. Foto som full-bleed bare på nivå 2–3 (cover, SoMe, kampanje), alltid med en mørk vertikal gradient under teksten (`rgba(15,46,76,.88)` → transparent) i stedet for en kapsel oppå bildet. Ingen gradient-mesh, ingen glassmorphism, ingen mønstre eller teksturer. Skjoldets diagonal (`--diagonal: 16deg`) kan brukes som sparsomt grafisk motiv — maks ett sted per flate.

**Foto.** Ett hovedfokus per bilde: menneske, miljø eller objekt. Varme, nærhet, folk i arbeid. Profilfargene skal helst finnes i motivet. Varier mellom nære og fjerne utsnitt. Fargestemning i WANGs eget materiale er kjølig-naturlig (hall, snø, kveld) med varme hudtoner — ikke gradert mot mørk cinematic sportsreklame, ingen glow, ingen lens flare, ingen korn lagt på i etterkant. Ikke stock. Ikke AI-genererte atleter. Ikke «team celebrating with confetti».

**Form.** Kort: radius 4 px, 1 px kant `#D2D2D2`, ingen skygge — kant før skygge. Knapp og input: radius 8 px. Pille (`999px`) bare til status og filter, aldri til knapper eller kort. Aldri 20 px+ radius. Kort med farget venstrekant brukes kun som prioritetsmarkør (3 px grønn/mint) og maks ett per skjerm.

**Skygge.** Nesten aldri. Tre nivåer finnes: ingen (standard), `0 1px 2px rgba(23,68,111,.08)` for en løftet mobilflate, og `0 12px 32px rgba(15,46,76,.22)` kun for dialog. Ingen innerskygger.

**Transparens og blur.** Transparens brukes bare i to tilfeller: hvit `rgba(255,255,255,.07–.20)` for hover/aktiv rad på blå flate, og mørk `rgba(15,46,76,.44)` som dialogbakteppe. Ingen backdrop-blur. Ingen frostet panel.

**Bevegelse.** 180–240 ms, ease-out `cubic-bezier(.16,.84,.44,1)`, interruptible. Dialog kommer inn 8 px nedenfra på 240 ms. Fargeskift 180 ms. Trykk 120 ms. Ingen count-up på tall, ingen konfetti, ingen streak-animasjon, ingen parallax. `prefers-reduced-motion` slår alt av.

**Hover og press.** Hover på lys flate: lys blåtone `#F2F5F8` som flate — ikke opasitet, ikke løft. Hover på primærknapp: mørkere rosa `#B32450`. Hover på blå flate: 7 % hvitt. Press: `#9C1F46` på primær, og `scale(.985)` — en knapt synlig innsynkning, ikke en bounce. Fokus: 1 px lys blå kant + 3 px `rgba(0,125,177,.35)` ring. Aktiv rad i sidemeny: 14 % hvitt.

**Kort — oppsummert.** Hvit flate, 4 px radius, 1 px grå kant, 24 px padding, tittel i Montserrat Medium 17 px, meta i Montserrat Medium 13 px i `--text-muted`, brød i Quattrocento Sans 16 px. Ingen skygge. Ingen ikon-badge i hjørnet. Aldri tolv identiske KPI-kort i rutenett.

**Det systemet aktivt unngår:** Inter/Roboto/Poppins/Geist som merkevarefont, 20 px+ radius, gradient-mesh, glassmorphism, navy vegg-til-vegg i appen, AI-dashbord med identiske KPI-kort, stock med glow, engelsk UI, gamification, farger utenfor paletten.

---

## ICONOGRAPHY

WANG har **to etablerte ikonspråk**, og de blandes ikke:

1. **Idretts-piktogrammer** (wang.no). Solide, sorte, Olympia-aktige strekfigurer — én per idrett: alpint, fotball, golf, innebandy, langrenn, skiskyting, sykkel, turn, freeski, hopp og kombinert, ishockey, orientering, skøyter, tekniske idretter, utholdenhet, cheerleading, friidrett, håndball, kampidrett, roing, svømming, tennis, volleyball, andre idretter. Se `guidelines/reference/wang-no-piktogrammer.png`. Disse brukes til idrettsvalg og segmentering, med en **rosa pil** `#D12A5C` som lenkeaffordans til høyre i raden — pilen er WANGs digitale lenkemotiv.
2. **Strek-illustrasjoner** (wang.no). Enkle, sorte konturtegninger med jevn strek som illustrerer verdiløfter («Vi bryr oss om elevene», «Fag i fokus», «Våre trenere og lærere»). Se `guidelines/reference/wang-no-strekillustrasjoner.png`. På mint/grønn flate finnes de som hvite konturikoner (hjerte, søvn, eple, flaske, sko, hode) — se `wang-no-helhetlig-helse-hero.png`.
3. **Skiltikoner** (manualen s. 48). Eget bibliotek for dørskilt og bygg — kjemi, rektor, bibliotek, grupperom, helsetjeneste, heis, toaletter, avfall. Finnes som AI, SVG og PNG hos markedsansvarlig.

**Ikonfilene kom i to leveranser.** Første pulje 21.09.2026 (åtte idretter og fem strek-illustrasjoner), andre pulje samme dag med 15 idretter til. **23 av 26 idretter** og alle fem strek-illustrasjoner ligger nå i `assets/icons/idrett/` og `assets/icons/illustrasjon/`, renset for C2PA-metadata. De rendres med komponenten `Pictogram`, som tegner dem som CSS-maske fylt med `currentColor` — fargen kommer fra elementet, ikke fra filen.

**Én figur, tre navn.** `andre-idretter.svg`, `orientering.svg` og `utholdenhet.svg` er identiske — wang.no bruker samme generiske løperfigur på alle tre. Filene er beholdt under hvert sitt navn så oppslag på idrett fungerer, men de skal aldri stå ved siden av hverandre i samme liste.

**Merk om filstørrelse:** hver SVG her er ca. 7,7 kB større enn strektegningen tilsier. Redigeringsmiljøet signerer alle filer det skriver med en C2PA-provenansmanifest, og den legges på igjen hver gang filen lagres — den kan altså ikke fjernes herfra. Selve strekdataen er 0,7–6,5 kB. Kjør `svgo --disable=removeMetadata --enable=removeMetadata` eller bare et `<metadata>`-strip i byggesteget når settet flyttes inn i produksjonskoden. **Tre idretter mangler fortsatt** — sykkel, bryting og studiespesialiserende — og skiltikonene likeså. Ikke tegn dem selv — hent resten fra wang.no på samme måte, eller be markedsansvarlig om settet.

**Substitusjon i mellomtiden (flagget):** UI-ikoner i produktet bruker **Phosphor Light** fra CDN (`https://unpkg.com/@phosphor-icons/web@2.1.1/src/light/style.css`) gjennom komponenten `Icon`. Phosphor Light er valgt fordi den er den nærmeste matchen på WANGs eget uttrykk: én familie, tynn og jevn strek, geometrisk, ingen fyll og ingen farge. Lucide og Heroicons ble forkastet — briefen avviser Lucide-settet eksplisitt, og Heroicons' solid-varianter blir klistremerke-aktige.

Emoji brukes ikke. Unicode-tegn brukes ikke som ikoner. Ikoner er alltid énfargede og arver tekstfargen; de får aldri egen farge utenom `--wang-pink` på et faktisk varsel.

**Når resten av settene kommer:** legg piktogrammene i `assets/icons/idrett/`, strek-illustrasjonene i `assets/icons/illustrasjon/` og skiltikonene i `assets/icons/skilt/`. `Pictogram` plukker dem opp på filnavn uten videre endring. Når alle 26 idretter er inne, kan Phosphor reduseres til rene UI-handlinger.

---

## Tilgjengelighet — kontrakt, ikke intensjon

Elevene er 13–19 år. Noen har dysleksi, konsentrasjonsvansker eller bruker skjermleser. Skolen er offentlig finansiert. **Systemet følger WCAG 2.2 AA.** Det er et krav, ikke en ambisjon.

**Kontrast.** Hver tillatt tekst/flate-kombinasjon er målt — se kortene «Kontrast — godkjent» og «Kontrast — forbudt». Brødtekst 4,5:1, stor tekst (19 px+ eller 14 px fet) 3:1. To målte avvik står i `CHANGELOG.md`: hvit på grønn `#2E857D` er 4,4:1, og meta-tonen `#5B7793` på lys flate er 4,3:1. Begge er dokumentert med regel for hva som gjelder i stedet.

**Farge er aldri eneste signal.** Status har alltid tekst ved siden av prikken. Feil har alltid en setning, ikke bare en rosa kant. Grafer bruker aldri rød/grønn alene.

**Tastatur.** Alt som kan trykkes kan nås med tab, aktiveres med Enter, og for knapper også med mellomrom. Fokusrekkefølgen følger leserekkefølgen. `Dialog` fanger fokus og lukkes med Escape. `TabBar` og `SideNav` setter `aria-current="page"`. `Notice` med tone `varsel` er `role="alert"`.

**Fokus er synlig.** Hover, press og fokus styres av `.wang-i` i `tokens/interactions.css` — CSS `:hover` / `:active` / `:focus-visible`, aldri JS mus-events. Det er forskjellen på at en tastaturbruker ser hvor hen er og ikke gjør det. `--focus-ring` på lys flate, `--focus-ring-on-dark` på blå og grønn.

**Treffflate minst 44 × 44 px.** Gjelder knapp, listerad, tab, checkbox og radio. Er det visuelle elementet mindre, utvid treffflaten med padding — ikke gjør elementet større.

**Bevegelse respekterer `prefers-reduced-motion`.** Varighetene faller til 1 ms, press-transformen slås av, spinneren bremses. Ingenting i systemet krever bevegelse for å forstås.

**Tekst kan forstørres.** Ingen fast høyde på en boks som holder tekst. Alt skalerer til 200 % uten at innhold forsvinner.

**Hva som ikke er verifisert ennå:** skjermlesergjennomgang med VoiceOver og NVDA, og automatisk kontrastsjekk i CI. Begge står i `arbeidsplan.md`.

---

## WANG trenerdemo — operativ prototype

`templates/wang-coach-demo/` er en klikkbar breddeversjon av hele produktflaten, bygget på dette designsystemet. Egen readme ligger i mappa. Entry: `WangCoachDemo.dc.html`.

**59 skjermer i åtte menygrupper.** Ruten ligger i URL-fragmentet (`#testing/skarkort#venter`), og System › Skjermoversikt er et internt register med WANG-id, menyinngang, rolle, status og dyp-lenke til hver skjerm.

| Gruppe | Områder | Skjermer |
|---|---|---|
| Oversikt | Hjem, kalender, min profil | WANG-01 – 06 |
| Utøvere | Spillere, grupper, oppmøte, utviklingsplan | WANG-10 – 22 |
| Testing | Testhub, protokoller, testdag, skårkort, rangering | WANG-30 – 41 |
| Planlegging | Arbeidsbenk, treningssamling | WANG-50 – 58 |
| Dialog | Kommunikasjon, samtykke og deling | WANG-60 – 64 |
| Organisasjon | Skoler, trenere og tilgang, administrasjon | WANG-70 – 76 |
| Rollevisninger | Foresatt, helsepersonell | WANG-80 – 85 |
| System | Skjermoversikt | WANG-90 |

**Brukerreiser som er operative** (simulert resultat, ingen eksterne handlinger): opprett gruppe → inviter spiller og foresatt → invitasjonsstatus. Ta oppmøte → registrer fraværsårsak → varsle foresatt. Sett opp testdag → TrackMan-oppsett → spillerens registrering → skårkort → rangering. Rediger økt → lagre utkast eller publiser til gruppe. Utviklingssjekk → del med trener → samtale. Samtykke per organisasjon → «hvem ser hva». Rollebytteren i topplinja hopper til hjemflaten for trener, spiller, foresatt og administrasjon.

**Sammenslåinger.** Menyen grupperer framfor å liste: kalender og profil ligger under Oversikt, ikke som egne toppnivåer. Skårkort og rangering ligger under Testing i stedet for å være egne områder. Foresatt- og helseflaten er samlet som rollevisninger — de er samme produkt sett gjennom en annen tilgang, ikke egne apper. Mobil viser fem faner (Hjem, Utøvere, Testing, Plan, Mer); resten nås gjennom Mer.

**Åpne produktvalg.** Om brutto score skal suppleres med en aldersjustert verdi. Om foresatte skal se rangeringsliste i det hele tatt — står nå som «kun med samtykke». Om testansvarlig skal være en egen rolle eller et flagg på trenerrollen. Hvor lenge et avvist belastningsvarsel skal ligge stille før det kommer tilbake (står nå på to uker). Om WANG Ung-avvikene skal kunne overstyres av rektor.

**Klart for demo:** alle åtte gruppene. To skjermer er merket delvis — Outlook- og Teams-tilkobling (WANG-05) og integrasjoner (WANG-76), fordi de bevisst er simulerte brytere uten ekte kobling.

---

## Index — hva ligger hvor

**Rot**

| Fil | Hva |
|---|---|
| `styles.css` | Global CSS-inngang. Kun `@import`-linjer. Dette er den ene fila et prosjekt lenker. |
| `readme.md` | Denne fila — designguide og manifest. |
| `SKILL.md` | Agent Skill-innpakning, for bruk i Claude Code. |
| `thumbnail.html` | Merkevaretile for systemet. |

**Tokens** (`tokens/`, alle `@import`ert fra `styles.css`)

`fonts.css` (Montserrat + Quattrocento Sans, `@font-face`) · `colors.css` (base + semantiske aliaser) · `typography.css` (produkt- og dokumentskala) · `spacing.css` (4/8-grid, layoutmål) · `form.css` (radius, kant, skygge, treffflate) · `motion.css` (varighet, easing, reduced-motion).

**Komponenter** (`components/`) — 11 stykker, hver med `.jsx`, `.d.ts` og `.prompt.md`

| Gruppe | Komponenter |
|---|---|
| `components/core/` | **Button**, **Input**, **Card**, **StatusPill**, **Badge**, **Eyebrow**, **Stat**, **EmptyState**, **Dialog** |
| `components/forms/` | **Select**, **Checkbox**, **Radio**, **Switch** |
| `components/navigation/` | **TabBar** (elev, mobil), **SideNav** (trener/admin, desktop) |
| `components/data/` | **ScanList** |
| `components/feedback/` | **Notice** |
| `components/brand/` | **Logo**, **Pictogram**, **Icon** |

Dette dekker briefens åtte produktprimitiver — knapp, input, kort, status, navigasjon (mobil + desktop), tabell/liste, tom tilstand og dialog — pluss skjemakontrollene og de typografiske mønstrene kanalflatene trenger.

**Intentional additions.** `Logo` og `Icon` står ikke på briefens liste over åtte primitiver. `Logo` er lagt til fordi logobruk har faste luftregler som ellers blir brutt hver gang noen skriver `<img>` selv. `Icon` er lagt til fordi de åtte primitivene ikke kan bygges uten en ikonkilde, og wrapperen gir ett sted å bytte når WANGs egne ikonfiler kommer. `Select`, `Checkbox`, `Radio` og `Switch` er lagt til fordi skjema i admin, samtykke og varslingsvalg ellers måtte bygges fra bunnen hver gang. `Badge`, `Eyebrow` og `Stat` er de tre typografiske mønstrene rapport, plakat og SoMe bruker om igjen. `Notice` er lagt til fordi WANG ikke har toast — beskjeden må kunne stå i flaten den gjelder.

**UI-kit**

- `ui_kits/elev-mobil/` — elev, mobil 390: I dag, Uke, Økt-detalj, Mål, Meldinger (med tom tilstand) og fraværsdialog. `index.html` er klikkbar.
- `ui_kits/trener-desktop/` — trener/admin, desktop 1280: Uke, Gruppe (med filter og tom tilstand), Elevkort, Nærvær, Meldinger. `index.html` er klikkbar.

**Maler** (`templates/`) — brukes som utgangspunkt i nye prosjekter

- `templates/treningsplan/` — ukeplan på én A4-side, print-trygg.
- `templates/presentasjon/` — 16:9 cover, innholdsslide, foto-slide og sitatslide.
- `templates/brev/` — formelt brev til foresatte, A4, nivå 1.
- `templates/rapport/` — tre A4-sider: blå forside, nøkkeltall og tabell, vurdering.
- `templates/tilbud/` — tilbud med pris og vilkår + møtereferat, to lyse A4-sider.
- `templates/program/` — sportsplan med foto-forside og periodisering, to A4-sider.
- `templates/epost/` — tabellbasert e-post på 600 px, én primærhandling.
- `templates/sosiale-instagram/` — 1:1, 4:5, 9:16 og tre karusellkort.
- `templates/sosiale-facebook/` — lenkebilde, feed, cover, arrangement og LinkedIn-banner.
- `templates/sosiale-story/` — Snapchat, Reels, resultatliste, trygg sone, YouTube-miniatyr og video-outro.
- `templates/plakat/` — plakat A3 i blå og hvit, diplom A4 liggende, rollup 850×2000 mm.

Lys og blå finnes begge steder der det gir mening. `tilbud/` og innsidene i `rapport/` er bevisst kun lyse: de skal leses, og blå papir koster lesbarhet.

**Kanalbevis** (`kanaler/`) — e-postsignatur (nivå 1), transaksjonell e-post, SoMe 4:5 + story 9:16, merch-plassering med mål fra manualen.

**Slides** (`slides/`) — cover og innholdsslide som enkeltkort i Design System-fanen.

**Foundations-kort** (`guidelines/`) — 39 spesimenkort i gruppene Brand, Colors, Type, Spacing og Stemme, pluss `guidelines/reference/` med wang.no-skjermbildene.

**Assets** (`assets/`) — `logo/` (ni offisielle lockup i inntil seks toner, se «Logofamilien»), `icons/idrett/` (23 av 26 piktogrammer) og `icons/illustrasjon/` (5 strek-illustrasjoner), `photo/` (14 profesjonelle foto fra wang.no + 11 stills fra hero-filmen — se `assets/photo/README.md`).

---

## LÅST vs. VENTER

**Låst — endres ikke uten ny beslutning**

- Logo kun fra PNG-originalene i `assets/logo/`. Aldri redraw, aldri satt på nytt i Montserrat. Skjoldet rekonstrueres aldri.
- Blå `#17446F`, grønn `#2E857D`, mint `#49CA9F`, rosa `#D12A5C` (én primærhandling per flate), grå `#D2D2D2`. Sekundærfargene er bundet til status. Ingen nye farger, ingen gull, ingen krem.
- Hvitt er hovedflaten. Maks to bakgrunnsfarger per dokument eller deck.
- Montserrat Light til sidetittel (−0.015em), Montserrat Medium til label, Montserrat ExtraBold til ett nøkkeltall, Quattrocento Sans 16/1,55 til brød. CAPS kun i lockup og kicker, 0.18em. Dato `DD.MM.ÅÅÅÅ`, klokke 24-timer.
- Radius 4 kort / 8 kontroll / 0 fullflate. Pille kun til status, filter og Switch-sporet. Aldri 20 px+.
- Kant før skygge. Tre skyggenivåer finnes; dialog er det eneste som får den store.
- Foto med vertikal gradient `#0F2E4C` i .55 / .78 / .90. Kjølig-naturlig, ingen filter, ingen stock, ingen AI-utøvere.
- Diagonalen er 16° og brukes maks ett sted per flate. Den er systemets eneste grafiske grep utenom logoen.
- Bevegelse 120 / 180 / 240 ms på `cubic-bezier(.16,.84,.44,1)`. Fade og 8–16 px. Ingen sprett, ingen count-up, ingen konfetti.
- Bokmål. «Du» til eleven, «vi» om skolen. Knappetekst er verb + objekt. Ingen emoji, ingen gamification.

**Venter på WANG**

- **Skiltikonene og de tre resterende idretts-piktogrammene** (sykkel, bryting, studiespesialiserende). 23 idretter og fem strek-illustrasjoner er inne. Phosphor Light er fortsatt stand-in for UI-ikoner. Se ICONOGRAPHY.
- **Vektorfil av logoen** (AI/EPS/SVG). PNG-ene holder til A3. Skilt, rollup i produksjon, foliering og bildekor er blokkert til vektor foreligger — se kortet «Mangler vektor».
- **Fontfiler.** Montserrat og Quattrocento Sans er manualens egne og hentes fra Google Fonts. Skal WANG være CDN-fri, legg `.woff2` i `assets/fonts/` og bytt `src` i `tokens/fonts.css`.
- **Mer foto.** Biblioteket mangler innendørs vinterøkt, klasserom i bruk og portrett i 9:16 av trener.
- **Produktkode eller Figma.** Ingen ble levert. Komponentene er tolkning av briefens craft-regler, ikke gjenskaping av eksisterende produkt.

---

## Caveats og hva som mangler

1. **Ikonfilene er nesten på plass.** 23 av 26 idrettspiktogrammer og alle fem strek-illustrasjoner er hentet fra wang.no. Sykkel, bryting og studiespesialiserende mangler, og hele skiltsettet mangler. Phosphor Light er fortsatt stand-in for UI-ikoner. Se ICONOGRAPHY.
2. **Fonter lastes fra Google Fonts.** Montserrat og Quattrocento Sans er manualens egne fonter og ligger fritt på Google Fonts, så det er ingen substitusjon — men `tokens/fonts.css` peker på `fonts.gstatic.com`. Skal WANG være CDN-fri, legg `.woff2`-filene i `assets/fonts/` og bytt `src`-urlene.
3. **Logosettet er komplett.** WANG, WANG TOPPIDRETT, WANG UNG, WANG TOPPIDRETT UNG, WANG STUDIESPESIALISERENDE og skjoldet alene — vertikalt, horisontalt og som ordmerke. `Logo`-komponenten dekker alle ni. De gamle variantnavnene `skjold`, `vertical` og `toppidrett` fungerer fortsatt.
4. **Ingen kodebase eller Figma.** Produktkomponentene er tolkning av briefens craft-regler, ikke gjenskaping av eksisterende produkt. Alt her er fase 1: fundament, primitiver, to nøkkelopplevelser og kanalbevis.
5. **wang.no er brukt som digital arv, ikke som mal.** Nettstedet er ikke gjenskapt — fire skjermbilder er lagret som referanse.
6. **Logofilene er originaler — men PNG, ikke SVG.** Settet er levert som PNG på transparent bakgrunn. Det holder til skjerm og trykk opp til A3, men for skilt, foliering, rollup i produksjon og bildekor trengs vektorfilene (AI/EPS/SVG). Det er nå den eneste manglende logoleveransen.
7. **Vektorfiler er ikke hentet fra manualen.** PDF-en har ingen innebygde logobilder (bare to stoffteksturer på s. 10) — skjoldet er vektortegning, og sidegjengivelse til bilde tidsavbryter i dette miljøet. Trenger du SVG/EPS, åpne PDF-en i Illustrator eller eksporter fra Acrobat.
