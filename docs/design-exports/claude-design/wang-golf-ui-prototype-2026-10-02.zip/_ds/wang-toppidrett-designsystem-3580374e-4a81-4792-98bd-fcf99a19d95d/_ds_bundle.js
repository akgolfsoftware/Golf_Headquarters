/* @ds-bundle: {"format":4,"namespace":"WANGToppidrettDesignsystem_358037","components":[{"name":"Icon","sourcePath":"components/brand/Icon.jsx"},{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"IDRETT","sourcePath":"components/brand/Pictogram.jsx"},{"name":"ILLUSTRASJON","sourcePath":"components/brand/Pictogram.jsx"},{"name":"Pictogram","sourcePath":"components/brand/Pictogram.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Dialog","sourcePath":"components/core/Dialog.jsx"},{"name":"EmptyState","sourcePath":"components/core/EmptyState.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"Stat","sourcePath":"components/core/Stat.jsx"},{"name":"StatusPill","sourcePath":"components/core/StatusPill.jsx"},{"name":"ScanList","sourcePath":"components/data/ScanList.jsx"},{"name":"Notice","sourcePath":"components/feedback/Notice.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"SideNav","sourcePath":"components/navigation/SideNav.jsx"},{"name":"TabBar","sourcePath":"components/navigation/TabBar.jsx"}],"sourceHashes":{"components/brand/Icon.jsx":"c814db8874aa","components/brand/Logo.jsx":"1706acb80fc2","components/brand/Pictogram.jsx":"b6f6e8ef99eb","components/core/Badge.jsx":"360e3416452e","components/core/Button.jsx":"e2b3850dc5d0","components/core/Card.jsx":"2d846dcb3b4f","components/core/Dialog.jsx":"ea87e1301dc6","components/core/EmptyState.jsx":"2340d01d4549","components/core/Eyebrow.jsx":"da24a32c3088","components/core/Input.jsx":"52452244d14e","components/core/Stat.jsx":"6d35ad69420e","components/core/StatusPill.jsx":"b8826ad83cd6","components/data/ScanList.jsx":"35703c2b5f93","components/feedback/Notice.jsx":"8f264c42a93b","components/forms/Checkbox.jsx":"32173d66abc5","components/forms/Radio.jsx":"9a077d5c9ab5","components/forms/Select.jsx":"dae68e9a3c1f","components/forms/Switch.jsx":"925f3b3459aa","components/navigation/SideNav.jsx":"633f7d57213c","components/navigation/TabBar.jsx":"de1aa7cf0c24","ui_kits/elev-mobil/screens.jsx":"0c26b7087c95","ui_kits/trener-desktop/screens.jsx":"fd323e1d2bf8"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.WANGToppidrettDesignsystem_358037 = window.WANGToppidrettDesignsystem_358037 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Icon.jsx
try { (() => {
/**
 * Én ikonfamilie: Phosphor Light — tynn strek, geometrisk, ingen fyll.
 * WANGs eget skiltikon-bibliotek (manualen s. 48) finnes, men filene fulgte
 * ikke med; Phosphor Light er nærmeste match og er flagget i readme.md.
 * Krever stilarket i dokumentet:
 * <link rel="stylesheet" href="https://unpkg.com/@phosphor-icons/web@2.1.1/src/light/style.css">
 */
function Icon({
  name,
  size = 20,
  color = 'currentColor',
  label,
  style
}) {
  return /*#__PURE__*/React.createElement("i", {
    className: 'ph-light ph-' + name,
    "aria-hidden": label ? undefined : 'true',
    "aria-label": label,
    role: label ? 'img' : undefined,
    style: {
      fontSize: size,
      lineHeight: 1,
      color,
      display: 'inline-flex',
      ...style
    }
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Icon.jsx", error: String((e && e.message) || e) }); }

// components/brand/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Hele det offisielle WANG-logosettet, levert som PNG på transparent bakgrunn 21.09.2026.
 * Nøkkel: variant → tone → filnavn i assets/logo/. Ingen fil tegnes på nytt, ingen typo settes på nytt.
 */
const FILES = {
  symbol: {
    farger: 'wang-symbol-farger.png',
    sort: 'wang-symbol-sort.png',
    hvit: 'wang-symbol-hvit.png',
    'sort-outline': 'wang-symbol-sort-outline.png',
    'hvit-outline': 'wang-symbol-hvit-outline.png'
  },
  vertikal: {
    farger: 'wang-vertikal-farger.png',
    sort: 'wang-vertikal-sort.png',
    hvit: 'wang-vertikal-hvit.png',
    'sort-outline': 'wang-vertikal-sort-outline.png',
    'hvit-outline': 'wang-vertikal-hvit-outline.png',
    'farger-hvit-typo': 'wang-vertikal-farger-hvit-typo.png'
  },
  'vertikal-toppidrett': {
    farger: 'wang-toppidrett-vertikal-farger.png',
    sort: 'wang-toppidrett-vertikal-sort.png',
    hvit: 'wang-toppidrett-vertikal-hvit.png',
    'sort-outline': 'wang-toppidrett-vertikal-sort-outline.png',
    'hvit-outline': 'wang-toppidrett-vertikal-hvit-outline.png',
    'farger-hvit-typo': 'wang-toppidrett-vertikal-farger-hvit-typo.png'
  },
  'horisontal-toppidrett': {
    sort: 'wang-toppidrett-horisontal-sort.png',
    hvit: 'wang-toppidrett-horisontal-hvit.png'
  },
  'horisontal-ung': {
    sort: 'wang-ung-horisontal-sort.png',
    hvit: 'wang-ung-horisontal-hvit.png'
  },
  'horisontal-toppidrett-ung': {
    sort: 'wang-toppidrett-ung-horisontal-sort.png',
    hvit: 'wang-toppidrett-ung-horisontal-hvit.png'
  },
  typo: {
    sort: 'wang-typo-sort.png',
    hvit: 'wang-typo-hvit.png'
  },
  'typo-toppidrett': {
    sort: 'wang-toppidrett-typo-sort.png',
    hvit: 'wang-toppidrett-typo-hvit.png'
  },
  'typo-studspes': {
    sort: 'wang-studspes-typo-sort.png',
    hvit: 'wang-studspes-typo-hvit.png'
  }
};

/** Eldre navn fra fase 1 — beholdt så eksisterende flater ikke knekker. */
const ALIAS = {
  skjold: 'symbol',
  vertical: 'vertikal',
  toppidrett: 'horisontal-toppidrett'
};

/** Faller tilbake til nærmeste lovlige fil når en tone ikke finnes for varianten. */
const FALLBACK = {
  farger: ['farger', 'sort'],
  sort: ['sort'],
  hvit: ['hvit'],
  'sort-outline': ['sort-outline', 'sort'],
  'hvit-outline': ['hvit-outline', 'hvit'],
  'farger-hvit-typo': ['farger-hvit-typo', 'hvit']
};
function Logo({
  variant = 'vertikal',
  tone,
  height = 48,
  onDark = false,
  clearSpace = false,
  base = '../..',
  alt,
  ...rest
}) {
  const key = ALIAS[variant] || variant;
  const set = FILES[key] || FILES.vertikal;
  const wanted = tone || (onDark ? 'hvit' : key === 'symbol' || key.startsWith('vertikal') ? 'farger' : 'sort');
  const chain = FALLBACK[wanted] || [wanted, 'sort'];
  const file = chain.map(t => set[t]).find(Boolean) || Object.values(set)[0];
  const pad = clearSpace ? {
    padding: `${height}px ${height}px ${height * 1.5}px`
  } : null;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      ...pad
    }
  }, rest), /*#__PURE__*/React.createElement("img", {
    src: `${base}/assets/logo/${file}`,
    alt: alt != null ? alt : 'WANG',
    style: {
      height,
      width: 'auto',
      display: 'block'
    }
  }));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/brand/Pictogram.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const IDRETT = ['alpint', 'andre-idretter', 'cheerleading', 'fotball', 'freeski-og-snowboard', 'friidrett', 'golf', 'handball', 'hopp-og-kombinert', 'innebandy', 'ishockey', 'kampidrett', 'langrenn', 'orientering', 'padling', 'roing', 'skiskyting', 'skoyter', 'svomming', 'tennis', 'turn', 'utholdenhet', 'volleyball'];
const ILLUSTRASJON = ['klasserom', 'medalje', 'omsorg', 'pult', 'spire'];

/**
 * WANGs egne piktogrammer og strek-illustrasjoner fra assets/icons/.
 * Tegnes som maske med `currentColor`, så de arver tekstfargen og aldri får egen farge.
 * 23 av 26 idretter er levert. `andre-idretter`, `orientering` og `utholdenhet`
 * deler én og samme generiske løperfigur — det er slik wang.no bruker den.
 * Mangler: sykkel, bryting, studiespesialiserende. Se readme.
 */
function Pictogram({
  name,
  set = 'idrett',
  size = 40,
  base = '../..',
  title,
  ...rest
}) {
  const url = `${base}/assets/icons/${set}/${name}.svg`;
  const mask = {
    WebkitMaskImage: `url("${url}")`,
    maskImage: `url("${url}")`,
    WebkitMaskRepeat: 'no-repeat',
    maskRepeat: 'no-repeat',
    WebkitMaskPosition: 'center',
    maskPosition: 'center',
    WebkitMaskSize: 'contain',
    maskSize: 'contain'
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    role: title ? 'img' : undefined,
    "aria-label": title,
    "aria-hidden": title ? undefined : true,
    style: {
      display: 'inline-block',
      width: size,
      height: size,
      background: 'currentColor',
      flex: 'none',
      ...mask
    }
  }, rest));
}
Object.assign(__ds_scope, { IDRETT, ILLUSTRASJON, Pictogram });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Pictogram.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
const TONES = {
  neutral: {
    fg: 'var(--text-muted)',
    bg: 'var(--surface-subtle)',
    bd: 'var(--border-subtle)'
  },
  blue: {
    fg: 'var(--wang-blue)',
    bg: 'var(--wang-blue-tint)',
    bd: 'var(--wang-blue-tint)'
  },
  green: {
    fg: 'var(--wang-green)',
    bg: 'var(--wang-green-tint)',
    bd: 'var(--wang-green-tint)'
  },
  pink: {
    fg: 'var(--wang-pink)',
    bg: 'var(--wang-pink-tint)',
    bd: 'var(--wang-pink-tint)'
  },
  solid: {
    fg: 'var(--wang-white)',
    bg: 'var(--wang-blue)',
    bd: 'var(--wang-blue)'
  }
};

/** Kategori eller antall. Firkantet (4 px) — pille er reservert status og filter. */
function Badge({
  children,
  tone = 'neutral',
  onDark = false
}) {
  const t = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '3px var(--space-2)',
      borderRadius: 'var(--radius-card)',
      background: onDark ? 'rgba(255,255,255,.14)' : t.bg,
      border: 'var(--border-width) solid ' + (onDark ? 'transparent' : t.bd),
      color: onDark ? 'var(--wang-white)' : t.fg,
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--type-micro)',
      letterSpacing: 'var(--tracking-label)',
      whiteSpace: 'nowrap'
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const BASE = {
  fontFamily: 'var(--font-display)',
  fontWeight: 'var(--weight-medium)',
  letterSpacing: 'var(--tracking-label)',
  borderRadius: 'var(--radius-control)',
  borderStyle: 'solid',
  borderWidth: 'var(--border-width)',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 'var(--space-2)',
  cursor: 'pointer',
  textDecoration: 'none',
  whiteSpace: 'nowrap'
};
const SIZES = {
  sm: {
    minHeight: 36,
    padding: '0 var(--space-4)',
    fontSize: 'var(--type-meta)'
  },
  md: {
    minHeight: 'var(--hit-min)',
    padding: '0 var(--space-6)',
    fontSize: 'var(--type-body)'
  },
  lg: {
    minHeight: 52,
    padding: '0 var(--space-8)',
    fontSize: 'var(--type-body-lg)'
  }
};

/* Tilstandene settes som CSS-variabler og aktiveres av .wang-i i tokens/interactions.css.
   Det er med vilje: :hover/:active/:focus-visible gjelder også for tastatur, JS mus-events gjør ikke. */
function palette(variant, onDark) {
  if (variant === 'primary') return {
    '--i-bg': 'var(--action-primary)',
    '--i-bd': 'var(--action-primary)',
    '--i-fg': 'var(--wang-white)',
    '--i-bg-h': 'var(--action-primary-hover)',
    '--i-bd-h': 'var(--action-primary-hover)',
    '--i-bg-a': 'var(--action-primary-press)',
    '--i-bd-a': 'var(--action-primary-press)'
  };
  if (variant === 'secondary') return onDark ? {
    '--i-bg': 'transparent',
    '--i-bd': 'rgba(255,255,255,.7)',
    '--i-fg': 'var(--wang-white)',
    '--i-bg-h': 'rgba(255,255,255,.12)',
    '--i-bd-h': 'var(--wang-white)',
    '--i-bg-a': 'rgba(255,255,255,.2)'
  } : {
    '--i-bg': 'transparent',
    '--i-bd': 'var(--action-secondary-border)',
    '--i-fg': 'var(--wang-blue)',
    '--i-bg-h': 'var(--wang-blue-tint)',
    '--i-bg-a': '#E4EBF2'
  };
  return onDark ? {
    '--i-bg': 'transparent',
    '--i-bd': 'transparent',
    '--i-fg': 'var(--wang-white)',
    '--i-bg-h': 'rgba(255,255,255,.12)',
    '--i-bg-a': 'rgba(255,255,255,.2)'
  } : {
    '--i-bg': 'transparent',
    '--i-bd': 'transparent',
    '--i-fg': 'var(--wang-blue)',
    '--i-bg-h': 'var(--wang-blue-tint)',
    '--i-bg-a': '#E4EBF2'
  };
}
function Button({
  children,
  variant = 'primary',
  size = 'md',
  onDark = false,
  disabled = false,
  loading = false,
  block = false,
  icon,
  iconAfter,
  as = 'button',
  onClick,
  className,
  ...rest
}) {
  const inert = disabled || loading;
  const Tag = as;
  const style = {
    ...BASE,
    ...(SIZES[size] || SIZES.md),
    ...palette(variant, onDark),
    '--i-press': 'scale(.985)',
    width: block ? '100%' : undefined,
    opacity: loading ? 0.85 : 1,
    ...(disabled ? {
      '--i-bg': variant === 'primary' ? 'var(--action-disabled)' : 'transparent',
      '--i-bd': variant === 'primary' ? 'var(--action-disabled)' : 'var(--wang-grey)',
      '--i-fg': 'var(--text-disabled)',
      '--i-bg-h': variant === 'primary' ? 'var(--action-disabled)' : 'transparent',
      '--i-press': 'none',
      cursor: 'not-allowed'
    } : null)
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: ['wang-i', className].filter(Boolean).join(' '),
    "data-on-dark": onDark ? '' : undefined,
    style: style,
    disabled: Tag === 'button' ? inert : undefined,
    "aria-disabled": Tag !== 'button' && inert ? 'true' : undefined,
    "aria-busy": loading || undefined,
    onClick: inert ? undefined : onClick
  }, rest), loading ? /*#__PURE__*/React.createElement(Spinner, null) : icon, /*#__PURE__*/React.createElement("span", null, loading ? 'Lagrer \u2026' : children), !loading ? iconAfter : null);
}
function Spinner() {
  return /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 14,
      height: 14,
      borderRadius: '50%',
      display: 'inline-block',
      border: '2px solid currentColor',
      borderTopColor: 'transparent',
      animation: 'wang-spin 700ms linear infinite'
    }
  }, /*#__PURE__*/React.createElement("style", null, '@keyframes wang-spin{to{transform:rotate(360deg)}}@media (prefers-reduced-motion:reduce){[style*="wang-spin"]{animation-duration:2s}}'));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Kort: radius 4 px, 1 px kant #D2D2D2, skygge nesten aldri. Kant før skygge. */
function Card({
  children,
  tone = 'default',
  title,
  meta,
  action,
  accent = false,
  padding = 'var(--space-6)',
  as = 'section',
  ...rest
}) {
  const tones = {
    default: {
      background: 'var(--surface-card)',
      color: 'var(--text-body)',
      borderColor: 'var(--border-card)'
    },
    subtle: {
      background: 'var(--surface-subtle)',
      color: 'var(--text-body)',
      borderColor: 'transparent'
    },
    structure: {
      background: 'var(--surface-structure)',
      color: 'var(--text-on-dark)',
      borderColor: 'transparent'
    },
    field: {
      background: 'var(--surface-field)',
      color: 'var(--text-on-dark)',
      borderColor: 'transparent'
    }
  };
  const dark = tone === 'structure' || tone === 'field';
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      borderRadius: 'var(--radius-card)',
      borderWidth: 'var(--border-width)',
      borderStyle: 'solid',
      boxShadow: 'var(--shadow-none)',
      padding,
      position: 'relative',
      overflow: 'hidden',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--type-body)',
      lineHeight: 'var(--leading-body)',
      ...tones[tone]
    }
  }, rest), accent ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      width: 3,
      height: '100%',
      background: dark ? 'var(--wang-mint)' : 'var(--wang-green)'
    }
  }) : null, title || meta || action ? /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 'var(--space-4)',
      marginBottom: children ? 'var(--space-4)' : 0
    }
  }, /*#__PURE__*/React.createElement("div", null, title ? /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--type-subheading)',
      lineHeight: 'var(--leading-title)',
      color: 'inherit'
    }
  }, title) : null, meta ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '4px 0 0',
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--type-meta)',
      fontWeight: 'var(--weight-medium)',
      color: dark ? 'var(--text-accent-on-dark)' : 'var(--text-muted)'
    }
  }, meta) : null), action) : null, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Dialog.jsx
try { (() => {
/** Dialog / bekreftelse. Én primærhandling, rosa. Avbryt er sekundær. */
function Dialog({
  open = true,
  title,
  body,
  children,
  confirmLabel = 'Bekreft',
  cancelLabel = 'Avbryt',
  onConfirm,
  onCancel,
  tone = 'default',
  width = 440
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    role: "presentation",
    onClick: onCancel,
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'rgba(15,46,76,.44)',
      padding: 'var(--space-6)',
      zIndex: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    "aria-label": title,
    onClick: e => e.stopPropagation(),
    style: {
      width: '100%',
      maxWidth: width,
      background: 'var(--wang-white)',
      border: 'var(--border-width) solid var(--border-card)',
      borderRadius: 'var(--radius-card)',
      boxShadow: 'var(--shadow-overlay)',
      padding: 'var(--space-8)',
      animation: 'wang-dialog-in var(--dur-slow) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("style", null, '@keyframes wang-dialog-in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}'), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-regular)',
      fontSize: 'var(--type-heading)',
      lineHeight: 'var(--leading-title)',
      color: 'var(--text-body)'
    }
  }, title), body ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 'var(--space-3) 0 0',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--type-body)',
      lineHeight: 'var(--leading-body)',
      color: 'var(--text-muted)'
    }
  }, body) : null, children ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-5)'
    }
  }, children) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      justifyContent: 'flex-end',
      marginTop: 'var(--space-8)'
    }
  }, cancelLabel ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "secondary",
    onClick: onCancel
  }, cancelLabel) : null, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: tone === 'danger' ? 'primary' : 'primary',
    onClick: onConfirm
  }, confirmLabel))));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/core/EmptyState.jsx
try { (() => {
/** Tom tilstand: én setning, én handling. Ingen grå ghost-illustrasjon. */
function EmptyState({
  title,
  body,
  actionLabel,
  onAction,
  onDark = false,
  align = 'left'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-10) var(--space-6)',
      border: onDark ? 'none' : 'var(--border-width) solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      background: onDark ? 'transparent' : 'var(--wang-white)',
      textAlign: align,
      display: 'flex',
      flexDirection: 'column',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-light)',
      fontSize: 'var(--type-title)',
      lineHeight: 'var(--leading-title)',
      letterSpacing: 'var(--tracking-display)',
      color: onDark ? 'var(--text-on-dark)' : 'var(--text-body)'
    }
  }, title), body ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 'var(--space-2) 0 0',
      maxWidth: '44ch',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--type-body)',
      lineHeight: 'var(--leading-body)',
      color: onDark ? 'rgba(255,255,255,.82)' : 'var(--text-muted)'
    }
  }, body) : null), actionLabel ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: onDark ? 'secondary' : 'primary',
    onDark: onDark,
    onClick: onAction
  }, actionLabel) : null);
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
/** Kicker over tittel: CAPS, Montserrat Medium, 0.18em tracking. Nivå 2–3. */
function Eyebrow({
  children,
  onDark = false,
  rule = true,
  color
}) {
  const ink = color || (onDark ? 'var(--wang-mint)' : 'var(--wang-pink)');
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, rule ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 24,
      height: 2,
      background: ink
    }
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--type-micro)',
      letterSpacing: 'var(--tracking-lockup)',
      textTransform: 'uppercase',
      color: onDark ? 'var(--wang-white)' : 'var(--text-body)'
    }
  }, children));
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useId,
  useState
} = React;
function Input({
  label,
  value,
  onChange,
  placeholder,
  help,
  error,
  type = 'text',
  multiline = false,
  required = false,
  disabled = false,
  suffix,
  id,
  ...rest
}) {
  const auto = useId();
  const fieldId = id || auto;
  const [focus, setFocus] = useState(false);
  const Tag = multiline ? 'textarea' : 'input';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      fontFamily: 'var(--font-body)'
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--type-meta)',
      color: 'var(--text-body)'
    }
  }, label, required ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--wang-pink)'
    }
  }, " *") : null) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Tag, _extends({
    id: fieldId,
    type: multiline ? undefined : type,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    rows: multiline ? 4 : undefined,
    "aria-invalid": !!error,
    "aria-describedby": error || help ? fieldId + '-note' : undefined,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      minHeight: multiline ? 104 : 'var(--hit-min)',
      padding: multiline ? 'var(--space-3) var(--space-4)' : '0 var(--space-4)',
      paddingRight: suffix ? 'var(--space-12)' : undefined,
      borderRadius: 'var(--radius-control)',
      border: 'var(--border-width) solid ' + (error ? 'var(--wang-pink)' : focus ? 'var(--border-focus)' : 'var(--border-card)'),
      boxShadow: focus ? 'var(--focus-ring)' : 'none',
      outline: 'none',
      background: disabled ? 'var(--surface-subtle)' : 'var(--wang-white)',
      color: disabled ? 'var(--text-disabled)' : 'var(--text-body)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--type-body)',
      lineHeight: multiline ? 'var(--leading-body)' : undefined,
      transition: 'var(--transition-control)',
      resize: multiline ? 'vertical' : undefined
    }
  }, rest)), suffix ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 'var(--space-4)',
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--type-meta)',
      color: 'var(--text-muted)',
      pointerEvents: 'none'
    }
  }, suffix) : null), error || help ? /*#__PURE__*/React.createElement("p", {
    id: fieldId + '-note',
    style: {
      margin: 0,
      fontSize: 'var(--type-meta)',
      lineHeight: 1.4,
      fontFamily: 'var(--font-body)',
      color: error ? 'var(--wang-pink)' : 'var(--text-muted)'
    }
  }, error || help) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/Stat.jsx
try { (() => {
/** Ett nøkkeltall. Montserrat ExtraBold. Maks ett–tre per flate — aldri tolv like KPI-kort. */
function Stat({
  value,
  label,
  unit,
  size = 'md',
  onDark = false,
  align = 'left'
}) {
  const fs = size === 'lg' ? 'var(--type-metric-lg)' : size === 'sm' ? 'var(--type-title)' : 'var(--type-metric)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-1)',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      textAlign: align
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-extrabold)',
      fontSize: fs,
      lineHeight: 1,
      letterSpacing: 'var(--tracking-display)',
      color: onDark ? 'var(--wang-white)' : 'var(--text-body)',
      display: 'flex',
      alignItems: 'baseline',
      gap: 4
    }
  }, value, unit ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.42em',
      fontWeight: 'var(--weight-medium)',
      letterSpacing: 0,
      color: onDark ? 'var(--text-accent-on-dark)' : 'var(--text-muted)'
    }
  }, unit) : null), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--type-meta)',
      color: onDark ? 'rgba(255,255,255,.78)' : 'var(--text-muted)'
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stat.jsx", error: String((e && e.message) || e) }); }

// components/core/StatusPill.jsx
try { (() => {
const STATES = {
  planlagt: {
    label: 'Planlagt',
    fg: 'var(--status-planned)',
    bg: 'var(--status-planned-bg)'
  },
  pagar: {
    label: 'Pågår',
    fg: 'var(--status-active)',
    bg: 'var(--status-active-bg)'
  },
  gjennomfort: {
    label: 'Gjennomført',
    fg: 'var(--status-done)',
    bg: 'var(--status-done-bg)'
  },
  fravaer: {
    label: 'Fravær',
    fg: 'var(--status-absent)',
    bg: 'var(--status-absent-bg)'
  },
  varsel: {
    label: 'Varsel',
    fg: 'var(--status-alert)',
    bg: 'var(--status-alert-bg)'
  }
};

/** Pille brukes bare til status og filter — aldri knapp, aldri kort. */
function StatusPill({
  state = 'planlagt',
  label,
  onDark = false,
  dot = true
}) {
  const s = STATES[state] || STATES.planlagt;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      borderRadius: 'var(--radius-pill)',
      padding: '4px var(--space-3)',
      background: onDark ? 'rgba(255,255,255,.14)' : s.bg,
      color: onDark ? 'var(--wang-white)' : s.fg,
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--type-micro)',
      letterSpacing: 'var(--tracking-label)',
      whiteSpace: 'nowrap'
    }
  }, dot ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: onDark ? 'var(--wang-mint)' : s.fg
    }
  }) : null, label || s.label);
}
Object.assign(__ds_scope, { StatusPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatusPill.jsx", error: String((e && e.message) || e) }); }

// components/data/ScanList.jsx
try { (() => {
/**
 * Scanbar liste/tabell for trener. Skal leses på to sekunder:
 * linjer, ikke bokser. Ingen zebra-striper, ingen skygge.
 */
function ScanList({
  columns = [],
  rows = [],
  onRowClick,
  dense = false,
  caption
}) {
  const grid = columns.map(c => c.width || '1fr').join(' ');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      border: 'var(--border-width) solid var(--border-card)',
      borderRadius: 'var(--radius-card)',
      background: 'var(--wang-white)',
      overflow: 'hidden'
    }
  }, caption ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-4) var(--space-5)',
      borderBottom: 'var(--border-width) solid var(--border-subtle)',
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--type-subheading)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-body)'
    }
  }, caption) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: grid,
      gap: 'var(--space-4)',
      padding: 'var(--space-3) var(--space-5)',
      borderBottom: 'var(--border-width) solid var(--border-subtle)'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("span", {
    key: c.key,
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--type-micro)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-muted)',
      textAlign: c.align || 'left'
    }
  }, c.label))), rows.map((row, i) => /*#__PURE__*/React.createElement(Row, {
    key: row.id || i,
    row: row,
    columns: columns,
    grid: grid,
    dense: dense,
    last: i === rows.length - 1,
    onRowClick: onRowClick
  })));
}
function Row({
  row,
  columns,
  grid,
  dense,
  last,
  onRowClick
}) {
  const clickable = !!onRowClick;
  return /*#__PURE__*/React.createElement("div", {
    className: clickable ? 'wang-i' : undefined,
    role: clickable ? 'button' : undefined,
    tabIndex: clickable ? 0 : undefined,
    onClick: clickable ? () => onRowClick(row) : undefined,
    onKeyDown: clickable ? e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        onRowClick(row);
      }
    } : undefined,
    style: {
      display: 'grid',
      gridTemplateColumns: grid,
      gap: 'var(--space-4)',
      alignItems: 'center',
      padding: dense ? 'var(--space-3) var(--space-5)' : 'var(--space-4) var(--space-5)',
      minHeight: dense ? 40 : 'var(--hit-min)',
      borderBottom: last ? 'none' : 'var(--border-width) solid var(--border-subtle)',
      '--i-bg': 'transparent',
      '--i-bg-h': 'var(--surface-subtle)',
      cursor: clickable ? 'pointer' : 'default'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.key,
    style: {
      fontFamily: c.display ? 'var(--font-display)' : 'var(--font-body)',
      fontWeight: c.display ? 'var(--weight-medium)' : 'var(--weight-regular)',
      fontSize: 'var(--type-meta)',
      color: 'var(--text-body)',
      textAlign: c.align || 'left',
      display: 'flex',
      justifyContent: c.align === 'right' ? 'flex-end' : c.align === 'center' ? 'center' : 'flex-start',
      alignItems: 'center',
      gap: 'var(--space-2)',
      minWidth: 0
    }
  }, c.render ? c.render(row) : row[c.key])));
}
Object.assign(__ds_scope, { ScanList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ScanList.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Notice.jsx
try { (() => {
const TONES = {
  info: {
    fg: 'var(--wang-lightblue)',
    bg: 'var(--status-planned-bg)'
  },
  suksess: {
    fg: 'var(--wang-green)',
    bg: 'var(--status-done-bg)'
  },
  obs: {
    fg: 'var(--wang-orange)',
    bg: 'var(--status-active-bg)'
  },
  varsel: {
    fg: 'var(--wang-pink)',
    bg: 'var(--status-alert-bg)'
  }
};

/** Rolig, inline melding. Ingen toast, ingen auto-skjul, ingen ikonfjes. */
function Notice({
  tone = 'info',
  title,
  children,
  action,
  onDismiss
}) {
  const t = TONES[tone] || TONES.info;
  return /*#__PURE__*/React.createElement("div", {
    role: tone === 'varsel' ? 'alert' : 'status',
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start',
      padding: 'var(--space-4)',
      borderRadius: 'var(--radius-card)',
      background: t.bg,
      border: 'var(--border-width) solid ' + t.bg,
      fontFamily: 'var(--font-body)',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      flex: '0 0 auto',
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: t.fg,
      marginTop: 7
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-1)'
    }
  }, title ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--type-subheading)',
      color: 'var(--text-body)'
    }
  }, title) : null, children ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--type-body)',
      lineHeight: 'var(--leading-body)'
    }
  }, children) : null, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-2)'
    }
  }, action) : null), onDismiss ? /*#__PURE__*/React.createElement("button", {
    onClick: onDismiss,
    "aria-label": "Lukk melding",
    style: {
      flex: '0 0 auto',
      width: 28,
      height: 28,
      border: 0,
      background: 'transparent',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      fontSize: 18,
      lineHeight: 1,
      borderRadius: 'var(--radius-card)'
    }
  }, "\xD7") : null);
}
Object.assign(__ds_scope, { Notice });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Notice.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useId
} = React;
function Checkbox({
  label,
  help,
  checked = false,
  onChange,
  disabled = false,
  indeterminate = false,
  id,
  ...rest
}) {
  const auto = useId();
  const fieldId = id || auto;
  const on = checked || indeterminate;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start',
      minHeight: 'var(--hit-min)',
      padding: 'var(--space-3) 0',
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontFamily: 'var(--font-body)',
      color: disabled ? 'var(--text-disabled)' : 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 1,
      height: 1
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      flex: '0 0 auto',
      width: 20,
      height: 20,
      marginTop: 1,
      borderRadius: 'var(--radius-card)',
      border: 'var(--border-width) solid ' + (disabled ? 'var(--action-disabled)' : on ? 'var(--wang-blue)' : 'var(--border-card)'),
      background: on ? disabled ? 'var(--action-disabled)' : 'var(--wang-blue)' : 'var(--wang-white)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'var(--transition-control)'
    }
  }, indeterminate ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 2,
      background: 'var(--wang-white)'
    }
  }) : checked ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 5,
      height: 9,
      borderRight: '2px solid var(--wang-white)',
      borderBottom: '2px solid var(--wang-white)',
      transform: 'translateY(-1px) rotate(45deg)'
    }
  }) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--type-body)',
      lineHeight: 1.35
    }
  }, label), help ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--type-meta)',
      color: 'var(--text-muted)',
      lineHeight: 1.4
    }
  }, help) : null));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
const {
  useId
} = React;
function Radio({
  name,
  value,
  options = [],
  onChange,
  label,
  help,
  disabled = false,
  direction = 'column'
}) {
  const auto = useId();
  const group = name || auto;
  return /*#__PURE__*/React.createElement("fieldset", {
    style: {
      border: 0,
      margin: 0,
      padding: 0,
      fontFamily: 'var(--font-body)'
    }
  }, label ? /*#__PURE__*/React.createElement("legend", {
    style: {
      padding: 0,
      marginBottom: 'var(--space-1)',
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--type-meta)',
      color: 'var(--text-body)'
    }
  }, label) : null, help ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 var(--space-2)',
      fontSize: 'var(--type-meta)',
      color: 'var(--text-muted)'
    }
  }, help) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: direction,
      gap: direction === 'row' ? 'var(--space-6)' : 0
    }
  }, options.map(o => {
    const val = typeof o === 'string' ? o : o.value;
    const lab = typeof o === 'string' ? o : o.label;
    const on = value === val;
    return /*#__PURE__*/React.createElement("label", {
      key: val,
      style: {
        display: 'flex',
        gap: 'var(--space-3)',
        alignItems: 'center',
        minHeight: 'var(--hit-min)',
        padding: direction === 'row' ? 0 : 'var(--space-2) 0',
        cursor: disabled ? 'not-allowed' : 'pointer',
        color: disabled ? 'var(--text-disabled)' : 'var(--text-body)'
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "radio",
      name: group,
      value: val,
      checked: on,
      disabled: disabled,
      onChange: onChange,
      style: {
        position: 'absolute',
        opacity: 0,
        width: 1,
        height: 1
      }
    }), /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        flex: '0 0 auto',
        width: 20,
        height: 20,
        borderRadius: '50%',
        border: 'var(--border-width) solid ' + (disabled ? 'var(--action-disabled)' : on ? 'var(--wang-blue)' : 'var(--border-card)'),
        background: 'var(--wang-white)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        transition: 'var(--transition-control)'
      }
    }, on ? /*#__PURE__*/React.createElement("span", {
      style: {
        width: 10,
        height: 10,
        borderRadius: '50%',
        background: disabled ? 'var(--action-disabled)' : 'var(--wang-blue)'
      }
    }) : null), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--type-body)'
      }
    }, lab));
  })));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useId,
  useState
} = React;
function Select({
  label,
  value,
  onChange,
  options = [],
  placeholder,
  help,
  error,
  required = false,
  disabled = false,
  id,
  ...rest
}) {
  const auto = useId();
  const fieldId = id || auto;
  const [focus, setFocus] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      fontFamily: 'var(--font-body)'
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 'var(--type-meta)',
      color: 'var(--text-body)'
    }
  }, label, required ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--wang-pink)'
    }
  }, " *") : null) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: fieldId,
    value: value,
    onChange: onChange,
    disabled: disabled,
    required: required,
    "aria-invalid": !!error,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      height: 'var(--hit-min)',
      padding: '0 var(--space-10) 0 var(--space-4)',
      borderRadius: 'var(--radius-control)',
      border: 'var(--border-width) solid ' + (error ? 'var(--wang-pink)' : focus ? 'var(--border-focus)' : 'var(--border-card)'),
      boxShadow: focus ? 'var(--focus-ring)' : 'none',
      outline: 'none',
      appearance: 'none',
      background: disabled ? 'var(--surface-subtle)' : 'var(--wang-white)',
      color: disabled ? 'var(--text-disabled)' : value ? 'var(--text-body)' : 'var(--text-muted)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--type-body)',
      transition: 'var(--transition-control)'
    }
  }, rest), placeholder ? /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder) : null, options.map(o => {
    const val = typeof o === 'string' ? o : o.value;
    const lab = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: val,
      value: val
    }, lab);
  })), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      right: 'var(--space-4)',
      width: 8,
      height: 8,
      borderRight: '1.5px solid ' + (disabled ? 'var(--text-disabled)' : 'var(--text-muted)'),
      borderBottom: '1.5px solid ' + (disabled ? 'var(--text-disabled)' : 'var(--text-muted)'),
      transform: 'translateY(-2px) rotate(45deg)',
      pointerEvents: 'none'
    }
  })), error || help ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--type-meta)',
      lineHeight: 1.4,
      color: error ? 'var(--wang-pink)' : 'var(--text-muted)'
    }
  }, error || help) : null);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
const {
  useId
} = React;
function Switch({
  label,
  help,
  checked = false,
  onChange,
  disabled = false,
  id
}) {
  const auto = useId();
  const fieldId = id || auto;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      alignItems: 'center',
      justifyContent: 'space-between',
      minHeight: 'var(--hit-min)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontFamily: 'var(--font-body)',
      color: disabled ? 'var(--text-disabled)' : 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--type-body)'
    }
  }, label), help ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--type-meta)',
      color: 'var(--text-muted)',
      lineHeight: 1.4
    }
  }, help) : null), /*#__PURE__*/React.createElement("input", {
    id: fieldId,
    type: "checkbox",
    role: "switch",
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 1,
      height: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      flex: '0 0 auto',
      width: 44,
      height: 24,
      borderRadius: 'var(--radius-pill)',
      background: disabled ? 'var(--action-disabled)' : checked ? 'var(--wang-green)' : 'var(--wang-grey)',
      padding: 2,
      display: 'flex',
      justifyContent: checked ? 'flex-end' : 'flex-start',
      transition: 'background-color var(--dur-base) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: '50%',
      background: 'var(--wang-white)',
      transition: 'transform var(--dur-base) var(--ease-out)'
    }
  })));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SideNav.jsx
try { (() => {
/** Desktop-sidemeny for trener/admin. WANG-blå er skallet — aldri hele siden. */
function SideNav({
  items = [],
  active,
  onSelect,
  user,
  footer
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      width: 'var(--sidenav-width)',
      flex: '0 0 var(--sidenav-width)',
      background: 'var(--surface-structure)',
      color: 'var(--text-on-dark)',
      display: 'flex',
      flexDirection: 'column',
      minHeight: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-6) var(--space-6) var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    variant: "horizontal",
    onDark: true,
    height: 30
  })), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: '0 var(--space-3)',
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, items.map(it => /*#__PURE__*/React.createElement(SideNavItem, {
    key: it.id,
    item: it,
    active: it.id === active,
    onSelect: onSelect
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      padding: 'var(--space-6)',
      borderTop: '1px solid rgba(255,255,255,.14)'
    }
  }, footer || (user ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: '50%',
      background: 'var(--wang-green)',
      display: 'grid',
      placeItems: 'center',
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-bold)',
      fontSize: 'var(--type-micro)',
      color: 'var(--wang-white)'
    }
  }, user.initials), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--type-meta)',
      fontWeight: 'var(--weight-medium)'
    }
  }, user.name), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--type-micro)',
      color: 'var(--wang-mint)'
    }
  }, user.role))) : null)));
}
function SideNavItem({
  item,
  active,
  onSelect
}) {
  return /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("button", {
    className: "wang-i",
    "data-on-dark": "",
    onClick: () => onSelect && onSelect(item.id),
    "aria-current": active ? 'page' : undefined,
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      minHeight: 'var(--hit-min)',
      padding: '0 var(--space-3)',
      cursor: 'pointer',
      border: 'none',
      borderRadius: 'var(--radius-control)',
      '--i-bg': active ? 'rgba(255,255,255,.14)' : 'transparent',
      '--i-bg-h': active ? 'rgba(255,255,255,.18)' : 'rgba(255,255,255,.07)',
      '--i-fg': active ? 'var(--wang-white)' : 'rgba(255,255,255,.78)',
      '--i-fg-h': 'var(--wang-white)',
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--type-meta)',
      fontWeight: active ? 'var(--weight-medium)' : 'var(--weight-regular)',
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: item.icon,
    size: 18
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, item.label), item.badge ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--type-micro)',
      fontWeight: 'var(--weight-bold)',
      background: 'var(--wang-pink)',
      color: 'var(--wang-white)',
      borderRadius: 'var(--radius-pill)',
      padding: '1px 7px'
    }
  }, item.badge) : null));
}
Object.assign(__ds_scope, { SideNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SideNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TabBar.jsx
try { (() => {
/** Mobilnavigasjon for elev. Tommel-sone, min 44 px treffflate, maks 5 punkter. */
function TabBar({
  items = [],
  active,
  onSelect
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${Math.max(items.length, 1)},1fr)`,
      height: 'var(--tabbar-height)',
      background: 'var(--wang-white)',
      borderTop: 'var(--border-width) solid var(--border-subtle)'
    }
  }, items.map(it => {
    const on = it.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      className: "wang-i",
      onClick: () => onSelect && onSelect(it.id),
      "aria-current": on ? 'page' : undefined,
      style: {
        border: 'none',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 2,
        minHeight: 'var(--hit-min)',
        padding: 0,
        '--i-bg': 'transparent',
        '--i-bg-h': 'var(--surface-subtle)',
        '--i-fg': on ? 'var(--wang-pink)' : 'var(--text-muted)',
        '--i-fg-h': on ? 'var(--action-primary-hover)' : 'var(--text-body)'
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: it.icon,
      size: 22
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-display)',
        fontSize: 'var(--type-micro)',
        fontWeight: on ? 'var(--weight-medium)' : 'var(--weight-regular)'
      }
    }, it.label));
  }));
}
Object.assign(__ds_scope, { TabBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TabBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/elev-mobil/screens.jsx
try { (() => {
// WANG Toppidrett — elev-app, skjermer. Mobil 390.
// Lastes som text/babel og registreres på window (ingen bundler i prosjektet).
const {
  Button,
  Card,
  StatusPill,
  EmptyState,
  Dialog,
  TabBar,
  Icon,
  Logo,
  ScanList,
  Notice,
  Stat,
  Badge
} = window.WANGToppidrettDesignsystem_358037;
const DAG = [{
  id: 1,
  tid: '07:00',
  tittel: 'Styrke — Hall B',
  trener: 'Ingrid Holm',
  status: 'planlagt',
  neste: true
}, {
  id: 2,
  tid: '10:15',
  tittel: 'Norsk — rom 204',
  trener: 'Skole',
  status: 'planlagt'
}, {
  id: 3,
  tid: '15:30',
  tittel: 'Langrenn, teknikk — Sykehusfjellet',
  trener: 'Ingrid Holm',
  status: 'planlagt'
}];
const UKE = [{
  dag: 'Man 12.10',
  okter: [{
    tid: '07:00',
    tittel: 'Styrke',
    status: 'gjennomfort'
  }, {
    tid: '15:30',
    tittel: 'Rulleski',
    status: 'gjennomfort'
  }]
}, {
  dag: 'Tir 13.10',
  okter: [{
    tid: '07:00',
    tittel: 'Styrke',
    status: 'planlagt'
  }, {
    tid: '15:30',
    tittel: 'Teknikk',
    status: 'planlagt'
  }]
}, {
  dag: 'Ons 14.10',
  okter: [{
    tid: '06:45',
    tittel: 'Rolig løp',
    status: 'planlagt'
  }]
}, {
  dag: 'Tor 15.10',
  okter: [{
    tid: '07:00',
    tittel: 'Intervall',
    status: 'planlagt'
  }]
}, {
  dag: 'Fre 16.10',
  okter: [{
    tid: '09:00',
    tittel: 'Test 3 km',
    status: 'planlagt'
  }]
}];
function ScreenHeader({
  title,
  meta,
  right
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      padding: '18px 20px 16px',
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, meta ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, meta) : null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '2px 0 0',
      fontFamily: 'var(--font-display)',
      fontWeight: 300,
      fontSize: 30,
      lineHeight: 1.08,
      letterSpacing: '-.015em',
      color: 'var(--wang-blue)'
    }
  }, title)), right);
}
function IDagScreen({
  onOpenOkt,
  onConfirm,
  confirmed
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-structure)',
      color: 'var(--text-on-dark)',
      padding: '16px 20px 20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    variant: "horizontal",
    height: 22,
    onDark: true,
    base: "../.."
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 20,
    color: "rgba(255,255,255,.8)"
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '22px 0 0',
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 13,
      color: 'var(--wang-mint)'
    }
  }, "Tirsdag 13.10.2026"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '2px 0 0',
      fontFamily: 'var(--font-display)',
      fontWeight: 300,
      fontSize: 32,
      lineHeight: 1.08,
      letterSpacing: '-.015em'
    }
  }, "Hei, Mathias."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '10px 0 0',
      fontFamily: 'var(--font-body)',
      fontSize: 16,
      lineHeight: 1.5,
      color: 'rgba(255,255,255,.88)'
    }
  }, "Neste \xF8kt er styrke 07:00 i Hall B."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, confirmed ? /*#__PURE__*/React.createElement(StatusPill, {
    state: "gjennomfort",
    label: "Oppm\xF8te bekreftet",
    onDark: true
  }) : /*#__PURE__*/React.createElement(Button, {
    block: true,
    onClick: onConfirm
  }, "Bekreft oppm\xF8te"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 28px',
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Notice, {
    tone: "info",
    title: "Torsdag er flyttet til Hall B."
  }, "Samme tid, 07:00."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "Dagen din"), DAG.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.id,
    onClick: () => onOpenOkt(o),
    style: {
      textAlign: 'left',
      border: '1px solid var(--border-card)',
      borderRadius: 'var(--radius-card)',
      background: 'var(--wang-white)',
      padding: 16,
      cursor: 'pointer',
      display: 'grid',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 22,
      color: 'var(--wang-blue)'
    }
  }, o.tid), o.neste ? /*#__PURE__*/React.createElement(StatusPill, {
    state: "pagar",
    label: "Neste"
  }) : /*#__PURE__*/React.createElement(Icon, {
    name: "caret-right",
    size: 16,
    color: "var(--text-muted)"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 16,
      color: 'var(--wang-blue)'
    }
  }, o.tittel), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, o.trener))), /*#__PURE__*/React.createElement(Card, {
    tone: "subtle",
    title: "Belastning",
    meta: "Siste 7 dager"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 6,
      height: 54,
      marginTop: 4
    }
  }, [30, 44, 22, 50, 38, 12, 26].map((h, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      flex: 1,
      height: h,
      background: i === 6 ? 'var(--wang-green)' : 'var(--wang-grey)'
    }
  }))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '12px 0 0',
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, "Moderat uke. Snakk med trener hvis noe kjennes tungt."))));
}
function UkeScreen({
  onOpenOkt
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ScreenHeader, {
    meta: "12.10 \u2013 18.10.2026",
    title: "Uke 42",
    right: /*#__PURE__*/React.createElement(Icon, {
      name: "calendar-blank",
      size: 22,
      color: "var(--wang-blue)"
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 20px 28px',
      display: 'grid',
      gap: 18
    }
  }, UKE.map(d => /*#__PURE__*/React.createElement("div", {
    key: d.dag
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, d.dag), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8
    }
  }, d.okter.map((o, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: () => onOpenOkt({
      ...o,
      trener: 'Ingrid Holm'
    }),
    style: {
      display: 'grid',
      gridTemplateColumns: '58px 1fr auto',
      alignItems: 'center',
      gap: 12,
      minHeight: 'var(--hit-min)',
      textAlign: 'left',
      cursor: 'pointer',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      background: 'var(--wang-white)',
      padding: '10px 14px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 15,
      color: 'var(--wang-blue)'
    }
  }, o.tid), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 15,
      color: 'var(--wang-blue)'
    }
  }, o.tittel), /*#__PURE__*/React.createElement(StatusPill, {
    state: o.status,
    dot: false
  }))))))));
}
function OktScreen({
  okt,
  onBack,
  onAbsence
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("header", {
    style: {
      padding: '16px 20px 0'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      border: 'none',
      background: 'transparent',
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      cursor: 'pointer',
      padding: 0,
      minHeight: 44,
      color: 'var(--wang-blue)',
      fontFamily: 'var(--font-display)',
      fontSize: 14,
      fontWeight: 500
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-left",
    size: 18
  }), " Tilbake")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 20px 28px',
      display: 'grid',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "Tirsdag 13.10.2026 \xB7 ", okt.tid), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '2px 0 0',
      fontFamily: 'var(--font-display)',
      fontWeight: 300,
      fontSize: 28,
      lineHeight: 1.1,
      color: 'var(--wang-blue)'
    }
  }, okt.tittel)), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/photo/basis-hekkehopp.jpg",
    alt: "Styrkerom",
    style: {
      width: '100%',
      height: 150,
      objectFit: 'cover',
      borderRadius: 'var(--radius-card)',
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement(Card, {
    title: "Program",
    meta: okt.trener
  }, /*#__PURE__*/React.createElement("ol", {
    style: {
      margin: 0,
      paddingLeft: 18,
      display: 'grid',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("li", null, "Oppvarming 10 min, sykkel"), /*#__PURE__*/React.createElement("li", null, "Kneb\xF8y 4\xD75 \u2014 80 % av 1RM"), /*#__PURE__*/React.createElement("li", null, "Utfall med vekt 3\xD78 per bein"), /*#__PURE__*/React.createElement("li", null, "Kjerne 3 runder"), /*#__PURE__*/React.createElement("li", null, "Mobilitet hofte, 8 min"))), /*#__PURE__*/React.createElement(Card, {
    tone: "subtle",
    title: "Sted",
    meta: "Hall B, styrkerommet"
  }, "Ta med egen flaske. Skoene skiftes i garderoben."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    block: true,
    onClick: onAbsence
  }, "Meld frav\xE6r")));
}
function MeldingerScreen({
  empty
}) {
  if (empty) {
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ScreenHeader, {
      title: "Meldinger",
      meta: "Skole og trener"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '0 20px'
      }
    }, /*#__PURE__*/React.createElement(EmptyState, {
      title: "Ingen meldinger.",
      body: "Trener og skole n\xE5r deg her. Du kan svare p\xE5 samme sted.",
      actionLabel: "Skriv til trener"
    })));
  }
  const trader = [{
    fra: 'Ingrid Holm',
    rolle: 'Trener · langrenn',
    tid: '08:12',
    txt: 'Bra jobbet i motbakkene i går. Husk rulleski til torsdag.',
    ny: true
  }, {
    fra: 'WANG Fredrikstad',
    rolle: 'Skole',
    tid: 'man 16:40',
    txt: 'Utviklingssamtale flyttet til torsdag 15.10 kl 13:00.'
  }, {
    fra: 'Ingrid Holm',
    rolle: 'Trener · langrenn',
    tid: 'fre 11:02',
    txt: 'Testen fredag er 3 km. Møt 08:45 for oppvarming.'
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ScreenHeader, {
    title: "Meldinger",
    meta: "Skole og trener"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 20px 28px',
      display: 'grid',
      gap: 10
    }
  }, trader.map((t, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      padding: 14,
      background: 'var(--wang-white)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 15,
      color: 'var(--wang-blue)'
    }
  }, t.fra), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, t.tid)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '2px 0 0',
      fontFamily: 'var(--font-display)',
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, t.rolle), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '8px 0 0',
      fontFamily: 'var(--font-body)',
      fontSize: 15,
      lineHeight: 1.5,
      color: 'var(--wang-blue)'
    }
  }, t.txt), t.ny ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "pink"
  }, "Ny")) : null))));
}
function MalScreen() {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ScreenHeader, {
    title: "M\xE5l",
    meta: "Sesong 2026/27"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 20px 28px',
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 28,
      padding: '4px 0 12px'
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    value: "94",
    unit: "%",
    label: "Oppm\xF8te uke 42",
    size: "sm"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "18",
    label: "\xD8kter i oktober",
    size: "sm"
  })), /*#__PURE__*/React.createElement(Card, {
    accent: true,
    title: "Hovedm\xE5l",
    meta: "Satt med Ingrid 02.09.2026"
  }, "G\xE5 NM-normen p\xE5 5 km klassisk innen februar."), /*#__PURE__*/React.createElement(Card, {
    title: "Delm\xE5l denne perioden",
    meta: "Uke 40\u201346"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 10
    }
  }, [['Tre styrkeøkter i uka', 'gjennomfort'], ['3 km-test under 10:20', 'pagar'], ['Søvn over 8 timer, 5 av 7 netter', 'planlagt']].map(([t, s]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15
    }
  }, t), /*#__PURE__*/React.createElement(StatusPill, {
    state: s,
    dot: false
  }))))), /*#__PURE__*/React.createElement(Card, {
    tone: "field",
    title: "Neste utviklingssamtale",
    meta: "Torsdag 15.10.2026, 13:00"
  }, "Ta med egne notater om hva som har fungert siden sist.")));
}
Object.assign(window, {
  IDagScreen,
  UkeScreen,
  OktScreen,
  MeldingerScreen,
  MalScreen,
  ScreenHeader
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/elev-mobil/screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/trener-desktop/screens.jsx
try { (() => {
// WANG Toppidrett — trener/admin, desktop 1280. Lastes som text/babel.
const {
  Button,
  Card,
  StatusPill,
  EmptyState,
  Dialog,
  ScanList,
  SideNav,
  Icon,
  Logo,
  Input,
  Notice,
  Stat,
  Badge,
  Select
} = window.WANGToppidrettDesignsystem_358037;
const NAV = [{
  id: 'uke',
  label: 'Uke',
  icon: 'calendar-blank'
}, {
  id: 'gruppe',
  label: 'Gruppe',
  icon: 'users-three',
  badge: 2
}, {
  id: 'elev',
  label: 'Elevkort',
  icon: 'identification-card'
}, {
  id: 'naervaer',
  label: 'Nærvær',
  icon: 'list-checks'
}, {
  id: 'meldinger',
  label: 'Meldinger',
  icon: 'chat-circle'
}];
const ELEVER = [{
  id: 1,
  navn: 'Mathias Berg',
  gruppe: 'Langrenn G2',
  status: 'gjennomfort',
  belastning: 'Moderat',
  okter: '4 av 4'
}, {
  id: 2,
  navn: 'Sara Lien',
  gruppe: 'Langrenn G2',
  status: 'pagar',
  belastning: 'Høy',
  okter: '4 av 4'
}, {
  id: 3,
  navn: 'Jonas Ødegård',
  gruppe: 'Langrenn G2',
  status: 'fravaer',
  belastning: '—',
  okter: '2 av 4'
}, {
  id: 4,
  navn: 'Amina Yusuf',
  gruppe: 'Langrenn G2',
  status: 'planlagt',
  belastning: 'Lav',
  okter: '3 av 4'
}, {
  id: 5,
  navn: 'Emil Haugen',
  gruppe: 'Langrenn G2',
  status: 'varsel',
  belastning: 'Høy',
  okter: '4 av 4'
}, {
  id: 6,
  navn: 'Thea Nordby',
  gruppe: 'Langrenn G2',
  status: 'gjennomfort',
  belastning: 'Moderat',
  okter: '4 av 4'
}];
const UKE = [{
  dag: 'Man 12.10',
  okter: [{
    tid: '07:00',
    t: 'Styrke',
    sted: 'Hall B',
    status: 'gjennomfort'
  }, {
    tid: '15:30',
    t: 'Rulleski',
    sted: 'Sykehusfjellet',
    status: 'gjennomfort'
  }]
}, {
  dag: 'Tir 13.10',
  okter: [{
    tid: '07:00',
    t: 'Styrke',
    sted: 'Hall B',
    status: 'pagar'
  }, {
    tid: '15:30',
    t: 'Teknikk',
    sted: 'Sykehusfjellet',
    status: 'planlagt'
  }]
}, {
  dag: 'Ons 14.10',
  okter: [{
    tid: '06:45',
    t: 'Rolig løp',
    sted: 'Glombo',
    status: 'planlagt'
  }]
}, {
  dag: 'Tor 15.10',
  okter: [{
    tid: '07:00',
    t: 'Intervall',
    sted: 'Stadion',
    status: 'planlagt'
  }, {
    tid: '13:00',
    t: 'Utviklingssamtaler',
    sted: 'Rom 204',
    status: 'planlagt'
  }]
}, {
  dag: 'Fre 16.10',
  okter: [{
    tid: '09:00',
    t: 'Test 3 km',
    sted: 'Stadion',
    status: 'planlagt'
  }]
}];
function TopBar({
  title,
  meta,
  action
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: 'var(--topbar-height)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 24,
      padding: '0 var(--gutter-desktop)',
      borderBottom: '1px solid var(--border-subtle)',
      background: 'var(--wang-white)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 300,
      fontSize: 26,
      letterSpacing: '-.015em',
      color: 'var(--wang-blue)'
    }
  }, title), meta ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, meta) : null), action);
}
function UkeScreenT({
  onTakeAttendance
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TopBar, {
    title: "Uke 42",
    meta: "Langrenn G2 \xB7 12.10 \u2013 18.10.2026",
    action: /*#__PURE__*/React.createElement(Button, {
      onClick: onTakeAttendance
    }, "Ta oppm\xF8te")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--gutter-desktop)',
      display: 'grid',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(5,1fr)',
      gap: 12,
      alignItems: 'start'
    }
  }, UKE.map(d => /*#__PURE__*/React.createElement("div", {
    key: d.dag
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, d.dag), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8
    }
  }, d.okter.map((o, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      border: '1px solid var(--border-card)',
      borderRadius: 'var(--radius-card)',
      padding: 12,
      background: 'var(--wang-white)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 17,
      color: 'var(--wang-blue)'
    }
  }, o.tid), /*#__PURE__*/React.createElement(StatusPill, {
    state: o.status,
    dot: false
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '8px 0 0',
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 14,
      color: 'var(--wang-blue)'
    }
  }, o.t), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '2px 0 0',
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, o.sted))), d.okter.length === 1 ? /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px dashed var(--border-card)',
      borderRadius: 'var(--radius-card)',
      minHeight: 72
    }
  }) : null)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.6fr 1fr',
      gap: 20,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(ScanList, {
    caption: "Oppm\xF8te i dag \u2014 styrke 07:00, Hall B",
    onRowClick: () => {},
    columns: [{
      key: 'navn',
      label: 'Elev',
      width: '1.6fr',
      display: true
    }, {
      key: 'okter',
      label: 'Økter denne uka',
      width: '1fr'
    }, {
      key: 'status',
      label: 'Status',
      width: '150px',
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        state: r.status
      })
    }, {
      key: 'belastning',
      label: 'Belastning',
      width: '120px',
      align: 'right',
      display: true
    }],
    rows: ELEVER
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Oppm\xF8te denne uka",
    meta: "Langrenn G2"
  }, /*#__PURE__*/React.createElement(Stat, {
    value: "92",
    unit: "%",
    label: "To registrerte frav\xE6r \u2014 begge meldt av foresatt"
  })), /*#__PURE__*/React.createElement(Card, {
    accent: true,
    title: "Krever handling",
    meta: "2 saker"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14
    }
  }, "Emil Haugen \u2014 h\xF8y belastning tre uker"), /*#__PURE__*/React.createElement(StatusPill, {
    state: "varsel",
    dot: false
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14
    }
  }, "Jonas \xD8deg\xE5rd \u2014 to frav\xE6r"), /*#__PURE__*/React.createElement(StatusPill, {
    state: "fravaer",
    dot: false
  }))))))));
}
function GruppeScreen({
  onOpenElev
}) {
  const [filter, setFilter] = React.useState('alle');
  const rows = filter === 'alle' ? ELEVER : ELEVER.filter(e => e.status === filter);
  const filters = [['alle', 'Alle'], ['gjennomfort', 'Gjennomført'], ['fravaer', 'Fravær'], ['varsel', 'Varsel']];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TopBar, {
    title: "Langrenn G2",
    meta: "18 elever \xB7 trener Ingrid Holm",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary"
    }, "Legg til elev")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--gutter-desktop)',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, filters.map(([id, label]) => /*#__PURE__*/React.createElement("button", {
    key: id,
    onClick: () => setFilter(id),
    style: {
      borderRadius: 'var(--radius-pill)',
      padding: '7px 16px',
      minHeight: 36,
      cursor: 'pointer',
      border: '1px solid ' + (filter === id ? 'var(--wang-blue)' : 'var(--wang-grey)'),
      background: filter === id ? 'var(--wang-blue)' : 'transparent',
      color: filter === id ? 'var(--wang-white)' : 'var(--wang-blue)',
      fontFamily: 'var(--font-display)',
      fontSize: 13,
      fontWeight: 500,
      transition: 'var(--transition-control)'
    }
  }, label))), rows.length ? /*#__PURE__*/React.createElement(ScanList, {
    caption: 'Gruppe — ' + rows.length + ' av ' + ELEVER.length + ' vist',
    onRowClick: onOpenElev,
    dense: true,
    columns: [{
      key: 'navn',
      label: 'Elev',
      width: '1.6fr',
      display: true
    }, {
      key: 'gruppe',
      label: 'Gruppe',
      width: '1fr'
    }, {
      key: 'okter',
      label: 'Økter',
      width: '110px'
    }, {
      key: 'status',
      label: 'Status',
      width: '150px',
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        state: r.status
      })
    }, {
      key: 'belastning',
      label: 'Belastning',
      width: '120px',
      align: 'right',
      display: true
    }],
    rows: rows
  }) : /*#__PURE__*/React.createElement(EmptyState, {
    title: "Ingen elever med denne statusen.",
    body: "Pr\xF8v et annet filter, eller se hele gruppa.",
    actionLabel: "Vis alle",
    onAction: () => setFilter('alle')
  })));
}
function ElevkortScreen({
  onAbsence
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TopBar, {
    title: "Mathias Berg",
    meta: "Vg2 \xB7 langrenn \xB7 17 \xE5r",
    action: /*#__PURE__*/React.createElement(Button, {
      onClick: onAbsence
    }, "Registrer frav\xE6r")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--gutter-desktop)',
      display: 'grid',
      gridTemplateColumns: '1.5fr 1fr',
      gap: 20,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Uke 42",
    meta: "4 av 4 \xF8kter gjennomf\xF8rt"
  }, /*#__PURE__*/React.createElement(ScanList, {
    columns: [{
      key: 'dag',
      label: 'Dag',
      width: '1fr',
      display: true
    }, {
      key: 'okt',
      label: 'Økt',
      width: '1.4fr'
    }, {
      key: 'status',
      label: 'Status',
      width: '150px',
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        state: r.status,
        dot: false
      })
    }],
    rows: [{
      dag: 'Man 12.10',
      okt: 'Styrke — Hall B',
      status: 'gjennomfort'
    }, {
      dag: 'Man 12.10',
      okt: 'Rulleski — Sykehusfjellet',
      status: 'gjennomfort'
    }, {
      dag: 'Tir 13.10',
      okt: 'Styrke — Hall B',
      status: 'pagar'
    }, {
      dag: 'Ons 14.10',
      okt: 'Rolig løp — Glombo',
      status: 'planlagt'
    }],
    dense: true
  })), /*#__PURE__*/React.createElement(Card, {
    title: "M\xE5l",
    meta: "Satt 02.09.2026"
  }, "G\xE5 NM-normen p\xE5 5 km klassisk innen februar. Delm\xE5l: tre styrke\xF8kter i uka, 3 km under 10:20."), /*#__PURE__*/React.createElement(Card, {
    title: "Notat til utviklingssamtale",
    meta: "Torsdag 15.10.2026, 13:00"
  }, /*#__PURE__*/React.createElement(Input, {
    multiline: true,
    placeholder: "Kort, faktabasert. Ingen helseopplysninger.",
    help: "Synlig for elev og foresatt."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm"
  }, "Lagre notat"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost"
  }, "Avbryt")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Card, {
    tone: "structure",
    title: "Kontakt",
    meta: "Foresatt"
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 15
    }
  }, "Kari Berg \xB7 400 00 000"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '4px 0 0',
      fontSize: 15,
      color: 'var(--wang-mint)'
    }
  }, "Har innsyn i plan og n\xE6rv\xE6r")), /*#__PURE__*/React.createElement(Card, {
    title: "Belastning",
    meta: "Siste 7 dager"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 6,
      height: 60
    }
  }, [30, 44, 22, 50, 38, 12, 26].map((h, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      flex: 1,
      height: h,
      background: i === 6 ? 'var(--wang-green)' : 'var(--wang-grey)'
    }
  }))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '12px 0 0',
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, "Moderat. Egenrapportert, ikke en helsejournal.")), /*#__PURE__*/React.createElement(Card, {
    tone: "subtle",
    title: "N\xE6rv\xE6r skole",
    meta: "Skole\xE5ret 2026/27"
  }, /*#__PURE__*/React.createElement(Stat, {
    value: "96",
    unit: "%",
    label: "2 dager egenmeldt",
    size: "sm"
  })))));
}
function NaervaerScreen() {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TopBar, {
    title: "N\xE6rv\xE6r",
    meta: "Admin \xB7 skole\xE5ret 2026/27",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary"
    }, "Last ned rapport")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--gutter-desktop)',
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Notice, {
    tone: "obs",
    title: "Tre grupper mangler oppm\xF8te for uke 42."
  }, "Ta oppm\xF8te f\xF8r rapporten lastes ned."), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 260
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Periode",
    value: "Uke 42",
    options: ['Uke 42', 'Uke 41', 'Uke 40', 'Hele høsten']
  })), /*#__PURE__*/React.createElement(ScanList, {
    caption: "Grupper \u2014 n\xE6rv\xE6r per uke 42",
    dense: true,
    columns: [{
      key: 'gruppe',
      label: 'Gruppe',
      width: '1.6fr',
      display: true
    }, {
      key: 'trener',
      label: 'Trener',
      width: '1.2fr'
    }, {
      key: 'elever',
      label: 'Elever',
      width: '90px',
      align: 'right'
    }, {
      key: 'naervaer',
      label: 'Nærvær',
      width: '110px',
      align: 'right',
      display: true
    }, {
      key: 'status',
      label: 'Status',
      width: '150px',
      render: r => /*#__PURE__*/React.createElement(StatusPill, {
        state: r.status,
        dot: false
      })
    }],
    rows: [{
      gruppe: 'Langrenn G2',
      trener: 'Ingrid Holm',
      elever: 18,
      naervaer: '92 %',
      status: 'gjennomfort'
    }, {
      gruppe: 'Fotball J1',
      trener: 'Ola Nybakk',
      elever: 22,
      naervaer: '88 %',
      status: 'gjennomfort'
    }, {
      gruppe: 'Ishockey G1',
      trener: 'Petter Aune',
      elever: 20,
      naervaer: '74 %',
      status: 'varsel'
    }, {
      gruppe: 'Tennis blandet',
      trener: 'Marte Vik',
      elever: 12,
      naervaer: '95 %',
      status: 'gjennomfort'
    }, {
      gruppe: 'Kampsport',
      trener: 'Aisha Rahim',
      elever: 14,
      naervaer: '91 %',
      status: 'gjennomfort'
    }]
  })));
}
Object.assign(window, {
  TrenerNav: NAV,
  TopBar,
  UkeScreenT,
  GruppeScreen,
  ElevkortScreen,
  NaervaerScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/trener-desktop/screens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.IDRETT = __ds_scope.IDRETT;

__ds_ns.ILLUSTRASJON = __ds_scope.ILLUSTRASJON;

__ds_ns.Pictogram = __ds_scope.Pictogram;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.StatusPill = __ds_scope.StatusPill;

__ds_ns.ScanList = __ds_scope.ScanList;

__ds_ns.Notice = __ds_scope.Notice;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.SideNav = __ds_scope.SideNav;

__ds_ns.TabBar = __ds_scope.TabBar;

})();
