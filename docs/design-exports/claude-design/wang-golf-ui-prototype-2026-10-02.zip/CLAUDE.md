# WANG Golf UI prototype — designinstrukser

## Språk (Anders 02.10.2026, bindende)
- Master for synlig språk og treningsbegreper: Precision-prosjektet `guidelines/treningsplanlegging-master.md` (kopi av AK Golf HQ `docs/treningsplanlegging.md`, låst 30.09.2026, PR #1061). Repoets docs/-bane er ikke tilgjengelig her; Precision-kopien brukes.
- Gjelder alle WANG Golf-skjermer: IUP, plan/økt, testbatteri, statuser, knapper, tom- og feilmeldinger, tall og enheter.
- WANG beholder eget visuelt system (WANG Toppidrett Designsystem) og presise skolebegreper der de beskriver en skolerolle (Sportssjef, kontaktlærer, klasse, trinn, elev i skolesammenheng). Golfspillerrollen og felles treningsord følger masteren.
- Eldre designfiler, prototypetekst og egne terminologilister er bare underlag ved konflikt.
- Kjerneord: Spiller · Coach · Målsetning (det spilleren sikter mot; «mål» bare om måltall) · Øvelse (ikke drill) · Registrer (ikke logg/før) · Økt · Nærspill (ikke kortspill) · Spesialperiode · Turneringsperiode · Gjennomført (økt og test) · Låst/Åpen.
- Statusord: Lagring Ikke lagret · Lagrer · Lagret · Kunne ikke lagres. Økt Planlagt · Pågår · Gjennomført · Avlyst · Hoppet over. Plan Utkast · Venter på spiller · Godtatt · Avvist.
- Tall: norsk bokmål, desimalkomma, mellomrom før % og enhet (73 %, 150 m), tusenskille mellomrom, kl. 09:00. Putting i fot, øvrige avstander meter, Club Speed/Ball Speed mph. Manglende verdi «—», reell 0 er 0. Brutto score.
- TrackMan-parametere med engelsk navn og stor forbokstav (Club Path, Face Angle, Attack Angle, Dynamic Loft, Ball Speed, Club Speed).
- Ord masteren ikke dekker, eller der WANG-skolerolle og master kolliderer: la stå og før i avvikslista under. Ikke finn på ny fasit.

## Kjente språkavvik som venter avklaring
- «Trener»: WANG-rolle i meny og rollevalg (Sportssjef/Trener). Masteren sier «Coach» om AK Golfs coach. Står som WANG-skolerolle til Anders avgjør. Ny testbatteri-tekst bruker «Coach» om den som registrerer på vegne av spilleren.
- «Elev»: brukt mye i eldre filer (429 forekomster). Skolesammenheng beholdes; golfspillerrollen skal hete Spiller. Gjennomgang fil for fil gjenstår.
- Putting vises i fot med eksplisitt omregning (1 m = 3,28084 fot, 1 fot = 30,48 cm). Kildeverdien (m eller cm) står i parentes og lagres uendret. 9 hull lengde er unntatt til målenheten er avklart.

## Øvrige faste regler
- Eneste WANG-prosjekt. Samordning bare med Precision (7d7c2994) og Team Norway App delivery (bc3e41fc).
- Bare syntetiske data. Ingen appkode, backend, tilgang eller produksjon.
- Kategori A–K etter brutto snittscore, [min, maks).
- 390 og 1280/1440, tilstandene data/tom/laster/feil, scrollWidth === clientWidth, treffmål minst 44 px.
