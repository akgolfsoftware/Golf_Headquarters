# WANG Golf UI prototype — dekningsmatrise R01–R17 (02.10.2026)

Eneste WANG-prosjekt. Fil for nye reiser: `WANG Golf Elevprofil.dc.html` (B18). Rekkefølge: Precision → WANG → Team Norway. Bare design og prototype, syntetiske data. Ingen kode, backend, tilgang eller produksjon er endret eller bevist.
Status: **Tegnet** (skjerm finnes) · **Klikkbar** (handling virker i prototypen) · **Prøvd** (målt/kjørt her) · **Delvis** · **Mangler**.
Prøvd betyr alltid: 390 og 1280, tilstandene data/tom/laster/feil, `scrollWidth − clientWidth = 0`, ingen «undefined/NaN».

| R | Krav-ID | WANG-skjerm (fil#rute) | Primærhandling | Tilstander | Kildeversjon | Prøve 02.10 | Restavvik |
|---|---|---|---|---|---|---|---|
| R01 | IUP-01–18, alle spørsmål | WANG-47 Skjema og kildeversjoner (`#kilde`) + `kildemateriale/WANG-register-X01-X18.md` | Bytt nivå Ung/Junior/Amatør/Profesjonell/Sesong | data/tom/laster/feil | iup-2027-kilde-2026-10-01; 2025 som historikk | Prøvd: 34/43/47/38 + 13 rader med celle | Felt-for-felt-register (lagringsfelt, test-ID) er Codex sitt; ikke ferdig |
| R02 | IUP-02/03, PH-05, TR-20/24 | WANG-34 Samtykke (`#samtykke`), WANG-07, WANG-44 | Elev trekker WANG-deling; be om utvidet deling | Aktiv, Begrenset, Venter på forelder, Ikke delt, Trukket, Ingen tilgang, Invitert | — | Prøvd: trekk stopper WANG, TN uendret; blokkert profil uten navn | WANG→TN testdeling uten TN-medlemskap vises bare som tekst; utløpt deling, annen skole, avsluttet trener ikke tegnet |
| R03 | IUP-01–03, TR-03/04/22 | WANG-44 Elevprofil (`#profil/sofie/iup`) | Åpne IUP-del → underfunksjon → tilbake | data/tom/laster/feil/ingen tilgang | — | Prøvd | Støtteapparat med rolle/gyldighet og helsefelt mangler |
| R04 | IUP-04/11, PH-14/15, TR-05 | WANG-45 (`#sjekk/sofie/p2`, `#sjekk/sofie/sesong`), WANG-47 | Se svar, logg samtale, Lag prosessmål | levert/utkast/ikke påbegynt/åpner; lagringsfeil | 2027 (1–5), 2025 (1–8) historikk, sesong 1–4 | Prøvd | Amatør/Profesjonell har ingen WANG-elever; skjema finnes i WANG-47. Sammenligning over tid innen samme skjema mangler |
| R05 | IUP-05/06, TR-06 | WANG-44 IUP del 3–4 | Foreslå endring | data/— | — | Delvis | Full målmatrise (SG/PEI/putting-intervaller, kvartaler) mangler |
| R06 | IUP-07–09, TR-07/08 | WANG-44 Plan (uke 39–43) | Foreslå endring per uke | data | — | Prøvd | Workbench år/periode/måned, uketyper, treukerssyklus mangler |
| R07 | IUP-10/16, TR-14 | WANG-44 Plan → økt-dialog | Åpne økt; se registrert tid | 60/45 = 45 min · 75 %; 60/0; 60/— | — | Prøvd | Dagbok, etterregistrering, øktbygger mangler |
| R08 | IUP-13–15 | WANG-44 IUP del 11–12 (tekst) | — | data | — | Delvis | Teknisk før/etter, driller, TrackMan 2027-felt mangler |
| R09 | IUP-12/13/15/17/18, TR-10–13 | WANG-48, 48A, 48B (`WANG Golf Testbatteri.dc.html`) | Registrer forsøk | Foreløpig/fullført, — uten forsøk | TN v3 · kontrakt 02.10.2026 | Prøvd: PEI 3,2 %, 8-ball 48/96 og grenser, 12,5 p, 3/6, Putt Gate, Putt Speed, teknikk C | Kildefiler ikke kontrollert; 9 hull enhet, Impact Location, fysiske normer venter |
| R10 | PH-18, TR-12/13 | WANG-48B | Lagre, rett, bilde | Lagrer/Lagret/Venter på nett/Kunne ikke lagres, konflikt, bildefeil, rettet | — | Prøvd: uten nett → lagret etter nett, lagringsfeil → prøv igjen, konflikt, revisjon 2 tåler omlasting | Bilde ikke automatisk prøvd |
| R11 | TR-10–13 | WANG-49 Felles testdag | Åpne, sjekk inn, registrer | Planlagt/Åpnet/Avsluttet/Avlyst, frakoblet | TN v3 | Klikkbar, ikke automatisk prøvd | Felles rangering krever beslutning |
| R12 | PH-26, TR-07/19 | WANG-46 Forslag (`#forslag`) | Godta/avvis (prototype), endre kilde, trekk, send nytt | Venter, Godtatt, Avvist, Konflikt, Trukket; lagringsfeil | — | Prøvd: konflikt, dobbeltklikk, trekk, lagring tåler reload og visningsbytte | Utkast/Sett/Utløpt og før/etter-visning mangler |
| R13 | TR-08/09 | — | — | — | — | Mangler | Samlinger og invitasjoner |
| R14 | IUP-08, TR-15/16/23 | WANG-44 Turneringer | — | data/— | AK Golf pipelines | Delvis | Katalog over pipeline-profiler, kildeklokke, identitetskonflikt mangler |
| R15 | DG-01–17, TR-17 | — | — | — | — | Mangler | Hele DataGolf-familien (Precision eier første versjon) |
| R16 | TR-01–24 | WANG-43 I dag, WANG-07, meny i 17 filer | — | data/tom/laster/feil | — | Delvis | TR-08/09/11/16/17/18/21 mangler i WANG |
| R17 | Alle | Denne matrisen | — | — | — | — | Ingen samlet godkjenning; Excel kan ikke avvikles |

## Prototypelagring
Forslag, samtaler, delinger, invitasjoner og påminnelser lagres lokalt (`wang-elevprofil-v1`) og tåler bytte av visning og omlasting. «Nullstill prototypedata» i prototypelinjen.

## Kildeavvik som står åpne
- Kilden har skrivefeilen «gjennomfär» (C41, O50) og én engelsk setning (AM8). Gjengitt som i kilden.
- 2025 hadde Junior 41 og Amatør 41; 2027 har 43 og 47. Historiske svar beholder 2025-versjon.
