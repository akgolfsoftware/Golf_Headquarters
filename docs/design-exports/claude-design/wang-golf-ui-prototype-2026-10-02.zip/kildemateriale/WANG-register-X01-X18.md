# WANG Golf UI prototype — register X01–X18 og overlevering (01.10.2026, oppdatert etter leveranse 2)

**Eneste WANG-destinasjon:** dette prosjektet (6cfa623c) med WANG Toppidrett Designsystem. Ingen egen WANG-app eller annet WANG-prosjekt. Ingen avhengighet til WANG Toppidrett Software (e77c6ef7); bestillingen der er trukket tilbake.
**Samordning:** bare Precision (7d7c2994, eier AK-spillerreisen), Team Norway App delivery (bc3e41fc, eier TN-trenerprofilen) og dette prosjektet (WANG-laget).
**Prinsipp:** samme AK Golf HQ-spillerdata deles med WANG/TN. Ingen egen kopi av IUP-svar, planer eller tester. WANG-laget legger bare til skole og kompetansemål (Udir) og viser kun det samtykket tillater.

Status per rad: **T** = tegnet · **K** = klikkbar · **M** = målt 390/1280 · **S** = visuelt sett. «—» = ikke gjort.

| ID | Skjerm / fil / inngang | Status | Mangler |
|---|---|---|---|
| X01 Intro | — (trenerhjem WANG-43 viser fullføringsstatus indirekte via fireukerssjekk) | — | Fullføringsstatus per spiller som egen visning |
| X02 Coaches | Elevprofil (WANG-44) viser trener; ingen støtteapparat-visning | — | Fagroller og kontakt, uten rettigheter |
| X03 Personinfo | WANG-44 → IUP del 1 (Elevprofil.dc.html) | T K M S | Helse/skade i beskyttet del og eget samtykke; klubb-/GolfBox-felt |
| X04 Evaluering | WANG-45 → «Sesongevaluering 2026 · uke 42» (Elevprofil.dc.html#sjekk/sofie); IUP del 2 → «Åpne sesongevaluering» | T K M S | 13 kildespørsmål (3 fritekst B2/B4/B6 + 10 på 1–4 B11–B20), faktisk/ønsket fordeling FYS·TEK·SLAG·SPILL·TURN, tre forbedringspunkter med «Lag prosessmål» → forslag til eleven. Svar er demodata |
| X05 Målsetting og oppfølging | WANG-44 → IUP del 3: snittscore, SG, WAGR, NGF juniorranking | T K M S | De øvrige radene fra ark 3 (PEI-intervaller, putt-intervaller, scrambling osv.) med definisjon, kilde, vindu, antall |
| X06 Prosessmål | WANG-44 → IUP del 4 (demodata) | T K M | Strukturert handling, tidsrom, målekriterium, hjelper, koblede økter |
| X07 Årsplan | WANG-44 → IUP del 5 og Plan-fanen (uke 40–43) | T K M S | Ukeprioritet per område, sted, mengde, maler |
| X08 Turneringsplan | WANG-44 → Turneringer og IUP del 6 | T K M S | WAGR Power, hullantall, reise, nivåbalanse, forberedelse/evaluering |
| X09 Ukeplan | WANG-44 → Plan: uke 40–43 (inneværende + tre fram) med periode, økter, turnering og sesongevaluering uke 42; Foreslå endring per uke | T K M S | Treukerssyklus, testplassering |
| X10 Treningsøkter | WANG-44 → Plan: klikk på økt åpner økt-dialog (planlagt min, faktisk «ikke ført ennå», forrige uke, Foreslå endring, Se tester) | T K M | Formål, oppgaver/reps, utstyr, press; gjennomføring |
| X11 Utviklingssjekk | WANG-45 «Uke 40–43 · 2027-skjema» + IUP del 9 → «Åpne utviklingssjekk» | T K M S | **2027 lagt inn med eksakt ordlyd og kildecelle: Ung 34, Junior 43, skala 1–5.** Utkast lagret/«— » for ubesvarte. 2025 (1–8) beholdes som historikk (uke 32–39) og omregnes ikke. Amatør 47 og Profesjonell 38 er ikke lagt inn (ingen WANG-elever på de nivåene). Kilden har skrivefeilen «gjennomfär» (C41/O50); beholdt som i kilden |
| X12 Tester | WANG-44 → Tester, WANG-08 testdag, WANG-22 protokoller, WANG-23 resultater | T K M S | Retest-planlegging, egenført/kontrollert historikk |
| X13 Teknikktest | Katalogført, sperret («—») | — | Én versjonert protokoll (sju TrackMan-felt, A/B-motstrid) |
| X14 Teknikkplan | WANG-44 → IUP del 11 (tekst) | T | Ballflukt før/ønsket, GOBBS, øvelser, film, ferdiguke |
| X15 Fystester | WANG-44 → Tester → Fysisk (5 tester) | T K M S | Valgbare protokoller; 3000 m/CMJ innføres ikke |
| X16 Treningsdagbok | — (planlagt tid vises i Plan-fanen) | — | Faktisk/planlagt tid og antall som separate tall |
| X17 Statistics | WANG-44 → Stats (SG, runder) | T K M S | Referanser per avstand/ballplassering |
| X18 Ref | — | — | Versjonerte referanseverdier med kildeforklaring |

## Bevarte vedtak
- Nivå i utviklingssjekk: WANG etter klassetrinn (Ung 8.–10., Junior VG1–VG3); Team Norway junior til og med året man fyller 19. Fireukersoppfølging bare WANG/TN.
- AK Golf kategori A–K etter snittscore (grenser fra 28.09). Ranking: WAGR og NGF juniorranking.
- Wedge Gate: 9 slag, Treff/Bom. Øvrige tester uten skala viser «—» til Team Norways scorekort-ark er lagt inn. Standard fysisk batteri er uendret.
- Roller: Sportssjef og Trener. Eleven bruker PlayerHQ.

## Deling (nå)
Seks statuser på liste og detalj (WANG-34, WANG-07, WANG-44): **Aktiv · Begrenset · Venter på forelder · Ikke delt · Trukket · Ingen tilgang** (+ Invitert, sju dagers invitasjon atskilt fra deling). Begrenset = gammelt smalt samtykke: plan, stats, tester, IUP, samtaler, turneringer; ikke helse/meldinger; «Be om utvidet deling» krever nytt samtykke. Team Norway-deling er egen kolonne i detaljteksten; «Eleven trekker delingen med WANG» stopper bare WANG (prøvd: Trukket = 1, TN uendret). Trukket/ikke delt profil viser generisk «Du har ikke tilgang» uten navn; eleven forsvinner fra elevliste, trenger-liste og forslag. 
**Mangler:** TN-trenerens egen visning og valg av arbeidskontekst (AK/WANG/TN), eksport/filer/søk ved trukket, varsler utover banner.

## Forslag og spillerbeslutning (nå)
WANG-46: Venter · Godtatt · Avvist · Konflikt. Prototypeknapper for spillerens valg (godtar/avviser/endrer kilden). Godta mot endret kilde gir Konflikt uten endring; «Send nytt forslag» erstatter. Dobbeltklikk endrer kilde én gang. Lagringsfeil (bryter «Lagring: Feiler» i prototypelinjen) beholder teksten; nytt forsøk virker.

## Klikkbar reise (nå)
Trenerliste (WANG-43/07) → samlet profil (WANG-44, tilbake-lenke til utgangspunkt, sesong 2026/27 i overskrift) → IUP del 2/9 → sesongevaluering / utviklingssjekk (WANG-45) → Lag prosessmål / Foreslå endring → WANG-46 → spillerens valg → konflikt. Plan → uke → økt → Se tester.

## Målt og sett (01.10)
Målt scrollWidth − clientWidth = 0 i 390 og 1280, tilstandene data/tom/laster/feil, for trenger, elever, profil (plan, IUP, begrenset elev, blokkert elev), sjekk (Sofie, Filip), forslag og samtykke: 80 av 80. Atferd prøvd: konflikt og nytt forslag, lagringsfeil og nytt forsøk, Escape lukker dialog, fokus i dialogfelt, trekking av delingen. Visuelt sett i 924 px bredde (samtykke, begrenset profil, utkast og sesongevaluering); 390 er bare målt, ikke sett.

## Restliste
1. X01–X03 (fullføringsstatus, støtteapparat, helse/skade i beskyttet del), X05-radene fra ark 3, X06-struktur, X13 teknikktest, X14 teknikkplan, X16 dagbok, X17–X18.
2. Amatør/Profesjonell-spørsmål (lagt til bare hvis slike elever kommer inn).
3. Arbeidskontekst AK/WANG/TN, eksport/søk/filer ved trukket deling.
4. Se 390 visuelt; økt-dialog og Lag prosessmål-dialog er sett som tekst, ikke som bilde.

## Rettet 01.10 (tid)
Faktisk treningstid = registrerte minutter i PlayerHQ. 60 planlagt / 45 registrert = 45 min · 75 % av plan; 60/0 = 0 min · 0 %; 60/ukjent = «—». Gjennomføringsstatus føres separat og regnes ikke om til tid; «halv tid» er fjernet. Uke 39 (kort, søylene, IUP «Treningsøkter», økt-dialog) bruker samme minutter. Økter uten registrering holdes utenfor andelen og telles opp. X09/X10/X16 er likevel ikke ferdige: faktisk tid per økt finnes bare for uke 39, ingen dagbok/etterregistrering.
