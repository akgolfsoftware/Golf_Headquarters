# WANG Golf DataGolf · DG-01–17 · overlevering 02.10.2026

Fil: `WANG Golf DataGolf.dc.html` (B20). Inngang: Konkurranse → fanen DataGolf (WANG-50). Lagt inn i menyen og skjermregisteret i alle 19 filer. Testbatteri, Workbench, IUP og registreringsregler er ikke endret.
Design: WANG Toppidrett Designsystem (Button, Notice, kort, chips). Ingen Precision- eller TN-farger. Syntetiske data merket på hver skjerm. Simulator, ikke integrasjon: ingen ekte kall, ingen API-nøkler, ingen driftslogger.

## Dekningsmatrise
| DG | WANG-ID | Rute | Primærhandling | Tilstander | Kilde (lokal modell) | Prøvd 02.10 | Avvik / rest |
|---|---|---|---|---|---|---|---|
| DG-01 | WANG-50 | #oversikt | Åpne inngang, lagre/åpne utvalg | alle 8 + avtale | DgRound/DgRoundSg-dekning, synk | sw 0 | Dekningstall syntetiske |
| DG-02 | WANG-50.02 | #katalog | Søk, filter, sorter, feltvalg → profil | alle | DgPlayer, DgTour | sw 0 | Kvinnedekning ikke kontrollert |
| DG-03 | WANG-50.03 | #profil/<id> | Lag tiltak, sammenlign, innspill, historikk, trend | alle, ukjent ID | DgPlayer, DgRoundSg, DgPlayerDecomposition, DgEventFinish | Utvalgsbrikke bevart fra toppliste | AK-kategori/PEI/Broadie bare henvist til Elevprofil |
| DG-04 | WANG-50.04 | #topp | Mål/sesong/tour/kilde, eksport, lagre utvalg | alle, lite grunnlag | DgRoundSg, DgPlayerDecomposition | SG innspill · 2026 · Amatør: rangert + under minimum | Ball striking mangler i modell |
| DG-05 | WANG-50.05 | #sammen | Legg til/fjern (maks 4), referanse, lag tiltak | alle | DgRoundSg | Coachmerknad, lite grunnlag | Bare for coach |
| DG-06 | WANG-50.06 | #innspill/<id> | Velg spiller/sesong | alle | DgApproachSkill, DgRoundSg | sw 0 | Lie-intervaller, gode/dårlige slag mangler i modell |
| DG-07 | WANG-50.07 | #hist/<id>/<event> | Turnering → runde | alle, SG mangler | DgRound, DgRoundSg, DgEventFinish | Manglende SG = — | |
| DG-08 | WANG-50.08 | #kalender | Filter → turnering | alle | DgEvent, DgCourse | sw 0 | Starttider: field-updates uten lagringsmodell |
| DG-09 | WANG-50.09 | #turnering/<id> | Resultater, banerunder, live | alle, ikke ferdigspilt | DgEvent, DgEventFinish, DgRound | sw 0 | Feltstyrke bare avledet av DG-rank, ikke WAGR Power |
| DG-10 | WANG-50.10 | #live | Oppdatert/forsinket/feil, prøv igjen | feil viser siste vellykkede | in-play/live-stats: ingen lagringsmodell | Feil viser data kl. 14:20 | Hele visningen er syntetisk design |
| DG-11 | WANG-50.11 | #modell | Filter | alle | DgPlayerDecomposition, DgPreTournamentPrediction | Modell merket | Skala for true skill/sannsynlighet uavklart |
| DG-12 | WANG-50.12 | #bane/<id> | Bane → turnering | alle | DgCourse, DgEvent | sw 0 | Banepassform, hullstatistikk mangler |
| DG-13 | WANG-50.13 | #trend/<id> | Periode, referanse, tabellbygger, eksport | alle | DgRoundSg | sw 0 | Nettsidefunksjoner uten API listet |
| DG-14 | WANG-50.14 | #utforsker | Søk, modell/klasse, kolonner, 10/25/alle, sider, eksport | alle; direkte lenke til odds sperret | Feltregister 135 felt / 16 modeller | 107 vist; 0 interne driftsfelt og 0 oddsfelt synlige | |
| DG-15 | WANG-50.15 | #kilde | Endepunkt, dekning, kobling; sportssjef ser avtale | alle, også uten avtale | 21 klientmetoder | Trygg feilmelding, ingen params/s3/last_error | Kobling klient → modell utledet av navn |
| DG-16 | WANG-50.16 | #tiltak/<id> | Funn → målsetning → periode → øvelse/test/økt → før/etter → send → spiller godtar/avviser | alle; B og C sperret | DgRoundSg mot referanse | 2×4 = 8 og 2×6 = 12 udaterte økter i før/etter, sendt-melding, kvittering og plan; avvist og konflikt gir 0 nye økter; dobbeltklikk på Send og Godta gir én anvendelse; summen 20 består etter omlasting; eldre godkjenning uten mengdedata vises som «mengden kan ikke bekreftes» | Beslutning simulert; «Konflikt»/«Trukket» er ikke statusord i masteren |
| DG-17 | WANG-50.17 | #spesialist | Les register | alle | DgOutrightOdds 7, DgMatchupOdds 11, DgDfsPoints 6 | Ingen verdier, ingen spillenker | Bare intern voksen analytikerrolle i AK Golf HQ |

## Regler i designet
- yd → meter × 0,9144, kildeverdi i yd ved siden av. Prosent, sannsynlighet, skill_* og true_skill: «skala uavklart». Manglende = —. Brutto score.
- Målt, modellestimat, AK-nivå, Broadie og PEI holdes atskilt. SG-søyler har lik skala om null.
- Offentlig pipelineprofil ≠ PlayerHQ-profil. Navnelikhet kobler aldri. Treningsforslag krever koblet konto og full deling (Spiller A). Spiller B (bare testdeling) og C (ikke koblet) sperres.
- Filtre, utvalg og forslag lagres i nettleseren og følger reisen.
- Tilstander: Data, Tom, Laster, Feil, Delvis dekning, Utdatert, Lite grunnlag, Ingen tilgang + kundeavtale Ikke dokumentert / Visning / Visning og eksport. Eksport sperret uten eksportavtale.

## Kontroll 02.10 (prototype)
- 20 ruter × 1440/1280/390 × 8 tilstander + uten avtale: scrollWidth − clientWidth = 0 i alle. Ingen «undefined/NaN».
- DS-knapper var under 44 px; satt til min. 44 px. Etter retting målt 0 treffmål under 44 px på tiltak, topp, sammen, utforsker, kilde og profil i 390 og 1440.
- Kjernereisen klikket gjennom i 390. Fokus på lenke gir synlig fokusring.
- Ikke gjort: skjermleser, full tastaturrunde på alle skjermer, nattmodus (finnes ikke i WANG-systemet). To åpne faner overskriver hverandres prototypelagring.

## Retting 02.10: mengde i DG-16
- Elementtypene regnes hver for seg. En gjentatt økt gir frekvens × uker udaterte økter, for eksempel «to ganger i uka» × 4 uker = 8. En engangstest gir 1 udatert test i perioden. En gjentatt test (Wedge Variation hver tredje uke) beholder intervallet: coach må velge første testuke (ingen forhåndsvalg), skjermen viser relative testuker, og antallet regnes ut fra valget (for eksempel 6 uker, første testuke 3, hver 3. uke → uke 3 og 6 = 2 tester). Uten valgt første testuke kan forslaget ikke sendes. En øvelse gir 1 øvelse i øvelsesbanken og ingen økt. Det settes ingen startdato.
- Før og etter, sendt-meldingen, kvitteringen og forslagslisten viser antall, uker og frekvens. Spilleren må godta før planen endres. Godkjenningen anvendes én gang, også ved gjentatte klikk og omlasting. Avvisning, konflikt og trukket forslag gir «0 nye økter».
- Eldre lagrede prototypegodkjenninger uten mengdedata vises som «mengden kan ikke bekreftes» og holdes utenfor summen. Den lagrede historikken er ikke slettet; den misvisende teksten «1 elementer» skjules bare i visningen.
- Kontroll: 390 klikkprøve med 4 uker (8), 6 uker (12), avvisning (0), konflikt etter planendring (0) og omlasting (summen 20 består). 1440, 1280 og 390: ingen sidelengs rulling etter at lange valgknapper fikk bryte linje (390 hadde 17 px overflyt før rettingen). Ingen treffmål under 44 px.
- Gjenstår: frekvens per økt er satt i forslagsteksten og kan ikke redigeres egen. Spillerens plassering av de udaterte øktene i Workbench er ikke tegnet her.

## Retting 02.10: gjentatt test i DG-16
- Wedge Variation står som gjentatt test, hver tredje uke, og er ikke lenger en engangstest. Intervallet, første testuke og de relative testukene lagres i hvert forslag. Driver Gate, Nærspill Gate og Putt Speed 3×3 er fortsatt engangstester i perioden. Økter (2 per uke) og engangsøvelser er uendret. Testprotokoller og poeng er ikke endret.
- Eldre lagrede forslag uten dette grunnlaget viser «testantall kan ikke bekreftes». Øktene deres vises som før. Forslag uten mengdedata viser fortsatt «mengden kan ikke bekreftes».
