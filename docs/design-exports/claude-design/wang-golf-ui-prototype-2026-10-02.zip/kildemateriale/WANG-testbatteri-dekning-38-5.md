# WANG testbatteri — dekning 38 + 5 (02.10.2026)

Fil: `WANG Golf Testbatteri.dc.html` (B19). Skjermer: WANG-48 Testbatteri `#oversikt` · WANG-48A Oppsett `#variant/<id>` · WANG-48B Scorekort `#kort/<id>/<A|B|C>` · WANG-48C Testhistorikk `#hist/<spiller>` · WANG-49 Felles testdag `#testdag`. Koblet i menyen Tester (faner Batteri, Felles testdag) i alle 18 filer.
Versjon: TN v3 · faglig kontrakt 02.10.2026, med Anders' rettelse av 8-ball-grensene (nedre grense inkludert). **Kildefilene (NGF v3 xlsx og testbeskrivelse 2026 pdf) er ikke kontrollert mot designet.** Reglene følger Anders' kontrakt.
Språk: AK Golf HQ-masteren (`CLAUDE.md`).

| Test-ID | Navn | Forsøk | Mønster | Skjerm | Venter fagavklaring | Prøvd 02.10 |
|---|---|---|---|---|---|---|
| 8-ball-variation | 8-ball variation | 24 | ball8 | 48A · 48B (ball8) · 48C | — | Grenser 0,099/0,1/1/2/3 m → 4/3/2/1/0 (C, registrert i prøve) |
| 8-ball-blocked | 8-ball blocked | 24 | ball8 | 48A · 48B (ball8) · 48C | — | 48 av 96 (A) |
| golfslag-bane-gutter | Golfslag bane · gutter | 30 | bane | 48A · 48B (bane) · 48C | — | Åpner, oppsett og felt vises |
| golfslag-bane-jenter | Golfslag bane · jenter | 30 | bane | 48A · 48B (bane) · 48C | — | Åpner, oppsett og felt vises |
| 18-hull-gutter | 18 hull · gutter | 18 | bane | 48A · 48B (bane) · 48C | — | Åpner, oppsett og felt vises |
| 18-hull-jenter | 18 hull · jenter | 18 | bane | 48A · 48B (bane) · 48C | — | Åpner, oppsett og felt vises |
| golfslag-bane-egen | Golfslag bane · egen | 30 | bane | 48A · 48B (bane) · 48C | — | Åpner, oppsett og felt vises |
| driver-270 | Driver 270 | 5 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| driver-220 | Driver 220 | 5 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| inspill-gutter-145 | Innspill Basis gutter 145 | 5 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| inspill-gutter-160 | Innspill Basis gutter 160 | 5 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| inspill-jenter-125 | Innspill Basis jenter 125 | 5 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| inspill-jenter-145 | Innspill Basis jenter 145 | 5 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| wedge-variation | Wedge Variation | 9 | carry | 48A · 48B (carry) · 48C | — | PEI 3,2 % (A) |
| putt-1-3m | Putt 1–3 m | 25 | putt13 | 48A · 48B (putt13) · 48C | — | Åpner, oppsett og felt vises |
| 9-hull-lengde | 9 hull lengde | 9 | nihull | 48A · 48B (nihull) · 48C | Målseriens enhet (meter/fot) | Åpner, oppsett og felt vises |
| naerspill-gate | Nærspill Gate | 9 | manuell | 48A · 48B (manuell) · 48C | — | 12,5 poeng (B) |
| visa-express | VISA Express | 9 | manuell | 48A · 48B (manuell) · 48C | — | Åpner, oppsett og felt vises |
| wedge-gate | Wedge Gate | 9 | treff | 48A · 48B (treff) · 48C | — | Åpner, oppsett og felt vises |
| driver-gate | Driver Gate | 6 | treff | 48A · 48B (treff) · 48C | — | 3 av 6 (B) |
| putt-gate | Putt Gate | 10 | puttgate | 48A · 48B (puttgate) · 48C | — | Ren gate + for lang = ikke godkjent (A) |
| putt-speed-1x5 | Putt Speed 1 × 5 | 5 | speed | 48A · 48B (speed) · 48C | — | Kort 10 + lang 10 cm = 10 cm (B) |
| putt-speed-3x3 | Putt Speed 3 × 3 | 9 | speed | 48A · 48B (speed) · 48C | — | Åpner, oppsett og felt vises |
| pei-test-bane | PEI-test bane | valgbart, 18 standard | bane | 48A · 48B (bane) · 48C | — | Åpner, oppsett og felt vises |
| pei-slagtest-egen | PEI slagtest egen | 18 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| pei-wedgetest-egen | PEI wedgetest egen | 18 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| pei-st-leon | PEI St. Leon | 18 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| pei-st-cloud | PEI St. Cloud | 18 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| pei-pga27 | PEI PGA 27 | 27 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| pei-inspill-120 | PEI innspill 120 | 5 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| pei-inspill-160 | PEI innspill 160 | 5 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| pei-inspill-variation | PEI innspill variation | 10 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| pei-wedge-blocked | PEI wedge blocked | 9 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| pei-wedge-variation | PEI wedge variation | 9 | carry | 48A · 48B (carry) · 48C | — | Åpner, oppsett og felt vises |
| standard-sving | Standard sving 7-jern | 10 | sving | 48A · 48B (sving) · 48C | — | Standard 140 m og tilpasset 132 m hver for seg (A) |
| teknikktest-a | Teknikktest A | 15 | teknikk | 48A · 48B (teknikk) · 48C | Impact Location: enhet og metode | Åpner, oppsett og felt vises |
| teknikktest-b | Teknikktest B | 15 | teknikk | 48A · 48B (teknikk) · 48C | Impact Location: enhet og metode | Åpner, oppsett og felt vises |
| teknikktest-c | Teknikktest C | 10 | teknikk | 48A · 48B (teknikk) · 48C | Impact Location: enhet og metode | 10 forsøk = 5 + 5; rettelse med begrunnelse → revisjon 2 (A) |
| benkpress | Benkpress | 1 | fys | 48A · 48B (fys) · 48C | Belastning, repetisjoner, validitetsprotokoll og norm. Fullføring sperret | Åpner, oppsett og felt vises |
| trapbar | Markløft trapbar | 1 | fys | 48A · 48B (fys) · 48C | Belastning, repetisjoner, validitetsprotokoll og norm. Fullføring sperret | Åpner, oppsett og felt vises |
| lengdehopp | Lengdehopp | 1 | fys | 48A · 48B (fys) · 48C | Belastning, repetisjoner, validitetsprotokoll og norm. Fullføring sperret | Åpner, oppsett og felt vises |
| rotasjonskast | Rotasjonskast | 1 | fys | 48A · 48B (fys) · 48C | Belastning, repetisjoner, validitetsprotokoll og norm. Fullføring sperret | Åpner, oppsett og felt vises |
| club-speed | Club Speed | 1 | fys | 48A · 48B (fys) · 48C | Belastning, repetisjoner, validitetsprotokoll og norm. Fullføring sperret | Åpner, oppsett og felt vises |

Mønstre: ball8 (rest m → hele poeng 0–4 + PEI, maks 96) · carry (carry + side → rest = hypot(mål − carry, side) → PEI) · bane (avstand og rest → PEI) · putt13 (antall putter, 1–3 m) · nihull (senket/rest i fot → 6/3/1/0,5/0, halve poeng) · manuell (poeng, desimaler) · treff (Treff/Ikke treff, Godkjent/Ikke godkjent) · puttgate (gate og lengdesone, begge kreves) · speed (absolutt cm, kort/lang separat) · sving (standard og tilpasset mål hver for seg) · teknikk (grunnmålinger + måleforsøk, rådata, median er ikke et slag) · fys (råverdi, ingen norm).

## Felles for alle varianter (WANG-48B)
Ett aktuelt forsøk, stor inndata, neste mål, fremdrift, rediger tidligere forsøk, rettelse med begrunnelse og revisjon, Egenført/Kontrollert, foreløpig/fullført. Lagring: Lagrer · Lagret (etter bekreftelse) · Venter på nett · Kunne ikke lagres + Prøv igjen. Konflikt fra annen enhet: begge versjoner vises, ingen overskrives. Bilde per forsøk: legg til (kamera/bibliotek), miniatyr, åpne, erstatt, fjern, laster opp, avbryt, feil, prøv igjen. Tall lagres selv om bildet feiler. Prototypelagring i nettleseren, ikke backendbevis.

## Tilgang (prøvd)
Skoletrener Fredrikstad ser A og C, ikke B. Skoletrener Oslo ser B. TN-trener ser A (WANG-testdeling uten TN-medlemskap) og B (TN-medlem), ikke C (testdeling utløpt). Arrangør ser bare stasjonsdata på testdagen, ikke historikk. Invitasjon til testdag utvider ikke profilinnsyn.

## Felles testdag (WANG-49)
WANG Fredrikstad + WANG Oslo + TN Junior, fire stasjoner, to puljer, kapasitet, trener per stasjon. Fire medlemskap gir tre spillere (B telles én gang). Planlagt → Åpnet → Avsluttet/Avlyst, innsjekking, fravær/avbrutt, liveoversikt fra bekreftede registreringer med antall forsøk, foreløpig/endelig, sist oppdatert, tilkobling og stasjonsfilter. Ingen sum på tvers av enheter. Felles rangering ikke vist: publikum krever beslutning.

## Målt 02.10
13 ruter × 1440 og 390 × data/tom/laster/feil: scrollWidth − clientWidth = 0 i alle 104. Ingen «undefined/NaN». Treffmål under 44 px funnet på chips og knapper, rettet med min-height 44 px etter målingen (ikke målt på nytt).

## Ikke gjort
- Kildefilene er ikke åpnet eller kontrollert.
- Testdag-reisen og bildeflyten er klikkbare, men ikke kjørt i automatisk prøve.
- Dag/natt: WANG-designsystemet har ingen nattmodus. Ikke laget.
- Spillerens egen PlayerHQ-flate er simulert med aktørvalget, ikke tegnet som egen spillerskjerm.

## Kontrollrunde 02.10 (Codex-uttrekk av NGF v3)
- Uttrekket er lagret i `kildemateriale/ngf-v3-uttrekk-codex-2026-10-02.json` (sha256 f9f8ddfe…). Brukt som underlag; kildefilen er ikke selvstendig kontrollert her.
- Katalogen er sammenlignet med uttrekket: 43 av 43 ID-er og alle antall stemmer. Fysiske ID-er er omdøpt til fys-benkpress, fys-trapbar, fys-lengdehopp, fys-rotasjonskast, fys-club-speed.
- Målserier brukes i kilderekkefølge per ID. Kildecelle og kildestatus vises i oppsettet.
- Tester uten mål i kilden (golfslag-bane-egen, pei-test-bane, pei-slagtest-egen, pei-wedgetest-egen, standard-sving) krever at målet registreres. Ingen standardverdi fylles inn. De tidligere eksempelmålene 140 og 132 m på standard-sving er fjernet.
- Gate-testene viser kildens oppsett (Lav/Middels/Høy, loft og avstand, gateavstand 2 m og 40 cm).
- «Fullført» er byttet til «Gjennomført» i testbatteriet og i «Ikke gjennomført» på testkortene i fem eldre filer.
- Putting vises i fot med kildeverdien i parentes.
- Ingen «Må avklares»-merking er fjernet. Uttrekket avklarer ikke de fire som står: 9 hull lengde (status awaiting-target-unit), Impact Location, fysiske protokoller og felles livepublikum. Teknikktest A–C har status partially-specified i uttrekket og beholder dagens felt.

### Prøvd
- PEI: wedge-variation (A) gir 3,2 %, og driver-270 (B, 8,64 / 270) gir 3,2 %. 8-ball-blocked gir 48 av 96 med PEI per type. Nærspill Gate gir 12,5 poeng, Driver Gate 3 av 6, og Putt Gate 0 av 10 med 1 lengdefeil (for lang). Putt Speed gir 0,33 fot (10 cm).
- Bilde: feil, Prøv igjen, laster opp, miniatyr, åpne dialog, Escape og fjern. Tallet er uendret gjennom hele flyten.
- Testdag: Åpne, sjekk inn, spilleren registrerer selv, og live viser forsøket først etter bekreftet lagring.
- Roller: arrangør ser alle tre på testdagen, men får ikke tilgang til historikken. Oslo ser B. TN ser A og B.
- Måling: 12 ruter i 1440 og 390, hver i tilstandene data, tom, laster og feil, gir sw = 0. Treffmål under 44 px er null etter rettelsen, på seks ruter i 1440 og 390 (to knapper i oppsett er rettet etter målingen).

## Retting 02.10: registreringsmerke etter faktisk aktør (WANG-48B, 48C)
- Hvert forsøk lagrer hvem som registrerte (spiller eller coach) med navn og klokkeslett. Merket for serien regnes ut av forsøkene: Egenført (bare spiller), Coachregistrert (bare coach) eller Blandet registrering, med antall per aktør.
- Kontroll er en egen handling, «Marker serien som kontrollert». Den lagrer hvem, når og hvilke forsøk som ble kontrollert. Coachregistrering gir ikke kontroll. Endres forsøk etterpå, vises «endret etter kontroll». Gjennomføring og rettelse setter ikke kontroll.
- Prøvd på Putt Gate, Spiller A, i 390: to forsøk av spilleren ga Egenført. Et tredje forsøk av coach (ren gate, for lang) ga Ikke godkjent og Blandet registrering (2 av spilleren, 1 av coach), og serien var fortsatt Ikke kontrollert. Kontroll ga «Kontrollert av …». Et nytt forsøk av spilleren ga «endret etter kontroll». Historikken viser det samme. 1440 viser samme merke etter omlasting. sw = 0 og ingen treffmål under 44 px i begge bredder.
- Poengreglene er ikke endret.
