# Workbench v0.3 — funksjon + design (obligatorisk)

Utgangspunkt: `AgencyOS Workbench v0.2.dc.html` (WB-01…WB-11).  
Mål: **Workbench v0.3** i leveranse/ som fasit — effektiv planleggingskaskade + økt med flere øvelser fra banken + **ett** kategorisystem overalt.

## 1. Ett kategorisystem (kanonisk)

Samme chips/filter overalt (Øvelsesbank, Øktbygger, Periode-skall, Uke-kildepanel):

| Dimensjon | Bruk |
|---|---|
| Pyramide | nivå i ferdighetspyramide |
| Område | teknikk / fysisk / mental / strategi / … |
| L-fase | læringsfase |
| Motorikk | motorisk krav |
| Situasjon | banekontekst / drillkontekst |
| Køllehastighet | bånd / mål |
| Miljø | range / bane / gym / hjem |
| Press | lav → høy |

**Regel:** En øvelse i banken og samme øvelse i en økt viser **identiske** kategori-chips. Filter i bank = filter i «legg til i økt». Ingen parallell taksonomi.

## 2. Øktbygger (WB-09) — flere øvelser

En treningsøkt er en **ordnet liste** av øvelser (0…N), ikke én øvelse.

### Må tegnes
1. **Økt-header:** tittel, varighet, pyramide-mål, status (utkast / klar / publisert)
2. **Øvelsesliste:** dra for rekkefølge, tid, dose, registreringsform per rad
3. **Legg til fra bank:** panel/ark med ØVB-søk + **samme** kategorifilter → flervalg → «Legg N øvelser i økta»
4. **Hurtig-ny:** opprett øvelse ufullstendig (merkes) med samme kategorifelt
5. **Tom økt:** én setning + CTA «Åpne øvelsesbank»
6. **Lagre:** oppskrift og gjennomføring fortsatt adskilt
7. **Tilstander:** normal · tom · legger til · mangler obligatorisk felt · lagrer · feil · for mange øvelser (ærlig grense)

### Interaksjon (effektiv)
- Desktop 1440: bank i venstre kildepanel (248 px) mens økta er midt; detalj 340 px
- 834/390: «Legg til» åpner fullt ark med filter + flervalg + sticky «Legg til (N)»
- Tastevei: `/` fokus søk i bank, `Enter` legger valgte, `⇧↑↓` flytter rad

## 3. Planleggingskaskade — effektiv prosess

Nivåene er allerede tegnet (WB-05…08). De skal føles som **én flyt**, ikke fire separate apper.

```
Årsplan (WB-05) → Periode (WB-06) → Måned (WB-07) → Uke (WB-08) → Økt (WB-09)
```

### Effektivitetsregler (må synes i UI)
1. **Kontekststripe** øverst på alle nivå: Spiller/gruppe · År · Periode · Måned · Uke — klikkbar breadcrumb, ingen full reload-følelse
2. **Valg arves ned:** valgt periode i årsplan åpner Periode forhåndsvalgt; valgt uke i måned åpner Uke; valgt økt-skall åpner Øktbygger
3. **Skall → oppskrift:** Periode lager stiplete økt-skall med pyramide/kategori; Uke fyller tid; Øktbygger fyller øvelser fra bank (samme kategori)
4. **Bulk:** «Fyll skall fra periodemal», «Kopier forrige uke», «Sett inn program» — synlige, rust secondary/outline, én primær rust per steg
5. **Én lagre-meta:** «Lagret» vs «Publisert» alltid synlig i kontekststripe (tre statuser som i WB-08)
6. **Tilbake er billig:** Esc / breadcrumb — ingen «er du sikker?» ved ren navigasjon uten dirty state
7. **Dirty state:** sticky «Ulagrede endringer» + Lagre — aldri stille navigasjon bort
8. **Ingen slide mellom nivå** (Emil): 140 ms fade. Nivåbytte skjer titalls ganger/dag.

### Per nivå — hva som må forbedres

**WB-05 Årsplan**
- Fire spor + periodisering beholdes
- Hurtig: klikk periode → «Åpne periode» (primær); dobbeltklikk = samme
- Vis volum/belastning ærlig uten grønn sone (ACWR uten fargesone)
- Mobil: agenda for «nå» + liste over perioder

**WB-06 Periode**
- −/+ økter per pyramide beholdes
- Ny: «Foreslå økt-skall» basert på kategori-mål for perioden
- Skall viser kategori-chips (samme system) — tomme for øvelser til de fylles
- CTA: «Åpne uke for skall» / «Bygg økt»

**WB-07 Måned**
- Maks 2 hendelser + «+N mer» beholdes
- Ukenummer = én handling til WB-08 (ingen ekstra dialog)
- Tetthet: «tett»-tilstand mer lesbar (sand/kant, ikke fargekaos)

**WB-08 Uke**
- Behold flytt, varighet, publisering, spillerperspektiv
- Kildepanel: øvelsesbank + programmer filtrert med **samme** kategorisystem
- Fra økt-blokk: «Bygg økt» åpner WB-09 med økta forhåndsvalgt
- Effektiv: `C` ny økt, `B` åpne bank i kildepanel

**WB-09 Øktbygger** — se §2 (hovedløftet)

## 4. Visuell polish (Workbench)
- Følg VISUELL-EKSELLENS.md
- Desktop: tre kolonner stabile (kilder | plan | detalj)
- Oswald kun på nivånavn («Uke 37», «Økt»)
- Plex Mono på klokkeslett, varighet, dose
- Skall = stiplet kant sand-500; fylt økt = solid + blekk
- Primær rust per steg: Årsplan «Åpne periode» · Periode «Fyll skall» · Uke «Publiser» · Økt «Lagre oppskrift»

## 5. Acceptance (Claude Design)
- [ ] Workbench v0.3.dc.html er ny fasit i workbenchFasit.aktiv
- [ ] WB-09: legg til **flere** øvelser fra bank i én handling
- [ ] Kategorichips identiske i ØVB + Periode-skall + Uke-kilde + Øktbygger
- [ ] Breadcrumb-kaskade År→…→Økt uten tung navigasjon
- [ ] Bulk: kopier uke / fyll skall / sett inn program tegnet
- [ ] 390 + 834 + 1440 for WB-08 og WB-09; 1440 min for WB-05…07
- [ ] Impeccable polish + Emil kun press/fade (ingen nivå-slide)
- [ ] coverage + changelog oppdateres; designVersion v0.4.19
