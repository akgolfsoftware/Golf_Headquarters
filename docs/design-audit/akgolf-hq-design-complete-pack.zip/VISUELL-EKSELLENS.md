# Visuell eksellens — AK Golf HQ (Atletisk intelligens)

Mål: appen skal føles som et elite-sportsprodukt — rolig, skarp, atletisk — ikke som et generisk SaaS-dashboard.

## Fasit (aldri bryt)
- Visuell autoritet: `ak-hq-visual-authority-atletisk-intelligens-001`
- Palett: sand `#E6E3DD` / `#FAF8F3` / `#FFFFFF`, grafitt `#141413` / `#46443F` / `#6B6862`, rust `#9B2415` / `#D81E20`
- **Ingen grønn.** «Fullført» = blekk + ord
- Oswald kun på korte overskrifter/etiketter — aldri norsk brødtekst
- Archivo til UI-tekst, IBM Plex Mono til meta/tall/enheter
- Radius: 5 / 9 / 14 / pille — ikke «rounded-2xl everywhere»
- Skygge: kun `loftet` og `overlegg` — ingen myke fargede skygger
- Bevegelse ≤ 300 ms, ingen bounce, `prefers-reduced-motion` = 0 ms
- Trykkflate ≥ 48 px (52 px i Live)

## Hva som gjør det ekstremt bra (krav til Claude Design)

### 1. Hierarki som et magasin, ikke et skjema
- Én Oswald-linje per skjerm (tittel). Resten Archivo.
- Tall og enheter i Plex Mono med tydelig enhet (m, km/t, °, slag) — aldri «råtall uten kontekst».
- Sekundærtekst `#46443F`, dempet `#6B6862` — aldri grå `#999` utenfor systemet.
- Luft: bruk skala 4–48 px. Mellom seksjoner 32–48, inne i kort 12–18. Unngå «alt klemt» og «alt tomt».

### 2. Flater med dybde uten støy
- Bakgrunn sand-300, kort sand-100 / hvit hevet, kant sand-500 — tre lag, ikke mer.
- Én hevet flate per fokusområde (CTA, aktiv kort, Live-panel).
- Unngå dobbelkant + skygge + farget border samtidig.

### 3. Handling = rust, resten = blekk
- Primærknapp: rust-fylt, hvit tekst, pille eller radius-lg, min 48 px høy.
- Sekundær: blekk-outline på sand.
- Destruktiv: samme rust-familie, eksplisitt verb («Slett økt»), ikke ikon alene.
- Aldri blå primærknapp i AK-flater (blå er kun informasjon).

### 4. Live / bane = mørk fokus (bevisst)
- Live, GPS, kveldsøkt: `morkFokus` — ikke lys tema med mørke kort.
- Kontrast på sol: tekst `#FAF8F3`, handling `#EE4B44`.
- Store trykkmål (52 px), færre elementer, mer «ett trykk = ett slag».

### 5. Motion (Emil) — atletisk, ikke leketøy
- Press: `scale(0.97)` 140–160 ms ease-out på knapper.
- Dialog/scrim: 180 ms, scale 0.97→1 + fade.
- Liste ↔ detalj: 140 ms fade — **ingen** slide på nivåbytte (brukes titalls ganger/dag).
- GPS/live state-change: kort 160 ms fade mellom tillatelse → henter → aktiv.
- Ingen parallax, ingen confetti, ingen spring.

### 6. Kart, data, TrackMan
- Kart: rolig, ingen neon-pins. Posisjon = blekk/rust-punkt med diskret halo.
- Tabeller: Plex Mono for tall, Archivo for labels, sticky header, zebra kun via sand-150 (ikke grå).
- TrackMan-kort: kilde + dato + enhet alltid synlig. Tomtilstand ærlig, ikke illustrasjons-spam.

### 7. Tomtilstander og feil (premium-følelse)
- Tom: én setning + én primærhandling. Ingen «🎨 empty state illustration»-kitsch.
- Feil: rust-flate `#FBEBEA`, klar årsak, «Prøv igjen» / alternativ vei.
- Loading: skjelett i sand-toner, ikke spinner midt i skjermen som default.

### 8. Polish-pass (Impeccable) — obligatorisk før ZIP
Kjør audit/critique/polish og fiks:
- Ujevn padding inne i kort
- Oswald på for lange norske strenger
- Ikoner som ikke deler stroke-vekt
- CTA som konkurrerer (to rust-knapper side om side)
- Meta uten Plex Mono
- Skjermer som ser «generisk dashboard» ut → stram til atletisk ro

### 9. Anti-mønstre (forbudt)
- Glassmorphism, neon gradients, purple SaaS glow
- Inter / Poppins / Roboto som erstatning
- Grønn suksess, blå «primary» i AK
- Card-shadow stacks, 24 px radius overalt
- Stock sport-foto som hero uten funksjon
- «AI-generated vibe»-illustrasjoner

### 10. Referansefølelse (retning, ikke kopi)
Tenk: elite training OS — rolig som et papirkort på klubbhuset, skarpt som en scorebok, raskt som et Live-slag. Mer Rolex/TrackMan-produkt enn Notion/Linear-klon.
