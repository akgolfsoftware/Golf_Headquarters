# Komplett bestilling til Claude Design — design + visuelt + Workbench v0.3

Kopier alt under «PROMPT» til Claude Design. Bruk `akgolf-hq-design-complete-pack.zip` (fonter, wireframes, VISUELL-EKSELLENS.md, WORKBENCH-KRAV.md).

---

## PROMPT

```
Du er Claude Design for AK Golf HQ.

VISUELL FASIT: Atletisk intelligens (ak-hq-visual-authority-atletisk-intelligens-001). Claw kun for /team-norway/*.
Skills: Impeccable obligatorisk. Emil for press/dialog/GPS/fade. Taste kun mot AI-slop.
UTGANGSPUNKT: v0.4.18 + Code Xpert design-complete-pack.
selectedForBuilding: false.

MÅL: AK-Golf-HQ-Design-v0.4.19.zip som er komplett, visuelt ekstremt sterk, OG har Workbench v0.3 med effektiv planlegging + flersøvelse-økt.

### A. FONTER
Binærer fra packen. Fjern Google @import. Oppdater README. Fjern fra manglendeFiler.

### B. J11 komplett tegnet
GP-LIVE, GP-ROUND, GP-OFFLINE, GP-NOTE (j11-gameplan-gps.html).

### C. J12 komplett tegnet (designkontrakt)
BAG-SAVE + TM-PHOTO (j12-trackman-bag.html).

### D. WIREFRAME → PROTOTYPE
Alle wireframe-kort → klikkbare .dc.html + coverage.

### E. VISUELL EKSELLENS
Følg VISUELL-EKSELLENS.md. Magasin-hierarki, sand-flater, rust primary, morkFokus i Live, Emil ≤300ms, forbud glass/neon/Inter/Poppins/grønn.

### F. WORKBENCH v0.3 (HOVEDLØFT — Anders 14.09)
Les WORKBENCH-KRAV.md og wireframes/workbench-v03.html. Erstatt fasit:
workbenchFasit.aktiv = prototype/AgencyOS Workbench v0.3.dc.html
(v0.2 blir historikk/utgatt).

#### F1. Ett kategorisystem
Pyramide · Område · L-fase · Motorikk · Situasjon · Køllehastighet · Miljø · Press
Samme chips/filter i: Øvelsesbank (ØVB) · Periode-skall · Uke-kildepanel · Øktbygger.
Ingen parallell taksonomi.

#### F2. Økt = flere øvelser fra bank (WB-09)
- Ordnet liste 0…N (ikke én øvelse)
- «Åpne øvelsesbank»: samme kategorifilter, flervalg, én handling «Legg N øvelser i økta»
- Dra-rekkefølge, tid, dose, registreringsform per rad
- Hurtig-ny øvelse (ufullstendig merkes) med samme kategorifelt
- Tom økt: én setning + CTA til bank
- Oppskrift ≠ gjennomføring (lagres hver for seg)
- Tilstander: normal · tom · legger til · mangler felt · lagrer · feil
- 1440: bank i kildepanel; 834/390: ark med sticky «Legg til (N)»

#### F3. Effektiv års→periode→måned→uke→økt
Breadcrumb/kontekststripe på alle WB-05…09: Spiller · År · Periode · Måned · Uke · Økt (klikkbare).
Valg arves nedover. Bulk: «Fyll skall fra mal», «Kopier forrige uke», «Sett inn program».
Dirty state sticky; Esc uten confirm hvis rent. Fade 140 ms mellom nivå — INGEN slide.
Primær rust per steg: Årsplan «Åpne periode» · Periode «Fyll skall»/«Bygg økt» · Måned «Åpne uke» · Uke «Publiser»/«Bygg økt» · Økt «Lagre oppskrift».

#### F4. Forbedre eksisterende WB-skjermer
WB-05…08: funksjon + visuell polish (ikke redesign fra null). Behold styrker (flytt, publisering, spillerperspektiv, stiplete skall). Løft lesbarhet, breadcrumb, kategori-konsistens, bulk.
WB-01…04, WB-10…11: polish + sørg for at de henger på samme kontekststripe der relevant.
Tegn 390+834+1440 for WB-08 og WB-09; minst 1440 for WB-05…07 (834 beskrevet eller tegnet).

#### F5. Acceptance Workbench
- [ ] v0.3 er aktiv fasit
- [ ] Flersøvelse fra bank i én handling
- [ ] Identiske kategorier overalt
- [ ] Breadcrumb-kaskade + bulk
- [ ] Impeccable + Emil (ingen nivå-slide)
- [ ] coverage/changelog/screens/*.json oppdatert

### G. POLISH-SKILLS
/impeccable audit → critique → polish på Workbench + nye J11/J12.
Emil kun state-change. Taste: fjern slop.

### H. PAKKE
designVersion v0.4.19 overalt. Regenerer coverage + checksums.
J11/J12 komplett_tegnet. selectedForBuilding: false.
changelog: fonter + J11 + J12 + visuell eksellens + Workbench v0.3 (flersøvelse, kategorier, kaskade).

OUTPUT: AK-Golf-HQ-Design-v0.4.19.zip
Suksess: coach kan planlegge år→uke effektivt, bygge økt med flere øvelser fra bank med samme kategorisystem, og hele flaten følger Atletisk intelligens.
```
