# Design-complete pack — AK Golf HQ (2026-09-14)

v0.4.18 → **v0.4.19** via Claude Design: fonter, J11/J12, visuell eksellens, **Workbench v0.3**.

## Innhold
1. `leveranse/design-system/fonts/` + `fonts.css` (offline)
2. `wireframes/` — J11, J12, **workbench-v03.html**
3. `VISUELL-EKSELLENS.md`
4. `WORKBENCH-KRAV.md` — flersøvelse, kategorier, års→uke-kaskade
5. `CLAUDE-DESIGN-PROMPT-KOMPLETT.md` — lim inn i Claude Design

## Workbench (Anders 14.09)
- Økt = flere øvelser fra øvelsesbank (flervalg)
- Ett kategorisystem overalt (pyramide → press)
- Effektiv prosess: Årsplan → Periode → Måned → Uke → Økt

## Bruk
Lim PROMPT inn i Claude Design, last opp denne zip-en, få `AK-Golf-HQ-Design-v0.4.19.zip`.
