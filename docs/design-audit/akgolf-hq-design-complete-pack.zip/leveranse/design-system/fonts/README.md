# Fontbinærer — vedlagt (v0.4.19)

Alle filer er OFL-lisensiert. Lisensfiler ligger i denne mappen.

| Fil | Familie | Vekt |
|---|---|---|
| `Archivo-Variable.woff2` | Archivo | 400–600 |
| `Oswald-Variable.woff2` | Oswald | 500–700 |
| `IBMPlexMono-Regular.woff2` | IBM Plex Mono | 400 |
| `IBMPlexMono-Medium.woff2` | IBM Plex Mono | 500 |
| `SchibstedGrotesk-Regular.woff2` | Schibsted Grotesk (Claw/TN) | 400 |
| `SchibstedGrotesk-Medium.woff2` | Schibsted Grotesk (Claw/TN) | 500 |

`fonts.css` er oppdatert: **ingen Google Fonts-@import**. Frakoblet bruk skal fungere.

Kilde: fontsource (npm) · pakket av Code Xpert 2026-09-14.
